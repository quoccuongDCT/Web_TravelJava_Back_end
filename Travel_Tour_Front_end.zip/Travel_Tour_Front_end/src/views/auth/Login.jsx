import React from "react";
import { Button, Form, Input } from "antd";

const Login = () => {
  return (
    <div>
      <Form
        name="normal_login"
        className="form_container"
        initialValues={{ remember: true }}
      >
        <h1>Đăng nhập tài khoản</h1>
        <Form.Item
          name="usernameOrEmail"
          rules={[
            {
              required: true,
              message: "Vui lòng nhập tên tài khoản hoặc email!",
            },
          ]}
        >
          <Input placeholder="Tên tài khoản hoặc email" size="large" />
        </Form.Item>
        <Form.Item
          name="password"
          rules={[{ required: true, message: "Vui lòng nhập mật khẩu!" }]}
        >
          <Input.Password placeholder="Mật khẩu" size="large" />
        </Form.Item>

        <Form.Item>
          <Button htmlType="submit" className="btn_signin">
            Đăng nhập
          </Button>
        </Form.Item>
      </Form>
    </div>
  );
};

export default Login;
