import React, { useEffect, useState, useCallback, useRef } from "react";
import { Modal, Form, Table, message, Button } from "antd";
import dayjs from "dayjs";
import { PrinterOutlined, PoweroffOutlined } from "@ant-design/icons";
import "./ChiTietHoaDon.css";
// import { useReactToPrint } from "react-to-print";

const { Column, ColumnGroup } = Table;

const FormChiTietThanhToan = ({ visible, onCancel, onBack, paymentId }) => {
  const [paymentDetails, setPaymentDetails] = useState([]);
  const contentRef = useRef(); // Tham chiếu cho nội dung in

  // Fetch thông tin hóa đơn
  const fetchPaymentDetails = useCallback(async () => {
    try {
      const response = await fetch(
        `http://localhost:8080/api/hoadon/${paymentId}`
      );
      if (!response.ok) {
        throw new Error("Không thể tải thông tin thanh toán");
      }
      const data = await response.json();
      console.log("hoa don: ", data);
      const dataWithId = data.map((item, index) => ({
        ...item,
        hoaDonId: index + 1,
      }));
      setPaymentDetails(dataWithId);
    } catch (error) {
      message.error("Tải thông tin thanh toán thất bại.");
      console.error("Lỗi khi lấy chi tiết thanh toán:", error);
    }
  }, [paymentId]);

  useEffect(() => {
    if (visible && paymentId) {
      fetchPaymentDetails();
    }
  }, [visible, paymentId, fetchPaymentDetails]);

  // Tính tổng tiền
  const calculateAge = (namSinh) => {
    if (!namSinh) {
      console.error("Năm sinh không hợp lệ:", namSinh); // Log lỗi nếu năm sinh không hợp lệ
      return null;
    }

    const birthDate = dayjs(namSinh); // Chuyển đổi chuỗi ngày thành đối tượng dayjs
    if (!birthDate.isValid()) {
      console.error("Ngày sinh không hợp lệ:", namSinh); // Log lỗi nếu ngày không hợp lệ
      return null;
    }

    const currentDate = dayjs();
    return currentDate.diff(birthDate, "year"); // Tính tuổi dựa trên khoảng cách năm
  };

  const formatCurrency = (value) => {
    return new Intl.NumberFormat("vi-VN", {
      style: "currency",
      currency: "VND",
    }).format(value);
  };

  if (!paymentDetails.length) {
    return null;
  }
  const convertNumberToWords = (number) => {
    const units = [
      "",
      "Một",
      "Hai",
      "Ba",
      "Bốn",
      "Năm",
      "Sáu",
      "Bảy",
      "Tám",
      "Chín",
    ];
    const tens = [
      "",
      "Mười",
      "Hai Mươi",
      "Ba Mươi",
      "Bốn Mươi",
      "Năm Mươi",
      "Sáu Mươi",
      "Bảy Mươi",
      "Tám Mươi",
      "Chín Mươi",
    ];
    const powers = ["", "nghìn", "triệu", "tỷ", "nghìn tỷ"];

    if (number === 0) return "Không đồng";

    let words = [];
    let unitIndex = 0;

    while (number > 0) {
      let chunk = number % 1000;
      if (chunk > 0) {
        let chunkWords = [];
        let hundred = Math.floor(chunk / 100);
        let ten = Math.floor((chunk % 100) / 10);
        let unit = chunk % 10;

        if (hundred > 0) {
          chunkWords.push(units[hundred] + " Trăm");
        }
        if (ten > 1) {
          chunkWords.push(tens[ten]);
          if (unit > 0) {
            chunkWords.push(units[unit]);
          }
        } else if (ten === 1) {
          chunkWords.push("Mười");
          if (unit > 0) {
            chunkWords.push(units[unit]);
          }
        } else if (unit > 0) {
          chunkWords.push(units[unit]);
        }

        chunkWords.push(powers[unitIndex]);
        words.unshift(chunkWords.join(" ").trim());
      }

      number = Math.floor(number / 1000);
      unitIndex++;
    }

    return words.join(" ").trim() + " đồng";
  };

  const payment = paymentDetails[0];

  const reactToPrintFn = () => {
    if (!contentRef.current) {
      message.error("Không có nội dung để in");
      return;
    }

    const printWindow = window.open("", "", "height=600,width=800");
    const content = contentRef.current.innerHTML;

    printWindow.document.write("<html><head><title>---</title>");
    printWindow.document.write("<div><h3>Travel Go</h3></div>");
    printWindow.document.write(
      "<div class='address'><i>Khu II, Đ. 3 Tháng 2, Xuân Khánh, Ninh Kiều, Cần Thơ</i> <br /> <i>ĐT: 0396782577</i></div>"
    );
    printWindow.document.write("<div><hr /></div>");
    printWindow.document.write(`
    <div class='header'> <h3>Hóa Đơn Hàng</h3></div>
  `);
    printWindow.document.write(`  
    <style>  
      @media print {  
        body {  
          font-family: Arial, sans-serif;  
          margin: 0;  
          padding: 20px;  
        }  
      .header h3 {
          margin-top: 20px;  
          text-align: center;  
          font-size: 30px;    
      }
      .address i {
      font-size: 10px;    
      }
        .ant-modal, .ant-btn {  
          display: none;  
        }  

        h1, h2, h3, h4, h5, h6 {  
          margin: 0;  
          padding: 0;  
        }  

        h1 {  
          font-size: 24px;  
          text-align: center;  
        }  

        h6 {  
          font-size: 16px;  
          margin: 10px 0;  
          
        }  

        Table {  
          width: 100%;  
          border-collapse: collapse;  
          margin-top: 20px;  
        }  

        Table th, Table td {  
          border: 1px solid #ddd;  
          padding: 8px;  
          text-align: left;  
        }  

        Table th {  
          background-color: #f5f5f5;  
          font-weight: bold;  
        }  

        Table td {  
          word-wrap: break-word;  
        }  

        .footer {  
          margin-top: 20px;  
          text-align: center;  
          font-size: 18px;
          font-weight: bold; 
        }  

        .total {  
          font-weight: bold;  
          font-size: 18px;  
        }  

        .row {  
          margin-bottom: 10px;  
        }  

        .col-lg-3 {  
          width: 22%;  
          display: inline-block;  
          padding: 5px;  
        }  
          .col-lg-12{
          margin-top:10px
          }

        label{
          font-size: 15px;
          font-weight: normal;
        }

       .tong {
          text-align: right;
        }
      
        .Ten-Tour{
           font-size: 18px;
           color: blue;  
        }
      }  
    </style>  
  `);
    printWindow.document.write("</head><body>");
    printWindow.document.write(content);
    printWindow.document.write(
      "<div class='footer'>Travel Go xin cảm ơn quý khách đã sử dụng dịch vụ!</div>"
    );
    printWindow.document.write("</body></html>");

    printWindow.document.close();
    printWindow.print();
  };

  return (
    <div>
      <Modal
        title="Chi Tiết Thông Tin Hóa Đơn"
        visible={visible}
        onCancel={onBack}
        forceRender={true}
        footer={[
          // <Button key="close" onClick={onBack}>
          //   <PoweroffOutlined /> Đóng
          // </Button>,
          <Button key="print" onClick={reactToPrintFn}>
            <PrinterOutlined /> In Hóa Đơn
          </Button>,
        ]}
        width={1000}
      >
        <hr />
        {/* Nội dung cần in */}
        <div ref={contentRef}>
          {/* <h6>Khách Hàng:</h6> */}
          <Form layout="vertical">
            <div className="row">
              <div className="col-lg-6">
                <Form.Item>
                  <h6>
                    <strong>Khách Hàng: </strong>
                    {paymentDetails[0]?.nguoiDungHoTen}
                  </h6>
                  <h6>
                    <strong>SĐT: </strong>
                    <label>{paymentDetails[0]?.nguoiDungSoDienThoai}</label>
                  </h6>
                </Form.Item>
              </div>
              <div className="col-lg-6">
                <Form.Item>
                  <h6>
                    <strong>Email: </strong>
                    <label>{paymentDetails[0]?.nguoiDungEmail}</label>
                  </h6>
                  <h6>
                    <strong>Địa Chỉ: </strong>
                    <label>{paymentDetails[0]?.nguoiDungDiaChi}</label>
                  </h6>
                </Form.Item>
              </div>
            </div>
            {/* <br /> */}
            {/* <h6>Thông tin đơn hàng</h6> */}
            <div className="row">
              <div
                className="col-lg-12"
                style={{ fontSize: "18px", color: "blue" }}
              >
                <strong className="Ten-Tour">{payment.tenTour}</strong>
              </div>
              <div className="col-lg-3">
                <Form.Item label="Mã Đơn Hàng">
                  <h6>{payment.moTa}</h6>
                </Form.Item>
              </div>

              <div className="col-lg-3">
                <Form.Item label="Trạng Thái">
                  <h6
                    style={{ color: payment.hoaDonTrangThai ? "green" : "red" }}
                  >
                    {payment.hoaDonTrangThai ? "Đã thanh toán" : "Đã hủy"}
                  </h6>
                </Form.Item>
              </div>
              <div className="col-lg-3">
                <Form.Item label="Ngày Đặt">
                  <h6>{dayjs(payment.ngayDat).format("DD-MM-YYYY")}</h6>
                </Form.Item>
              </div>
            </div>

            <Table
              dataSource={paymentDetails}
              bordered
              size="middle"
              scroll={{ x: 700 }}
              pagination={false}
            >
              <Column
                title="ID"
                dataIndex="hoaDonId"
                key="hoaDonId"
                width={40}
                align="center"
              />
              <Column
                title="Họ Tên"
                dataIndex="hoTen"
                key="hoTen"
                width={150}
                align="center"
              />
              <Column 
              title="Email" 
              dataIndex="email" 
              key="email" width={100} 
              align="center" />
              <Column
                title="Số điện thoại"
                dataIndex="soDienThoai"
                key="soDienThoai"
                width={100}
                align="center"
              />
              <Column
                title="Năm Sinh"
                dataIndex="namSinh"
                key="namSinh"
                width={100}
                    render={(text) => dayjs(text).format("DD-MM-YYYY")}
                align="center"
              />
              <ColumnGroup title="Thông tin giá">
                <Column
                  title="Giá người lớn"
                  dataIndex="giaNguoiLon"
                  key="giaNguoiLon"
                  render={(text) => {
                    return new Intl.NumberFormat('vi-VN').format(text) + ' VNĐ'; // Thêm 'VNĐ' vào cuối giá trị
                  }}
                  align="center"
                />
                <Column
                  title="Giá trẻ em"
                  dataIndex="giaTreEm"
                  key="giaTreEm"
                  render={(text) => {
                    return new Intl.NumberFormat('vi-VN').format(text) + ' VNĐ'; // Thêm 'VNĐ' vào cuối giá trị
                  }}
                  align="center"
                />
              </ColumnGroup>
              <Column
                title="Giá Tiền"
                key="giaTien"
                render={(text, record) => {
                  const age = calculateAge(record.namSinh);

                  if (age === null) {
                    console.error(
                      `Không thể tính giá tiền cho Họ Tên: ${record.hoTen}`
                    );
                    return "Không xác định"; // Giá trị mặc định khi không tính được tuổi
                  }

                  const price = age > 14 ? record.giaNguoiLon : record.giaTreEm;

                  console.log(
                    `Họ Tên: ${record.hoTen}, Tuổi: ${age}, Giá Tiền: ${
                      age > 14 ? "Người lớn" : "Trẻ em"
                    }, Giá: ${price}`
                  );

                  return price + " VNĐ"; // Hiển thị giá tiền sau định dạng
                }}
              />
            </Table>
            <div className="col-lg-12">
              {/* <Form.Item label="Tổng tiền" style={{ textAlign: "right" }}>
                <h6 className="text-red-500">{payment.tongTien} VNĐ</h6>
              </Form.Item> */}
              <div className="col-lg-12" style={{ display: 'flex', justifyContent: 'flex-end' }}>
                <Form.Item className="tong mt-2" label="Tổng tiền">
                  <strong style={{ color: "red" }}>
                    {new Intl.NumberFormat('vi-VN').format(payment?.tongTien)} <span>VNĐ</span>
                  </strong>
                </Form.Item>
              </div>
              
            </div>
            <div className="col-lg-12">
              <Form.Item>
                {" "}
                <i> Viết bằng chữ: </i>
                {convertNumberToWords(payment.tongTien)} <br />
                <i>
                  Giá tiền này đã bao gồm giá của người đặt và giá người đi cùng
                </i>{" "}
                <br />
                <i>Ghi chú: </i>
                {payment.ghiChu}
              </Form.Item>
            </div>
          </Form>
        </div>
      </Modal>
    </div>
  );
};

export default FormChiTietThanhToan;
