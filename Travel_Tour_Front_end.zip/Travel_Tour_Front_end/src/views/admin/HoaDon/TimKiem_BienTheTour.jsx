import React, { useState } from "react";
import { Button, Input, Row, Col, DatePicker, message } from "antd";
import { SearchOutlined } from "@ant-design/icons";
import axios from "axios";

// Hàm xử lý khi thay đổi ngày
const onDateChange = (date, dateString, allData, setData) => {
  console.log("Selected date:", dateString);
  // Lọc dữ liệu dựa trên ngày bắt đầu, nếu có dữ liệu đã tải trước đó
  const filteredData = allData.filter((item) => {
    return item.ngayThanhToan && item.ngayThanhToan.startsWith(dateString);
  });
  setData(filteredData);
};

const TimKiemHoaDon = ({ allData, setData }) => {
  const [searchValue, setSearchValue] = useState("");

  // Hàm tìm kiếm khi nhấn nút
  const onSearch = (value) => {
    setSearchValue(value);
    if (value.trim() === "") {
      setData(allData); // Nếu không có giá trị tìm kiếm, hiển thị tất cả
    } else {
      const normalizedValue = value.trim().toLowerCase();
      const filteredData = allData.filter((item) => {
        const normalizedId = item.id.toString();
        const normalizedName =
          item.nguoiDung && item.nguoiDung.hoTen
            ? item.nguoiDung.hoTen.trim().toLowerCase()
            : "";
        return (
          normalizedId.includes(normalizedValue) ||
          normalizedName.includes(normalizedValue)
        );
      });

      if (filteredData.length === 0) {
        message.warning("Không tìm thấy kết quả.");
      }
      setData(filteredData);
    }
  };

  // Hàm xử lý khi nhấn nút tìm kiếm
  const handleSearchClick = () => {
    onSearch(searchValue);
  };

  return (
    <div>
      <Row gutter={16} align="middle">
        {/* DatePicker (Tìm kiếm ngày tháng năm) */}
        <Col>
          <DatePicker
            onChange={(date, dateString) =>
              onDateChange(date, dateString, allData, setData)
            }
            style={{ width: 200 }}
            placeholder="Chọn ngày bắt đầu"
          />
        </Col>
        <Col className="flex items-center gap-[16px]">
          <Input
            size="large"
            placeholder="Nhập ID hoặc tên khách hàng"
            value={searchValue}
            onChange={(e) => setSearchValue(e.target.value)}
            className="h-[32px] min-w-[240px]"
          />
          <Button icon={<SearchOutlined />} onClick={handleSearchClick}>
            Tìm kiếm
          </Button>
        </Col>
      </Row>
    </div>
  );
};

export default TimKiemHoaDon;
