import React, { useEffect, useState } from "react";
import {
  Table,
  Radio,
  Tag,
  Tooltip,
  Button,
  Space,
  message,
  Modal,
  DatePicker,
} from "antd";
import { EyeTwoTone, DownloadOutlined } from "@ant-design/icons";
import axios from "axios";
import ChiTietThanhToan from "./ChiTietHoaDon"; // Chi tiết
import dayjs from "dayjs";
import isBetween from "dayjs/plugin/isBetween";
import * as xlsx from "xlsx";
import TimKiemHoaDon from "./TimKiem_BienTheTour";

dayjs.extend(isBetween);
const FormHoaDon = () => {
  const showModal = (record) => {
    setSelectedTour(record); // Lưu thông tin bản ghi cần hủy
    setIsModalOpen(true); // Hiển thị modal
    console.log("huy new", record);
  };

  const [cancelReason, setCancelReason] = useState("");

  const [isModalOpen, setIsModalOpen] = useState(false);
  const handleOk = async () => {
    if (!cancelReason.trim()) {
      message.error("Vui lòng nhập lý do hủy tour!");
      return;
    }

    try {
      // Gửi yêu cầu hủy tour đến API
      await axios.post("http://localhost:8080/api/tours/huy", {
        chiTietHoaDonId: selectedTour.id,
        cancelReason: cancelReason,
      });

      message.success("Tour đã được hủy thành công!");

      // Cập nhật trạng thái của bản ghi trong dữ liệu cục bộ
      setData((prevData) =>
        prevData.map((item) =>
          item.id === selectedTour.id
            ? { ...item, trangThai: false } // Cập nhật trạng thái thành đã hủy
            : item
        )
      );

      setCancelReason(""); // Xóa lý do sau khi hủy
      setIsModalOpen(false); // Đóng modal
    } catch (error) {
      message.error("Lỗi khi hủy tour!");
    }
  };

  const handleCancel = () => {
    setIsModalOpen(false);
  };
  const [data, setData] = useState([]);
  const [selectedUserId, setSelectedUserId] = useState(null);
  const [visible, setVisible] = useState(false);
  const [selectedTour, setSelectedTour] = useState(null);
  const [allData, setAllData] = useState([]);
  const [filter, setFilter] = useState("thisWeek"); // Default to "This Week"
  const [customDateRange, setCustomDateRange] = useState([null, null]);

  const handleFilterChange = (e) => {
    setFilter(e.target.value);
  };

  const bienTheTourId = decodeURIComponent(new URLSearchParams(window.location.search).get("idBienTheTour"));
  console.log("bienTheTourId",bienTheTourId)
  // Date range picker for custom date range
  const handleDateRangeChange = (dates) => {
    setCustomDateRange(dates);
  };
  const filterData = (data) => {
    let filteredData = [...data];

    const now = dayjs();
    switch (filter) {
      case "thisWeek":
        // Filter data for the current week
        filteredData = data.filter((item) =>
          dayjs(item.ngayThanhToan).isSame(now, "week")
        );
        break;
      case "thisMonth":
        // Filter data for the current month
        filteredData = data.filter((item) =>
          dayjs(item.ngayThanhToan).isSame(now, "month")
        );
        break;
      case "customRange":
        // Filter data for the custom date range
        if (customDateRange[0] && customDateRange[1]) {
          filteredData = data.filter((item) =>
            dayjs(item.ngayThanhToan).isBetween(
              customDateRange[0],
              customDateRange[1],
              "day",
              "[]"
            )
          );
        }
        break;
      default:
        break;
    }
    return filteredData;
  };

  useEffect(() => {
    const fetchData = async () => {
      try {
        // Kiểm tra nếu bienTheTour tồn tại
        const url = bienTheTourId
          ? `http://localhost:8080/api/hoadon/bienthetour2/${encodeURIComponent(bienTheTourId)}`
          : "http://localhost:8080/api/hoadon";  // Nếu không có bienTheTour, lấy tất cả dữ liệu
        
        const response = await axios.get(url);
        
        if (response.status === 200) {
          const HoaDons = response.data;
          const sortedHoaDons = HoaDons.sort((a, b) => b.id - a.id);
          setData(sortedHoaDons);
          setAllData(sortedHoaDons);
        } else {
          message.error(`Lỗi khi tải dữ liệu! Status: ${response.status}`);
        }
      } catch (error) {
        console.error('Lỗi tải hóa đơn:', error); // Log chi tiết lỗi ra console
        message.error("Lỗi khi tải dữ liệu!");
      }
    };
    
    fetchData();
  }, []);

  const handleBack = () => {
    setVisible(false);
    setSelectedUserId(null);
  };

  const handleChiTiet = (record) => {
    setSelectedUserId(record.id);
    setVisible(true);
  };

  // Hàm xuất file Excel
  const exportToExcel = () => {
    const filteredData = filterData(data); // Filter the data first

    const rowData = [
      [
        "STT",
        "Họ và Tên",
        "Tổng Tiền",
        "Ngày Thanh Toán",
        "Trạng Thái",
        "Phương Thức Thanh Toán",
        "Hủy Tour",
      ], // Tiêu đề
      ...filteredData.map((row, index) => [
        index + 1,
        row.nguoiDung?.hoTen,
        formatCurrencyVND(row.tongTien),
        dayjs(row.ngayThanhToan).format("DD/MM/YYYY"),
        row.trangThai ? "Đã thanh toán" : "Đã hủy",
        row.phuongThucThanhToan ? "Tiền mặt" : "Thanh toán online",
        row.ghiChu || "",
      ]),
    ];

    // Chuyển dữ liệu thành worksheet
    const wsData = xlsx.utils.aoa_to_sheet(rowData);

    const wscols = [
      { wpx: 100 }, // STT
      { wpx: 250 }, // Họ và Tên
      { wpx: 200 }, // Tổng Tiền
      { wpx: 200 }, // Ngày Thanh Toán
      { wpx: 250 }, // Trạng Thái
      { wpx: 250 }, // Phương Thức Thanh Toán
      { wpx: 120 }, // Hủy Tour
    ];

    wsData["!cols"] = wscols;

    // Create the workbook and append the sheet
    const wb = xlsx.utils.book_new();
    xlsx.utils.book_append_sheet(wb, wsData, "HoaDon");

    // Export the Excel file
    xlsx.writeFile(wb, "HoaDon.xlsx");
  };

  const formatCurrencyVND = (amount) => {
    return new Intl.NumberFormat("vi-VN", {
      style: "currency",
      currency: "VND",
      currencyDisplay: "code",
    })
      .format(amount)
      .replace("VNĐ", "Đ");
  };
  const columns = (handleChiTiet) => [
    {
      title: "STT",
      dataIndex: "id",
      key: "id",
      render: (_, __, index) => (
        <a href="#!" onClick={(e) => e.preventDefault()}>
          {index + 1}
        </a>
      ),
      width: 70,
    },
    {
      title: "Họ Và Tên",
      dataIndex: "nguoiDung",
      key: "nguoiDung",
      ellipsis: {
        showTitle: false,
      },
      render: (nguoiDung) => (
        <Tooltip placement="topLeft" title={nguoiDung?.hoTen}>
          {nguoiDung?.hoTen}
        </Tooltip>
      ),
      width: 150,
    },
    {
      title: "Tổng Tiền",
      dataIndex: "tongTien",
      key: "tongTien",
      ellipsis: { showTitle: false },
      render: (tongTien) => (
        <Tooltip
          placement="topLeft"
          title={new Intl.NumberFormat("vi-VN", {
            style: "currency",
            currency: "VND",
          }).format(tongTien)}
        >
          {formatCurrencyVND(tongTien)}
        </Tooltip>
      ),
      sorter: (a, b) => a.id - b.id,
      width: 150,
    },
    {
      title: "Ngày Thanh Toán",
      dataIndex: "ngayThanhToan",
      key: "ngayThanhToan",
      ellipsis: { showTitle: false },
      render: (ngayThanhToan) => (
        <Tooltip placement="topLeft" title={ngayThanhToan}>
          {dayjs(ngayThanhToan).format("DD/MM/YYYY")}
        </Tooltip>
      ),
      width: 200,
      sorter: (a, b) => {
        const dateA = new Date(a.ngayThanhToan);
        const dateB = new Date(b.ngayThanhToan);
        return dateA - dateB;
      },
    },
    {
      title: "Trạng Thái",
      dataIndex: "trangThai",
      key: "trangThai",
      ellipsis: { showTitle: false },
      render: (_, { trangThai }) => {
        let color = trangThai ? "red" : "yellow"; // Màu đỏ cho "Đã thanh toán", vàng cho "Đã hủy"
        let statusText = trangThai ? "Đã thanh toán" : "Đã hủy";

        if (!trangThai) {
          color = "#F05252"; // Màu vàng cho "Đã hủy"
        } else {
          color = "#0E9F6E"; // Màu đỏ cho "Đã thanh toán"
        }

        return (
          <Tooltip placement="topLeft" title={statusText}>
            <Tag color={color} key={statusText}>
              {statusText}
            </Tag>
          </Tooltip>
        );
      },
      width: 150,
    },
    {
      title: "Phương thức thanh toán",
      dataIndex: "phuongThucThanhToan",
      key: "phuongThucThanhToan",
      ellipsis: { showTitle: false },
      render: (_, { phuongThucThanhToan }) => {
        let color = phuongThucThanhToan ? "red" : "yellow"; // Màu đỏ cho "Đã thanh toán", vàng cho "Đã hủy"
        let statusText = phuongThucThanhToan ? "Tiền mặt" : "Thanh toán online";

        if (!phuongThucThanhToan) {
          color = "#6C2BD9"; // Màu vàng cho "Đã hủy"
        } else {
          color = "#1A56DB"; // Màu đỏ cho "Đã thanh toán"
        }

        return (
          <Tooltip placement="topLeft" title={statusText}>
            <Tag color={color} key={statusText}>
              {statusText.toUpperCase()}
            </Tag>
          </Tooltip>
        );
      },
      width: 200,
    },
    {
      title: "",
      key: "action",
      render: (_, record) => (
        <Space size="middle">
          {/* Nút Chi tiết */}
          <Button icon={<EyeTwoTone />} onClick={() => handleChiTiet(record)} />
          {/* Nút Hủy Tour nếu trạng thái là đã thanh toán */}
          {record.trangThai && (
            <button
              style={{ fontSize: "10px" }}
              className="border rounded-md text-white bg-red-500 px-[8px] py-[4px] hover:bg-red-700"
              onClick={() => showModal(record)}
            >
              Hủy Tour
            </button>
          )}
        </Space>
      ),
      width: 140,
    },
  ];

  return (
    <div className="container">
      <h3>Quản Lý Hóa Đơn</h3>
      <div className="flex flex-col gap-[16px]">
        <TimKiemHoaDon allData={allData} setData={setData} />
        <div className="flex gap-[16px] mb-4">
          <Radio.Group onChange={handleFilterChange} value={filter}>
            <Radio value="thisWeek">Tuần</Radio>
            <Radio value="thisMonth">Tháng</Radio>
            <Radio value="customRange">Theo yêu cầu</Radio>
          </Radio.Group>

          {filter === "customRange" && (
            <DatePicker.RangePicker
              value={customDateRange}
              onChange={handleDateRangeChange}
              format="DD/MM/YYYY"
            />
          )}
        </div>

        <div className="button-container">
          <Button
            type="primary"
            icon={<DownloadOutlined />} // Icon tải xuống
            onClick={exportToExcel} // Gọi hàm xuất Excel
            style={{ marginBottom: 5 }} // Khoảng cách dưới nút
          >
            Xuất Excel
          </Button>
        </div>
      </div>
      <div className="table-container align-items-center mt-5">
        <Table
          columns={columns(handleChiTiet)}
          dataSource={data.map((item) => ({ ...item, key: item.id }))}
        />
      </div>
      <ChiTietThanhToan
        visible={visible}
        onBack={handleBack}
        paymentId={selectedUserId}
      />
      <>
        <Modal
          title="Xác nhận hủy tour"
          open={isModalOpen}
          onOk={handleOk}
          onCancel={handleCancel}
        >
          <p>Bạn có chắc chắn muốn hủy tour này?</p>
          {selectedTour && (
            <ul>
              <li>
                <strong>Tour Id</strong> {selectedTour.id}
              </li>
              <li>
                <strong>Họ và Tên Người Đặt:</strong>{" "}
                {selectedTour.nguoiDung?.hoTen}
              </li>
              <li>
                <strong>Tổng Tiền:</strong>{" "}
                {new Intl.NumberFormat("vi-VN", {
                  style: "currency",
                  currency: "VND",
                }).format(selectedTour.tongTien)}
              </li>
              <li>
                <strong>Ngày Thanh Toán:</strong>{" "}
                {dayjs(selectedTour.ngayThanhToan).format("DD/MM/YYYY")}
              </li>
            </ul>
          )}
          <textarea
            placeholder="Nhập lý do hủy tour..."
            value={cancelReason}
            onChange={(e) => setCancelReason(e.target.value)}
            className="w-full mt-4 p-2 border rounded-md"
            rows={4}
          />
        </Modal>
      </>
    </div>
  );
};

export default FormHoaDon;
