import React, { useState, useEffect } from "react";
import axios from "axios"; // Import axios
import {
  Table,
  Tooltip,
  Button,
  ConfigProvider,
  Space,
  message,
  Modal,
} from "antd";
import {
  AntDesignOutlined,
  DeleteOutlined,
  EyeTwoTone,
  HighlightTwoTone,
} from "@ant-design/icons";

// import "./Css/NhanVien.css";
import ThemDanhMucTour from "./ThemDanhMucTour.jsx";
import CapNhatDanhMucTour from "./CapNhatDanhMucTour.jsx";
import DanhMucTourtimkiem from "./TimKiem_DanhMucTour.jsx";
import { useNavigate,useLocation } from "react-router-dom";

// Cột dữ liệu của bảng
const columns = (handleDanhMucTour, showEditModal, handleDelete) => [
  {
    title: "STT",
    dataIndex: "id",
    key: "id",
    fixed: "left",
    render: (_, __, index) => (
      <a href="#!" onClick={(e) => e.preventDefault()}>
        {index + 1}
      </a>
    ),
    width: 70,
  },
  {
    title: "Tên Danh Mục Tour",
    dataIndex: "tenDanhMuc",
    key: "tenDanhMuc",
    ellipsis: {
      showTitle: false,
    },
    render: (tenDanhMuc) => (
      <Tooltip placement="topLeft" title={tenDanhMuc}>
        {tenDanhMuc}
      </Tooltip>
    ),
  },
  {
    title: "",
    key: "action",
    fixed: "right",
    render: (_, record) => (
      <Space size="middle">
        {/* Nút xem chi tiết  */}
        <Tooltip title="Xem thông tin Tour">
          <Button
            icon={<EyeTwoTone />}
            onClick={() => handleDanhMucTour(record.tenDanhMuc)} // Gọi hàm thông tin tour
          ></Button>
        </Tooltip>

        {/* Nút Sửa */}
        <Tooltip title="Sửa thông tin Danh Mục Tour">
          <Button
            icon={<HighlightTwoTone />}
            onClick={() => showEditModal(record)} // Hiển thị modal với dữ liệu người dùng được chọn
          ></Button>
        </Tooltip>

        {/* Nút Xóa */}
        <Tooltip title="Xóa Thông tin Danh Mục Tour">
          <Button
            icon={<DeleteOutlined />}
            danger
            onClick={() => handleDelete(record.id, record.tenDanhMuc)} // Gọi hàm xóa
          ></Button>
        </Tooltip>
      </Space>
    ),
  },
];

// Component chính
const DanhMucTour = () => {
  const [visible, setVisible] = useState(false);
  const [editingUser, setEditingUser] = useState(null);
  const [data, setData] = useState([]); // Trạng thái lưu trữ dữ liệu
  // const [selectedUserId, setSelectedUserId] = useState(null);
  const [filteredData, setFilteredData] = useState([]);
  const navigate = useNavigate();
  const location = useLocation();
  // Gọi API khi component được tải
  const fetchData = async () => {
    try {
      const response = await axios.get("http://localhost:8080/api/danhmuctour");
      const sortedNhanViens = response.data.sort((a, b) => b.id - a.id);
      setData(sortedNhanViens); // Update the data state
      setFilteredData(sortedNhanViens);
    } catch (error) {
      console.error("Lỗi khi tải dữ liệu:", error);
      message.error("Không thể tải dữ liệu từ server."); // Hiển thị thông báo lỗi
    }
  };
  useEffect(() => {
    fetchData();
  }, []); // Chạy một lần khi component được tải

  const showModal = () => {
    setVisible(true);
  };
  // Hàm xử lý xem chi tiết
  const handleDanhMucTour = (tenDanhMuc) => {
    // Giải mã URL nếu tenDanhMuc đã bị mã hóa
    const decodedTenDanhMuc = decodeURIComponent(tenDanhMuc);

    // Điều hướng đến URL với tenDanhMuc đã giải mã
    // window.location.href = `http://localhost:3000/admin/tour?tenDanhMuc=${decodedTenDanhMuc}`;
    navigate(`/admin/tour?tenDanhMuc=${decodedTenDanhMuc}`);
  };

  // Xử lý xem chi tiết
  const handleChiTiet = (record) => {
    // setSelectedUserId(record.id); // Lưu ID người dùng đã chọn vào state
    setVisible(true); // Hiển thị modal chi tiết người dùng
  };

  const handleCancel = () => {
    setVisible(false);
    setEditingUser(null);
  };

  const showEditModal = (user) => {
    setEditingUser(user);
    setVisible(true);
  };
  const handleUpdateSuccess = async () => {
    try {
      const response = await axios.get("http://localhost:8080/api/danhmuctour");
      const sortedNhanViens = response.data.sort((a, b) => b.id - a.id);
      setData(sortedNhanViens); // Update the data state
      setVisible(false); // Close the modal
      setEditingUser(null); // Clear the editing user
      // handleUpdateSuccess();
    } catch (error) {
      message.error("Không thể tải dữ liệu từ server.");
    }
  };
  // Hàm xử lý xóa và hiển thị thông báo
  const handleDelete = (id, tenDanhMuc) => {
    // Show the confirmation popup with the category name included
    Modal.confirm({
      title: `Bạn có chắc chắn muốn xóa Danh mục tour với Tên Danh Mục: ${tenDanhMuc}`, // Display the category name in the confirmation message
      okText: "Có", // Text for the OK button (Yes)
      cancelText: "Không", // Text for the Cancel button (No)
      onOk: async () => {
        // onOk is called when the user clicks "Yes"
        try {
          // Make the DELETE request to the backend
          await axios.delete(
            `http://localhost:8080/api/danhmuctour/delete/${id}`
          );

          // Remove the deleted item from the local state to update the UI
          setData((prevData) => prevData.filter((item) => item.id !== id));

          // Show success message
          message.success(`Đã xóa thành công: ${tenDanhMuc}`);
        } catch (error) {
          console.error("Lỗi khi xóa Danh mục tour:", error);
          message.error("Không thể xóa Danh mục tour.");
        }
      },
      onCancel: () => {
        // Optionally, log or handle the cancel action
        console.log("Xóa bị hủy");
      },
    });
  };

  const handleSearch = (searchValue) => {
    if (!searchValue) {
      setFilteredData(data); // Nếu không nhập gì, hiển thị toàn bộ dữ liệu
    } else {
      const lowerCaseSearchValue = searchValue.toLowerCase();
      const filtered = data.filter((item) =>
        item.tenDanhMuc.toLowerCase().includes(lowerCaseSearchValue)
      );
      setFilteredData(filtered);
    }
  };
  // Remove the earlier declaration of handleDelete here

  return (
    <div className="container">
      <h3>Danh Mục Tour</h3>

      {/* Nút "Thêm" */}
      <ConfigProvider>
        <div className="button-container">
          <Button
            className="nguoidung-them"
            type="primary"
            size="large"
            icon={<AntDesignOutlined />}
            onClick={showModal}
          >
            Thêm
          </Button>
        </div>
        <ThemDanhMucTour
          visible={visible}
          onCancel={handleCancel}
          reloadData={fetchData}
        />
      </ConfigProvider>
      <div className="flex flex-col gap-[16px]">
        <DanhMucTourtimkiem onSearch={handleSearch} />
        <div
          className="table-container align-items-center"
          style={{ marginRight: "-100px" }}
        >
          <Table
            columns={columns(
              handleDanhMucTour,
              showEditModal,
              handleDelete,
              handleChiTiet
            )}
            // scroll={{ x: 2100 }}
            dataSource={data}
            rowKey="id"
          />
        </div>
      </div>

      {/* Các phần khác , Hàm cập nhật người dùng  */}
      {editingUser && (
        <CapNhatDanhMucTour
          visible={visible}
          onCancel={handleCancel}
          categoryData={editingUser} // Pass the editing user data
          onUpdateSuccess={handleUpdateSuccess} // Pass the callback
        />
      )}
    </div>
  );
};

export default DanhMucTour;
