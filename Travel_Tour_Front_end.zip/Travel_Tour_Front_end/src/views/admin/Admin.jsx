import React, { useState, useEffect } from "react";
import { useNavigate, Outlet, useLocation, Navigate } from "react-router-dom";
import { Breadcrumb, Menu, Switch } from "antd";
import {
  TeamOutlined,
  CalendarOutlined,
  PictureOutlined,
  HomeOutlined,
  TruckOutlined,
  FolderOpenOutlined,
  ContainerOutlined,
  SettingOutlined,
  DollarOutlined,
} from "@ant-design/icons";
import "bootstrap/dist/css/bootstrap.min.css";
import "./NguoiDung/Css/NhanVien.css";
import "./index.css";
import { toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import axios from "axios";
import Chatbot from "../../components/chatbot";

const LANGUAGES = {
  en: {
    logo: "travel go",
    home: "Home",
    userManagement: "User Management",
    tourManagement: "Tour Management",
    staff: "Staff",
    customers: "Customers",
    discountManagement: "Discount Management",
    mediaTour: "Media Tour",
    hotelManagement: "Hotel Management",
    vehicleManagement: "Vehicle Management",
    articleManagement: "Article Management",
    reviewManagement: "Review Management",
    // invoiceManagement: "Invoice Management",
    darkMode: "Dark Mode",
    lightMode: "Light Mode",
    logout: "Logout",
  },
  vi: {
    logo: "Travel go",
    home: "Trang Chủ",
    userManagement: "Quản Lý Người Dùng",
    tourManagement: "Quản Lý Thông Tin Tour",
    staff: "Nhân Viên",
    customers: "Khách Hàng",
    discountManagement: "Quản Lý Giảm Giá",
    mediaTour: "Media Tour",
    hotelManagement: "Quản Lí Khách Sạn",
    vehicleManagement: "Quản lí Phương Tiện",
    articleManagement: "Quản Lý bài viết",
    reviewManagement: "Quản Lý Đánh Giá",
    // invoiceManagement: "Quản lí Hóa Đơn",
    darkMode: "Chế Độ Tối",
    lightMode: "Chế Độ Sáng",
    logout: "Đăng xuất",
  },
};

const items = (t, role) => {
  const commonItems = [
    {
      key: "trangchu",
      label: t.home,
      icon: <SettingOutlined />,
    },
    {
      key: "danh-muc-tour",
      icon: <FolderOpenOutlined />,
      label: t.tourManagement,
    },
    { key: "media-tour", icon: <PictureOutlined />, label: t.mediaTour },
    { key: "khach-san", icon: <HomeOutlined />, label: t.hotelManagement },
    { key: "phuong-tien", icon: <TruckOutlined />, label: t.vehicleManagement },
    {
      key: "quan-ly-tin-tuc",
      icon: <ContainerOutlined />,
      label: t.articleManagement,
    },
    // { key: "danh-gia", icon: <CopyOutlined />, label: t.reviewManagement },
  ];

  // Nếu là Quản trị viên (role === "1"), hiển thị toàn bộ menu
  if (role === "admin") {
    return [
      ...commonItems,
      {
        key: "sub2",
        label: t.userManagement,
        icon: <TeamOutlined />,
        children: [
          { key: "nhan-vien", label: t.staff },
          { key: "khach-hang", label: t.customers },
        ],
      },
      {
        key: "giam-gia",
        icon: <CalendarOutlined />,
        label: t.discountManagement,
      },
      // { key: "hoa-don", icon: <DollarOutlined />, label: t.invoiceManagement },
    ];
  }

  // Nếu là Nhân viên (role === "2"), chỉ hiển thị các mục hạn chế
  return commonItems;
};

const topMenuItems = (setLanguage, t, user, avatar, handleLogout) => [
  {
    label: (
      <div className="travel-logo-container">
        <h2>{t.logo}</h2>
        <img src="/images/Blue Minimalist Travel Logo.png" alt="Travel Logo" />
      </div>
    ),
    key: "",
  },
  {
    label: (
      <div
        style={{
          display: "flex",
          marginRight: "-90px",
        }}
      >
        <Switch
          onChange={(checked) => {
            document.body.classList.toggle("dark-mode", checked);
          }}
          checkedChildren={t.darkMode}
          unCheckedChildren={t.lightMode}
          style={{
            display: "flex",
            margin: -10,
          }}
        />
      </div>
    ),
    key: "SwitchTheme",
  },
  {
    label: (
      <div
        style={{
          display: "flex",
          alignItems: "center",
          // marginLeft: "10px",
          marginRight: "-80px",
        }}
      >
        <img
          src="https://img.icons8.com/fluency/48/language-skill.png"
          alt="language-skill"
          style={{
            width: "40px",
            height: "40px",
            borderRadius: "50%",
            marginRight: "10px",
            marginTop: "3px",
          }}
        />
      </div>
    ),
    key: "SubLanguage",

    children: [
      {
        label: (
          <div>
            <button onClick={() => setLanguage("en")}>English</button>
          </div>
        ),
        key: "LanguageSwitchEN",
      },
      {
        label: (
          <div>
            <button onClick={() => setLanguage("vi")}>Tiếng Việt</button>
          </div>
        ),
        key: "LanguageSwitchVN",
      },
    ],
  },
  {
    label: (
      <div
        style={{
          display: "flex",
          alignItems: "center",
          marginRight: "250px",
        }}
      >
        <img
          src={avatar}
          alt="user"
          style={{
            width: "40px",
            height: "40px",
            borderRadius: "50%",
            marginRight: "10px",
          }}
        />

        <span>{user}</span>
      </div>
    ),
    key: "SubMenu",
    children: [
      {
        key: "23",
        label: t.logout,
        onClick: handleLogout,
      },
    ],
  },
];

export const Admin = () => {
  const location = useLocation();
  const { pathname } = location;
  const isAccountPage = pathname === "/admin";
  const isChildPage = pathname.includes("/admin/");

  const [current, setCurrent] = useState("trangchu");
  const [language, setLanguage] = useState("vi");
  const t = LANGUAGES[language];
  const [user, setUser] = useState(null);
  const [avatar, setAvatar] = useState("/images/user.png");
  const [role, setRole] = useState(null);

  const navigate = useNavigate();

  const handleClick = (e) => {
    setCurrent(e.key);
    navigate(`/admin/${e.key}`);
  };

  const handleLogout = async () => {
    try {
      await axios.post(
        "http://localhost:8080/api/logout",
        {},
        { withCredentials: true }
      );

      localStorage.removeItem("hoTen");
      localStorage.removeItem("token");
      localStorage.removeItem("email");
      localStorage.removeItem("diaChi");
      localStorage.removeItem("role");
      localStorage.removeItem("id");
      localStorage.removeItem("hinhAnh");

      toast.success("đăng xuất thành công!");
      navigate("/");
    } catch (error) {
      toast.error("Đăng xuất thất bại:", error);
    }
  };

  useEffect(() => {
    const userData = localStorage.getItem("hoTen");
    const avatarFromLocalStorage = localStorage.getItem("hinhAnh");
    const userRole = localStorage.getItem("role");

    if (userData) {
      setUser(userData);
    } else {
      setUser(null);
      setAvatar("/images/user.png");
    }

    if (avatarFromLocalStorage) {
      setAvatar(avatarFromLocalStorage);
    }

    if (userRole) {
      setRole(userRole);
    }
  }, [localStorage.getItem("hoTen"), localStorage.getItem("diaChi")]);

  const generateBreadcrumbItems = (pathname, t) => {
    const pathSnippets = pathname
      .replace("/admin", "") // Loại bỏ "/admin" khỏi đường dẫn
      .split("/") // Tách các phần của URL
      .filter((i) => i); // Loại bỏ các phần rỗng

    // Tạo một mảng breadcrumb từ các phần trong URL
    const breadcrumbItems = pathSnippets.map((segment, index) => {
      const url = `/admin/${pathSnippets.slice(0, index + 1).join("/")}`; // Tạo URL cho từng phần trong breadcrumb
      let label;

      // Xử lý các segment của URL và tạo label phù hợp
      if (segment === "danh-muc-tour") {
        label = t["danh-muc-tour"] || "Danh Mục Tour"; // Label cho "Danh mục Tour"
      } else if (segment === "tour") {
        label = t["tour"] || "Tour"; // Label cho "Tour"
      } else if (segment === "bien-the-tour") {
        label = t["bien-the-tour"] || "Biến Thể Tour"; // Label cho "Biến thể Tour"
      } else if (segment === "lich-trinh-tour") {
        label = t["lich-trinh-tour"] || "Lịch Trình Tour"; // Label cho "Lịch trình"
      } else if (segment === "danh-gia") {
        label = t["danh-gia"] || "Đánh Giá"; // Label cho "Lịch trình"
      } else if (segment === "hoa-don") {
        label = t["hoa-don"] || "Hóa Đơn"; // Label cho "Lịch trình"
      } else if (segment === "trangchu") {
        label = t["trangchu"] || "trang chủ"; // Label cho "Lịch trình"
      } else if (segment === "media-tour") {
        label = t["media-tour"] || "Media Tour"; // Label cho "Lịch trình"
      } else if (segment === "khach-san") {
        label = t["khach-san"] || "Khách Sạn"; // Label cho "Lịch trình"
      } else if (segment === "phuong-tien") {
        label = t["phuong-tien"] || "Phương Tiện"; // Label cho "Lịch trình"
      } else if (segment === "quan-ly-tin-tuc") {
        label = t["quan-ly-tin-tuc"] || "Bài Viết"; // Label cho "Lịch trình"
      } else if (segment === "nhan-vien") {
        label = t["nhan-vien"] || "Nhân Viên"; // Label cho "Lịch trình"
      } else if (segment === "khach-hang") {
        label = t["khach-hang"] || "Khách Hàng"; // Label cho "Lịch trình"
      } else if (segment === "giam-gia") {
        label = t["giam-gia"] || "Giảm Giá"; // Label cho "Lịch trình"
      } else {
        label = t[segment] || segment; // Nếu không có trong t, dùng tên segment
      }

      // Kiểm tra xem có phải vị trí hiện tại không
      const isCurrent = index === pathSnippets.length - 1;

      return {
        title: (
          <button
            onClick={() => navigate(-1)} // Lùi lại trang trước
            className={isCurrent ? "active" : ""}
            style={{
              textDecoration: "none",
              fontWeight: isCurrent ? "bold" : "normal",
            }}
          >
            {label}
          </button>
        ), // Hiển thị breadcrumb với button
        href: url,
        isCurrent,
      };
    });

    // Thêm breadcrumb cho trang chủ
    const breadcrumbWithHome = [
      {
        title: (
          <button
            onClick={() => navigate(-1)}
            style={{ textDecoration: "none" }}
          >
            {t["home"]}
          </button>
        ),
      },
    ];

    // Kiểm tra nếu URL là "/admin/tour", thêm "Danh mục Tour" vào breadcrumb sau trang chủ
    if (pathname === "/admin/tour") {
      breadcrumbWithHome.push({
        title: (
          <button
            onClick={() => navigate(-1)}
            style={{ textDecoration: "none" }}
          >
            {t["danh-muc-tour"] || "Danh mục Tour"}
          </button>
        ),
      });
    }

    // Kiểm tra nếu URL là "/admin/bien-the-tour", thêm "Danh mục Tour" và "Tour" vào breadcrumb
    if (pathname === "/admin/bien-the-tour") {
      breadcrumbWithHome.push({
        title: (
          <button
            onClick={() => navigate(-1)}
            style={{ textDecoration: "none" }}
          >
            {t["danh-muc-tour"] || "Danh mục Tour"}
          </button>
        ),
      });
      breadcrumbWithHome.push({
        title: (
          <button
            onClick={() => navigate(-1)}
            style={{ textDecoration: "none" }}
          >
            {t["tour"] || "Tour"}
          </button>
        ),
      });
    }

    if (pathname === "/admin/hoa-don") {
      breadcrumbWithHome.push({
        title: (
          <button
            onClick={() => navigate(-1)}
            style={{ textDecoration: "none" }}
          >
            {t["danh-muc-tour"] || "Danh mục Tour"}
          </button>
        ),
      });
      breadcrumbWithHome.push({
        title: (
          <button
            onClick={() => navigate(-1)}
            style={{ textDecoration: "none" }}
          >
            {t["tour"] || "Tour"}
          </button>
        ),
      });
      breadcrumbWithHome.push({
        title: (
          <button
            onClick={() => navigate(-1)}
            style={{ textDecoration: "none" }}
          >
            {t["bien-the-tour"] || "Biến Thể Tour"}
          </button>
        ),
      });
    }

    // Kiểm tra nếu URL là "/admin/bien-the-tour", thêm "Danh mục Tour" và "Tour" vào breadcrumb
    if (pathname === "/admin/danh-gia") {
      breadcrumbWithHome.push({
        title: (
          <button
            onClick={() => navigate(-1)}
            style={{ textDecoration: "none" }}
          >
            {t["danh-muc-tour"] || "Danh mục Tour"}
          </button>
        ),
      });
      breadcrumbWithHome.push({
        title: (
          <button
            onClick={() => navigate(-1)}
            style={{ textDecoration: "none" }}
          >
            {t["tour"] || "Tour"}
          </button>
        ),
      });
    }

    // Kiểm tra nếu URL là "/admin/lich-trinh-tour", thêm "Tour" và "Biến thể Tour" vào breadcrumb
    if (pathname === "/admin/lich-trinh-tour") {
      breadcrumbWithHome.push({
        title: (
          <button
            onClick={() => navigate(-1)}
            style={{ textDecoration: "none" }}
          >
            {t["danh-muc-tour"] || "Danh mục Tour"}
          </button>
        ),
      });
      breadcrumbWithHome.push({
        title: (
          <button
            onClick={() => navigate(-1)}
            style={{ textDecoration: "none" }}
          >
            {t["tour"] || "Tour"}
          </button>
        ),
      });
      breadcrumbWithHome.push({
        title: (
          <button
            onClick={() => navigate(-1)}
            style={{ textDecoration: "none" }}
          >
            {t["bien-the-tour"] || "Biến thể Tour"}
          </button>
        ),
      });
    }

    // Thêm các breadcrumb phần còn lại vào sau phần breadcrumb trang chủ và "Danh mục Tour"
    return [...breadcrumbWithHome, ...breadcrumbItems];
  };

  return (
    <div className="row">
      <div
        className="col-lg-12"
        style={{
          marginLeft: "280px",
          zIndex: 1000,
          backgroundColor: "#fff",
          position: "fixed",
          paddingLeft: "0px",
          outline: "none",
        }}
      >
        <Menu
          selectedKeys={[current]}
          mode="horizontal"
          items={topMenuItems(setLanguage, t, user, avatar, handleLogout)}
          style={{ display: "flex", justifyContent: "space-between" }}
        />
      </div>
      <div className="breadcrumb-container fixed top-[60px] left-[280px] w-[calc(100%-280px)] p-[14PX] z-10 bg-white">
        <Breadcrumb items={generateBreadcrumbItems(pathname, t)} />
      </div>
      <div className="col-lg-3 flex">
        <div
          className=""
          style={{
            width: "270px",
            height: "100vh",
            overflowY: "auto",
            position: "fixed",
          }}
        >
          <Menu
            onClick={handleClick}
            style={{ width: 256 }}
            defaultSelectedKeys={["trangchu"]}
            defaultOpenKeys={["sub2"]}
            mode="inline"
            items={items(t, role)}
          />
        </div>
      </div>

      <div
        className="col-lg-9"
        style={{ marginLeft: "280px", paddingTop: "130px" }}
      >
        {isAccountPage && !isChildPage && <Navigate to="trangchu" replace />}
        {/* Thêm Outlet để hiển thị các route con */}
        <Outlet />
        <Chatbot />
      </div>
    </div>
  );
};
