import React, { useState } from "react";
import { Input, Button, Row, Col } from "antd";
import { SearchOutlined } from "@ant-design/icons";

const TimKiemMediaTour = ({ onSearch }) => {
  const [searchValue, setSearchValue] = useState("");

  const handleInputChange = (e) => setSearchValue(e.target.value);

  const handleSearchClick = () => {
    onSearch(searchValue); // Gọi hàm tìm kiếm với giá trị nhập
  };

  return (
    <Row gutter={16} align="middle">
      <Col>
        <Input
          size="large"
          placeholder="Nhập từ khóa tìm kiếm"
          value={searchValue}
          onChange={handleInputChange}
        />
      </Col>
      <Col>
        <Button
          icon={<SearchOutlined />}
          size="large"
          onClick={handleSearchClick}
        >
          Tìm kiếm
        </Button>
      </Col>
    </Row>
  );
};

export default TimKiemMediaTour;
