import React, { useState, useEffect } from "react";
import {
  Button,
  Checkbox,
  Form,
  Modal,
  Select,
  message,
  Upload,
  Image,
} from "antd";
import { PlusOutlined } from "@ant-design/icons";
import axios from "axios";
import {
  getStorage,
  ref,
  uploadString,
  getDownloadURL,
} from "firebase/storage";
import { initializeApp } from "firebase/app";

// Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyAtXg4mkxx1gic_VlvyxWcEloGZ6VFyymg",
  authDomain: "travel-e7f79.firebaseapp.com",
  projectId: "travel-e7f79",
  storageBucket: "travel-e7f79.appspot.com",
  messagingSenderId: "52519186637",
  appId: "1:52519186637:web:d0bb8aa8a499a7179b3984",
  measurementId: "G-HLNSGQZCPH",
};

const app = initializeApp(firebaseConfig);
const storage = getStorage(app);

const getBase64 = (file) =>
  new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => resolve(reader.result);
    reader.onerror = (error) => reject(error);
  });

const FormCapNhat = ({ visible, onCancel, userData, onUpdateSuccess }) => {
  const [componentDisabled, setComponentDisabled] = useState(false);
  const [loaiTourList, setLoaiTourList] = useState([]);
  const [fileList, setFileList] = useState([]); // For image uploads
  const [videoFile, setVideoFile] = useState(null); // For video uploads
  const [previewImage, setPreviewImage] = useState("");
  const [previewOpen, setPreviewOpen] = useState(false);

  useEffect(() => {
    const fetchLoaiTour = async () => {
      try {
        const response = await axios.get("http://localhost:8080/api/tours");
        setLoaiTourList(response.data);
      } catch (error) {
        console.error("Error fetching tour types:", error);
      }
    };

    fetchLoaiTour();

    // Pre-fill the form with existing image and video data
    if (userData) {
      if (userData.hinhAnh) {
        setFileList([
          {
            uid: "-1",
            name: "image.png", // Or any name you want
            status: "done",
            url: userData.hinhAnh,
          },
        ]);
      }
      if (userData.video) {
        setVideoFile({
          uid: "-1",
          name: "video.mp4", // Or any name you want
          status: "done",
          url: userData.video,
        });
      }
    }
  }, [userData]);

  const handlePreview = async (file) => {
    if (!file.url && !file.preview) {
      file.preview = await getBase64(file.originFileObj);
    }
    setPreviewImage(file.url || file.preview);
    setPreviewOpen(true);
  };

  // const handleChange = ({ fileList: newFileList }) => setFileList(newFileList);

  const uploadButton = (
    <div>
      <PlusOutlined />
      <div style={{ marginTop: 8 }}>Tải lên</div>
    </div>
  );

  const handleChange = ({ fileList: newFileList }) => {
    // Ensure that the files have the correct format
    if (newFileList.every((file) => file.originFileObj instanceof Blob)) {
      setFileList(newFileList);
    }
  };

  const handleVideoChange = ({ fileList: newFileList }) => {
    if (
      newFileList.length > 0 &&
      newFileList[0].originFileObj instanceof Blob
    ) {
      setVideoFile(newFileList[0]);
    } else {
      setVideoFile(null); // Clear if not valid
    }
  };

  const uploadImageToFirebase = async (base64Image) => {
    try {
      const imageRef = ref(storage, `images/${Date.now()}.png`);
      await uploadString(imageRef, base64Image, "data_url");
      return await getDownloadURL(imageRef);
    } catch (error) {
      console.error("Error uploading image to Firebase:", error);
      throw error;
    }
  };

  const uploadVideoToFirebase = async (file) => {
    try {
      // Ensure that `file` is a Blob/File object
      const videoBlob = file.originFileObj; // Extract the actual File object
      const videoRef = ref(storage, `videos/${Date.now()}_${videoBlob.name}`);
      await uploadString(videoRef, await getBase64(videoBlob), "data_url");
      return await getDownloadURL(videoRef);
    } catch (error) {
      console.error("Error uploading video to Firebase:", error);
      throw error;
    }
  };

  const onFinish = async (values) => {
    const hinhAnhBase64 =
      fileList.length > 0 ? await getBase64(fileList[0].originFileObj) : "";

    const hinhAnhUrl = hinhAnhBase64
      ? await uploadImageToFirebase(hinhAnhBase64)
      : null;

    // Check if videoFile is available and has the originFileObj property
    const videoUrl =
      videoFile && videoFile.originFileObj
        ? await uploadVideoToFirebase(videoFile)
        : null;

    const tourData = {
      tour: { id: values.tour },
      hinhAnh: hinhAnhUrl,
      video: videoUrl,
    };

    try {
      // Use PUT request for updating media tour
      const response = await axios.put(
        `http://localhost:8080/api/mediatour/update/${userData.id}`, // Pass the ID from userData
        tourData
      );

      if (response.status === 200) {
        message.success("Cập nhật giảm giá thành công!");
        onUpdateSuccess(); // Trigger success callback
        onCancel();
      }
    } catch (error) {
      message.error("Cập nhật thất bại. Vui lòng thử lại.");
      console.error("Error updating discount:", error);
    }
  };

  return (
    <div className="container-fluid mt-5">
      <Modal
        title="Cập Nhật Giảm Giá"
        visible={visible}
        onCancel={onCancel}
        footer={null}
        width={900}
      >
        <Checkbox
          className="mb-3"
          checked={componentDisabled}
          onChange={(e) => setComponentDisabled(e.target.checked)}
        >
          Vô hiệu hóa biểu mẫu
        </Checkbox>
        <Form
          layout="vertical"
          disabled={componentDisabled}
          onFinish={onFinish}
          initialValues={{
            tour: userData?.tour?.id,
          }}
        >
          <div className="row">
            <div className="col-lg-6">
              <Form.Item
                label="Tour"
                name="tour"
                rules={[{ required: true, message: "Tour không bỏ trống!" }]}
              >
                <Select placeholder="Chọn Tour">
                  {loaiTourList.map((item) => (
                    <Select.Option key={item.id} value={item.id}>
                      {item.tenTour}
                    </Select.Option>
                  ))}
                </Select>
              </Form.Item>
            </div>
            <div className="col-lg-6">
              <Form.Item label="Hình Ảnh" name="hinhAnh">
                <Upload
                  listType="picture-card"
                  fileList={fileList}
                  onPreview={handlePreview}
                  onChange={handleChange}
                >
                  {fileList.length >= 1 ? null : uploadButton}
                </Upload>
                <Modal
                  visible={previewOpen}
                  title="Xem trước hình ảnh"
                  footer={null}
                  onCancel={() => setPreviewOpen(false)}
                >
                  <Image
                    alt="example"
                    style={{ width: "100%" }}
                    src={previewImage}
                  />
                </Modal>
              </Form.Item>
            </div>
            <div className="col-lg-6">
              <Form.Item label="Video" name="video">
                <Upload
                  accept="video/*"
                  listType="text"
                  fileList={videoFile ? [videoFile] : []}
                  onChange={handleVideoChange}
                  showUploadList={false}
                >
                  {videoFile ? (
                    <Button>Video đã được chọn</Button>
                  ) : (
                    uploadButton
                  )}
                </Upload>
              </Form.Item>
            </div>
          </div>
          <div className="text-right">
            <Button onClick={onCancel}>Quay lại</Button>
            <Button
              style={{ marginLeft: 10 }}
              type="primary"
              htmlType="submit"
              className="mr-3"
            >
              Cập Nhật MediaTour
            </Button>
          </div>
        </Form>
      </Modal>
    </div>
  );
};

export default FormCapNhat;
