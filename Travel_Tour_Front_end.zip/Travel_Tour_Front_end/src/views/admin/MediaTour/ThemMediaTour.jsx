import React, { useEffect, useState } from "react";
import {
  Button,
  Checkbox,
  Form,
  Modal,
  Upload,
  Image,
  Select,
  message,
} from "antd";
import { PlusOutlined } from "@ant-design/icons";
import axios from "axios";
import "bootstrap/dist/css/bootstrap.min.css";
import { initializeApp } from "firebase/app";
import "./style.css";
import {
  getStorage,
  ref,
  uploadString,
  getDownloadURL,
} from "firebase/storage";

// Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyAtXg4mkxx1gic_VlvyxWcEloGZ6VFyymg",
  authDomain: "travel-e7f79.firebaseapp.com",
  projectId: "travel-e7f79",
  storageBucket: "travel-e7f79.appspot.com",
  messagingSenderId: "52519186637",
  appId: "1:52519186637:web:d0bb8aa8a499a7179b3984",
  measurementId: "G-HLNSGQZCPH",
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const storage = getStorage(app);

const getBase64 = (file) =>
  new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => resolve(reader.result);
    reader.onerror = (error) => reject(error);
  });

const FormThemMediaTour = ({ visible, onCancel, onBack, reloadData }) => {
  const [componentDisabled, setComponentDisabled] = useState(false);
  const [previewOpen, setPreviewOpen] = useState(false);
  const [previewImage, setPreviewImage] = useState("");
  const [fileList, setFileList] = useState([]);
  const [loaiTourList, setLoaiTourList] = useState([]);
  const [videoFile, setVideoFile] = useState(null);

  useEffect(() => {
    const fetchTourData = async () => {
      try {
        const response = await axios.get("http://localhost:8080/api/tours"); // Unified API endpoint
        const loaiTour = response.data; // Assuming response returns { loaiTour, danhMucTour }

        setLoaiTourList(loaiTour);
        // setDanhMucTourList(danhMucTour);
      } catch (error) {
        console.error(
          "Lỗi khi lấy danh sách loại tour và danh mục tour:",
          error
        );
      }
    };

    fetchTourData();
  }, []);

  const handlePreview = async (file) => {
    if (!file.url && !file.preview) {
      file.preview = await getBase64(file.originFileObj);
    }
    setPreviewImage(file.url || file.preview);
    setPreviewOpen(true);
  };

  const handleChange = ({ fileList: newFileList }) => setFileList(newFileList);

  const uploadButton = (
    <div>
      <PlusOutlined />
      <div style={{ marginTop: 8 }}>Tải lên</div>
    </div>
  );
  const handleVideoChange = ({ fileList: newFileList }) => {
    setVideoFile(newFileList[0]?.originFileObj || null); // Store the first video file
  };

  const uploadImageToFirebase = async (base64Image) => {
    try {
      const imageRef = ref(storage, `images/${Date.now()}.png`);
      await uploadString(imageRef, base64Image, "data_url");
      return await getDownloadURL(imageRef);
    } catch (error) {
      console.error("Lỗi khi upload hình ảnh lên Firebase:", error);
      throw error;
    }
  };
  const uploadVideoToFirebase = async (file) => {
    try {
      const videoRef = ref(storage, `videos/${Date.now()}_${file.name}`);
      await uploadString(videoRef, await getBase64(file), "data_url");
      return await getDownloadURL(videoRef);
    } catch (error) {
      console.error("Lỗi khi upload video lên Firebase:", error);
      throw error;
    }
  };

  const onFinish = async (values) => {
    const hinhAnhBase64 =
      fileList.length > 0 ? await getBase64(fileList[0].originFileObj) : "";

    const hinhAnhUrl = hinhAnhBase64
      ? await uploadImageToFirebase(hinhAnhBase64)
      : null;

    const videoUrl = videoFile ? await uploadVideoToFirebase(videoFile) : null;

    const tourData = {
      tour: { id: values.tour },
      hinhAnh: hinhAnhUrl,
      video: videoUrl,
    };

    const response = await axios.post(
      "http://localhost:8080/api/mediatour/them",
      tourData
    );

    if (response.status === 200) {
      reloadData(); // Refresh danh sách tour sau khi thêm thành công
      message.success("Giảm giá đã được thêm thành công!");
      onCancel();
    }
  };

  return (
    <div className="container-fluid mt-5">
      <Modal
        title="Thêm MediaTour"
        visible={visible}
        onCancel={onCancel}
        footer={null}
        width={900}
      >
        <Checkbox
          className="mb-3"
          checked={componentDisabled}
          onChange={(e) => setComponentDisabled(e.target.checked)}
        >
          Vô hiệu hóa biểu mẫu
        </Checkbox>
        <Form
          layout="vertical"
          disabled={componentDisabled}
          onFinish={onFinish}
        >
          <div className="row">
            <div className="col-lg-6">
              <Form.Item
                label="Tour"
                name="tour"
                rules={[{ required: true, message: "Tour không bỏ trống!" }]}
              >
                <Select placeholder="Chọn Tour">
                  {loaiTourList?.map((item) => (
                    <Select.Option key={item.id} value={item.id}>
                      {item?.tenTour} {/* Display the name here */}
                    </Select.Option>
                  ))}
                </Select>
              </Form.Item>
            </div>
            <div className="col-lg-6">
              <Form.Item label="Hình Ảnh" name="hinhAnh">
                <Upload
                  listType="picture-card"
                  fileList={fileList}
                  onPreview={handlePreview}
                  onChange={handleChange}
                  // className={fileList.length === 0 ? "upload-error" : ""}
                >
                  {fileList.length >= 1 ? null : uploadButton}
                </Upload>
                <Modal
                  visible={previewOpen}
                  title="Xem trước hình ảnh"
                  footer={null}
                  onCancel={() => setPreviewOpen(false)}
                >
                  <Image
                    alt="example"
                    style={{ width: "100%" }}
                    src={previewImage}
                  />
                </Modal>
              </Form.Item>
            </div>
            <div className="col-lg-6">
              <Form.Item label="Video" name="video">
                <Upload
                  accept="video/*" // Accept only video files
                  listType="text"
                  fileList={videoFile ? [videoFile] : []} // Display the selected video file
                  onChange={handleVideoChange}
                  showUploadList={false} // Hide default upload list
                >
                  {videoFile ? (
                    <Button>Video đã được chọn</Button>
                  ) : (
                    uploadButton // Show upload button if no file is selected
                  )}
                </Upload>
              </Form.Item>
            </div>
          </div>
          <div className="text-right">
            <Button onClick={onBack}>Trở Về</Button>
            <Button style={{ marginLeft: 10 }} type="primary" htmlType="submit">
              Thêm MediaTour
            </Button>
          </div>
        </Form>
      </Modal>
    </div>
  );
};

export default FormThemMediaTour;
