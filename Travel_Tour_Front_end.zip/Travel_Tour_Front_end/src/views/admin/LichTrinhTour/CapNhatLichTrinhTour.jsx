import React, { useState, useEffect, useRef } from "react";
import {
  Button,
  Checkbox,
  Form,
  Input,
  Modal,
  DatePicker,
  Select,
  message,
} from "antd";
import axios from "axios";
import moment from "moment";
import { Editor } from "@tinymce/tinymce-react";
import { initializeApp } from "firebase/app";
import {
  getStorage,
  ref,
  uploadString,
  getDownloadURL,
} from "firebase/storage";
const { TextArea } = Input;

// Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyAtXg4mkxx1gic_VlvyxWcEloGZ6VFyymg",
  authDomain: "travel-e7f79.firebaseapp.com",
  projectId: "travel-e7f79",
  storageBucket: "travel-e7f79.appspot.com",
  messagingSenderId: "52519186637",
  appId: "1:52519186637:web:d0bb8aa8a499a7179b3984",
  measurementId: "G-HLNSGQZCPH",
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const storage = getStorage(app); // Initialize storage

// Function to convert file to base64
const getBase64 = (file) =>
  new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => resolve(reader.result);
    reader.onerror = (error) => reject(error);
  });

const FormCapNhatLichTrinhTour = ({
  visible,
  onCancel,
  userData, // This will hold data from selected row
  onUpdateSuccess,
}) => {
  const [form] = Form.useForm();
  const [componentDisabled, setComponentDisabled] = useState(false);
  const [bienTheTourList, setBienTheTourList] = useState([]);
  const editorRef = useRef(null);

  // Fetch tour types when component mounts
  useEffect(() => {
    const fetchBienTheTourData = async () => {
      try {
        const response = await axios.get(
          "http://localhost:8080/api/bienthetour/tours"
        );
        setBienTheTourList(response.data);
      } catch (error) {
        console.error("Error fetching BienTheTour data:", error);
      }
    };

    fetchBienTheTourData();
  }, []);

  // Form submission handler
  const onFinish = async (values) => {
    const noiDung = editorRef.current.getContent();

    const formData = {
      bienTheTour: { id: values.bienTheTour },
      tieuDe: values.tieuDe,
      moTa: values.moTa,
      thoiGianBatDau: values.thoiGianBatDau,
      thoiGianKetThuc: values.thoiGianKetThuc,
      noiDung,
      ngay: values.ngay,
    };
    if (userData?.id) {
      const response = await axios.put(
        `http://localhost:8080/api/lichtrinhtour/update/${userData.id}`,
        formData
      );
      onUpdateSuccess();
      console.log(response.data);
      message.success("Cập nhật Lịch trình tour thành công");
    } else {
      message.error("Không tìm thấy Lịch trình tour để cập nhật");
    }

    onCancel();
  };

  // When a row in table is selected, populate the form with data
  useEffect(() => {
    if (userData) {
      form.setFieldsValue({
        bienTheTour: userData.bienTheTour?.id,
        tieuDe: userData.tieuDe,
        moTa: userData.moTa,
        thoiGianBatDau: userData.thoiGianBatDau,
        thoiGianKetThuc: userData.thoiGianKetThuc,
        ngay: userData.ngay ? moment(userData.ngay) : null,
        // Set the content of TinyMCE editor
      });
      // Set the content of TinyMCE editor
      if (editorRef.current) {
        editorRef.current.setContent(userData.noiDung || "");
      }
    }
  }, [userData, form]);
  return (
    <div className="container-fluid mt-5">
      <Modal
        title="Cập Nhật Lịch Trình Tour"
        visible={visible}
        onCancel={onCancel}
        footer={null}
        width={900}
      >
        <Checkbox
          className="mb-3"
          checked={componentDisabled}
          onChange={(e) => setComponentDisabled(e.target.checked)}
        >
          Vô hiệu hóa biểu mẫu
        </Checkbox>
        <Form
          layout="vertical"
          disabled={componentDisabled}
          onFinish={onFinish}
          form={form}
        >
          <div className="row">
            <div className="col-lg-6">
              <Form.Item
                label="Tour"
                name="bienTheTour"
                rules={[{ required: true, message: "Tour không bỏ trống!" }]}
              >
                <Select placeholder="Chọn Tour">
                  {bienTheTourList?.map((item) => (
                    <Select.Option key={item?.id} value={item?.id}>
                      {item?.tour?.tenTour}{" "}
                    </Select.Option>
                  ))}
                </Select>
              </Form.Item>
            </div>
            <div className="col-lg-6">
              <Form.Item
                label="Tiêu Đề"
                name="tieuDe"
                rules={[{ required: true, message: "Tiêu Đề không bỏ trống!" }]}
              >
                <Input className="rounded-lg text-xs" />
              </Form.Item>
            </div>
            <div className="col-lg-6">
              <Form.Item
                label="Ngày"
                name="ngay"
                rules={[{ required: true, message: "Ngày không bỏ trống!" }]}
              >
                <DatePicker className="w-100" format="DD/MM/YYYY" />
              </Form.Item>
            </div>
            <div className="col-lg-6">
              <Form.Item
                label="Thời Gian Bắt Đầu"
                name="thoiGianBatDau"
                rules={[
                  {
                    required: true,
                    message: "Thời Gian Bắt Đầu không bỏ trống!",
                  },
                ]}
              >
                <Input className="rounded-lg text-xs" />
              </Form.Item>
            </div>
            <div className="col-lg-6">
              <Form.Item
                label="Thời Gian Kết Thúc"
                name="thoiGianKetThuc"
                rules={[
                  {
                    required: true,
                    message: "Thời Gian Kết Thúc không bỏ trống!",
                  },
                ]}
              >
                <Input className="rounded-lg text-xs" />
              </Form.Item>
            </div>
            {/* TinyMCE Content */}
            <div className="col-lg-12">
              <Form.Item
                label="Nội Dung"
                rules={[
                  { required: true, message: "Nội Dung không bỏ trống!" },
                ]}
              >
                <Editor
                  apiKey="4bscneoksvcb1t8gkcv05q02fz4oqvv6n4pxk59anep55a4t"
                  onInit={(_, editor) => (editorRef.current = editor)}
                  initialValue={userData?.noiDung || ""}
                  init={{
                    height: 300,
                    menubar: false,
                    plugins: [
                      "advlist",
                      "autolink",
                      "lists",
                      "link",
                      "image",
                      "charmap",
                      "preview",
                      "anchor",
                      "searchreplace",
                      "visualblocks",
                      "code",
                      "fullscreen",
                      "insertdatetime",
                      "media",
                      "table",
                      "help",
                      "wordcount",
                    ],
                    toolbar:
                      "undo redo | blocks | " +
                      "bold italic forecolor | alignleft aligncenter " +
                      "alignright alignjustify | bullist numlist outdent indent | " +
                      "removeformat | image | help",
                    content_style:
                      "body { font-family:Helvetica,Arial,sans-serif; font-size:14px }",
                    file_picker_callback: (callback, value, meta) => {
                      // Tạo input chọn file
                      const input = document.createElement("input");
                      input.setAttribute("type", "file");
                      input.setAttribute("accept", "image/*");

                      // Khi người dùng chọn file
                      // Khi người dùng chọn file
                      input.onchange = async function () {
                        const file = this.files[0];
                        if (file) {
                          try {
                            // Chuyển file thành base64
                            const base64 = await getBase64(file);

                            // Upload lên Firebase Storage
                            const storageRef = ref(
                              storage,
                              `images/${file.name}`
                            );
                            await uploadString(storageRef, base64, "data_url");

                            // Lấy URL của hình ảnh đã upload
                            const downloadURL = await getDownloadURL(
                              storageRef
                            );

                            // Gọi callback để chèn URL vào trong nội dung của TinyMCE
                            callback(downloadURL, { alt: file.name });
                          } catch (error) {
                            console.error("Error uploading image:", error);
                          }
                        }
                      };

                      input.click();
                    },
                  }}
                />
              </Form.Item>
            </div>

            <div className="col-lg-12">
              <Form.Item label="Mô Tả" name="moTa">
                <TextArea rows={4} />
              </Form.Item>
            </div>
          </div>
          <div className="text-right">
            <Button onClick={onCancel}>Quay lại</Button>
            <Button
              style={{ marginLeft: 10 }}
              type="primary"
              htmlType="submit"
              className="mr-3"
            >
              Cập Nhật
            </Button>
          </div>
        </Form>
      </Modal>
    </div>
  );
};

export default FormCapNhatLichTrinhTour;
