import React, { useState, useEffect } from "react";
import {
  Table,
  Tooltip,
  Button,
  ConfigProvider,
  Space,
  message,
  Modal,
} from "antd";
import {
  AntDesignOutlined,
  DeleteOutlined,
  HighlightTwoTone,
} from "@ant-design/icons";
// import TimKiem from "./TimKiem_Tour.jsx"; // Thành phần tìm kiếm
import ThemLichTrinhTour from "./ThemLichTrinhTour.jsx"; // Thành phần thêm Giảm giá
import CapNhatLichTrinhTour from "./CapNhatLichTrinhTour.jsx"; // Thành phần cập nhật Giảm giá
import axios from "axios"; // Thư viện gọi API
import { useNavigate } from "react-router-dom";
// import { ellipsis } from "@tiptap/pm/inputrules";

// Cột dữ liệu của bảng

const stripHtml = (html) => {
  const doc = new DOMParser().parseFromString(html, "text/html");
  return doc.body.textContent || "";
};
const columns = (navigateToLichTrinhTour, showEditModal, handleDelete) => [
  {
    title: "STT",
    dataIndex: "id",
    key: "id",
    fixed: "left",
    render: (_, record, index) => (
      <Tooltip placement="topLeft" title={`Tour ID: ${record.tenTour}`}>
        <a
          href="#!"
          aria-label={`Tour ID: ${record.tenTour}`} // Thêm aria-label cho thẻ a
          onClick={(e) => {
            e.preventDefault();
            navigateToLichTrinhTour(record.tenTour); // Gọi hàm điều hướng
          }}
        ></a>
        {index + 1}
      </Tooltip>
    ),
    width: 70,
  },
  {
    title: "Tên Tour",
    dataIndex: "bienTheTour",
    key: "bienTheTour",
    ellipsis: {
      showTitle: false,
    },
    // render: (bienTheTour) => (
    //   <Tooltip placement="topLeft" title={bienTheTour}>
    //     {bienTheTour?.tour?.tenTour}
    //   </Tooltip>
    // ),
    render: (bienTheTour) => {
      const tenTour = bienTheTour?.tour?.tenTour || "Không xác định";
      return (
        <Tooltip placement="topLeft" title={tenTour}>
          {tenTour}
        </Tooltip>
      );
    },
  },
  {
    title: "Tiêu Đề",
    dataIndex: "tieuDe",
    key: "tieuDe",
    ellipsis: {
      showTitle: false,
    },
    render: (tieuDe) => (
      <Tooltip placement="topLeft" title={tieuDe}>
        {tieuDe}
      </Tooltip>
    ),
  },
  {
    title: "Thời Gian Bắt Đầu",
    dataIndex: "thoiGianBatDau",
    key: "thoiGianBatDau",
    ellipsis: {
      showTitle: false,
    },
    render: (thoiGianBatDau) => (
      <Tooltip placement="topLeft" title={thoiGianBatDau}>
        {thoiGianBatDau}
      </Tooltip>
    ),
  },
  {
    title: "Thời Gian Kết Thúc",
    dataIndex: "thoiGianKetThuc",
    key: "thoiGianKetThuc",
    ellipsis: {
      showTitle: false,
    },
    render: (thoiGianKetThuc) => (
      <Tooltip placement="topLeft" title={thoiGianKetThuc}>
        {thoiGianKetThuc}
      </Tooltip>
    ),
  },
  {
    title: "Nội Dung",
    dataIndex: "noiDung",
    key: "noiDung",
    ellipsis: {
      showTitle: false,
    },
    render: (noiDung) => (
      <Tooltip placement="topLeft" title={stripHtml(noiDung)}>
        {stripHtml(noiDung)}
      </Tooltip>
    ),
  },
  {
    title: "Ngày",
    dataIndex: "ngay",
    key: "ngay",
    width: 120,
    render: (ngay) => (
      <Tooltip placement="topLeft" title={ngay}>
        {new Date(ngay).toLocaleString("vi-VN", {
          day: "2-digit",
          month: "2-digit",
          year: "numeric",
        })}{" "}
        {/* Định dạng ngày ở đây */}
      </Tooltip>
    ),
  },
  {
    title: "Mô Tả",
    dataIndex: "moTa",
    key: "moTa",
    ellipsis: {
      showTitle: false,
    },
    render: (moTa) => (
      <Tooltip placement="topLeft" title={moTa}>
        {moTa}
      </Tooltip>
    ),
  },
  {
    title: "",
    key: "action",
    render: (_, record) => (
      <Space size="middle">
        {/* Nút Sửa */}
        <Tooltip title="Cập nhật thông tin Lịch Trình Tour">
          <Button
            icon={<HighlightTwoTone />}
            onClick={() => showEditModal(record)} // Hiển thị modal với dữ liệu tour được chọn
          ></Button>
        </Tooltip>

        {/* Nút Xóa */}
        <Tooltip title="Xóa Lịch Trình Tour">
          <Button
            icon={<DeleteOutlined />}
            danger
            onClick={() =>
              handleDelete(record.id, record.bienTheTour?.tour?.tenTour)
            } // Gọi hàm xóa
          ></Button>
        </Tooltip>
      </Space>
    ),
  },
];

// Component chính
const FormLichTrinhTour = () => {
  const [visible, setVisible] = useState(false); // Trạng thái hiển thị modal
  const [editingUser, setEditingUser] = useState(null); // Trạng thái tour đang chỉnh sửa
  const [data, setData] = useState([]); // Dữ liệu bảng
  const navigate = useNavigate();
  const [tenTour, setTenTour] = useState(""); // Biến trạng thái lưu tên Tour
  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search);
    const tourName = urlParams.get("tenTour"); // Lấy tham số tenTour từ URL

    if (tourName) {
      setTenTour(tourName); // Cập nhật trạng thái tên Tour
      fetchTours(tourName); // Gọi API khi có tenTour trong URL
    } else {
      fetchTours(); // Gọi API lấy tất cả dữ liệu khi không có tham số
    }
  }, []);

  const navigateToLichTrinhTour = async (tenTour) => {
    try {
      // Giải mã lại tenDanhMuc nếu nó bị mã hóa
      const decodedTenTour = decodeURIComponent(tenTour);

      // Gọi API để lấy danh sách tour theo tên tour
      const response = await axios.get(
        `http://localhost:8080/api/lichtrinhtour/lichtrinhtour/${decodedTenTour}`
      );

      if (response.status === 200) {
        // Nếu có dữ liệu, điều hướng đến trang với dữ liệu đã lọc
        navigate(`/admin/lich-trinh-tour?tenTour=${decodedTenTour}`);
      } else {
        message.error("Không tìm thấy dữ liệu tour cho danh mục này.");
      }
    } catch (error) {
      console.error("Lỗi khi gọi API:", error);
      message.error("Lỗi khi gọi API.");
    }
  };

  // Hàm này sẽ được gọi khi trang được tải lại với URL có tham số tenDanhMuc
  const fetchTours = async (tenTour) => {
    try {
      const response = await axios.get(
        `http://localhost:8080/api/lichtrinhtour/lichtrinhtour/${tenTour}`
      );
      setData(response.data); // Cập nhật dữ liệu với các tour theo danh mục
      console.log(response.data);
    } catch (error) {
      message.error("Lỗi khi tải dữ liệu tour.");
    }
  };

  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search);
    const tenTour = urlParams.get("tenTour"); // Lấy tham số tenDanhMuc từ URL

    if (tenTour) {
      fetchTours(tenTour); // Gọi API khi có tenTour trong URL
    } else {
      fetchTours(); // Gọi API lấy tất cả dữ liệu khi không có tham số
    }
  }, []);
  useEffect(() => {
    fetchTours();
  }, []);
  const handleDelete = (id, tenTour) => {
    // Show the confirmation popup with the category name included
    Modal.confirm({
      title: `Bạn có chắc chắn muốn xóa Lịch Trình Tour với Tên Tour: ${tenTour}`, // Display the category name in the confirmation message
      okText: "Có", // Text for the OK button (Yes)
      cancelText: "Không", // Text for the Cancel button (No)
      onOk: async () => {
        // onOk is called when the user clicks "Yes"
        try {
          // Make the DELETE request to the backend
          await axios.delete(
            `http://localhost:8080/api/lichtrinhtour/delete/${id}`
          );

          // Remove the deleted item from the local state to update the UI
          setData((prevData) => prevData.filter((item) => item.id !== id));

          // Show success message
          message.success(`Đã xóa thành công: ${tenTour}`);
        } catch (error) {
          console.error("Lỗi khi xóa Lịch Trình Tour:", error);
          message.error("Không thể xóa Lich Trình Tour.");
        }
      },
      onCancel: () => {
        // Optionally, log or handle the cancel action
        console.log("Xóa bị hủy");
      },
    });
  };
  const handleUpdateSuccess = async () => {
    // try {
    //   const response = await axios.get(
    //     "http://localhost:8080/api/lichtrinhtour"
    //   );
    //   setData(response.data); // Cập nhật dữ liệu
    //   setVisible(false); // Đóng modal
    //   const sortedData = response.data.sort((a, b) => b.id - a.id);
    //   setData(sortedData); // Cập nhật dữ liệu đã được sắp xếp
    //   setEditingUser(null); // Xóa thông tin tour đang chỉnh sửa
    // } catch (error) {
    //   message.error("Không thể tải dữ liệu từ server.");
    // }
    const urlParams = new URLSearchParams(window.location.search);
    const tenTour = urlParams.get("tenTour"); // Lấy tham số tenDanhMuc từ URL

    if (tenTour) {
      fetchTours(tenTour); // Gọi API khi có tenTour trong URL
    } else {
      fetchTours(); // Gọi API lấy tất cả dữ liệu khi không có tham số
    }
  };

  const showModal = () => {
    setVisible(true); // Mở modal thêm tour
  };

  const handleCancel = () => {
    setVisible(false); // Đóng modal
    setEditingUser(null); // Reset trạng thái sau khi đóng modal
  };

  const showEditModal = (tour) => {
    setEditingUser(tour); // Đặt tour đang được chỉnh sửa
    setVisible(true); // Mở modal
  };

  return (
    <div className="container">
      <h3>Danh Sách Lịch Trình Tour</h3>
      {/* Nút "Thêm" */}
      <ConfigProvider>
        <div className="button-container">
          <Button
            className="nguoidung-them"
            type="primary"
            size="large"
            icon={<AntDesignOutlined />}
            onClick={showModal}
          >
            Thêm
          </Button>
        </div>
        <ThemLichTrinhTour
          visible={visible}
          onCancel={handleCancel}
          reloadData={fetchTours}
        />
      </ConfigProvider>
      {/* Tìm kiếm tour */}
      {/* <TimKiem /> */}
      {/* Bảng tour */}
      {/* <div
        className="table-container align-items-center"
        style={{ marginRight: "-100px" }}
      > */}
      <div
        className="table-container align-items-center"
        style={{ marginRight: "-100px" }}
      >
        {data.length === 0 ? (
          // Hiển thị thông báo khi không có dữ liệu
          <div style={{ textAlign: "center", marginTop: "20px" }}>
            <h4>
              Không có Lịch Trình Tour nào cho Tour:{" "}
              <strong style={{ textTransform: "uppercase" }}>
                {decodeURIComponent(tenTour || "Không xác định")}
              </strong>
            </h4>
          </div>
        ) : (
          // Hiển thị bảng khi có dữ liệu
          <Table
            columns={columns(
              navigateToLichTrinhTour,
              showEditModal,
              handleDelete
            )}
            scroll={{ x: 1800 }}
            dataSource={data} // Map dữ liệu API vào bảng
            rowKey="id" // Đặt rowKey là id
          />
        )}
      </div>
      {/* </div> */}
      {/* Modal cập nhật tour */}
      {editingUser && (
        <CapNhatLichTrinhTour
          visible={visible}
          onCancel={handleCancel}
          userData={editingUser} // Tên biến truyền vào model phải trùng
          onUpdateSuccess={handleUpdateSuccess} // Gọi callback khi thành công
        />
      )}
    </div>
  );
};

export default FormLichTrinhTour;
