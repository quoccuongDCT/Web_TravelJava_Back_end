import React, { useEffect, useState, useRef } from "react";
import {
  Button,
  Checkbox,
  Form,
  DatePicker,
  Input,
  Modal,
  Select,
  message,
} from "antd";
import axios from "axios";
import "bootstrap/dist/css/bootstrap.min.css";
import "./style.css";
import { Editor } from "@tinymce/tinymce-react";
import { initializeApp } from "firebase/app";

import { GoogleGenerativeAI } from "@google/generative-ai";
import {
  getStorage,
  ref,
  uploadString,
  getDownloadURL,
} from "firebase/storage";
const { TextArea } = Input;

// Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyAtXg4mkxx1gic_VlvyxWcEloGZ6VFyymg",
  authDomain: "travel-e7f79.firebaseapp.com",
  projectId: "travel-e7f79",
  storageBucket: "travel-e7f79.appspot.com",
  messagingSenderId: "52519186637",
  appId: "1:52519186637:web:d0bb8aa8a499a7179b3984",
  measurementId: "G-HLNSGQZCPH",
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const storage = getStorage(app); // Initialize storage

// Function to convert file to base64
const getBase64 = (file) =>
  new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => resolve(reader.result);
    reader.onerror = (error) => reject(error);
  });
const FormThemTour = ({ visible, onCancel, onBack, reloadData }) => {
  const [form] = Form.useForm();
  const [componentDisabled, setComponentDisabled] = useState(false);
  const [bienTheTourList, setBienTheTourList] = useState([]);
  const editorRef = useRef(null); // Khai báo editorRef
  const [selectedLichTrinhTour, setSelectedLichTrinhTour] = useState(null);
  const [loading, setLoading] = useState(null);
  const apiKey = "AIzaSyBNk4leALxM6dnL0ogzpnCYrr8H6OoUCO8"; // Tích hợp API key trực tiếp

  useEffect(() => {
    const fetchBienTheTourData = async () => {
      try {
        const response = await axios.get(
          "http://localhost:8080/api/bienthetour/tours"
        );
        const tours = response.data;

        setBienTheTourList(tours);

        // Lấy `tenTour` từ URL
        const urlParams = new URLSearchParams(window.location.search);
        const tenTour = urlParams.get("tenTour");

        if (tenTour) {
          // Tìm tour phù hợp với `tenTour`
          const matchingTour = tours.find(
            (item) => item.tour.tenTour === decodeURIComponent(tenTour) // Giải mã `tenTour`
          );

          if (matchingTour) {
            setSelectedLichTrinhTour(matchingTour.id); // Đặt giá trị mặc định
            form.setFieldsValue({ bienTheTour: matchingTour.id }); // Đồng bộ với Form
          }
        }
      } catch (error) {
        console.error("Lỗi khi gọi API:", error);
        message.error("Không thể tải danh sách Tour!");
      }
    };

    if (visible) {
      fetchBienTheTourData();
    }
  }, [form, visible]);

  useEffect(() => {
    const fetchBienTheTourData = async () => {
      try {
        const response = await axios.get(
          "http://localhost:8080/api/bienthetour/tours"
        );
        setBienTheTourList(response.data);
      } catch (error) {
        console.error("Error fetching BienTheTour data:", error);
        message.error("Không thể tải danh sách Tour!");
      }
    };

    if (visible) {
      fetchBienTheTourData();
    }
  }, [visible]);

  const onFinish = async (values) => {
    const noiDung = editorRef.current?.getContent() || ""; // Lấy nội dung từ TinyMCE

    // Kiểm tra nội dung trước khi gửi
    if (!noiDung.trim()) {
      message.error("Nội Dung không được bỏ trống!");
      return;
    }

    const tourData = {
      bienTheTour: { id: values.bienTheTour },
      tieuDe: values.tieuDe,
      moTa: values.moTa || "",
      thoiGianBatDau: values.thoiGianBatDau,
      thoiGianKetThuc: values.thoiGianKetThuc,
      noiDung: noiDung,
      ngay: values.ngay.format("YYYY-MM-DD"),
    };

    console.log("Dữ liệu gửi đi:", tourData); // Log dữ liệu để kiểm tra

    try {
      const response = await axios.post(
        "http://localhost:8080/api/lichtrinhtour/them",
        tourData
      );
      if (response.status === 200 || response.status === 201) {
        reloadData();
        message.success("Lịch Trình Tour đã được thêm thành công!");
        form.resetFields(); // Reset form sau khi thành công
        if (editorRef.current) {
          editorRef.current.setContent(""); // Reset nội dung TinyMCE
        }
        onCancel();
      } else {
        throw new Error("Không thể thêm lịch trình tour!");
      }
    } catch (error) {
      console.error("Error adding Lịch Trình Tour:", error);
      message.error("Có lỗi xảy ra khi thêm lịch trình tour!");
    }
  };
  // ham gợi ý AI Gemini
  const handleGenerateContent = async () => {
    // Lấy giá trị từ URL
    const urlParams = new URLSearchParams(window.location.search);
    const tenTour = urlParams.get("tenTour");

    if (!tenTour) {
      message.error(
        "Không tìm thấy tên tour trong URL! Vui lòng kiểm tra lại."
      );
      return;
    }

    const prompt = `Hãy tạo một gợi ý lịch trình tour chi tiết cho tour: ${tenTour}`;
    setLoading(true);

    try {
      const genAI = new GoogleGenerativeAI(apiKey);
      const model = await genAI.getGenerativeModel({
        model: "gemini-1.5-flash",
      });
      const result = await model.generateContent(prompt);

      if (editorRef.current) {
        editorRef.current.setContent(result.response.text()); // Chèn nội dung vào TinyMCE
      }
    } catch (error) {
      console.error("Error generating content:", error);
      message.error("Không thể tạo gợi ý nội dung!");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="container-fluid mt-5">
      <Modal
        title="Thêm Lịch Trình Tour"
        open={visible}
        onCancel={onCancel}
        footer={null}
        width={900}
      >
        <Checkbox
          className="mb-3"
          checked={componentDisabled}
          onChange={(e) => setComponentDisabled(e.target.checked)}
        >
          Vô hiệu hóa biểu mẫu
        </Checkbox>
        <Form
          form={form}
          layout="vertical"
          disabled={componentDisabled}
          onFinish={onFinish}
        >
          <div className="row">
            {/* Chọn Tour */}
            <div className="col-lg-6">
              <Form.Item
                label="Tour"
                name="bienTheTour"
                rules={[
                  { required: true, message: "Tour không được bỏ trống!" },
                ]}
              >
                <Select
                  placeholder="Chọn Tour"
                  value={selectedLichTrinhTour} // Hiển thị giá trị từ URL
                  onChange={(value) => setSelectedLichTrinhTour(value)} // Cập nhật giá trị khi thay đổi
                  loading={!bienTheTourList.length} // Loading nếu chưa có dữ liệu
                >
                  {bienTheTourList?.map((item) => (
                    <Select.Option key={item.id} value={item.id} disabled>
                      {item.tour?.tenTour} {/* Hiển thị tên tour */}
                    </Select.Option>
                  ))}
                </Select>
              </Form.Item>
            </div>

            {/* Tiêu Đề */}
            <div className="col-lg-6">
              <Form.Item
                label="Tiêu Đề"
                name="tieuDe"
                rules={[{ required: true, message: "Tiêu Đề không bỏ trống!" }]}
              >
                <Input className="rounded-lg text-xs" />
              </Form.Item>
            </div>

            {/* Thời Gian Bắt Đầu */}
            <div className="col-lg-6">
              <Form.Item
                label="Thời Gian Bắt Đầu"
                name="thoiGianBatDau"
                rules={[
                  {
                    required: true,
                    message: "Thời Gian Bắt Đầu không bỏ trống!",
                  },
                ]}
              >
                <Input className="rounded-lg text-xs" />
              </Form.Item>
            </div>

            {/* Thời Gian Kết Thúc */}
            <div className="col-lg-6">
              <Form.Item
                label="Thời Gian Kết Thúc"
                name="thoiGianKetThuc"
                rules={[
                  {
                    required: true,
                    message: "Thời Gian Kết Thúc không bỏ trống!",
                  },
                ]}
              >
                <Input className="rounded-lg text-xs" />
              </Form.Item>
            </div>
            {/* Ngày */}
            <div className="col-lg-6">
              <Form.Item
                label="Ngày"
                name="ngay"
                rules={[{ required: true, message: "Ngày không bỏ trống!" }]}
              >
                <DatePicker className="w-100" format="DD/MM/YYYY" />
              </Form.Item>
            </div>

            {/* Nội Dung TinyMCE */}
            <div className="col-lg-12">
              <Form.Item
                label="Nội Dung"
                // Loại bỏ `name` để quản lý riêng nội dung TinyMCE
                rules={[
                  { required: true, message: "Nội Dung không bỏ trống!" },
                ]}
              >
                {" "}
                <Button
                  type="default"
                  onClick={handleGenerateContent}
                  disabled={!selectedLichTrinhTour || loading}
                >
                  {loading ? "Đang tạo gợi ý..." : "Gợi ý Nội Dung"}
                </Button>
                <Editor
                  apiKey="4bscneoksvcb1t8gkcv05q02fz4oqvv6n4pxk59anep55a4t"
                  onInit={(_, editor) => (editorRef.current = editor)}
                  initialValue=""
                  init={{
                    height: 300, // Giảm chiều cao để phù hợp hơn
                    menubar: false,
                    plugins: [
                      "advlist",
                      "autolink",
                      "lists",
                      "link",
                      "image",
                      "charmap",
                      "preview",
                      "anchor",
                      "searchreplace",
                      "visualblocks",
                      "code",
                      "fullscreen",
                      "insertdatetime",
                      "media",
                      "table",
                      "help",
                      "wordcount",
                    ],
                    toolbar:
                      "undo redo | blocks | " +
                      "bold italic forecolor | alignleft aligncenter " +
                      "alignright alignjustify | bullist numlist outdent indent | " +
                      "removeformat | image | help",
                    content_style:
                      "body { font-family:Helvetica,Arial,sans-serif; font-size:14px }",
                    file_picker_callback: (callback, value, meta) => {
                      // Tạo input chọn file
                      const input = document.createElement("input");
                      input.setAttribute("type", "file");
                      input.setAttribute("accept", "image/*");

                      // Khi người dùng chọn file
                      // Khi người dùng chọn file
                      input.onchange = async function () {
                        const file = this.files[0];
                        if (file) {
                          try {
                            // Chuyển file thành base64
                            const base64 = await getBase64(file);

                            // Upload lên Firebase Storage
                            const storageRef = ref(
                              storage,
                              `images/${file.name}`
                            );
                            await uploadString(storageRef, base64, "data_url");

                            // Lấy URL của hình ảnh đã upload
                            const downloadURL = await getDownloadURL(
                              storageRef
                            );

                            // Gọi callback để chèn URL vào trong nội dung của TinyMCE
                            callback(downloadURL, { alt: file.name });
                          } catch (error) {
                            console.error("Error uploading image:", error);
                          }
                        }
                      };

                      input.click();
                    },
                  }}
                />
              </Form.Item>
            </div>

            {/* Mô Tả */}
            <div className="col-lg-12">
              <Form.Item label="Mô Tả" name="moTa">
                <TextArea rows={4} />
              </Form.Item>
            </div>
          </div>

          {/* Nút Submit */}
          <div className="text-right">
            <Button onClick={onBack}>Trở Về</Button>
            <Button style={{ marginLeft: 10 }} type="primary" htmlType="submit">
              Thêm Lịch Trình Tour
            </Button>
          </div>
        </Form>
      </Modal>
    </div>
  );
};

export default FormThemTour;
