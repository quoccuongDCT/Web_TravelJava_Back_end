import React, { useEffect, useState } from "react";
import { Table, Tooltip, Button, ConfigProvider, Space, message } from "antd";
import { AntDesignOutlined, DeleteOutlined } from "@ant-design/icons";
import ThemPhanQuyen from "./ThemPhanQuyen.jsx";
import CapNhatPhanQuyen from "./CapNhatPhanQuyen.jsx";
import axios from "axios";

// Hàm columns cho bảng
const columns = (handleDelete) => [
  {
    title: "ID",
    dataIndex: "id",
    key: "id",
    render: (text) => (
      <a href="#!" onClick={(e) => e.preventDefault()}>
        {text}
      </a>
    ),
    width: 50,
  },
  {
    title: "Họ Tên",
    dataIndex: "hoTen",
    key: "hoTen",
    ellipsis: { showTitle: false },
    render: (ten) => (
      <Tooltip placement="topLeft" title={ten}>
        {ten}
      </Tooltip>
    ),
  },
  {
    title: "Email",
    dataIndex: "email",
    key: "email",
    ellipsis: { showTitle: false },
    render: (email) => (
      <Tooltip placement="topLeft" title={email}>
        {email}
      </Tooltip>
    ),
  },
  {
    title: "Chức năng",
    key: "chucNang",
    render: (_, record) => (
      <Tooltip title="Danh sách chức năng">
        <span>{record.chucNang || "Không có chức năng"}</span> {/* Hiển thị chức năng */}
      </Tooltip>
    ),
    width: 250,
  },
  {
    title: "",
    key: "action",
    render: (_, record) => (
      <Space size="middle">
        <Button
          icon={<DeleteOutlined />}
          danger
          onClick={() => handleDelete(record.id)} // Gọi hàm xóa
        />
      </Space>
    ),
  },
];

const PhanQuyenForm = () => {
  const [visible, setVisible] = useState(false);
  const [editingUser, setEditingUser] = useState(null);
  const [data, setData] = useState([]);

  // Fetch dữ liệu người dùng với vai trò 2
  useEffect(() => {
    fetchUsersWithRole2();
  }, []);

  // Lấy danh sách người dùng có vai trò 2
  const fetchUsersWithRole2 = async () => {
    try {
      const response = await axios.get("http://localhost:8080/api/nguoidung?vaiTroId=2");
      const users = response.data;

      // Lấy chức năng cho từng người dùng
      const usersWithFunctions = await Promise.all(
        users.map(async (user) => {
          const chucNang = await fetchFunctionList(user.id);
          return {
            ...user,
            chucNang, // Thêm chức năng vào người dùng
          };
        })
      );

      setData(usersWithFunctions);
    } catch (error) {
      message.error("Không thể tải dữ liệu tài khoản");
      console.error("Error fetching users with role 2:", error);
    }
  };

  // Lấy danh sách chức năng của người dùng
  const fetchFunctionList = async (idNguoiDung) => {
    try {
      const response = await axios.get(`http://localhost:8080/api/phan-quyen/nguoi-dung-voi-chuc-nang`);
      const chucNangData = response.data.filter((item) => item.id === idNguoiDung);

      return chucNangData.map((item) => item.chucNang).join(", "); // Hiển thị danh sách chức năng
    } catch (error) {
      console.error(`Lỗi Không thể lấy được chức năng cho người dùng ${idNguoiDung}:`, error);
      return "";
    }
  };

  // Hiển thị modal thêm quyền
  const showModal = () => {
    setVisible(true);
  };

  // Đóng modal
  const handleCancel = () => {
    setVisible(false);
    setEditingUser(null);
  };


  // Xóa quyền
  const handleDelete = async (idNguoiDung) => {
    try {
      if (!idNguoiDung) {
        console.log("ID người dùng không hợp lệ");
        return;
      }
  
      // Gọi API xóa tất cả phân quyền của người dùng
      const response = await axios.delete(`http://localhost:8080/api/phan-quyen/nguoi-dung/${idNguoiDung}`);
  
      if (response.status === 204) {
        message.success("Xóa tất cả quyền thành công!");
        fetchUsersWithRole2(); // Cập nhật lại danh sách người dùng
      }
    } catch (error) {
      console.error("Lỗi khi xóa quyền:", error);
      message.error("Không thể xóa quyền. Vui lòng thử lại.");
    }
  };
  
  return (
    <div className="container">
      <h3>Quản Lý Phân Quyền Nhân Viên</h3>

      <ConfigProvider>
        <Space>
          <Button
            className="nguoidung-them"
            type="primary"
            size="large"
            icon={<AntDesignOutlined />}
            onClick={showModal}
          >
            Phân quyền cho nhân viên
          </Button>
        </Space>

        {/* Truyền callback fetchUsersWithRole2 vào ThemPhanQuyen */}
        <ThemPhanQuyen visible={visible} onCancel={handleCancel} onAddSuccess={fetchUsersWithRole2} />
      </ConfigProvider>

      <div className="table-container align-items-center" style={{ marginRight: "-100px" }}>
        <Table columns={columns(handleDelete)} dataSource={data} rowKey="id" />
      </div>

      {editingUser && (
        <CapNhatPhanQuyen
          visible={visible}
          onCancel={handleCancel}
          user={editingUser}
        />
      )}
    </div>
  );
};

export default PhanQuyenForm;
