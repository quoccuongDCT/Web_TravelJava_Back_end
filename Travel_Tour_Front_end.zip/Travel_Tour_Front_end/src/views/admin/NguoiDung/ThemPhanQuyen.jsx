import React, { useState, useEffect } from "react";
import { Button, Checkbox, Form, Select, Modal, message, Table, Space, Tooltip } from "antd";
import "bootstrap/dist/css/bootstrap.min.css";
import axios from 'axios';

const FormThemPhanQuyen = ({ visible, onCancel, onBack, onAddSuccess  }) => {
  const [users, setUsers] = useState([]);
  const [functions, setFunctions] = useState([]);
  const [selectedFunctions, setSelectedFunctions] = useState([]); 
  const [selectedEmail, setSelectedEmail] = useState(null); 
  const [userPermissions, setUserPermissions] = useState([]); 

  const fetchUsers = async () => {
    try {
      const response = await fetch("http://localhost:8080/api/nguoidung?vaiTroId=2");
      const data = await response.json();
      setUsers(data);
    } catch (error) {
      console.error("Error fetching users:", error);
    }
  };

  const fetchFunctions = async () => {
    try {
      const response = await fetch("http://localhost:8080/api/chuc-nang");
      const data = await response.json();
      setFunctions(data);
    } catch (error) {
      console.error("Error fetching functions:", error);
    }
  };

  const fetchUserPermissions = async (email) => {
    try {
      const response = await fetch(`http://localhost:8080/api/phan-quyen/${email}`);
      const data = await response.json();
      setUserPermissions(data);
      const existingPermissions = data.map((permission) => permission.idChucNang);
      setSelectedFunctions(existingPermissions);
    } catch (error) {
      console.error("Error fetching user permissions:", error);
    }
  };

  useEffect(() => {
    fetchUsers();
    fetchFunctions();
  }, []);

  const handleUserChange = (email) => {
    setSelectedEmail(email);
    fetchUserPermissions(email);
  };

  const handleAssignPermissions = async () => {
    try {
      const email = selectedEmail;
      const functionIds = selectedFunctions; 

      if (!functionIds || functionIds.length === 0) {
        message.error("Bạn cần chọn ít nhất một chức năng!");
        return;
      }

      if (!email) {
        message.error("Không tìm thấy người dùng!");
        return;
      }

      const response = await axios.post("http://localhost:8080/api/phan-quyen", {
        emailNhanVien: email, 
        idChucNang: functionIds, 
      });

      if (response.status === 200) {
        message.success("Cấp quyền thành công!");
        setSelectedFunctions([]); 
        setSelectedEmail(null); 
        setUserPermissions([]); 
        onAddSuccess();
        onCancel(); 
      }
    } catch (error) {
      message.error("Một số quyền đã được cấp trước đó vui lòng kiểm tra lại!.");
      if (error.response) {
        console.error("Backend Error:", error.response.data); 
      } else {
        console.error("Error:", error.message);
      }
    }
  };

  const columns = [
    {
      title: "#",
      dataIndex: "id",
      key: "id",
      render: (text) => <span>{text}</span>,
      width: 50,
    },
    {
      title: "Chức năng",
      dataIndex: "tenChucNang",
      key: "tenChucNang",
      render: (tenChucNang) => (
        <Tooltip placement="topLeft" title={tenChucNang}>
          {tenChucNang}
        </Tooltip>
      ),
    },
    {
      title: "Mô tả",
      dataIndex: "moTa",
      key: "moTa",
      render: (moTa) => (
        <Tooltip placement="topLeft" title={moTa}>
          {moTa}
        </Tooltip>
      ),
    },
    {
      title: "",
      key: "action",
      render: (_, record) => (
        <Space size="middle">
          <Checkbox
            checked={selectedFunctions.includes(record.id)}
            onChange={(e) => {
              const newSelectedFunctions = e.target.checked
                ? [...selectedFunctions, record.id]
                : selectedFunctions.filter((id) => id !== record.id);
              setSelectedFunctions(newSelectedFunctions);
            }}
          />
        </Space>
      ),
      width: 60,
    },
  ];

  return (
    <div className="container-fluid mt-5">
      <Modal
        title="Phân Quyền Cho Nhân Viên"
        visible={visible}
        onCancel={onCancel}
        footer={null}
        width={900}
      >
        <Form layout="vertical" onFinish={handleAssignPermissions}>
          <div className="row">
            <div className="col-lg-12">
              <Form.Item
                label="Email Nhân Viên"
                rules={[{ required: true, message: "Email nhân viên không bỏ trống!" }]}
              >
                <Select
                  value={selectedEmail}
                  onChange={handleUserChange}
                >
                  {users.map((user) => (
                    <Select.Option key={user.id} value={user.email}>
                      {user.email}
                    </Select.Option>
                  ))}
                </Select>
              </Form.Item>
            </div>

            <div className="col-lg-12">
              <Form.Item label="Chức Năng">
                <Table
                  columns={columns}
                  dataSource={functions}
                  pagination={false}
                  rowKey="id"
                />
              </Form.Item>
            </div>
          </div>
          <div className="d-flex justify-content-between mt-3">
            <Button className="btn btn-secondary" onClick={onBack}>
              Quay Lại
            </Button>
            <Button className="btn btn-primary" htmlType="submit">
              Xác Nhận
            </Button>
          </div>
        </Form>
      </Modal>
    </div>
  );
};

export default FormThemPhanQuyen;
