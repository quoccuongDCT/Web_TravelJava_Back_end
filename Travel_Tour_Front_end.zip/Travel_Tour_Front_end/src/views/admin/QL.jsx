// import React, { useState } from "react";
// import "bootstrap/dist/css/bootstrap.min.css";
// import {
//   AppstoreOutlined,
//   TeamOutlined,
//   CalendarOutlined,
//   MailOutlined,
//   SettingOutlined,
//   CopyOutlined,
//   DollarOutlined,
// } from "@ant-design/icons";
// import { Menu } from "antd";
// import NhanVienForm from "./NguoiDung/NhanVien"; // Import form Nhân Viên
// import KhachHangForm from "./NguoiDung/KhachHang"; // Import form Khách Hàng
// import PhanQuyenForm from "./NguoiDung/PhanQuyen"; // Import form Phân Quyền
// import LoaiTour from "./LoaiTour/LoaiTour"; // Import form Loại Tour
// import QuanLyTinTuc from "./TinTuc/QuanLyTinTuc"; //Import form Quản lý tin tức
// import BienTheTour from "./BienTheTour/QuanLyBienTheTour"; //Import from Biến thể Tour
// import LichTrinhTour from "./LichTrinhTour/LichTrinhTour"; //import from LichTrinh tour
// import Tour from "./Tour/Tour"; //import from Tour
// import QuanLyDanhGia from "./DanhGia/DanhGia"; //import from DanhGia tour
// import ChiTietHoaDon from "./ChiTietHoaDon/ChiTietHoaDon"; //import from Dặt tour
// import DanhSachNguoiDiCung from "./DanhSachNguoiDiCung/DanhSachNguoiDiCung"; //import from BienTheNguoiDung
// import HoaDon from "./HoaDon/HoaDon"; //import from ThanhToan
// import MediaTour from "./MediaTour/MediaTour"; //import from
// import DanhMucTour from "./DanhMucTour/DanhMucTour"; //
// import PhuongTien from "./PhuongTien/PhuongTien"; //
// import Hotels from "./Hotels/Hotels"; //
// import DanhSachGiaGiam from "./GiamGia/GiamGia"; //
// import YeuThich from "./YeuThich/YeuThich"; //
// import GioHangDanhSachNguoiDiCung from "./GioHangDanhSachNguoiDiCung/GioHangDanhSachNguoiDiCung";
// import ChiTietGioHang from "./ChiTietGioHang/ChiTietGioHang"; //Hang"; //

// import "./NguoiDung/Css/NhanVien.css";

// // Define menu items with nested structure
// const items = [
//   {
//     key: "sub1",
//     label: "Quản Lý Người Dùng",
//     icon: <TeamOutlined />,
//     children: [
//       {
//         key: "1",
//         label: "Nhân Viên",
//       },
//       {
//         key: "2",
//         label: "Phân Quyền",
//       },
//       {
//         key: "3",
//         label: "Khách Hàng",
//       },
//     ],
//   },
//   // {
//   //   key: "4",
//   //   icon: <SolutionOutlined />,
//   //   label: "Danh Sách Người Đi Cùng",
//   // },
//   {
//     key: "5",
//     icon: <CalendarOutlined />,
//     label: "Quản Lý Tin Tức",
//   },
//   {
//     key: "sub1-2",
//     label: "Quản Lý Thông Tin Tour",
//     icon: <AppstoreOutlined />,
//     children: [
//       {
//         key: "6",
//         label: "Giỏ hàng Danh sách người đi cùng",
//       },
//       {
//         key: "7",
//         label: "Quản lý Danh Mục Tour",
//       },
//       {
//         key: "8",
//         label: "Quản Lý Loại Tour",
//       },
//       {
//         key: "9",
//         label: "Tour",
//       },
//       {
//         key: "10",
//         label: "Lịch Trình Tour",
//       },
//       {
//         key: "11",
//         label: "MediaTour",
//       },
//       {
//         key: "12",
//         label: "Biến Thể Tour",
//       },
//       {
//         key: "sub2-1",
//         label: "Quản Lý Cấu Hình Tour",
//         children: [
//           {
//             key: "13",
//             label: "Phương Tiện",
//           },
//           {
//             key: "14",
//             label: "Hotels",
//           },
//           {
//             key: "15",
//             label: "Danh Sách Giá Giảm",
//           },
//         ],
//       },
//     ],
//   },
//   {
//     key: "16",
//     icon: <CopyOutlined />,
//     label: "Quản Lý Đánh Giá",
//   },
//   {
//     key: "17",
//     icon: <MailOutlined />,
//     label: "Chi Tiết Hóa Đơn ",
//   },
//   {
//     key: "18",
//     icon: <DollarOutlined />,
//     label: "Hóa Đơn ",
//   },
//   {
//     key: "19",
//     icon: <DollarOutlined />,
//     label: "Yêu Thích ",
//   },
//   {
//     key: "20",
//     icon: <DollarOutlined />,
//     label: "Chi Tiết Giỏ Hàng ",
//   },
//   {
//     key: "sub2",
//     label: "Thống Kê",
//     icon: <SettingOutlined />,
//     children: [
//       {
//         key: "21",
//         label: "Option 7",
//       },
//       {
//         key: "22",
//         label: "Option 8",
//       },
//     ],
//   },
// ];
// const item = [
//   {
//     label: (
//       <div style={{ height: "50px", fontFamily: "initial" }}>
//         <h2>TRAVEL</h2>
//       </div>
//     ),
//     key: "",
//   },
//   {
//     label: "Nguyễn Hoàng Ninh",
//     key: "SubMenu",
//     style: { marginRight: "auto" },
//     children: [
//       {
//         key: "23",
//         label: "Đăng xuất",
//       },
//     ],
//   },
// ];
// // Helper function to get the level of menu keys
// const getLevelKeys = (items1) => {
//   const key = {};
//   const func = (items2, level = 1) => {
//     items2.forEach((item) => {
//       if (item.key) {
//         key[item.key] = level;
//       }
//       if (item.children) {
//         func(item.children, level + 1);
//       }
//     });
//   };
//   func(items1);
//   return key;
// };
// const levelKeys = getLevelKeys(items);
// const FormQL = () => {
//   // const App = () => {
//   const [current, setCurrent] = useState("mail");
//   const onClick = (e) => {
//     console.log("click ", e);
//     setCurrent(e.key);
//   };
//   const [selectedKey, setSelectedKey] = useState(null);
//   const [stateOpenKeys, setStateOpenKeys] = useState(["sub1", "sub1-2"]);

//   // Handle menu item click
//   const handleClick = (e) => {
//     setSelectedKey(e.key);
//   };

//   // Render the appropriate form based on selected key
//   const renderForm = () => {
//     switch (selectedKey) {
//       case "1":
//         return <NhanVienForm />;
//       case "2":
//         return <PhanQuyenForm />;
//       case "3":
//         return <KhachHangForm />;
//       case "4":
//         return <DanhSachNguoiDiCung />;
//       case "5":
//         return <QuanLyTinTuc />;
//       case "6":
//         return <GioHangDanhSachNguoiDiCung />;
//       case "7":
//         return <DanhMucTour />;
//       case "8":
//         return <LoaiTour />;
//       case "9":
//         return <Tour />;
//       case "10":
//         return <LichTrinhTour />;
//       case "11":
//         return <MediaTour />;
//       case "12":
//         return <BienTheTour />;
//       case "13":
//         return <PhuongTien />;
//       case "14":
//         return <Hotels />;
//       case "15":
//         return <DanhSachGiaGiam />;
//       case "16":
//         return <QuanLyDanhGia />;
//       case "17":
//         return <ChiTietHoaDon />;
//       case "18":
//         return <HoaDon />;
//       case "19":
//         return <YeuThich />;
//       case "20":
//         return <ChiTietGioHang />;
//       default:
//         return <div>Chọn một mục từ menu.</div>;
//     }
//   };

//   // Handle open/close state of submenus
//   const onOpenChange = (openKeys) => {
//     const currentOpenKey = openKeys.find(
//       (key) => stateOpenKeys.indexOf(key) === -1
//     );
//     if (currentOpenKey !== undefined) {
//       const repeatIndex = openKeys
//         .filter((key) => key !== currentOpenKey)
//         .findIndex((key) => levelKeys[key] === levelKeys[currentOpenKey]);
//       setStateOpenKeys(
//         openKeys
//           .filter((_, index) => index !== repeatIndex)
//           .filter((key) => levelKeys[key] <= levelKeys[currentOpenKey])
//       );
//     } else {
//       setStateOpenKeys(openKeys);
//     }
//   };
//   const topMenuItems = [
//     {
//       label: (
//         <a href="/" style={{ height: "50px", fontFamily: "initial" }}>
//           <h2>TRAVEL</h2>
//         </a>
//       ),
//       key: "",
//     },
//     {
//       label: "Nguyễn Hoàng Ninh",
//       key: "SubMenu",
//       children: [
//         {
//           type: "group",
//           label: "Item 1",
//           children: [
//             {
//               label: "Option 1",
//               key: "setting:1",
//             },
//           ],
//         },
//       ],
//     },
//   ];
//   const [currents, setCurrents] = useState("");

//   const handleClicks = (e) => {
//     setCurrents(e.key);
//   };
//   return (
//     <div className="row">
//       <div
//         style={{
//           display: "flex",
//           justifyContent: "space-between", // Đẩy 2 mục sang 2 bên
//           alignItems: "center",
//           padding: "0 20px", // Khoảng cách padding ngang
//           backgroundColor: "#fff",
//           position: "fixed",
//           width: "100%",
//           zIndex: 1000,
//           borderBottom: "1px solid #ddd",
//         }}
//       >
//         {/* Menu bên trái */}
//         <Menu
//           selectedKeys={[currents]}
//           mode="horizontal"
//           items={[topMenuItems[0]]} // Chỉ hiển thị mục đầu tiên
//           onClick={handleClicks}
//           style={{
//             flexGrow: 1, // Đẩy mục này về bên trái
//           }}
//         />

//         {/* Menu bên phải */}
//         <Menu
//           selectedKeys={[currents]}
//           mode="horizontal"
//           items={[topMenuItems[1]]} // Hiển thị mục Nguyễn Hoàng Ninh
//           onClick={handleClicks}
//           style={{
//             marginLeft: "auto", // Đẩy sang phải
//           }}
//         />
//       </div>
//       <div className="col-lg-3">
//         <div
//           style={{
//             position: "fixed", // Keep the menu fixed
//             top: 0, // Align it to the top of the screen
//             left: 0,
//             width: "256px", // Set the width
//             height: "100vh", // Set the height to full viewport height
//             overflowY: "auto", // Allow scrolling if content is too long
//             padding: "0 18px",
//             marginTop: "10px",
//             background: "#fff", // Background color
//           }}
//         >
//           <Menu
//             style={{ width: 256 }}
//             mode="inline" // Fixed mode to "inline" as there's no need to switch
//             theme="light" // Fixed theme to "light" as there's no need to switch
//             items={items}
//             openKeys={stateOpenKeys}
//             onOpenChange={onOpenChange}
//             onClick={handleClick}
//           />
//         </div>
//       </div>
//       <div
//         className="col-lg-9"
//         style={{ marginLeft: "-70px", marginTop: "120px" }}
//       >
//         {renderForm()} {/* Hiển thị form tương ứng */}
//       </div>
//     </div>
//   );
// };

// // export default App;
// export default FormQL;
