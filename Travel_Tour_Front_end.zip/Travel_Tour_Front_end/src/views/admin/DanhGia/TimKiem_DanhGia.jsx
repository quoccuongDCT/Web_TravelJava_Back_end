import React, { useState } from "react";
import { Select, Row, Col } from "antd";

// Hàm xử lý khi thay đổi giá trị trong Select
const onChange = (value, onSort) => {
  onSort(value); // Gọi hàm sắp xếp từ component cha
};

const TimKiemDanhGia = ({ onSort }) => {
  return (
    <div>
      <Row gutter={16} align="middle">
        {/* Select để chọn thứ tự sắp xếp */}
        <Col>
          <Select
            showSearch
            placeholder="Thứ tự:"
            onChange={(value) => onChange(value, onSort)} // Truyền giá trị về onSort
            style={{ width: 250 }}
            options={[
              {
                value: "asc",
                label: "Tăng dần",
              },
              {
                value: "desc",
                label: "Giảm dần",
              },
            ]}
          />
        </Col>
      </Row>
    </div>
  );
};

export default TimKiemDanhGia;
