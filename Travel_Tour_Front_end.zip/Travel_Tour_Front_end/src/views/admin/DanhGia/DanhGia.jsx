import React, { useEffect, useState } from "react";
import { Table, Tooltip, message, Image } from "antd";
import TimKiemDanhGia from "./TimKiem_DanhGia";
import { useNavigate, useLocation } from "react-router-dom";

// Cột dữ liệu của bảng
const columns = (navigateToDanhGia) => [
  {
    title: "STT",
    dataIndex: "id",
    key: "id",
    fixed: "left",
    render: (_, record, index) => (
      <Tooltip placement="topLeft" title={`Tour ID: ${record.tenTour}`}>
        <a
          href="#!"
          aria-label={`Tour ID: ${record.tenTour}`} // Thêm aria-label cho thẻ a
          onClick={(e) => {
            e.preventDefault();
            navigateToDanhGia(record.tenTour); // Gọi hàm điều hướng
          }}
        ></a>
        {index + 1}
      </Tooltip>
    ),
    width: 100,
  },
  {
    title: "Tên Tour",
    dataIndex: "tenTour",
    key: "tenTour",
    ellipsis: {
      showTitle: false,
    },
    render: (tenTour) => (
      <Tooltip placement="topLeft" title={tenTour}>
        {tenTour}
      </Tooltip>
    ),
  },
  {
    title: "Số ngày",
    dataIndex: "soNgay",
    key: "soNgay",
    render: (soNgay) => (
      <Tooltip placement="topLeft" title={soNgay}>
        {soNgay}
      </Tooltip>
    ),
  },
  {
    title: "Số lượng người",
    dataIndex: "soLuongNguoi",
    key: "soLuongNguoi",
    render: (soLuongNguoi) => (
      <Tooltip placement="topLeft" title={soLuongNguoi}>
        {soLuongNguoi}
      </Tooltip>
    ),
  },
  {
    title: "Hình Ảnh",
    dataIndex: "hinhAnh",
    key: "hinhAnh",
    render: (hinhAnh) => (
      <Image src={hinhAnh} alt="Profile" style={{ width: 50, height: 50 }} />
    ),
  },
  {
    title: "Điểm khởi hành",
    dataIndex: "diemKhoiHanh",
    key: "diemKhoiHanh",
    render: (diemKhoiHanh) => (
      <Tooltip placement="topLeft" title={diemKhoiHanh}>
        {diemKhoiHanh || "No Data"}
      </Tooltip>
    ),
  },
  {
    title: "Số lượt đánh giá",
    dataIndex: "tour",
    key: "totalReviews",
    render: (_, record) => record.totalReviews || 0,
  },
];

const FormDanhGia = () => {
  const [data, setData] = useState([]);
  const [sortedData, setSortedData] = useState([]);
  const navigate = useNavigate();
  const location = useLocation();
  const queryParams = new URLSearchParams(location.search);
  const tenTourParam = queryParams.get("tenTour"); // Get tenTour from query parameters

  // Now you can use tenTourParam instead of `tenTour`
  const tenTour = tenTourParam; // Declare tenTour

  const renderStars = (stars) => {
    const maxStars = 5;
    return Array.from({ length: maxStars }, (_, index) => (
      <span
        key={index}
        style={{ color: index < stars ? "#FFD700" : "#d3d3d3" }}
      >
        ★
      </span>
    ));
  };

  const groupToursById = (tours) => {
    const grouped = {};

    tours.forEach((tour) => {
      if (!grouped[tour.tour.id]) {
        grouped[tour.tour.id] = { ...tour.tour, reviews: [] };
      }
      grouped[tour.tour.id].reviews.push(tour);
    });

    Object.keys(grouped).forEach((tourId) => {
      const tour = grouped[tourId];
      const totalRating = tour.reviews.reduce(
        (sum, review) => sum + review.danhGia,
        0
      );
      tour.averageRating = totalRating / tour.reviews.length;
      tour.totalReviews = tour.reviews.length;
    });

    return Object.values(grouped);
  };

  const fetchDanhGias = async () => {
    try {
      const url = tenTourParam
        ? `http://localhost:8080/api/danhgia?tenTour=${encodeURIComponent(
            tenTourParam
          )}`
        : "http://localhost:8080/api/danhgia";

      const response = await fetch(url);
      const tours = await response.json();
      const filteredTours = tours.filter(
        (tour) => tour.tour.tenTour === tenTourParam
      );

      const groupedTours = groupToursById(filteredTours);
      setData(groupedTours);
      setSortedData(groupedTours);
    } catch (error) {
      message.error("Tải dữ liệu thất bại.");
    }
  };

  useEffect(() => {
    fetchDanhGias();
  }, [tenTourParam]);

  const navigateToDanhGia = async (tenTour) => {
    try {
      const decodedTenTour = decodeURIComponent(tenTour);
      const response = await fetch(
        `http://localhost:8080/api/danhgia/danhgia/${decodedTenTour}`
      );
      if (response.status === 200) {
        navigate(`/admin/danh-gia?tenTour=${decodedTenTour}`);
      } else {
        message.error(`Tour ${tenTour} này chưa có đánh giá nào. `);
      }
    } catch (error) {
      console.error("Lỗi khi gọi API :", error);
      message.error("Lỗi khi gọi Tour");
    }
  };

  const handleSort = (order) => {
    const sorted = [...data].sort((a, b) => {
      if (order === "asc") {
        return a.averageRating - b.averageRating;
      } else {
        return b.averageRating - a.averageRating;
      }
    });
    setSortedData(sorted);
  };

  const expandedRowRender = (record) => {
    const expandDataSource = record.reviews.map((review, index) => ({
      key: index,
      id: review.id,
      name: review.nguoiDung?.hoTen,
      upgradeNum: review.danhGia,
      image: review.hinhAnh,
      note: review.moTa,
      date: review.ngay,
    }));

    const expandColumns = [
      {
        title: "STT",
        dataIndex: "id",
        key: "id",
        render: (_, __, index) => (
          <a href="#!" onClick={(e) => e.preventDefault()}>
            {index + 1}
          </a>
        ),
      },
      {
        title: "Họ tên",
        dataIndex: "name",
        key: "name",
      },
      {
        title: "Đánh giá",
        dataIndex: "upgradeNum",
        key: "upgradeNum",
        render: (upgradeNum) => renderStars(upgradeNum),
      },
      {
        title: "Hình ảnh",
        dataIndex: "image",
        key: "image",
        render: (image) => (
          <Image
            width="50"
            height="50"
            src={image || "https://img.icons8.com/bubbles/100/user.png"}
            alt="user"
            style={{ width: "150px", height: "100px" }}
          />
        ),
      },
      {
        title: "Ngày",
        dataIndex: "date",
        key: "date",
        render: (ngay) => {
          return new Date(ngay).toLocaleDateString("vi-VN", {
            day: "2-digit",
            month: "2-digit",
            year: "numeric",
          });
        },
      },
      {
        title: "Mô tả",
        dataIndex: "note",
        key: "note",
      },
    ];

    return (
      <Table
        columns={expandColumns}
        dataSource={expandDataSource}
        pagination={false}
      />
    );
  };

  return (
    <div className="container">
      <h3>Quản Lý Đánh Giá</h3>
      <TimKiemDanhGia onSort={handleSort} />

      <div className="table-container align-items-center">
        {sortedData.length === 0 ? (
          <div style={{ textAlign: "center", marginTop: "20px" }}>
            <h4>
              {tenTour
                ? `Tour ${tenTour} này chưa có đánh giá nào`
                : "Không có đánh giá cho tour này"}
            </h4>
          </div>
        ) : (
          <Table
            columns={columns(navigateToDanhGia)}
            dataSource={sortedData}
            rowKey="id"
            expandable={{
              expandedRowRender: expandedRowRender,
              defaultExpandedRowKeys: ["0"],
            }}
          />
        )}
      </div>
    </div>
  );
};

export default FormDanhGia;
