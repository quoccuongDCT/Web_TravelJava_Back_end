import React, { useState, useEffect } from "react";
import { Table, Tooltip, message } from "antd";
import TimKiem from "./TimKiem_TinTuc";

// Cột dữ liệu của bảng
const columns = (showEditModal) => [
  {
    title: "ID",
    dataIndex: "id",
    key: "index",
    render: (_, __, index) => (
      <a href="#!" onClick={(e) => e.preventDefault()}>
        {index + 1}
      </a>
    ),
    width: 50,
  },
  {
    title: "Người Đại Diện",
    dataIndex: "chiTietHoaDon",
    key: "chiTietHoaDon",
    ellipsis: {
      showTitle: false,
    },
    render: (chiTietHoaDon) => (
      <Tooltip
        placement="topLeft"
        title={chiTietHoaDon?.bienTheTour?.giamGia?.nguoiDung?.hoTen}
      >
        {chiTietHoaDon?.bienTheTour?.giamGia?.nguoiDung?.hoTen}
      </Tooltip>
    ),
  },
  {
    title: "Họ Và Tên",
    dataIndex: "hoTen",
    key: "hoTen",
    render: (hoTen) => (
      <Tooltip placement="topLeft" title={hoTen}>
        {hoTen}
      </Tooltip>
    ),
  },
  {
    title: "Email",
    dataIndex: "email",
    key: "email",
    render: (email) => (
      <Tooltip placement="topLeft" title={email}>
        {email}
      </Tooltip>
    ),
  },
  {
    title: "Số Điện Thoại ",
    dataIndex: "soDienThoai",
    key: "soDienThoai",
    render: (soDienThoai) => (
      <Tooltip placement="topLeft" title={soDienThoai}>
        {soDienThoai}
      </Tooltip>
    ),
  },
  {
    title: "Năm Sinh ",
    dataIndex: "namSinh",
    key: "namSinh",
    render: (namSinh) => (
      <Tooltip placement="topLeft" title={namSinh}>
        {namSinh}
      </Tooltip>
    ),
  },
];

// Component chính
const FormDanhSachNguoiDiCung = () => {
  const [data, setData] = useState([]);

  const fetchDanhSachNguoiDiCungs = async () => {
    try {
      const response = await fetch(
        "http://localhost:8080/api/danhsachnguoidicung"
      );
      const tours = await response.json();

      // Sắp xếp theo id từ lớn đến nhỏ
      const sortedDanhSachNguoiDiCungs = tours.sort((a, b) => b.id - a.id);
      setData(sortedDanhSachNguoiDiCungs);
    } catch (error) {
      message.error("Tải dữ liệu thất bại.");
    }
  };

  useEffect(() => {
    fetchDanhSachNguoiDiCungs();
  }, []);

  const showEditModal = (record) => {
    // Function logic for showing edit modal
    console.log("Show edit modal for", record);
  };

  return (
    <div className="container">
      <h3>Quản Lý Danh Sách Người Đi Cùng</h3>
      {/* Tìm kiếm người dùng */}
      <TimKiem />

      {/* Bảng người dùng */}
      <div className="table-container align-items-center">
        <Table columns={columns(showEditModal)} dataSource={data} rowKey="id" />
      </div>
    </div>
  );
};

export default FormDanhSachNguoiDiCung;
