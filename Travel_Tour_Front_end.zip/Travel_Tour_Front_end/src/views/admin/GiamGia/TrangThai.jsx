import React, { useState } from "react";
import { Button, Checkbox, Form, Switch, Modal, message } from "antd";
import axios from "axios";

import "bootstrap/dist/css/bootstrap.min.css";

const FormChuyenDoiTrangThai = ({
  visible,
  onCancel = () => {},
  onBack,
  tour,
}) => {
  // Ensure `tour` exists, and if not, provide a default value
  const initialHoatDong = tour ? tour.trangThai : false; // Default to false (inactive) if tour is undefined
  const [componentDisabled, setComponentDisabled] = useState(false);
  const [hoatDong, setHoatDong] = useState(initialHoatDong);

  // Function to handle form submission
  const onFinish = async (values) => {
    if (!tour) {
      message.error("Thông tin tour không khả dụng.");
      return;
    }

    try {
      const updatedTour = {
        ...tour,
        trangThai: hoatDong, // Send the updated status (hoạt động/ngưng hoạt động)
      };

      // Call the API to update the tour status
      await axios.put(
        `http://localhost:8080/api/tours/update/${tour.id}`,
        updatedTour
      );

      message.success("Cập nhật trạng thái thành công!"); // Show success message
      onCancel(); // Close modal after successful update
    } catch (error) {
      console.error("Lỗi khi cập nhật trạng thái tour:", error);
      message.error("Cập nhật trạng thái thất bại.");
    }
  };

  return (
    <div className="container-fluid mt-5">
      <Modal
        title="Chuyển Đổi Trạng Thái Tour"
        visible={visible}
        onCancel={onCancel} // Pass the onCancel function to close the modal
        footer={null}
        width={600}
      >
        <Checkbox
          className="mb-3"
          checked={componentDisabled}
          onChange={(e) => setComponentDisabled(e.target.checked)}
        >
          Vô hiệu hóa biểu mẫu
        </Checkbox>
        <Form
          layout="vertical"
          disabled={componentDisabled}
          onFinish={onFinish}
          initialValues={{ hoatDong }}
        >
          <Form.Item label="Trạng Thái" name="hoatDong" valuePropName="checked">
            <Switch
              checkedChildren="Hoạt Động"
              unCheckedChildren="Ngưng Hoạt Động"
              checked={hoatDong}
              onChange={(checked) => setHoatDong(checked)}
            />
          </Form.Item>
          <div className="d-flex justify-content-between">
            <Button onClick={onBack}>Trở Về</Button>
            <Button type="primary" htmlType="submit">
              Cập Nhật Trạng Thái
            </Button>
          </div>
        </Form>
      </Modal>
    </div>
  );
};

export default FormChuyenDoiTrangThai;
