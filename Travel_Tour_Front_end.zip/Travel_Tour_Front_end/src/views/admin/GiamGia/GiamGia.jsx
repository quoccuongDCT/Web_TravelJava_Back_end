import React, { useState, useEffect } from "react";
import {
  Table,
  Tooltip,
  Button,
  Image,
  ConfigProvider,
  Space,
  message,
  Modal,
} from "antd";
import {
  AntDesignOutlined,
  DeleteOutlined,
  HighlightTwoTone,
} from "@ant-design/icons";
import TimKiem from "./TimKiem_Tour.jsx"; // Thành phần tìm kiếm
import ThemGiamGia from "./ThemGiamGia.jsx"; // Thành phần thêm Giảm giá
import CapNhatGiamGia from "./CapNhatGiamGia.jsx"; // Thành phần cập nhật Giảm giá
import axios from "axios"; // Thư viện gọi API
// import { ellipsis } from "@tiptap/pm/inputrules";
import "./style.css";

// Cột dữ liệu của bảng
const columns = (showEditModal, handleDelete) => [
  {
    title: "STT",
    dataIndex: "id",
    key: "id",
    fixed: "left",
    render: (_, __, index) => (
      <Tooltip placement="topLeft" title={index}>
        {index + 1}
      </Tooltip>
    ),
    width: 100,
  },
  {
    title: "Họ Và tên",
    dataIndex: "nguoiDung",
    key: "nguoDung",
    ellipsis: {
      showTitle: false,
    },
    render: (nguoiDung) => (
      <Tooltip placement="topLeft" title={nguoiDung.hoTen}>
        {nguoiDung.hoTen}
      </Tooltip>
    ),
  },
  {
    title: "Tên Tour",
    dataIndex: "tour",
    key: "tour",
    ellipsis: {
      showTitle: false,
    },
    render: (tour) => (
      <Tooltip placement="topLeft" title={tour?.tenTour}>
        {tour?.tenTour}
      </Tooltip>
    ),
  },
  {
    title: "Tiêu Đề",
    dataIndex: "tieuDe",
    key: "tieuDe",
    ellipsis: {
      showTitle: false,
    },
    render: (tieuDe) => (
      <Tooltip placement="topLeft" title={tieuDe}>
        {tieuDe}
      </Tooltip>
    ),
  },
  {
    title: "Mã Giảm Giá",
    dataIndex: "maGiamGia",
    key: "maGiamGia",
    ellipsis: {
      showTitle: false,
    },
    render: (maGiamGia) => (
      <Tooltip placement="topLeft" title={maGiamGia}>
        {maGiamGia}
      </Tooltip>
    ),
  },
  {
    title: "Ngày Bắt Đầu",
    dataIndex: "ngayBatDau",
    key: "ngayBatDau",
    ellipsis: {
      showTitle: false,
    },
    render: (ngayBatDau) => {
      return new Date(ngayBatDau).toLocaleDateString("vi-VN", {
        day: "2-digit",
        month: "2-digit",
        year: "numeric",
      });
    },
  },
  {
    title: "Ngày Kết Thúc",
    dataIndex: "ngayKetThuc",
    key: "ngayKetThuc",
    ellipsis: {
      showTitle: false,
    },
    render: (ngayKetThuc) => {
      return new Date(ngayKetThuc).toLocaleDateString("vi-VN", {
        day: "2-digit",
        month: "2-digit",
        year: "numeric",
      });
    },
  },
  {
    title: "Nội Dung",
    dataIndex: "noiDung",
    key: "noiDung",
    ellipsis: {
      showTitle: false,
    },
    render: (noiDung) => (
      <Tooltip placement="topLeft" title={noiDung}>
        {noiDung}
      </Tooltip>
    ),
  },
  {
    title: "Ảnh",
    dataIndex: "hinhAnh",
    key: "hinhAnh",
    render: (hinhAnh) => (
      <Image src={hinhAnh} alt="Profile" style={{ width: 50, height: 50 }} />
    ),
  },
  {
    title: "Phần Trăm Giảm",
    dataIndex: "phanTram",
    key: "phanTram",
    ellipsis: {
      showTitle: false,
    },
    render: (phanTram) => (
      <Tooltip placement="topLeft" title={`${phanTram}%`}>
        <span className="discount-text">{phanTram}%</span>
      </Tooltip>
    ),
  },

  {
    title: "Số Lượng Giảm",
    dataIndex: "soLuong",
    key: "soLuong",
    ellipsis: {
      showTitle: false,
    },
    render: (soLuong) => (
      <Tooltip placement="topLeft" title={soLuong}>
        <span className="discount-quantity">{soLuong}</span>
      </Tooltip>
    ),
  },

  {
    title: "Mô Tả",
    dataIndex: "moTa",
    key: "moTa",
    ellipsis: {
      showTitle: false,
    },
    render: (moTa) => (
      <Tooltip placement="topLeft" title={moTa}>
        {moTa}
      </Tooltip>
    ),
  },
  {
    title: "",
    key: "action",
    render: (_, record) => (
      <Space size="middle">
        {/* Nút Sửa */}
        <Tooltip title="Cập nhật thông tin Giảm Giá">
          <Button
            icon={<HighlightTwoTone />}
            onClick={() => showEditModal(record)} // Hiển thị modal với dữ liệu tour được chọn
          ></Button>
        </Tooltip>

        {/* Nút Xóa */}
        <Tooltip title="Xóa Giảm Giá">
          <Button
            icon={<DeleteOutlined />}
            danger
            onClick={() => handleDelete(record.id, record.tour?.tenTour)} // Gọi hàm xóa
          ></Button>
        </Tooltip>
      </Space>
    ),
  },
];

// Component chính
const FormGiamGia = () => {
  const [visible, setVisible] = useState(false); // Trạng thái hiển thị modal
  const [editingUser, setEditingUser] = useState(null); // Trạng thái tour đang chỉnh sửa
  const [data, setData] = useState([]); // Dữ liệu bảng

  // Hàm lấy dữ liệu từ API
  const fetchTours = async () => {
    try {
      const response = await fetch("http://localhost:8080/api/giamgia");
      const tours = await response.json();

      // Sắp xếp theo id từ lớn đến nhỏ
      const sortedTours = tours.sort((a, b) => b.id - a.id);
      setData(sortedTours);
    } catch (error) {
      message.error("Tải dữ liệu thất bại.");
    }
  };
  useEffect(() => {
    fetchTours();
  }, []);
  const handleDelete = (id, tenTour) => {
    // Show the confirmation popup with the category name included
    Modal.confirm({
      title: `Bạn có chắc chắn muốn xóa Giảm Giá với Tên Tour: ${tenTour}`, // Display the category name in the confirmation message
      okText: "Có", // Text for the OK button (Yes)
      cancelText: "Không", // Text for the Cancel button (No)
      onOk: async () => {
        // onOk is called when the user clicks "Yes"
        try {
          // Make the DELETE request to the backend
          await axios.delete(`http://localhost:8080/api/giamgia/delete/${id}`);

          // Remove the deleted item from the local state to update the UI
          setData((prevData) => prevData.filter((item) => item.id !== id));

          // Show success message
          message.success(`Đã xóa thành công: ${tenTour}`);
        } catch (error) {
          console.error("Lỗi khi xóa Giảm Giá:", error);
          message.error("Không thể xóa Giảm Giá.");
        }
      },
      onCancel: () => {
        // Optionally, log or handle the cancel action
        console.log("Xóa bị hủy");
      },
    });
  };
  const handleUpdateSuccess = async () => {
    try {
      const response = await axios.get("http://localhost:8080/api/giamgia");
      setData(response.data); // Cập nhật dữ liệu
      setVisible(false); // Đóng modal
      const sortedData = response.data.sort((a, b) => b.id - a.id);
      setData(sortedData); // Cập nhật dữ liệu đã được sắp xếp
      setEditingUser(null); // Xóa thông tin tour đang chỉnh sửa
    } catch (error) {
      message.error("Không thể tải dữ liệu từ server.");
    }
  };

  const showModal = () => {
    setVisible(true); // Mở modal thêm tour
  };

  const handleCancel = () => {
    setVisible(false); // Đóng modal
    setEditingUser(null); // Reset trạng thái sau khi đóng modal
  };
  const showEditModal = (tour) => {
    setEditingUser(tour); // Đặt tour đang được chỉnh sửa
    setVisible(true); // Mở modal
  };

  return (
    <div className="container">
      <h3>Danh Sách Giảm Giá</h3>
      {/* Nút "Thêm" */}
      <ConfigProvider>
        <div className="button-container">
          <Button
            className="nguoidung-them"
            type="primary"
            size="large"
            icon={<AntDesignOutlined />}
            onClick={showModal}
          >
            Thêm
          </Button>
        </div>
        <ThemGiamGia
          visible={visible}
          onCancel={handleCancel}
          reloadData={fetchTours}
        />
      </ConfigProvider>
      {/* Tìm kiếm tour */}
      {/* <TimKiem /> */}
      {/* Bảng tour */}
      <div
        className="table-container align-items-center"
        style={{ marginRight: "-100px" }}
      >
        <Table
          columns={columns(showEditModal, handleDelete)}
          scroll={{ x: 1800 }}
          dataSource={data} // Map dữ liệu API vào bảng
          rowKey="id" // Đặt rowKey là id
        />
      </div>
      {/* Modal cập nhật tour */}
      {editingUser && (
        <CapNhatGiamGia
          visible={visible}
          onCancel={handleCancel}
          userData={editingUser} // Tên biến truyền vào model phải trùng
          onUpdateSuccess={handleUpdateSuccess} // Gọi callback khi thành công
        />
      )}
    </div>
  );
};

export default FormGiamGia;
