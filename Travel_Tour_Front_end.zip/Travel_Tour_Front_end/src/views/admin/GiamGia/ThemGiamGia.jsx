import React, { useEffect, useState } from "react";
import {
  Button,
  Checkbox,
  Form,
  DatePicker,
  Input,
  Modal,
  Upload,
  Image,
  Select,
  InputNumber,
  message,
} from "antd";
import { PlusOutlined } from "@ant-design/icons";
import axios from "axios";
import "bootstrap/dist/css/bootstrap.min.css";
import { initializeApp } from "firebase/app";
import "./style.css";
import {
  getStorage,
  ref,
  uploadString,
  getDownloadURL,
} from "firebase/storage";

const { TextArea } = Input;

// Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyAtXg4mkxx1gic_VlvyxWcEloGZ6VFyymg",
  authDomain: "travel-e7f79.firebaseapp.com",
  projectId: "travel-e7f79",
  storageBucket: "travel-e7f79.appspot.com",
  messagingSenderId: "52519186637",
  appId: "1:52519186637:web:d0bb8aa8a499a7179b3984",
  measurementId: "G-HLNSGQZCPH",
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const storage = getStorage(app);

const getBase64 = (file) =>
  new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => resolve(reader.result);
    reader.onerror = (error) => reject(error);
  });

const FormThemGiamGia = ({ visible, onCancel, onBack, reloadData }) => {
  const [componentDisabled, setComponentDisabled] = useState(false);
  const [previewOpen, setPreviewOpen] = useState(false);
  const [previewImage, setPreviewImage] = useState("");
  const [fileList, setFileList] = useState([]);
  const [number, setNumber] = useState(0);
  const [loaiTourList, setLoaiTourList] = useState([]);
  // const [danhMucTourList, setDanhMucTourList] = useState([]);

  useEffect(() => {
    const fetchTourData = async () => {
      try {
        const response = await axios.get("http://localhost:8080/api/tours"); // Unified API endpoint
        const loaiTour = response.data; // Assuming response returns { loaiTour, danhMucTour }

        setLoaiTourList(loaiTour);
        // setDanhMucTourList(danhMucTour);
      } catch (error) {
        console.error(
          "Lỗi khi lấy danh sách loại tour và danh mục tour:",
          error
        );
      }
    };

    fetchTourData();
  }, []);

  const handlePreview = async (file) => {
    if (!file.url && !file.preview) {
      file.preview = await getBase64(file.originFileObj);
    }
    setPreviewImage(file.url || file.preview);
    setPreviewOpen(true);
  };

  const handleChange = ({ fileList: newFileList }) => setFileList(newFileList);

  const uploadButton = (
    <div>
      <PlusOutlined />
      <div style={{ marginTop: 8 }}>Tải lên</div>
    </div>
  );

  const onNumberChange = (value) => {
    setNumber(value);
  };

  const uploadImageToFirebase = async (base64Image) => {
    try {
      const imageRef = ref(storage, `images/${Date.now()}.png`);
      await uploadString(imageRef, base64Image, "data_url");
      return await getDownloadURL(imageRef);
    } catch (error) {
      console.error("Lỗi khi upload hình ảnh lên Firebase:", error);
      throw error;
    }
  };

  const onFinish = async (values) => {
    const hinhAnhBase64 =
      fileList.length > 0 ? await getBase64(fileList[0].originFileObj) : "";

    const hinhAnhUrl = hinhAnhBase64
      ? await uploadImageToFirebase(hinhAnhBase64)
      : null;

    const tourData = {
      tour: { id: values.tour },
      nguoiDung: { id: 2 },
      tieuDe: values.tieuDe,
      maGiamGia: values.maGiamGia,
      moTa: values.moTa,
      ngayBatDau: values.ngayBatDau,
      ngayKetThuc: values.ngayKetThuc,
      noiDung: values.noiDung,
      hinhAnh: hinhAnhUrl,
      soLuong: number,
      phanTram: values.phanTram,
    };

    const response = await axios.post(
      "http://localhost:8080/api/giamgia/them",
      tourData
    );
    if (response.status === 200) {
      reloadData(); // Refresh danh sách tour sau khi thêm thành công
      message.success("Giảm giá đã được thêm thành công!");
      onCancel();
    }
  };

  return (
    <div className="container-fluid mt-5">
      <Modal
        title="Thêm Giảm Giá"
        visible={visible}
        onCancel={onCancel}
        footer={null}
        width={900}
      >
        <Checkbox
          className="mb-3"
          checked={componentDisabled}
          onChange={(e) => setComponentDisabled(e.target.checked)}
        >
          Vô hiệu hóa biểu mẫu
        </Checkbox>
        <Form
          layout="vertical"
          disabled={componentDisabled}
          onFinish={onFinish}
        >
          <div className="row">
            <div className="col-lg-6">
              <Form.Item
                label="Tour"
                name="tour"
                rules={[{ required: true, message: "Tour không bỏ trống!" }]}
              >
                <Select placeholder="Chọn Tour">
                  {loaiTourList.map((item) => (
                    <Select.Option key={item.id} value={item.id}>
                      {item.tenTour} {/* Display the name here */}
                    </Select.Option>
                  ))}
                </Select>
              </Form.Item>
            </div>
            <div className="col-lg-6">
              <Form.Item
                label="Tiêu Đề"
                name="tieuDe"
                rules={[{ required: true, message: "Tiêu Đề không bỏ trống!" }]}
              >
                <Input className="rounded-lg text-xs" />
              </Form.Item>
            </div>
            <div className="col-lg-6">
              <Form.Item
                label="Mã Giảm Giá"
                name="maGiamGia"
                rules={[
                  { required: true, message: "Mã Giảm Giá không bỏ trống!" },
                ]}
              >
                <Input className="rounded-lg text-xs" />
              </Form.Item>
            </div>
            <div className="col-lg-6">
              <Form.Item
                label="Phần Trăm Giảm"
                name="phanTram"
                rules={[
                  { required: true, message: "Phần Trăm không bỏ trống!" },
                ]}
              >
                <Input className="rounded-lg text-xs" />
              </Form.Item>
            </div>
            <div className="col-lg-6">
              <Form.Item label="Hình Ảnh" name="hinhAnh">
                <Upload
                  listType="picture-card"
                  fileList={fileList}
                  onPreview={handlePreview}
                  onChange={handleChange}
                  // className={fileList.length === 0 ? "upload-error" : ""}
                >
                  {fileList.length >= 1 ? null : uploadButton}
                </Upload>
                <Modal
                  visible={previewOpen}
                  title="Xem trước hình ảnh"
                  footer={null}
                  onCancel={() => setPreviewOpen(false)}
                >
                  <Image
                    alt="example"
                    style={{ width: "100%" }}
                    src={previewImage}
                  />
                </Modal>
              </Form.Item>
            </div>
            <div className="col-lg-6">
              <Form.Item
                label="Số Lượng"
                name="soLuong"
                rules={[
                  { required: true, message: "Số Lượng không bỏ trống!" },
                  {
                    type: "number",
                    min: 1,
                    message: "Số Lượng phải lớn hơn 0!",
                  },
                ]}
              >
                <InputNumber
                  min={0}
                  defaultValue={number}
                  onChange={onNumberChange}
                  style={{ width: 200 }}
                />
              </Form.Item>
            </div>

            <div className="col-lg-6">
              <Form.Item
                label="Ngày Bắt Đầu"
                name="ngayBatDau"
                rules={[
                  { required: true, message: "Ngày Bắt Đầu không bỏ trống!" },
                ]}
              >
                <DatePicker className="w-100" format="DD/MM/YYYY" />
              </Form.Item>
            </div>
            <div className="col-lg-6">
              <Form.Item
                label="Ngày Kết Thúc"
                name="ngayKetThuc"
                rules={[
                  { required: true, message: "Ngày Kết Thúc không bỏ trống!" },
                ]}
              >
                <DatePicker className="w-100" format="DD/MM/YYYY" />
              </Form.Item>
            </div>
            <div className="col-lg-12">
              <Form.Item label="Mô Tả" name="moTa">
                <TextArea rows={4} />
              </Form.Item>
            </div>
          </div>
          <div className="text-right">
            <Button onClick={onBack}>Trở Về</Button>
            <Button style={{ marginLeft: 10 }} type="primary" htmlType="submit">
              Thêm Giảm Giá
            </Button>
          </div>
        </Form>
      </Modal>
    </div>
  );
};

export default FormThemGiamGia;
