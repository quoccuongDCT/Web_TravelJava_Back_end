import React, { useState, useEffect } from "react";
import {
  Button,
  Checkbox,
  Form,
  Input,
  Modal,
  DatePicker,
  Upload,
  Image,
  Select,
  InputNumber,
  message,
} from "antd";
// Định dạng ngày tháng năm
// import moment from "moment";
import { PlusOutlined } from "@ant-design/icons";
import axios from "axios";
import moment from "moment";
import { initializeApp } from "firebase/app";
import {
  getStorage,
  ref,
  uploadString,
  getDownloadURL,
} from "firebase/storage";

const { TextArea } = Input;

const firebaseConfig = {
  apiKey: "AIzaSyAtXg4mkxx1gic_VlvyxWcEloGZ6VFyymg",
  authDomain: "travel-e7f79.firebaseapp.com",
  projectId: "travel-e7f79",
  storageBucket: "travel-e7f79.appspot.com",
  messagingSenderId: "52519186637",
  appId: "1:52519186637:web:d0bb8aa8a499a7179b3984",
  measurementId: "G-HLNSGQZCPH",
};

const app = initializeApp(firebaseConfig);
const storage = getStorage(app);

const getBase64 = (file) =>
  new Promise((resolve, reject) => {
    if (!file || !file.originFileObj) {
      reject(new Error("Đối tượng tệp không hợp lệ"));
      return;
    }
    const reader = new FileReader();
    reader.readAsDataURL(file.originFileObj);
    reader.onload = () => resolve(reader.result);
    reader.onerror = (error) => reject(error);
  });

const FormCapNhatGiamGia = ({
  visible,
  onCancel,
  // onBack,
  userData,
  onUpdateSuccess,
}) => {
  const [componentDisabled, setComponentDisabled] = useState(false);
  const [previewOpen, setPreviewOpen] = useState(false);
  const [previewImage, setPreviewImage] = useState("");
  const [fileList, setFileList] = useState([]);
  const [number, setNumber] = useState(0);
  const [loaiTourList, setLoaiTourList] = useState([]);
  // const [danhMucTourList, setdanhMucTourList] = useState([]);
  useEffect(() => {
    if (userData) {
      setFileList(userData.hinhAnh ? [{ url: userData.hinhAnh }] : []);
    }
  }, [userData]);

  const handlePreview = async (file) => {
    if (!file.url && !file.preview) {
      file.preview = await getBase64(file.originFileObj);
    }
    setPreviewImage(file.url || file.preview);
    setPreviewOpen(true);
  };
  // Lấy danh sách loại tour từ API khi component được mount
  useEffect(() => {
    const fetchLoaiTour = async () => {
      try {
        const response = await axios.get("http://localhost:8080/api/tours"); // API lấy danh sách loại tour
        setLoaiTourList(response.data);
      } catch (error) {
        console.error("Lỗi khi lấy danh sách loại tour:", error);
      }
    };

    fetchLoaiTour();
  }, []);
  const handleChange = ({ fileList: newFileList }) => setFileList(newFileList);

  const uploadButton = (
    <div>
      <PlusOutlined />
      <div style={{ marginTop: 8 }}>Tải lên</div>
    </div>
  );
  const onNumberChange = (value) => {
    setNumber(value);
  };
  const uploadImageToFirebase = async (base64Image) => {
    try {
      const imageRef = ref(storage, `images/${Date.now()}.png`);
      await uploadString(imageRef, base64Image, "data_url");
      return await getDownloadURL(imageRef);
    } catch (error) {
      console.error("Lỗi khi upload hình ảnh lên Firebase:", error);
      throw error;
    }
  };

  const onFinish = async (values) => {
    try {
      const hinhAnhBase64 =
        fileList.length > 0 && fileList[0].originFileObj
          ? await getBase64(fileList[0])
          : "";
      const hinhAnhUrl = hinhAnhBase64
        ? await uploadImageToFirebase(hinhAnhBase64)
        : userData?.hinhAnh;
      // Lấy idNguoiDung từ localStorage
      const idNguoiDung = localStorage.getItem("id");

      if (!idNguoiDung) {
        message.error("Không tìm thấy thông tin người dùng trong localStorage");
        return;
      }

      const formData = {
        tour: { id: values.tour },
        nguoiDung: { id: idNguoiDung }, // lấy idNguoiDung từ localStorage
        tieuDe: values.tieuDe,
        maGiamGia: values.maGiamGia,
        moTa: values.moTa,
        ngayBatDau: values.ngayBatDau,
        ngayKetThuc: values.ngayKetThuc,
        noiDung: values.noiDung,
        hinhAnh: hinhAnhUrl,
        soLuong: number,
        phanTram: values.phanTram,
      };
      if (userData?.id) {
        const response = await axios.put(
          `http://localhost:8080/api/giamgia/update/${userData.id}`,
          formData
        );
        onUpdateSuccess();
        setLoaiTourList(response.data);
        // setdanhMucTourList(response.data);
        console.log(response.data);
        message.success("Cập nhật tour thành công");
      } else {
        message.error("Không tìm thấy tour để cập nhật");
      }

      onCancel();
    } catch (error) {
      console.error(
        "Lỗi cập nhật tour:",
        error.response?.data || error.message
      );
      console.error("Lỗi cập nhật tour:", error);
    }
  };

  return (
    <div className="container-fluid mt-5">
      <Modal
        title="Cập Nhật Giảm Giá"
        visible={visible}
        onCancel={onCancel}
        footer={null}
        width={900}
      >
        <Checkbox
          className="mb-3"
          checked={componentDisabled}
          onChange={(e) => setComponentDisabled(e.target.checked)}
        >
          Vô hiệu hóa biểu mẫu
        </Checkbox>
        <Form
          layout="vertical"
          disabled={componentDisabled}
          onFinish={onFinish}
          initialValues={{
            tour: userData?.tour?.id,
            nguoiDung: userData?.nguoiDung?.id,
            tieuDe: userData?.tieuDe,
            maGiamGia: userData?.maGiamGia,
            moTa: userData?.moTa,
            ngayBatDau: userData?.ngayBatDau
              ? moment(userData.ngayBatDau)
              : null,
            ngayKetThuc: userData?.ngayKetThuc
              ? moment(userData.ngayKetThuc)
              : null,
            noiDung: userData?.noiDung,
            soLuong: userData?.soLuong,
            phanTram: userData?.phanTram,
          }}
        >
          <div className="row">
            <div className="col-lg-6">
              <Form.Item
                label="Tour"
                name="tour"
                rules={[{ required: true, message: "Tour không bỏ trống!" }]}
              >
                <Select placeholder="Chọn Tour">
                  {loaiTourList.map((item) => (
                    <Select.Option key={item.id} value={item.id}>
                      {item.tenTour} {/* Display the name here */}
                    </Select.Option>
                  ))}
                </Select>
              </Form.Item>
            </div>
            <div className="col-lg-6">
              <Form.Item
                label="Tiêu Đề"
                name="tieuDe"
                rules={[{ required: true, message: "Tiêu Đề không bỏ trống!" }]}
              >
                <Input className="rounded-lg text-xs" />
              </Form.Item>
            </div>
            <div className="col-lg-6">
              <Form.Item
                label="Mã Giảm Giá"
                name="maGiamGia"
                rules={[
                  { required: true, message: "Mã Giảm Giá không bỏ trống!" },
                ]}
              >
                <Input className="rounded-lg text-xs" />
              </Form.Item>
            </div>
            <div className="col-lg-6">
              <Form.Item
                label="Phần Trăm Giảm"
                name="phanTram"
                rules={[
                  { required: true, message: "Phần Trăm không bỏ trống!" },
                ]}
              >
                <Input className="rounded-lg text-xs" />
              </Form.Item>
            </div>
            <div className="col-lg-6">
              <Form.Item
                label="Nội Dung"
                name="noiDung"
                rules={[
                  { required: true, message: "Nội dung không bỏ trống!" },
                ]}
              >
                <Input className="rounded-lg text-xs" />
              </Form.Item>
            </div>
            <div className="col-lg-6">
              <Form.Item label="Hình Ảnh" name="hinhAnh">
                <Upload
                  listType="picture-card"
                  fileList={fileList}
                  onPreview={handlePreview}
                  onChange={handleChange}
                  // className={fileList.length === 0 ? "upload-error" : ""}
                >
                  {fileList.length >= 1 ? null : uploadButton}
                </Upload>
                <Modal
                  visible={previewOpen}
                  title="Xem trước hình ảnh"
                  footer={null}
                  onCancel={() => setPreviewOpen(false)}
                >
                  <Image
                    alt="example"
                    style={{ width: "100%" }}
                    src={previewImage}
                  />
                </Modal>
              </Form.Item>
            </div>
            <div className="col-lg-6">
              <Form.Item
                label="Số Lượng"
                name="soLuong"
                rules={[
                  { required: true, message: "Số Lượng không bỏ trống!" },
                  {
                    type: "number",
                    min: 1,
                    message: "Số Lượng phải lớn hơn 0!",
                  },
                ]}
              >
                <InputNumber
                  min={0}
                  defaultValue={number}
                  onChange={onNumberChange}
                  style={{ width: 200 }}
                />
              </Form.Item>
            </div>

            <div className="col-lg-6">
              <Form.Item
                label="Ngày Bắt Đầu"
                name="ngayBatDau"
                rules={[
                  { required: true, message: "Ngày Bắt Đầu không bỏ trống!" },
                ]}
              >
                <DatePicker className="w-100" format="DD/MM/YYYY" />
              </Form.Item>
            </div>
            <div className="col-lg-6">
              <Form.Item
                label="Ngày Kết Thúc"
                name="ngayKetThuc"
                rules={[
                  { required: true, message: "Ngày Kết Thúc không bỏ trống!" },
                ]}
              >
                <DatePicker className="w-100" format="DD/MM/YYYY" />
              </Form.Item>
            </div>
            <div className="col-lg-12">
              <Form.Item label="Mô Tả" name="moTa">
                <TextArea rows={4} />
              </Form.Item>
            </div>
          </div>
          <div className="text-right">
            <Button onClick={onCancel}>Quay lại</Button>
            <Button
              style={{ marginLeft: 10 }}
              type="primary"
              htmlType="submit"
              className="mr-3"
            >
              Cập Nhật Giảm Giá
            </Button>
          </div>
        </Form>
      </Modal>
    </div>
  );
};

export default FormCapNhatGiamGia;
