// https://www.youtube.com/watch?v=ycmK95xqe1k
import React, { useState, useEffect } from "react";
import { Table, Tooltip, Button, Space, message } from "antd";
import { EyeTwoTone } from "@ant-design/icons";
import TimKiem from "./TimKiem_BienTheTour.jsx";
import ChiTietDatTour from "./ChiTiet.jsx";

// Define table columns
const columns = (handleChiTiet) => [
  {
    title: "ID",
    dataIndex: "id",
    key: "id",
    render: (_, __, index) => (
      <a href="#!" onClick={(e) => e.preventDefault()}>
        {index + 1}
      </a>
    ),
    width: 50,
  },
  {
    title: "Họ Và Tên",
    dataIndex: "nguoiDung",
    key: "nguoiDung",
    ellipsis: {
      showTitle: false,
    },
    render: (nguoiDung) => (
      <Tooltip placement="topLeft" title={nguoiDung?.hoTen}>
        {nguoiDung?.hoTen}
      </Tooltip>
    ),
  },
  {
    title: "Biến Thể Tour",
    dataIndex: "bienTheTour",
    key: "bienTheTour",
    ellipsis: {
      showTitle: false,
    },
    render: (bienTheTour) => (
      <Tooltip placement="topLeft" title={bienTheTour?.ngayBatDau}>
        {bienTheTour?.ngayBatDau}
      </Tooltip>
    ),
  },
  {
    title: "Số Người",
    dataIndex: "soNguoi",
    key: "soNguoi",
    render: (soNguoi) => <Tooltip title={soNguoi}>{soNguoi}</Tooltip>,
  },
  {
    title: "Tổng Tiền",
    dataIndex: "tongTien",
    key: "tongTien",
    render: (tongTien) => (
      <Tooltip title={tongTien}>{tongTien.toLocaleString()} VND</Tooltip>
    ),
  },
  {
    title: "Mô Tả",
    dataIndex: "moTa",
    key: "moTa",
    render: (moTa) => <Tooltip title={moTa}>{moTa}</Tooltip>,
  },
  {
    title: "",
    key: "action",
    render: (_, record) => (
      <Space size="middle">
        {/* View Details */}
        <Button icon={<EyeTwoTone />} onClick={() => handleChiTiet(record)} />
      </Space>
    ),
  },
];

const App = () => {
  const [data, setData] = useState([]); // Store API data
  const [selectedUserId, setSelectedUserId] = useState(null);
  const [visible, setVisible] = useState(false);
  const fetchData = async () => {
    try {
      // Logic lấy dữ liệu từ API
      const response = await fetch("http://localhost:8080/api/chitietgiohang");
      const bienthetours = await response.json();
      // Sắp xếp theo id
      const sortedChiTietGioHangs = bienthetours.sort((a, b) => b.id - a.id);
      setData(sortedChiTietGioHangs);
    } catch (error) {
      message.error("Lỗi khi lấy dữ liệu: ");
      console.error("Lỗi khi lấy dữ liệu: ", error);
    }
  };
  useEffect(() => {
    fetchData();
  }, []);

  const handleBack = () => {
    setVisible(false);
    setSelectedUserId(null);
  };
  const handleChiTiet = (record) => {
    setSelectedUserId(record.id);
    setVisible(true);
  };

  return (
    <div className="container">
      <h3>Quản Lý Chi Tiết Giỏ Hàng</h3>
      <TimKiem />
      <Table columns={columns(handleChiTiet)} dataSource={data} />
      <ChiTietDatTour
        visible={visible}
        onBack={handleBack}
        paymentId={selectedUserId}
      />
    </div>
  );
};

export default App;
