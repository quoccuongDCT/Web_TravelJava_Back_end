import React, { useState, useEffect } from "react";
import axios from "axios";
import { Table, Tooltip, Button, ConfigProvider, Space, message } from "antd";
import {
  AntDesignOutlined,
  DeleteOutlined,
  HighlightTwoTone,
} from "@ant-design/icons";
import TimKiem from "./TimKiem_NguoiDung.jsx";
import ThemGiaTour from "./ThemGiaTour.jsx";
import CapNhatGiaTour from "./CapNhatGiaTour.jsx";

// Function to format currency in VND
const formatCurrency = (value) =>
  new Intl.NumberFormat("vi-VN", { style: "currency", currency: "VND" }).format(
    value
  );

// Cột dữ liệu của bảng
const columns = (showEditModal, handleDelete) => [
  {
    title: "ID",
    dataIndex: "id",
    key: "id",
    fixed: "left",
    render: (_, __, index) => (
      <a href="#!" onClick={(e) => e.preventDefault()}>
        {index + 1}
      </a>
    ),
    width: 50,
  },
  {
    title: "Giá Người Lớn",
    dataIndex: "giaNguoiLon",
    key: "giaNguoiLon",
    ellipsis: { showTitle: false },
    render: (giaNguoiLon) => (
      <Tooltip placement="topLeft" title={formatCurrency(giaNguoiLon)}>
        {formatCurrency(giaNguoiLon)}
      </Tooltip>
    ),
  },
  {
    title: "Giá Trẻ Em",
    dataIndex: "giaTreEm",
    key: "giaTreEm",
    ellipsis: { showTitle: false },
    render: (giaTreEm) => (
      <Tooltip placement="topLeft" title={formatCurrency(giaTreEm)}>
        {formatCurrency(giaTreEm)}
      </Tooltip>
    ),
  },
  {
    title: "",
    key: "action",
    fixed: "right",
    render: (_, record) => (
      <Space size="middle">
        <Button
          icon={<HighlightTwoTone />}
          onClick={() => showEditModal(record)}
        />
        <Button
          icon={<DeleteOutlined />}
          danger
          onClick={() => handleDelete(record.id)}
        />
      </Space>
    ),
  },
];

const App = () => {
  const [visible, setVisible] = useState(false);
  const [editingUser, setEditingUser] = useState(null);
  const [data, setData] = useState([]);

  const fetchData = async () => {
    try {
      const response = await axios.get("http://localhost:8080/api/giatour");
      const sortedNhanViens = response.data.sort((a, b) => b.id - a.id);
      setData(sortedNhanViens);
    } catch (error) {
      console.error("Lỗi khi tải dữ liệu:", error);
      message.error("Không thể tải dữ liệu từ server.");
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  const showModal = () => setVisible(true);

  const handleCancel = () => {
    setVisible(false);
    setEditingUser(null);
  };

  const showEditModal = (user) => {
    setEditingUser(user);
    setVisible(true);
  };

  const handleUpdateSuccess = async () => {
    try {
      const response = await axios.get("http://localhost:8080/api/giatour");
      const sortedNhanViens = response.data.sort((a, b) => b.id - a.id);
      setData(sortedNhanViens);
      setVisible(false);
      setEditingUser(null);
    } catch (error) {
      message.error("Không thể tải dữ liệu từ server.");
    }
  };

  const handleDelete = async (id) => {
    const confirmDelete = window.confirm(
      `Bạn có chắc chắn muốn xóa Hotels với ID: ${id}?`
    );
    if (confirmDelete) {
      try {
        await axios.delete(`http://localhost:8080/api/giatour/delete/${id}`);
        setData((prevData) => prevData.filter((user) => user.id !== id));
        message.success(`Đã xóa thành công: ${id}`);
      } catch (error) {
        console.error("Lỗi khi xóa Hotels :", error);
        message.error("Không thể xóa Hotels.");
      }
    }
  };

  return (
    <div className="container">
      <h3>Quản Lý Giá Tour</h3>
      <ConfigProvider>
        <Space>
          <Button
            className="nguoidung-them"
            type="primary"
            size="large"
            icon={<AntDesignOutlined />}
            onClick={showModal}
          >
            Thêm
          </Button>
        </Space>
        <ThemGiaTour
          visible={visible}
          onCancel={handleCancel}
          onDataReload={fetchData}
        />
      </ConfigProvider>

      <TimKiem />

      <div
        className="table-container align-items-center"
        style={{ marginRight: "-100px" }}
      >
        <Table
          columns={columns(showEditModal, handleDelete)}
          dataSource={data}
          rowKey="id"
        />
      </div>

      {editingUser && (
        <CapNhatGiaTour
          visible={visible}
          onCancel={handleCancel}
          GiaTourData={editingUser}
          onUpdateSuccess={handleUpdateSuccess}
        />
      )}
    </div>
  );
};

export default App;
