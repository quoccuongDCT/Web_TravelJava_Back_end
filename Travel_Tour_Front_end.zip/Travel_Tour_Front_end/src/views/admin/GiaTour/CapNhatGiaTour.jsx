import React, { useState } from "react";
import { Button, Checkbox, Form, Input, Modal, message } from "antd";
import axios from "axios";

const FormCapNhatGiaTour = ({
  visible,
  onCancel,
  GiaTourData,
  onUpdateSuccess,
}) => {
  const [componentDisabled, setComponentDisabled] = useState(false);
  const [form] = Form.useForm();

  const formatCurrencyVND = (value) => {
    if (!value) return "";
    return new Intl.NumberFormat("vi-VN", {
      style: "currency",
      currency: "VND",
    }).format(value);
  };

  const onFinish = async (values) => {
    try {
      const formData = {
        giaNguoiLon: parseInt(values.giaNguoiLon.replace(/\D/g, "")),
        giaTreEm: parseInt(values.giaTreEm.replace(/\D/g, "")),
      };

      if (GiaTourData?.id) {
        const response = await axios.put(
          `http://localhost:8080/api/giatour/update/${GiaTourData.id}`,
          formData
        );
        console.log(response.data);
        onUpdateSuccess();
        message.success("Cập nhật Giá Tour thành công");
        onCancel();
      } else {
        message.error("Không tìm thấy Giá Tour để cập nhật");
      }
    } catch (error) {
      if (error.response) {
        message.error(`Lỗi: ${error.response.data.message || error.message}`);
      } else if (error.request) {
        message.error("Không nhận được phản hồi từ máy chủ. Vui lòng thử lại.");
      } else {
        message.error("Đã xảy ra lỗi không mong muốn. Vui lòng thử lại.");
      }
    }
  };

  return (
    <Modal
      title="Cập Nhật Giá Tour"
      visible={visible}
      onCancel={onCancel}
      footer={null}
      width={900}
    >
      <Checkbox
        className="mb-3"
        checked={componentDisabled}
        onChange={(e) => setComponentDisabled(e.target.checked)}
      >
        Vô hiệu hóa biểu mẫu
      </Checkbox>
      <Form
        form={form}
        layout="vertical"
        disabled={componentDisabled}
        onFinish={onFinish}
        initialValues={{
          giaNguoiLon: formatCurrencyVND(GiaTourData.giaNguoiLon),
          giaTreEm: formatCurrencyVND(GiaTourData.giaTreEm),
        }}
      >
        <div className="row">
          <div className="col-lg-6">
            <Form.Item
              label="Giá Người Lớn"
              name="giaNguoiLon"
              rules={[
                {
                  required: true,
                  message: "Giá người lớn không được để trống!",
                },
              ]}
            >
              <Input
                placeholder="Giá người lớn"
                className="block w-full p-2 text-gray-900 border border-gray-300 rounded-lg bg-gray-50 text-xs focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                onChange={(e) =>
                  form.setFieldsValue({
                    giaNguoiLon: formatCurrencyVND(
                      e.target.value.replace(/\D/g, "")
                    ),
                  })
                }
              />
            </Form.Item>
          </div>
          <div className="col-lg-6">
            <Form.Item
              label="Giá Trẻ Em"
              name="giaTreEm"
              rules={[
                { required: true, message: "Giá trẻ em không được để trống!" },
              ]}
            >
              <Input
                placeholder="Giá trẻ em"
                className="block w-full p-2 text-gray-900 border border-gray-300 rounded-lg bg-gray-50 text-xs focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                onChange={(e) =>
                  form.setFieldsValue({
                    giaTreEm: formatCurrencyVND(
                      e.target.value.replace(/\D/g, "")
                    ),
                  })
                }
              />
            </Form.Item>
          </div>
        </div>
        <Form.Item className="text-right">
          <Button onClick={onCancel}>Quay Lại</Button>
          <Button style={{ marginLeft: 10 }} type="primary" htmlType="submit">
            Cập Nhật Giá Tour
          </Button>
        </Form.Item>
      </Form>
    </Modal>
  );
};

export default FormCapNhatGiaTour;
