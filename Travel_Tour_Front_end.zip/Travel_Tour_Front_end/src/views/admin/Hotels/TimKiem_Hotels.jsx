import React, { useState } from "react";
import { Select, AutoComplete, Button, Input, Row, Col } from "antd";
import { SearchOutlined } from "@ant-design/icons";

const TimKiem_khachSan = ({ data, onSearchResults }) => {
  const [searchValue, setSearchValue] = useState("");
  const [sortOrder, setSortOrder] = useState("");

  // Hàm xử lý tìm kiếm
  const handleSearch = () => {
    let filteredData = data;

    // Lọc dữ liệu theo từ khóa
    if (searchValue.trim()) {
      filteredData = data.filter((item) =>
        item.tenKhachSan.toLowerCase().includes(searchValue.toLowerCase())
      );
    }

    // Sắp xếp dữ liệu theo đánh giá
    if (sortOrder) {
      filteredData.sort((a, b) =>
        sortOrder === "asc"
          ? a.danhGiaKhachSan - b.danhGiaKhachSan
          : b.danhGiaKhachSan - a.danhGiaKhachSan
      );
    }

    onSearchResults(filteredData); // Gửi kết quả về component cha
  };

  return (
    <Row gutter={16} align="middle">
      {/* <Col>
        <Select
          showSearch
          placeholder="Sắp xếp đánh giá theo:"
          optionFilterProp="label"
          onChange={(value) => {
            setSortOrder(value);
            handleSearch(); // Gọi tìm kiếm khi thay đổi sắp xếp
          }}
          style={{ width: 250 }}
          options={[
            { value: "asc", label: "Tăng dần" },
            { value: "desc", label: "Giảm dần" },
          ]}
        />
      </Col> */}
      <Col className="flex items-center">
        <AutoComplete
          value={searchValue}
          onChange={(value) => {
            setSearchValue(value);
            handleSearch(); // Gọi tìm kiếm khi thay đổi từ khóa
          }}
          placeholder="Nhập từ khóa tìm kiếm"
          style={{ width: 250 }}
        ></AutoComplete>
      </Col>
      <Col>
        <Button icon={<SearchOutlined />} onClick={handleSearch}>
          Tìm kiếm
        </Button>
      </Col>
    </Row>
  );
};

export default TimKiem_khachSan;
