import React, { useRef, useState, useEffect } from "react";
import {
  Button,
  Checkbox,
  Form,
  Input,
  Modal,
  message,
  Select,
  Divider,
  Space,
  InputNumber,
} from "antd";
import { PlusOutlined } from "@ant-design/icons";
import axios from "axios"; // Import axios

const FormThemHotels = ({ visible, onCancel, reloadData }) => {
  const [componentDisabled, setComponentDisabled] = useState(false);
  const [items, setItems] = useState([]); // Initialize items for Select
  const [name, setName] = useState("");
  const inputRef = useRef(null);
  // let index = 0;

  useEffect(() => {
    if (visible) {
      fetchRatings();
    }
  }, [visible]);

  // Fetch the "Đánh giá khách sạn" data from the API
  const fetchRatings = async () => {
    try {
      const response = await axios.get("http://localhost:8080/api/hotels");

      // Tạo một tập hợp (Set) để lọc các đánh giá duy nhất
      const uniqueRatings = Array.from(
        new Set(response.data.map((hotel) => hotel.danhGiaKhachSan))
      );

      // Map các đánh giá duy nhất vào định dạng cần thiết cho các tùy chọn Select
      const hotelRatings = uniqueRatings.map((rating) => ({
        label: `Đánh giá ${rating}`, // Hiển thị nhãn đánh giá
        value: rating, // Sử dụng danhGiaKhachSan làm giá trị
      }));

      setItems(hotelRatings); // Thiết lập các tùy chọn với dữ liệu duy nhất
    } catch (error) {
      console.error("Không tải được đánh giá:", error);
      message.error("Lỗi khi tải đánh giá khách sạn!"); // Hiển thị lỗi nếu API thất bại
    }
  };

  const onFinish = async (values) => {
    const formData = {
      tenKhachSan: values.tenKhachSan,
      danhGiaKhachSan: values.danhGiaKhachSan, // Include the Select value
    };

    try {
      const response = await axios.post(
        "http://localhost:8080/api/hotels/them",
        formData
      );
      reloadData(); // Reload data after successful addition
      console.log("Hotels đã được thêm:", response.data);
      message.success("Thêm Hotels thành công"); // Success message
      onCancel(); // Close modal after submission
    } catch (error) {
      console.error("Có lỗi xảy ra:", error);
      message.error("Thêm Hotels thất bại!"); // Error message
    }
  };

  const onNameChange = (value) => {
    setName(value);
  };

  const addItem = (e) => {
    e.preventDefault();

    if (name !== "" && !isNaN(name)) {
      // Kiểm tra xem đánh giá đã tồn tại trong danh sách chưa
      const isExisting = items.some((item) => item.value === name);

      if (isExisting) {
        message.warning("Đánh giá này đã tồn tại!"); // Thông báo nếu đánh giá đã có
      } else {
        // Thêm đánh giá mới vào danh sách nếu chưa tồn tại
        setItems([...items, { label: `Đánh giá ${name}`, value: name }]);
        setName("");
        setTimeout(() => {
          inputRef.current?.focus();
        }, 0);
      }
    } else {
      message.error("Đánh giá phải là một số!"); // Hiển thị lỗi nếu không phải số
    }
  };

  return (
    <div className="container-fluid mt-5">
      <Modal
        title="Thêm Hotels"
        visible={visible}
        onCancel={onCancel}
        footer={null}
        width={900}
      >
        <Checkbox
          className="mb-3"
          checked={componentDisabled}
          onChange={(e) => setComponentDisabled(e.target.checked)}
        >
          Vô hiệu hóa biểu mẫu
        </Checkbox>
        <Form
          layout="vertical"
          disabled={componentDisabled}
          onFinish={onFinish}
        >
          <div className="row">
            {/* Select Dropdown for "Đánh giá khách sạn" */}
            <div className="col-lg-6">
              <Form.Item
                label="Đánh giá khách sạn"
                name="danhGiaKhachSan"
                rules={[
                  {
                    required: true,
                    message: "Đánh giá khách sạn không được để trống!",
                  },
                ]}
              >
                <Select
                  style={{
                    width: 300,
                  }}
                  placeholder="Đánh giá khách sạn"
                  dropdownRender={(menu) => (
                    <>
                      {menu}
                      <Divider
                        style={{
                          margin: "8px 0",
                        }}
                      />
                      <Space
                        style={{
                          padding: "0 8px 4px",
                        }}
                      >
                        <InputNumber
                          placeholder="Nhập đánh giá khách sạn"
                          ref={inputRef}
                          value={name}
                          onChange={onNameChange}
                          min={1} // Set a minimum value for rating
                          max={7} // Optional: Set a maximum value for rating
                          className="block w-full p-2 text-gray-900 border border-gray-300 rounded-lg bg-gray-50 text-xs focus:ring-blue-500 focus:border-blue-500"
                        />
                        <Button
                          type="text"
                          icon={<PlusOutlined />}
                          onClick={addItem}
                        >
                          Thêm đánh giá
                        </Button>
                      </Space>
                    </>
                  )}
                  options={items} // Use items for options
                />
              </Form.Item>
            </div>
            <div className="col-lg-6">
              <Form.Item
                label="Tên Khách Sạn "
                name="tenKhachSan"
                rules={[
                  {
                    required: true,
                    message: "Tên Khách Sạn không được để trống!",
                  },
                ]}
              >
                <Input
                  placeholder="Tên Khách Sạn"
                  className="block w-full p-2 text-gray-900 border border-gray-300 rounded-lg bg-gray-50 text-xs focus:ring-blue-500 focus:border-blue-500"
                />
              </Form.Item>
            </div>
          </div>
          <Form.Item className="text-right">
            <Button
              onClick={onCancel} // Call onCancel
            >
              Quay Lại
            </Button>
            <Button style={{ marginLeft: 10 }} type="primary" htmlType="submit">
              Thêm Hotels
            </Button>
          </Form.Item>
        </Form>
      </Modal>
    </div>
  );
};

export default FormThemHotels;


// import React, { useRef, useState, useEffect } from "react";
// import {
//   Button,
//   Checkbox,
//   Form,
//   Input,
//   Modal,
//   message,
//   Select,
//   Divider,
//   Space,
//   InputNumber,
// } from "antd";
// import { PlusOutlined } from "@ant-design/icons";
// import axios from "axios"; // Import axios

// const FormThemHotels = ({ visible, onCancel, reloadData }) => {
//   const [componentDisabled, setComponentDisabled] = useState(false);
//   const [items, setItems] = useState([]); // Initialize items for Select
//   const [name, setName] = useState("");
//   const inputRef = useRef(null);
//   // let index = 0;

//   useEffect(() => {
//     if (visible) {
//       fetchRatings();
//     }
//   }, [visible]);

//   // Fetch the "Đánh giá khách sạn" data from the API
//   const fetchRatings = async () => {
//     try {
//       const response = await axios.get("http://localhost:8080/api/hotels");

//       // Tạo một tập hợp (Set) để lọc các đánh giá duy nhất
//       const uniqueRatings = Array.from(
//         new Set(response.data.map((hotel) => hotel.danhGiaKhachSan))
//       );

//       // Map các đánh giá duy nhất vào định dạng cần thiết cho các tùy chọn Select
//       const hotelRatings = uniqueRatings.map((rating) => ({
//         label: `Đánh giá ${rating}`, // Hiển thị nhãn đánh giá
//         value: rating, // Sử dụng danhGiaKhachSan làm giá trị
//       }));

//       setItems(hotelRatings); // Thiết lập các tùy chọn với dữ liệu duy nhất
//     } catch (error) {
//       console.error("Không tải được đánh giá:", error);
//       message.error("Lỗi khi tải đánh giá khách sạn!"); // Hiển thị lỗi nếu API thất bại
//     }
//   };

//   const onFinish = async (values) => {
//     const formData = {
//       tenKhachSan: values.tenKhachSan,
//       danhGiaKhachSan: values.danhGiaKhachSan, // Include the Select value
//     };

//     try {
//       const response = await axios.post(
//         "http://localhost:8080/api/hotels/them",
//         formData
//       );
//       reloadData(); // Reload data after successful addition
//       console.log("Hotels đã được thêm:", response.data);
//       message.success("Thêm Hotels thành công"); // Success message
//       onCancel(); // Close modal after submission
//     } catch (error) {
//       console.error("Có lỗi xảy ra:", error);
//       message.error("Thêm Hotels thất bại!"); // Error message
//     }
//   };

//   const onNameChange = (value) => {
//     setName(value);
//   };

//   const addItem = (e) => {
//     e.preventDefault();
//     if (name !== "" && !isNaN(name)) {
//       // Ensure the added item is a number
//       setItems([...items, { label: `Đánh giá ${name}`, value: name }]);
//       setName("");
//       setTimeout(() => {
//         inputRef.current?.focus();
//       }, 0);
//     } else {
//       message.error("Đánh giá phải là một số!"); // Show error if not a number
//     }
//   };

//   return (
//     <div className="container-fluid mt-5">
//       <Modal
//         title="Thêm Hotels"
//         visible={visible}
//         onCancel={onCancel}
//         footer={null}
//         width={900}
//       >
//         <Checkbox
//           className="mb-3"
//           checked={componentDisabled}
//           onChange={(e) => setComponentDisabled(e.target.checked)}
//         >
//           Vô hiệu hóa biểu mẫu
//         </Checkbox>
//         <Form
//           layout="vertical"
//           disabled={componentDisabled}
//           onFinish={onFinish}
//         >
//           <div className="row">
//             {/* Select Dropdown for "Đánh giá khách sạn" */}
//             <div className="col-lg-6">
//               <Form.Item
//                 label="Đánh giá khách sạn"
//                 name="danhGiaKhachSan"
//                 rules={[
//                   {
//                     required: true,
//                     message: "Đánh giá khách sạn không được để trống!",
//                   },
//                 ]}
//               >
//                 <Select
//                   style={{
//                     width: 300,
//                   }}
//                   placeholder="Đánh giá khách sạn"
//                   dropdownRender={(menu) => (
//                     <>
//                       {menu}
//                       <Divider
//                         style={{
//                           margin: "8px 0",
//                         }}
//                       />
//                       <Space
//                         style={{
//                           padding: "0 8px 4px",
//                         }}
//                       >
//                         <InputNumber
//                           placeholder="Nhập đánh giá khách sạn"
//                           ref={inputRef}
//                           value={name}
//                           onChange={onNameChange}
//                           min={1} // Set a minimum value for rating
//                           max={7} // Optional: Set a maximum value for rating
//                           className="block w-full p-2 text-gray-900 border border-gray-300 rounded-lg bg-gray-50 text-xs focus:ring-blue-500 focus:border-blue-500"
//                         />
//                         <Button
//                           type="text"
//                           icon={<PlusOutlined />}
//                           onClick={addItem}
//                         >
//                           Thêm đánh giá
//                         </Button>
//                       </Space>
//                     </>
//                   )}
//                   options={items} // Use items for options
//                 />
//               </Form.Item>
//             </div>
//             <div className="col-lg-6">
//               <Form.Item
//                 label="Tên Khách Sạn "
//                 name="tenKhachSan"
//                 rules={[
//                   {
//                     required: true,
//                     message: "Tên Khách Sạn không được để trống!",
//                   },
//                 ]}
//               >
//                 <Input
//                   placeholder="Tên Khách Sạn"
//                   className="block w-full p-2 text-gray-900 border border-gray-300 rounded-lg bg-gray-50 text-xs focus:ring-blue-500 focus:border-blue-500"
//                 />
//               </Form.Item>
//             </div>
//           </div>
//           <Form.Item className="text-right">
//             <Button
//               onClick={onCancel} // Call onCancel
//             >
//               Quay Lại
//             </Button>
//             <Button style={{ marginLeft: 10 }} type="primary" htmlType="submit">
//               Thêm Hotels
//             </Button>
//           </Form.Item>
//         </Form>
//       </Modal>
//     </div>
//   );
// };

// export default FormThemHotels;

