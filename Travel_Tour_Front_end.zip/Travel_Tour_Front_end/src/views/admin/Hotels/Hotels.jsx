import React, { useState, useEffect } from "react";
import axios from "axios"; // Import axios
import {
  Table,
  Tooltip,
  Button,
  ConfigProvider,
  Space,
  message,
  Modal,
} from "antd";
import {
  AntDesignOutlined,
  DeleteOutlined,
  HighlightTwoTone,
} from "@ant-design/icons";
// import "./Css/NhanVien.css";
import ThemHotels from "./ThemHotels.jsx";
import CapNhatHotels from "./CapNhatHotels.jsx";
import TimKiem_khachSan from "./TimKiem_Hotels.jsx";

// Cột dữ liệu của bảng
const columns = (renderStars, showEditModal, handleDelete) => [
  {
    title: "STT",
    dataIndex: "id",
    key: "id",
    fixed: "left",
    render: (_, __, index) => (
      <a href="#!" onClick={(e) => e.preventDefault()}>
        {index + 1}
      </a>
    ),
    width: 100,
  },
  {
    title: "Đánh Giá Khách Sạn",
    dataIndex: "danhGiaKhachSan",
    key: "danhGiaKhachSan",
    ellipsis: {
      showTitle: false,
    },
    render: (danhGiaKhachSan) => (
      <Tooltip placement="topLeft" title={danhGiaKhachSan}>
        {renderStars(danhGiaKhachSan)}
      </Tooltip>
    ),
  },
  {
    title: "Tên Khách Sạn",
    dataIndex: "tenKhachSan",
    key: "tenKhachSan",
    ellipsis: {
      showTitle: false,
    },
    render: (tenKhachSan) => (
      <Tooltip placement="topLeft" title={tenKhachSan}>
        {tenKhachSan}
      </Tooltip>
    ),
  },
  {
    title: "",
    key: "action",
    fixed: "right",
    render: (_, record) => (
      <Space size="middle">
        {/* Nút Sửa */}
        <Tooltip title="Cập nhật thông tin Khách Sạn">
          <Button
            icon={<HighlightTwoTone />}
            onClick={() => showEditModal(record)} // Hiển thị modal với dữ liệu người dùng được chọn
          ></Button>
        </Tooltip>

        {/* Nút Xóa */}
        <Tooltip title="Xóa Khách Sạn">
          <Button
            icon={<DeleteOutlined />}
            danger
            onClick={() => handleDelete(record.id, record.tenKhachSan)} // Gọi hàm xóa
          ></Button>
        </Tooltip>
      </Space>
    ),
  },
];

const FormKhachSan = () => {
  const [visible, setVisible] = useState(false);
  const [editingUser, setEditingUser] = useState(null);
  const [data, setData] = useState([]);
  const [searchData, setSearchData] = useState([]); // Dữ liệu hiển thị sau tìm kiếm
  const [isSearching, setIsSearching] = useState(false);

  const fetchData = async () => {
    try {
      const response = await axios.get("http://localhost:8080/api/hotels");
      const sortedHotels = response.data.sort((a, b) => b.id - a.id);
      setData(sortedHotels);
    } catch (error) {
      console.error("Lỗi khi tải dữ liệu:", error);
      message.error("Không thể tải dữ liệu từ server.");
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  const handleSearchResults = (results) => {
    setSearchData(results); // Cập nhật dữ liệu hiển thị
    setIsSearching(true);
  };

  const showModal = () => {
    setVisible(true);
  };

  const handleCancel = () => {
    setVisible(false);
    setEditingUser(null);
  };

  const showEditModal = (user) => {
    setEditingUser(user);
    setVisible(true);
  };
  const renderStars = (stars) => {
    const maxStars = 5; // Assuming a maximum rating of 5 stars
    return Array.from({ length: maxStars }, (_, index) => (
      <span
        key={index}
        style={{ color: index < stars ? "#FFD700" : "#d3d3d3" }}
      >
        ★
      </span>
    ));
  };
  const handleDelete = (id, tenKhachSan) => {
    // Show the confirmation popup with the category name included
    Modal.confirm({
      title: `Bạn có chắc chắn muốn xóa Khách Sạn với Tên Khách Sạn: ${tenKhachSan}`, // Display the category name in the confirmation message
      okText: "Có", // Text for the OK button (Yes)
      cancelText: "Không", // Text for the Cancel button (No)
      onOk: async () => {
        // onOk is called when the user clicks "Yes"
        try {
          // Make the DELETE request to the backend
          await axios.delete(`http://localhost:8080/api/hotels/delete/${id}`);

          // Remove the deleted item from the local state to update the UI
          setData((prevData) => prevData.filter((item) => item.id !== id));

          // Show success message
          message.success(`Đã xóa thành công: ${tenKhachSan}`);
        } catch (error) {
          console.error("Lỗi khi xóa Khách Sạn:", error);
          message.error("Không thể xóa Khách Sạn .");
        }
      },
      onCancel: () => {
        // Optionally, log or handle the cancel action
        console.log("Xóa bị hủy");
      },
    });
  };

  return (
    <div className="container">
      <h3>Quản Lí Khách Sạn</h3>

      <ConfigProvider>
        <div className="button-container">
          <Button
            type="primary"
            size="large"
            icon={<AntDesignOutlined />}
            onClick={showModal}
          >
            Thêm
          </Button>
        </div>
        <ThemHotels
          visible={visible}
          onCancel={handleCancel}
          reloadData={fetchData}
        />
      </ConfigProvider>

      <div className="flex flex-col gap-[16px]">
        <TimKiem_khachSan data={data} onSearchResults={handleSearchResults} />
        <div className="table-container" style={{ marginRight: "-100px" }}>
          <Table
            columns={columns(renderStars, showEditModal, handleDelete)}
            dataSource={isSearching ? searchData : data}
            rowKey="id"
          />
        </div>
      </div>

      {editingUser && (
        <CapNhatHotels
          visible={visible}
          onCancel={handleCancel}
          HotelsData={editingUser}
          onUpdateSuccess={fetchData}
        />
      )}
    </div>
  );
};

export default FormKhachSan;
