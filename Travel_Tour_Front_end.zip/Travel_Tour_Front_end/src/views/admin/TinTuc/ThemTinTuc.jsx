import React, { useState, useEffect } from "react";
import { Button, Form, Input, Modal, Upload, Image,  message, DatePicker } from "antd";
import { PlusOutlined } from "@ant-design/icons";
import { storage } from "./js/Config";
import { ref, uploadBytes, getDownloadURL } from "firebase/storage";
import ReactQuill from "react-quill";
import "react-quill/dist/quill.snow.css";
import axios from "axios";
// import { message } from "react-messageify";

const { TextArea } = Input;

const FormThemBaiViet = ({ visible, onCancel, onBack, onAddSuccess }) => {
  const [fileList, setFileList] = useState([]);
  const [previewImage, setPreviewImage] = useState("");
  const [previewOpen, setPreviewOpen] = useState(false);
  const [noiDung, setNoiDung] = useState("");
  const [form] = Form.useForm();
  const [userId, setUserId] = useState(null);

  // Lấy userId từ localStorage
  useEffect(() => {
    const storedUserId = localStorage.getItem("id");
    if (storedUserId) {
      setUserId(storedUserId);
    }
  }, []);

  const getBase64 = (file) => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = () => resolve(reader.result);
      reader.onerror = (error) => reject(error);
    });
  };

  const handlePreview = async (file) => {
    if (!file.url && !file.preview) {
      file.preview = await getBase64(file.originFileObj);
    }
    setPreviewImage(file.url || file.preview);
    setPreviewOpen(true);
  };

  const handleChange = ({ fileList: newFileList }) => {
    setFileList(newFileList);
  };

  // thêm hình ảnh vào firebase
  const uploadToFirebase = async (file) => {
    const storageRef = ref(storage, `images/${file.name}`);
    await uploadBytes(storageRef, file.originFileObj);
    const url = await getDownloadURL(storageRef);
    return url;
  };

  // thêm video vào firebase
  const uploadVideoToFirebase = async (file) => {
    const storageRef = ref(storage, `videos/${file.name}`);
    await uploadBytes(storageRef, file.originFileObj);
    const url = await getDownloadURL(storageRef);
    return url;
  };

  const onFinish = async (values) => {
    if (!userId) {
      message.error("Không thể xác định người dùng.");
      return;
    }

    if (fileList.length === 0) {
      message.error("Vui lòng tải lên ít nhất một ảnh.");
      return;
    }

    try {
      const uploadedImages = await Promise.all(
        fileList.map((file) => uploadToFirebase(file))
      );

      // Nếu có video được chọn, upload video lên Firebase
      let uploadedVideoUrl = "";
      if (values.videoFile) {
        uploadedVideoUrl = await uploadVideoToFirebase(values.videoFile);
      }

      const formData = {
        ...values,
        hinhAnh: uploadedImages.join(","), // Chuyển danh sách ảnh thành chuỗi
        video: uploadedVideoUrl, // Lưu URL video
        noiDung, // Nội dung bài viết
        nguoiDung: { id: userId }, // Thêm userId vào dữ liệu bài viết
      };

      console.log("Dữ liệu form:", formData);

      // Gửi bài viết đến API
      const response = await axios.post(
        "http://localhost:8080/api/bai-viet/add",
        formData
      );
      console.log("Bài viết đã thêm:", response.data);

      message.success("Thêm bài viết thành công!");
      form.resetFields();
      setFileList([]);
      setNoiDung("");

      form.setFieldsValue({ videoFile: null });
      onAddSuccess();
      onCancel();
    } catch (error) {
      // message.error("Lỗi khi thêm bài viết.",error);
      message.error("Lỗi khi thêm bài viết, vui lòng thử lại.");
    }
  };

  const uploadButton = (
    <div>
      <PlusOutlined />
      <div style={{ marginTop: 8 }}>Tải lên</div>
    </div>
  );

  return (
    <div className="container-fluid mt-5">
      <Modal
        title="Thêm Tin Tức"
        visible={visible}
        onCancel={onCancel}
        footer={null}
        width={900}
      >
        <Form form={form} layout="vertical" onFinish={onFinish}>
          <Form.Item
            label="Tiêu Đề"
            name="tieuDe"
            rules={[
              { required: true, message: "Tiêu đề không được để trống!" },
            ]}
          >
            <Input placeholder="Tiêu đề" />
          </Form.Item>

          <Form.Item
            label="Ngày Đăng"
            name="ngayDang"
            rules={[
              { required: true, message: "Ngày đăng không được để trống!" },
            ]}
          >
            <DatePicker className="w-100" />
          </Form.Item>

          <Form.Item
            label="Nội Dung"
            name="noiDung"
            rules={[
              { required: true, message: "Nội dung không được để trống!" },
            ]}
          >
            <ReactQuill
              theme="snow"
              value={noiDung}
              onChange={setNoiDung}
              placeholder="Nội dung bài viết"
              style={{ height: "200px", marginBottom: "40px" }}
            />
          </Form.Item>

          <Form.Item label="Mô tả" name="moTa">
            <TextArea rows={3} placeholder="Mô tả" />
          </Form.Item>

          {/* <Form.Item
            label="Video"
            name="videoFile"
            valuePropName="file"
            getValueFromEvent={({ file }) => file}
          >
            <Upload
              accept="video/*"
              beforeUpload={() => false} // Tắt tự động upload
              listType="picture-card"
            >
              <div>
                <PlusOutlined />
                <div style={{ marginTop: 8 }}>Tải lên Video</div>
              </div>
            </Upload>
          </Form.Item> */}

          <Form.Item label="Ảnh" name="hinhAnh">
            <Upload
              listType="picture-circle"
              fileList={fileList}
              onPreview={handlePreview}
              onChange={handleChange}
              beforeUpload={() => false}
              maxCount={1} // Giới hạn chỉ tải 1 hình ảnh
            >
              {fileList.length < 1 ? uploadButton : null}
            </Upload>

            {previewImage && previewOpen && (
              <Image
                preview={{
                  visible: previewOpen,
                  onVisibleChange: (visible) => setPreviewOpen(visible),
                }}
                src={previewImage}
                className="img-fluid"
              />
            )}
          </Form.Item>

          <div className="d-flex justify-content-between mt-3">
            <Button onClick={onBack}>Quay Lại</Button>
            <Button type="primary" htmlType="submit">
              Thêm bài
            </Button>
          </div>
        </Form>
      </Modal>
    </div>
  );
};

export default FormThemBaiViet;
