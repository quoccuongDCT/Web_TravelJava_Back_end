import React, { useState, useEffect } from "react";
import { Table, Tooltip, Button, ConfigProvider , message,
  Space, 
  Modal} from "antd";
import {
  AntDesignOutlined,
  DeleteOutlined,
  HighlightTwoTone,
} from "@ant-design/icons";
import axios from "axios";
import TimKiem from "./TimKiem_TinTuc";
import ThemPhanQuyen from "./ThemTinTuc";
import CapNhatTinTuc from "./CapNhatTinTuc";
import { ref, getDownloadURL } from "firebase/storage";
import { storage } from "./js/Config";
import { Image } from "antd";
// import { message } from "react-messageify";

const columns = (showEditModal, handleDelete) => [
  {
    title: "STT",
    dataIndex: "id",
    key: "id",
    render: (_, __, index) => (
      <a href="#!" onClick={(e) => e.preventDefault()}>
        {index + 1}
      </a>
    ),
    width: 60,
  },
  {
    title: "Ảnh",
    dataIndex: "hinhAnh",
    key: "hinhAnh",
    render: (hinhAnh) => (
      <Image src={hinhAnh} alt="Profile" style={{ width: 200, height: 100 }} />
    ),
  },
  {
    title: "Tiêu Đề",
    dataIndex: "tieuDe",
    key: "tieuDe",
    ellipsis: { showTitle: false },
    render: (tieuDe) => (
      <Tooltip placement="topLeft" title={tieuDe}>
        {tieuDe}
      </Tooltip>
    ),
  },
  {
    title: "Mô Tả",
    dataIndex: "moTa",
    key: "moTa",
    ellipsis: { showTitle: false },
    render: (moTa) => (
      <Tooltip placement="topLeft" title={moTa}>
        {moTa}
      </Tooltip>
    ),
  },

  {
    title: "Ngày Đăng",
    dataIndex: "ngayDang",
    key: "ngayDang",
    ellipsis: { showTitle: false },
    render: (ngayDang) => (
      <Tooltip placement="topLeft" title={ngayDang}>
        {ngayDang}
      </Tooltip>
    ),
  },

  {
    title: "",
    key: "action",
    fixed: "right",
    render: (_, record) => (
      <Space size="middle">
        {/* Nút Sửa */}
        <Button
          icon={<HighlightTwoTone />}
          onClick={() => showEditModal(record)} // Hiển thị modal với dữ liệu người dùng được chọn
        ></Button>

        {/* Nút Xóa */}
        <Button
          icon={<DeleteOutlined />}
          danger
          onClick={() => handleDelete(record.id)} // Gọi hàm xóa
        ></Button>
      </Space>
    ),
  },
];

const FormQuanLyTinTuc = () => {
  const [visible, setVisibleEdit] = useState(false);
  // const [visibleDetail, setVisibleDetail] = useState(false);
  const [editingUser, setEditingUser] = useState(null);
  const [data, setData] = useState([]); // State lưu dữ liệu bài viết

  useEffect(() => {
    fetchBaiViet();
  }, []);

  const fetchBaiViet = async () => {
    try {
      const response = await axios.get("http://localhost:8080/api/bai-viet");
      const baiViets = response.data;

      // Lấy URL ảnh từ Firebase
      const updatedBaiViets = await Promise.all(
        baiViets.map(async (baiViet) => {
          try {
            const imageRef = ref(storage, baiViet.hinhAnh);
            const imageUrl = await getDownloadURL(imageRef);
            return { ...baiViet, hinhAnh: imageUrl };
          } catch (error) {
            // console.error(
            //   `Lỗi khi lấy URL cho bài viết ID: ${baiViet.id}`,
            //   error
            // );
            message.error(
              `Lỗi khi lấy URL cho bài viết ID: ${baiViet.id}`,
              error
            );
            return { ...baiViet, anh: "", video: "" };
          }
        })
      );

      setData(updatedBaiViets);
    } catch (error) {
      message.error("Lỗi khi lấy dữ liệu bài viết:", error);
    }
  };

  const showModalEdit = () => {
    setVisibleEdit(true);
  };

  const handleCancelEdit = () => {
    setVisibleEdit(false);
    setEditingUser(null);
  };

  const showEditModal = (user) => {
    setEditingUser(user);
    setVisibleEdit(true);
  };

  // const handleDelete = async (id) => {
  //   const confirmDelete = window.confirm(
  //     `Bạn có chắc chắn muốn xóa Tin Tức này với ID: ${id}?`
  //   );
  //   if (confirmDelete) {
  //     try {
  //       // Gửi yêu cầu DELETE tới API xóa bài viết
  //       const response = await axios.delete(
  //         `http://localhost:8080/api/bai-viet/delete/${id}`
  //       );

  //       // Nếu xóa thành công, hiển thị thông báo
  //       // message.success(response.data);
  //       message.success(response.data);

  //       // Sau khi xóa, gọi lại fetchBaiViet để cập nhật dữ liệu
  //       fetchBaiViet();
  //     } catch (error) {
  //       // console.error("Lỗi khi xóa bài viết:", error);
  //       message.error("Lỗi khi xóa bài viết:", error);
  //       // message.error(`Xóa bài viết với ID: ${id} thất bại`);
  //     }
  //   }
  // };

  const handleDelete = (id) => {
    // Show the confirmation popup with the category name included
    Modal.confirm({
      title: `Bạn có chắc chắn muốn xóa Tin Tức này: ${id}`, // Display the category name in the confirmation message
      okText: "Có", // Text for the OK button (Yes)
      cancelText: "Không", // Text for the Cancel button (No)
      onOk: async () => {
        // onOk is called when the user clicks "Yes"
        try {
          // Gửi yêu cầu DELETE tới API xóa bài viết
          const response = await axios.delete(
            `http://localhost:8080/api/bai-viet/delete/${id}`
          );
  
          // Nếu xóa thành công, hiển thị thông báo
          // message.success(response.data);
          message.success(response.data);
  
          // Sau khi xóa, gọi lại fetchBaiViet để cập nhật dữ liệu
          fetchBaiViet();
        } catch (error) {
          // console.error("Lỗi khi xóa bài viết:", error);
          message.error("Lỗi khi xóa bài viết:", error);
          // message.error(`Xóa bài viết với ID: ${id} thất bại`);
        }
      },
      onCancel: () => {
        // Optionally, log or handle the cancel action
        console.log("Xóa bị hủy");
      },
    });
  };

  return (
    <div className="container">
      <h3>Quản Lý Bài Viết</h3>
      <ConfigProvider>
        <div className="button-container">
          <Button
            className="tintuc-them"
            type="primary"
            size="large"
            icon={<AntDesignOutlined />}
            onClick={showModalEdit}
          >
            Thêm bài viết
          </Button>
        </div>
        <ThemPhanQuyen
          visible={visible}
          onCancel={handleCancelEdit}
          onAddSuccess={fetchBaiViet} /*tự động load lại khi thêm dữ liệu*/
        />
      </ConfigProvider>
      {/* <TimKiem /> */}
      <div
        className="table-container align-items-center"
        style={{ marginRight: "-100px" }}
      >
        <Table
          columns={columns(showEditModal, handleDelete)}
          dataSource={data}
          rowKey="id"
        />
      </div>
      {/* {editingUser && (
        <CapNhatTinTuc
          visible={visibleEdit}
          onCancel={handleCancelEdit}
          user={editingUser}
        />
      )} */}
      {editingUser && (
        <CapNhatTinTuc
          visible={visible}
          onCancel={handleCancelEdit}
          categoryData={editingUser} // Pass the editing user data
          onUpdateSuccess={
            fetchBaiViet
          } /*tự động load lại khi cập nhật dữ liệu*/
        />
      )}
    </div>
  );
};

export default FormQuanLyTinTuc;
