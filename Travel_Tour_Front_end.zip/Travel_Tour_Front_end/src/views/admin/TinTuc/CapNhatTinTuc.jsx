import React, { useState, useEffect } from "react";
import { Button, Form, Input, Modal, Upload, DatePicker, message } from "antd";
import { PlusOutlined } from "@ant-design/icons";
import { storage } from "./js/Config";
import { ref, uploadBytes, getDownloadURL } from "firebase/storage";
import ReactQuill from "react-quill";
import "react-quill/dist/quill.snow.css";
import axios from "axios";
import moment from "moment";

const { TextArea } = Input;

const FormCapNhatBaiViet = ({
  visible,
  onCancel,
  onBack,
  onUpdateSuccess,
  categoryData,
}) => {
  const [fileList, setFileList] = useState([]);
  const [noiDung, setNoiDung] = useState("");
  const [form] = Form.useForm();
  const [previewOpen, setPreviewOpen] = useState(false);
  const [previewImage, setPreviewImage] = useState("");
  const [userId, setUserId] = useState(null);

  useEffect(() => {
    if (categoryData && categoryData.id) {
      const storedUserId = localStorage.getItem("id");
      if (storedUserId) {
        setUserId(storedUserId);
      }

      const fetchPostData = async () => {
        try {
          const response = await axios.get(
            `http://localhost:8080/api/bai-viet/${categoryData.id}`
          );
          const postData = response.data;
          form.setFieldsValue({
            tieuDe: postData.tieuDe,
            ngayDang: moment(postData.ngayDang),
            moTa: postData.moTa,
          });
          setNoiDung(postData.noiDung);
          setFileList(postData.hinhAnh.split(",").map((url) => ({ url })));
        } catch (error) {
          message.error("Lỗi khi tải dữ liệu bài viết");
          console.error(error);
        }
      };
      fetchPostData();
    } else {
      // Kiểm tra và chỉ gọi một lần nếu categoryData không hợp lệ
      if (categoryData) {
        message.error("Không có dữ liệu bài viết.");
      }
    }
  }, [categoryData, form]); // Chỉ gọi lại khi categoryData hoặc form thay đổi

  const handleChange = ({ fileList: newFileList }) => {
    setFileList(newFileList);
  };

  const uploadToFirebase = async (file) => {
    const storageRef = ref(storage, `images/${file.name}`);
    await uploadBytes(storageRef, file.originFileObj);
    const url = await getDownloadURL(storageRef);
    return url;
  };

  const onFinish = async (values) => {
    try {
      const uploadedImages = await Promise.all(
        fileList.map((file) => uploadToFirebase(file))
      );

      const formData = {
        tieuDe: values.tieuDe,
        ngayDang: values.ngayDang.format("YYYY-MM-DD"),
        noiDung,
        moTa: values.moTa,
        hinhAnh: uploadedImages.join(","),
        nguoiDung: { id: userId },
      };

      const response = await axios.put(
        `http://localhost:8080/api/bai-viet/update/${categoryData.id}`,
        formData
      );

      // Kiểm tra phản hồi từ API
      if (response.status === 200) {
        message.success("Cập nhật bài viết thành công!");
        onUpdateSuccess();
        onCancel();
      } else {
        message.error("Cập nhật bài viết thất bại. Vui lòng thử lại.");
      }
    } catch (error) {
      console.error("Lỗi khi cập nhật bài viết:", error);
      message.error(`Lỗi khi cập nhật bài viết: ${error.message || error}`);
    }
  };

  const uploadButton = (
    <div>
      <PlusOutlined />
      <div style={{ marginTop: 8 }}>Tải lên</div>
    </div>
  );

  const handlePreview = async (file) => {
    setPreviewImage(file.url || file.thumbUrl);
    setPreviewOpen(true);
  };

  return (
    <div className="container-fluid mt-5">
      <Modal
        title="Cập Nhật Bài Viết"
        visible={visible}
        onCancel={onCancel}
        footer={null}
        width={900}
      >
        <Form
          form={form}
          layout="vertical"
          onFinish={onFinish}
          initialValues={{
            tieuDe: categoryData?.tieuDe,
            ngayDang: categoryData?.ngayDang
              ? moment(categoryData?.ngayDang)
              : null,
            moTa: categoryData?.moTa,
            noiDung: categoryData?.noiDung,
          }}
        >
          <Form.Item
            label="Tiêu Đề"
            name="tieuDe"
            rules={[
              { required: true, message: "Tiêu đề không được để trống!" },
            ]}
          >
            <Input placeholder="Tiêu đề" />
          </Form.Item>

          <Form.Item
            label="Ngày Đăng"
            name="ngayDang"
            rules={[
              { required: true, message: "Ngày đăng không được để trống!" },
            ]}
          >
            <DatePicker className="w-100" disabled />
          </Form.Item>

          <Form.Item
            label="Nội Dung"
            name="noiDung"
            rules={[
              { required: true, message: "Nội dung không được để trống!" },
            ]}
          >
            <ReactQuill
              theme="snow"
              value={noiDung}
              onChange={setNoiDung}
              placeholder="Nội dung bài viết"
              style={{ height: "500px", marginBottom: "40px" }}
            />
          </Form.Item>

          <Form.Item label="Mô tả" name="moTa">
            <TextArea rows={3} placeholder="Mô tả" />
          </Form.Item>

          <Form.Item label="Hình Ảnh" name="hinhAnh">
            <Upload
              listType="picture-card"
              fileList={fileList}
              onPreview={handlePreview}
              onChange={handleChange}
            >
              {fileList.length >= 1 ? null : uploadButton}
            </Upload>
            <Modal
              visible={previewOpen}
              title="Xem trước hình ảnh"
              footer={null}
              onCancel={() => setPreviewOpen(false)}
            >
              <img alt="example" style={{ width: "100%" }} src={previewImage} />
            </Modal>
          </Form.Item>

          <div className="d-flex justify-content-between mt-3">
            <Button onClick={onBack}>Quay Lại</Button>
            <Button type="primary" htmlType="submit">
              Cập Nhật bài viết
            </Button>
          </div>
        </Form>
      </Modal>
    </div>
  );
};

export default FormCapNhatBaiViet;
