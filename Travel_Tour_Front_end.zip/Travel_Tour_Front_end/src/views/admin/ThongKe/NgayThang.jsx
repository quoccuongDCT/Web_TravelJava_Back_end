import React from "react";
import { DatePicker, Space } from "antd";
import dayjs from "dayjs";

const { RangePicker } = DatePicker;

const NgayThang = ({ onChange }) => {
  const currentYearStart = dayjs().startOf("year"); // Ngày đầu năm hiện tại
  const currentYearEnd = dayjs().endOf("year"); // Ngày cuối năm hiện tại

  return (
    <Space direction="vertical" size={12}>
      <RangePicker
        format="DD/MM/YYYY"
        defaultValue={[currentYearStart, currentYearEnd]} // Đặt giá trị mặc định là đầu và cuối năm hiện tại
        onChange={(dates, dateStrings) => {
          console.log("Selected Dates (DayJS objects):", dates);
          console.log("Selected Dates (Formatted Strings):", dateStrings);
          onChange(dates); // Gửi mảng ngày đã chọn lên parent
        }}
      />
    </Space>
  );
};

export default NgayThang;
