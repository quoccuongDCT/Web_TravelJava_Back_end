"use client";

import React, { useState, useEffect } from "react";
import axios from "axios";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Bar,
  BarChart,
} from "recharts";
import TableDoanhThu from "./TableThongKe";
import NgayThang from "./NgayThang";
import TableTour from "./TableTour";
import moment from "moment"; // Cần cài moment để xử lý định dạng ngày

export default function RevenueDashboard() {
  const [totalBookedTours, setTotalBookedTours] = useState(0);
  const [revenueData, setRevenueData] = useState([]); // Lưu dữ liệu doanh thu từ API
  const [tourData, setTourData] = useState([]); // Lưu dữ liệu tour từ API
  const [participantData, setParticipantData] = useState([]); // Dữ liệu số lượng người tham gia tour
  const [participantData2, setParticipantData2] = useState([]);
  const [startDate, setStartDate] = useState(moment().startOf("year")); // Ngày đầu của năm hiện tại
  const [endDate, setEndDate] = useState(moment().endOf("year")); // Ngày cuối của năm hiện tại

  console.log("Ngày bắt đầu:", startDate.format("DD/MM/YYYY"));
  console.log("Ngày kết thúc:", endDate.format("DD/MM/YYYY"));

  const fetchTotalBookedTours = async () => {
    if (startDate && endDate) {
      try {
        const startDateStr = startDate.format("DD/MM/YYYY");
        const endDateStr = endDate.format("DD/MM/YYYY");
        const response = await axios.get(
          `http://localhost:8080/api/thongke/tong-so-luong-tour-da-dat?ngayBatDau=${startDateStr}&ngayKetThuc=${endDateStr}`
        );
        console.log("Dữ liệu tổng số lượng tour đã đặt:", response.data);

        setTotalBookedTours(response.data);
      } catch (error) {
        console.error("Lỗi khi lấy dữ liệu tổng số lượng tour đã đặt:", error);
      }
    }
  };
  //  Hàm gọi API để lấy dữ liệu doanh thu từ backend
  const fetchRevenueData = async () => {
    if (startDate && endDate) {
      try {
        // Chuyển ngày tháng thành định dạng phù hợp
        const startDateStr = startDate.format("DD/MM/YYYY");
        const endDateStr = endDate.format("DD/MM/YYYY");
        // Gửi yêu cầu API đến backend
        const response = await axios.get(
          `http://localhost:8080/api/thongke/tong-doanh-thu?ngayBatDau=${startDateStr}&ngayKetThuc=${endDateStr}`
        );
        console.log("Dữ liệu doanh thu nhận được từ API: ", response.data);
        // Lưu doanh thu vào state
        setRevenueData(response.data); // Lưu dữ liệu doanh thu vào state
      } catch (error) {
        console.error("Error fetching revenue data:", error);
      }
    }

    if (startDate && endDate) {
      try {
        // Chuyển ngày tháng thành định dạng phù hợp
        const startDateStr = startDate.format("DD/MM/YYYY");
        const endDateStr = endDate.format("DD/MM/YYYY");
        // Gửi yêu cầu API đến backend
        const response = await axios.get(
          `http://localhost:8080/api/thongke/bieu-do-doanh-thu?ngayBatDau=${startDateStr}&ngayKetThuc=${endDateStr}`
        );
        console.log("Dữ liệu doanh thu nhận được từ API: ", response.data); // Log dữ liệu trả về
        // Chuyển đổi dữ liệu từ mảng 2 chiều sang mảng đối tượng
        const formattedData = response.data.map((item) => ({
          date: moment(item[0]).format("DD/MM/YYYY"), // Ngày
          "Doanh Thu": item[1], // Doanh thu
        }));
        // Lưu dữ liệu đã chuyển đổi vào state
        setRevenueData(formattedData);
      } catch (error) {
        console.error("Error fetching revenue data:", error);
      }
    }
  };
  // Hàm gọi API để lấy dữ liệu số lượng tour đã đặt
  const fetchTourData = async () => {
    if (startDate && endDate) {
      try {
        // Chuyển ngày tháng thành định dạng phù hợp
        const startDateStr = startDate.format("DD/MM/YYYY");
        const endDateStr = endDate.format("DD/MM/YYYY");
        // Gửi yêu cầu API đến backend
        const response = await axios.get(
          `http://localhost:8080/api/thongke/bieu-do-so-luong-tour?ngayBatDau=${startDateStr}&ngayKetThuc=${endDateStr}`
        );
        console.log("Dữ liệu tour ss nhận được từ API: ", response.data); // Log dữ liệu trả về
        // Chuyển đổi dữ liệu từ mảng 2 chiều sang mảng đối tượng
        const formattedData = response.data.map((item) => ({
          date: moment(item[0]).format("DD/MM/YYYY"), // Định dạng lại ngày tháng
          tour: item[1], // Tổng số lượng tour đã đặt
        }));
        // Lưu dữ liệu đã chuyển đổi vào state
        setTourData(formattedData);
      } catch (error) {
        console.error("Error fetching tour data:", error);
      }
    }
  };
  // Hàm gọi API để lấy dữ liệu số lượng người tham gia tour
  const fetchParticipantData = async () => {
    if (startDate && endDate) {
      try {
        const startDateStr = startDate.format("DD/MM/YYYY");
        const endDateStr = endDate.format("DD/MM/YYYY");

        const response = await axios.get(
          `http://localhost:8080/api/thongke/table-so-luong-nguoi-tham-gia?ngayBatDau=${startDateStr}&ngayKetThuc=${endDateStr}`
        );
        console.log(
          "Dữ liệu người tham gia tour nhận được từ API: ",
          response.data
        );
        const formattedData = response.data.map((item) => ({
          date: moment(item[0]).format("DD/MM/YYYY"), // Định dạng lại ngày
          tour: item[1], // Tên tour
          participantCount: item[2], // Số lượng người tham gia
        }));

        setParticipantData(formattedData);
      } catch (error) {
        console.error("Error fetching participant data:", error);
      }
    }
  };

  // Hàm gọi API để lấy dữ liệu Doanh Thu Theo Từng tour
  const fetchParticipantData2 = async () => {
    if (startDate && endDate) {
      try {
        const startDateStr = startDate.format("DD/MM/YYYY");
        const endDateStr = endDate.format("DD/MM/YYYY");
        const response = await axios.get(
          `http://localhost:8080/api/thongke/table-doanh-thu-theo-tour?ngayBatDau=${startDateStr}&ngayKetThuc=${endDateStr}`
        );
        console.log("Dữ liệu Doanh thu tour nhận được từ API: ", response.data);
        const formattedData = response.data.map((item) => ({
          date: moment(item.nam).format("DD/MM/YYYY"),
          tour: item.tenTour,
          participantCount: item.tongTien,
        }));
        setParticipantData2(formattedData);
      } catch (error) {
        console.error("Error fetching participant data:", error);
      }
    }
  };

  useEffect(() => {
    fetchRevenueData();
    fetchTourData();
    fetchParticipantData();
    fetchParticipantData2();
    fetchTotalBookedTours();
  }, [startDate, endDate]);
  console.log(participantData);
  const totalRevenue = Array.isArray(revenueData)
    ? revenueData.reduce((sum, item) => sum + item["Doanh Thu"], 0)
    : 0;

  return (
    <div className="p-6 bg-gray-100 min-h-screen flex flex-col gap-[16px]">
      <div className="flex">
        <NgayThang
          defaultValue={[startDate, endDate]}
          onChange={(dates) => {
            if (dates && dates.length === 2) {
              setStartDate(dates[0]);
              setEndDate(dates[1]);
            }
          }}
        />
      </div>
      <div className="grid grid-cols-2 gap-4 ">
        <div className="bg-white p-4 rounded-lg shadow">
          <h2 className="text-sm text-gray-500 mb-1">
            Tổng số lượng tour đã đặt
            <p className="text-2xl font-bold">{totalBookedTours}</p>
          </h2>
          <p className="text-2xl font-bold"></p>
        </div>
        <div className="bg-white p-4 rounded-lg shadow">
          <h2 className="text-sm text-gray-500 mb-1">Doanh thu</h2>
          <p className="text-2xl font-bold">
            {totalRevenue.toLocaleString()} VND
          </p>
        </div>
        {/* <div className="bg-white p-4 rounded-lg shadow ">
          <h2 className="text-sm text-gray-500 mb-1 ">
            Số lượng khách hàng hằng năm
          </h2>
          <span className="text-red-500">đang phát triển !!!</span>
          <p className="text-2xl font-bold"></p>
        </div> */}
        {/* <div className="bg-white p-4 rounded-lg shadow">
          <h2 className="text-sm text-gray-500 mb-1">Đánh giá</h2>
          <span className="text-red-500">đang phát triển !!!</span>

          <p className="text-2xl font-bold"></p>
        </div> */}
      </div>
      <div className="bg-white p-4 rounded-lg shadow h-[1200px] flex flex-col gap-[16px]">
        <h2 className="text-lg font-semibold mb-4">Thống kê doanh thu</h2>
        <div className="flex flex-row gap-[16px]">
          <div className="flex-1 h-[400px]">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart
                data={tourData}
                margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
              >
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="date" />
                {/* <YAxis /> */}

                <YAxis tickFormatter={(value) => Math.round(value)} />
                <Tooltip />
                <Bar dataKey="tour" fill="#8884d8" />
              </BarChart>
            </ResponsiveContainer>
            <TableTour data={participantData} />
          </div>
          <div className="flex-1 h-[400px]">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart
                data={revenueData}
                margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
              >
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="date" />
                <YAxis yAxisId="left" orientation="left" stroke="#82ca9d" />
                <YAxis yAxisId="right" orientation="right" stroke="#8884d8" />
                <Tooltip />
                <Line
                  yAxisId="left"
                  type="monotone"
                  dataKey="Doanh Thu"
                  stroke="#82ca9d"
                  activeDot={{ r: 8 }}
                />
                <Bar yAxisId="right" dataKey="tour" fill="#8884d8" />
              </LineChart>
            </ResponsiveContainer>
            <TableDoanhThu data={participantData2} />
          </div>
        </div>
      </div>
    </div>
  );
}
