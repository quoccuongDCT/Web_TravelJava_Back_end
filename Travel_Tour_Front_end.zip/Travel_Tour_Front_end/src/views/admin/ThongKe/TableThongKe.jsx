import React, {useState } from "react";
import { Table } from "antd";

// const columns = [
//   {
//     title: "Ngày Đặt Tour",
//     dataIndex: "date",
//     sorter: (a, b) => new Date(a.date) - new Date(b.date),
//     render: (text) => new Date(text).toLocaleDateString("vi-VN"),
//     showSorterTooltip: false,
//   },
//   {
//     title: "Tên Tour",
//     dataIndex: "tour",
//   },
//   {
//     title: "Tổng tiền",
//     dataIndex: "participantCount",
//     sorter: (a, b) => a.participantCount - b.participantCount,
//     render: (text) => {
//       const validAmount = !isNaN(text) && text !== undefined && text !== null ? text : 0;
//       return validAmount.toLocaleString("vi-VN", { style: "currency", currency: "VND" });
//     },
//     showSorterTooltip: false,
//   },
// ];
const columns = [
  {
    title: "Ngày Đặt Tour",
    dataIndex: "date",
    sorter: (a, b) => new Date(a.date) - new Date(b.date),
    render: (text) => {
      // Chuyển đổi ngày từ định dạng 'DD/MM/YYYY' sang 'YYYY-MM-DD'
      const [day, month, year] = text.split('/'); 
      const formattedDate = `${year}-${month}-${day}`; // Chuyển sang định dạng 'YYYY-MM-DD'
      const date = new Date(formattedDate);

      // Kiểm tra xem ngày có hợp lệ không
      if (isNaN(date.getTime())) {
        return "Ngày không hợp lệ"; // Thay thế "Invalid Date" bằng thông báo lỗi
      }
      return date.toLocaleDateString("vi-VN"); // Hiển thị ngày nếu hợp lệ
    },
    showSorterTooltip: false,
  },
  {
    title: "Tên Tour",
    dataIndex: "tour",
  },
  {
    title: "Tổng tiền",
    dataIndex: "participantCount",
    sorter: (a, b) => a.participantCount - b.participantCount,
    render: (text) => {
      const validAmount =
        !isNaN(text) && text !== undefined && text !== null ? text : 0;
      return validAmount.toLocaleString("vi-VN", {
        style: "currency",
        currency: "VND",
      });
    },
    showSorterTooltip: false,
  },
];


const TableDoanhThu = ({ data }) => {
  console.log("datas",data)
  const [currentPage, setCurrentPage] = useState(1);
  const pageSize = 8;

  // Hàm xử lý khi thay đổi trang
  const handlePageChange = (page) => {
    setCurrentPage(page);
  };

  return (
    <Table
      className="p-[16px]"
      columns={columns}
      dataSource={data}
      pagination={{
        current: currentPage,
        pageSize: pageSize,
        total: data.length,
        onChange: handlePageChange,
        showSizeChanger: false,
        itemRender: (page, type, originalElement) => {
          if (type === "page") {
            const rangeStart = Math.max(1, currentPage - 1);
            const rangeEnd = Math.min(
              currentPage + 1,
              Math.ceil(data.length / pageSize)
            );

            // Hiển thị chỉ các số trang trong phạm vi xác định
            if (page >= rangeStart && page <= rangeEnd) {
              return originalElement;
            }
            return null; // Ẩn các số trang ngoài phạm vi
          }
          return originalElement; // Giữ nguyên các nút điều hướng khác (Previous, Next)
        },
      }}
    />
  );
};

export default TableDoanhThu;
