import React, { useState } from "react";
import { Table } from "antd";

// Cấu hình các cột của bảng
// const columns = [
//   {
//     title: "Ngày Đặt Tour",
//     dataIndex: "date", // Dữ liệu ngày từ field `date`
//     sorter: (a, b) => new Date(a.date) - new Date(b.date), // Sắp xếp theo ngày
//     render: (text) => new Date(text).toLocaleDateString(), // Chuyển đổi ngày thành định dạng dễ đọc
//   },
//   {
//     title: "Tên Tour",
//     dataIndex: "tour", // Dữ liệu tên tour từ field `tour`
//   },
//   {
//     title: "Số Lượng Người",
//     dataIndex: "participantCount", // Dữ liệu số lượng người tham gia
//     sorter: (a, b) => a.participantCount - b.participantCount, // Sắp xếp theo số lượng người tham gia
//   },
// ];
const columns = [
  {
    title: "Ngày Đặt Tour",
    dataIndex: "date",
    sorter: (a, b) => new Date(a.date) - new Date(b.date),
    render: (text) => {
      // Nếu ngày có định dạng 'DD/MM/YYYY', cần chuyển đổi sang 'YYYY-MM-DD' hoặc 'MM/DD/YYYY'
      const [day, month, year] = text.split('/');
      const formattedDate = `${year}-${month}-${day}`;  // Định dạng thành 'YYYY-MM-DD'
      
      // Chuyển đổi ngày sang đối tượng Date
      const date = new Date(formattedDate);
      
      // Kiểm tra xem ngày có hợp lệ không
      if (isNaN(date.getTime())) {
        return "Ngày không hợp lệ";  // Nếu ngày không hợp lệ, trả về thông báo lỗi
      }

      // Hiển thị ngày dưới định dạng dễ đọc (DD/MM/YYYY)
      return date.toLocaleDateString("vi-VN");
    },
  },
  {
    title: "Tên Tour",
    dataIndex: "tour",
  },
  {
    title: "Số Lượng Người",
    dataIndex: "participantCount",
    sorter: (a, b) => a.participantCount - b.participantCount,
  },
];

const TableTour = ({ data }) => {
  const [currentPage, setCurrentPage] = useState(1);
  const pageSize = 8;

  // Hàm xử lý khi thay đổi trang
  const handlePageChange = (page) => {
    setCurrentPage(page);
  };

  return (
    <Table
      className="p-[16px]"
      columns={columns}
      dataSource={data}
      pagination={{
        current: currentPage,
        pageSize: pageSize,
        total: data.length,
        onChange: handlePageChange,
        showSizeChanger: false,
        itemRender: (page, type, originalElement) => {
          if (type === "page") {
            const rangeStart = Math.max(1, currentPage - 1);
            const rangeEnd = Math.min(
              currentPage + 1,
              Math.ceil(data.length / pageSize)
            );

            // Hiển thị chỉ các số trang trong phạm vi xác định
            if (page >= rangeStart && page <= rangeEnd) {
              return originalElement;
            }
            return null; // Ẩn các số trang ngoài phạm vi
          }
          return originalElement; // Giữ nguyên các nút điều hướng khác (Previous, Next)
        },
      }}
      onChange={(pagination, filters, sorter, extra) => {
        console.log("params", pagination, filters, sorter, extra);
      }}
    />
  );
};

export default TableTour;
