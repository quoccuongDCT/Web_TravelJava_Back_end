import React, { useState } from "react";
import { AutoComplete, Button, Input, Row, Col } from "antd";
import { SearchOutlined } from "@ant-design/icons";

const TimKiemPhuongTien = ({ data, onSearchResults }) => {
  const [searchValue, setSearchValue] = useState("");

  const handleSearch = () => {
    if (!searchValue.trim()) {
      onSearchResults(data); // Nếu từ khóa trống, trả về toàn bộ dữ liệu
      return;
    }

    const filteredData = data.filter(
      (item) =>
        item.tenPhuongTien.toLowerCase().includes(searchValue.toLowerCase()) // Lọc theo từ khóa
    );

    onSearchResults(filteredData); // Gửi dữ liệu đã lọc lên component cha
  };

  return (
    <Row gutter={16} align="middle">
      <Col>
        <AutoComplete
          value={searchValue}
          onChange={(value) => setSearchValue(value)} // Chỉ cập nhật giá trị
          placeholder="Nhập tên phương tiện"
          style={{ width: 250 }}
          size="large"
        />
      </Col>
      <Col>
        <Button icon={<SearchOutlined />} onClick={handleSearch}>
          Tìm kiếm
        </Button>
      </Col>
    </Row>
  );
};

export default TimKiemPhuongTien;
