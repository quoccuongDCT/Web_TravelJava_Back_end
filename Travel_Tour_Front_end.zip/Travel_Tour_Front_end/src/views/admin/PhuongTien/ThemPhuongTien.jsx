import React, { useState } from "react";
import { Button, Checkbox, Form, Input, Modal, message } from "antd";
import axios from "axios"; // Import axios

const FormThemPhuongTien = ({ visible, onCancel, reloadData }) => {
  const [componentDisabled, setComponentDisabled] = useState(false);

  const onFinish = async (values) => {
    const formData = {
      tenPhuongTien: values.tenPhuongTien, // Đảm bảo sử dụng tên đúng của trường
    };

    try {
      const response = await axios.post(
        "http://localhost:8080/api/phuongtien/them",
        formData
      );
      reloadData(); // Tải lại dữ liệu sau khi thêm thành công
      console.log("Phương Tiện đã được thêm:", response.data);
      message.success("Thêm Phương Tiện thành công"); // Hiển thị thông báo thành công
      onCancel(); // Đóng modal sau khi gửi thành công
    } catch (error) {
      console.error("Có lỗi xảy ra:", error);
      message.error("Thêm Phương Tiện thất bại!"); // Hiển thị thông báo lỗi
    }
  };

  return (
    <div className="container-fluid mt-5">
      <Modal
        title="Thêm Phương Tiện"
        visible={visible}
        onCancel={onCancel}
        footer={null}
        width={900}
      >
        <Checkbox
          className="mb-3"
          checked={componentDisabled}
          onChange={(e) => setComponentDisabled(e.target.checked)}
        >
          Vô hiệu hóa biểu mẫu
        </Checkbox>
        <Form
          layout="vertical"
          disabled={componentDisabled}
          onFinish={onFinish}
        >
          <div className="row">
            {/* User form fields */}
            <div className="col-lg-12">
              <Form.Item
                label="Phương Tiện"
                name="tenPhuongTien"
                rules={[
                  {
                    required: true,
                    message: "Tên Phương Tiện không được để trống!",
                  },
                ]}
              >
                <Input
                  placeholder="Tên Phương Tiện"
                  className="block w-full p-2 text-gray-900 border border-gray-300 rounded-lg bg-gray-50 text-xs focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                  id="small-input"
                />
              </Form.Item>
            </div>
          </div>
          <Form.Item className="text-right">
            <Button
              onClick={onCancel} // Chỉnh sửa để gọi onCancel
            >
              Quay Lại
            </Button>
            <Button
              style={{ marginLeft: 10 }}
              type="primary" // Chỉnh sửa type thành "primary"
              htmlType="submit"
            >
              Thêm Phương Tiện
            </Button>
          </Form.Item>
        </Form>
      </Modal>
    </div>
  );
};

export default FormThemPhuongTien;
