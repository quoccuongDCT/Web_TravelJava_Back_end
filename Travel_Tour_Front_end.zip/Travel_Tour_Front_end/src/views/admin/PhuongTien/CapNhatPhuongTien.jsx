import React, { useState } from "react";
import { Button, Checkbox, Form, Input, Modal, message } from "antd";
import axios from "axios";

const FormCapNhatPhuongTien = ({
  visible,
  onCancel,
  onBack,
  PhuongTienData,
  onUpdateSuccess,
}) => {
  const [componentDisabled, setComponentDisabled] = useState(false);

  const onFinish = async (values) => {
    try {
      const formData = {
        tenPhuongTien: values.tenPhuongTien,
      };

      if (PhuongTienData?.id) {
        // Update category
        const response = await axios.put(
          `http://localhost:8080/api/phuongtien/update/${PhuongTienData.id}`,
          formData
        );
        onUpdateSuccess(); // Call the success callback
        onCancel(); // Close the modal
        console.log("Category updated successfully:", response.data);
        message.success("Cập nhật Phương Tiện thành công");
      } else {
        message.error("Không tìm thấy Phương Tiện để cập nhật");
      }

      onCancel();
    } catch (error) {
      if (error.response) {
        // Handle server response error
        console.error("Server responded with error:", error.response.data);
        message.error(`Lỗi: ${error.response.data.message || error.message}`);
      } else if (error.request) {
        // Handle request error
        console.error("No response received:", error.request);
        message.error("Không nhận được phản hồi từ máy chủ. Vui lòng thử lại.");
      } else {
        // Handle unexpected errors
        console.error("Error creating request:", error.message);
        message.error("Đã xảy ra lỗi không mong muốn. Vui lòng thử lại.");
      }
    }
  };

  return (
    <div className="container-fluid mt-5">
      <Modal
        title="Cập Nhật Phương Tiện"
        visible={visible}
        onCancel={onCancel}
        footer={null}
        width={900}
      >
        <Checkbox
          className="mb-3"
          checked={componentDisabled}
          onChange={(e) => setComponentDisabled(e.target.checked)}
        >
          Vô hiệu hóa biểu mẫu
        </Checkbox>
        <Form
          layout="vertical"
          disabled={componentDisabled}
          onFinish={onFinish}
          initialValues={{
            tenPhuongTien: PhuongTienData?.tenPhuongTien,
          }}
        >
          <div className="row">
            <div className="col-lg-12">
              <Form.Item
                label="Phương Tiện"
                name="tenPhuongTien"
                rules={[
                  {
                    required: true,
                    message: "Tên Phương Tiện không được để trống!",
                  },
                ]}
              >
                <Input
                  placeholder="Tên Phương Tiện"
                  className="block w-full p-2 text-gray-900 border border-gray-300 rounded-lg bg-gray-50 text-xs focus:ring-blue-500 focus:border-blue-500"
                />
              </Form.Item>
            </div>
          </div>
          <div className="text-right">
            <Button onClick={onBack}>Quay lại</Button>
            <Button style={{ marginLeft: 10 }} type="primary" htmlType="submit">
              Cập Nhật Phương Tiện
            </Button>
          </div>
        </Form>
      </Modal>
    </div>
  );
};

export default FormCapNhatPhuongTien;
