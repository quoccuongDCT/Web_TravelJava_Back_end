import React, { useState, useEffect } from "react";
import axios from "axios"; // Import axios
import {
  Table,
  Tooltip,
  Button,
  ConfigProvider,
  Space,
  message,
  Modal,
} from "antd";
import {
  AntDesignOutlined,
  DeleteOutlined,
  HighlightTwoTone,
} from "@ant-design/icons";

// import "./Css/NhanVien.css";
import ThemPhuongTien from "./ThemPhuongTien.jsx";
import CapNhatPhuongTien from "./CapNhatPhuongTien.jsx";
import TimKiemPhuongTien from "./TimKiem_PhuongTien.jsx";

// Cột dữ liệu của bảng
const columns = (showEditModal, handleDelete) => [
  {
    title: "STT",
    dataIndex: "id",
    key: "id",
    fixed: "left",
    render: (_, __, index) => (
      <a href="#!" onClick={(e) => e.preventDefault()}>
        {index + 1}
      </a>
    ),
    width: 100,
  },
  {
    title: "Tên Phương Tiên",
    dataIndex: "tenPhuongTien",
    key: "tenPhuongTien",
    ellipsis: {
      showTitle: false,
    },
    render: (tenPhuongTien) => (
      <Tooltip placement="topLeft" title={tenPhuongTien}>
        {tenPhuongTien}
      </Tooltip>
    ),
  },
  {
    title: "",
    key: "action",
    fixed: "right",
    render: (_, record) => (
      <Space size="middle">
        {/* Nút Sửa */}
        <Tooltip title="Cập nhật thông tin Phương tiện">
          <Button
            icon={<HighlightTwoTone />}
            onClick={() => showEditModal(record)} // Hiển thị modal với dữ liệu người dùng được chọn
          ></Button>
        </Tooltip>

        {/* Nút Xóa */}
        <Tooltip title="Xóa Phương Tiện">
          <Button
            icon={<DeleteOutlined />}
            danger
            onClick={() => handleDelete(record.id, record.tenPhuongTien)} // Gọi hàm xóa
          ></Button>
        </Tooltip>
      </Space>
    ),
  },
];

// Component chính
const FormPhuongTien = () => {
  const [visible, setVisible] = useState(false);
  const [editingUser, setEditingUser] = useState(null);
  const [data, setData] = useState([]); // Trạng thái lưu trữ dữ liệu
  // const [selectedUserId, setSelectedUserId] = useState(null);
  const [searchData, setSearchData] = useState([]); // Dữ liệu hiển thị sau tìm kiếm
  const [isSearching, setIsSearching] = useState(false);
  // Gọi API khi component được tải
  const fetchData = async () => {
    try {
      const response = await axios.get("http://localhost:8080/api/phuongtien");
      const sortedNhanViens = response.data.sort((a, b) => b.id - a.id);
      setData(sortedNhanViens); // Update the data state
    } catch (error) {
      console.error("Lỗi khi tải dữ liệu:", error);
      message.error("Không thể tải dữ liệu từ server."); // Hiển thị thông báo lỗi
    }
  };
  useEffect(() => {
    fetchData();
  }, []); // Chạy một lần khi component được tải

  const handleSearchResults = (results) => {
    setSearchData(results); // Cập nhật dữ liệu hiển thị
    setIsSearching(true); // Bật trạng thái tìm kiếm
  };

  const showModal = () => {
    setVisible(true);
  };

  // Xử lý xem chi tiết
  const handleChiTiet = (record) => {
    // setSelectedUserId(record.id); // Lưu ID người dùng đã chọn vào state
    setVisible(true); // Hiển thị modal chi tiết người dùng
  };

  const handleCancel = () => {
    setVisible(false);
    setEditingUser(null);
  };

  const showEditModal = (user) => {
    setEditingUser(user);
    setVisible(true);
  };
  const handleUpdateSuccess = async () => {
    try {
      const response = await axios.get("http://localhost:8080/api/phuongtien");
      const sortedNhanViens = response.data.sort((a, b) => b.id - a.id);
      setData(sortedNhanViens); // Update the data state
      setVisible(false); // Close the modal
      setEditingUser(null); // Clear the editing user
      // handleUpdateSuccess();
    } catch (error) {
      message.error("Không thể tải dữ liệu từ server.");
    }
  };
  // Hàm xử lý xóa và hiển thị thông báo
  const handleDelete = (id, tenPhuongTien) => {
    // Show the confirmation popup with the category name included
    Modal.confirm({
      title: `Bạn có chắc chắn muốn xóa Phương Tiện với Tên Phương Tiện: ${tenPhuongTien}`, // Display the category name in the confirmation message
      okText: "Có", // Text for the OK button (Yes)
      cancelText: "Không", // Text for the Cancel button (No)
      onOk: async () => {
        // onOk is called when the user clicks "Yes"
        try {
          // Make the DELETE request to the backend
          await axios.delete(
            `http://localhost:8080/api/phuongtien/delete/${id}`
          );

          // Remove the deleted item from the local state to update the UI
          setData((prevData) => prevData.filter((item) => item.id !== id));

          // Show success message
          message.success(`Đã xóa thành công: ${tenPhuongTien}`);
        } catch (error) {
          console.error("Lỗi khi xóa Phương Tiện:", error);
          message.error("Không thể xóa Phương Tiện .");
        }
      },
      onCancel: () => {
        // Optionally, log or handle the cancel action
        console.log("Xóa bị hủy");
      },
    });
  };
  // Remove the earlier declaration of handleDelete here

  return (
    <div className="container">
      <h3>Phương Tiện</h3>

      {/* Nút "Thêm" */}
      <ConfigProvider>
        <div className="button-container">
          <Button
            className="nguoidung-them"
            type="primary"
            size="large"
            icon={<AntDesignOutlined />}
            onClick={showModal}
          >
            Thêm
          </Button>
        </div>
        <ThemPhuongTien
          visible={visible}
          onCancel={handleCancel}
          reloadData={fetchData}
        />
      </ConfigProvider>
      <div className="flex flex-col gap-[16px]">
        <TimKiemPhuongTien data={data} onSearchResults={handleSearchResults} />
        <div
          className="table-container align-items-center"
          style={{ marginRight: "-100px" }}
        >
          <Table
            columns={columns(showEditModal, handleDelete, handleChiTiet)}
            dataSource={isSearching ? searchData : data} // Hiển thị kết quả tìm kiếm
            rowKey="id"
          />
        </div>
      </div>
      {/* Các phần khác , Hàm cập nhật người dùng  */}
      {editingUser && (
        <CapNhatPhuongTien
          visible={visible}
          onCancel={handleCancel}
          PhuongTienData={editingUser} // Pass the editing user data
          onUpdateSuccess={handleUpdateSuccess} // Pass the callback
        />
      )}
    </div>
  );
};

export default FormPhuongTien;
