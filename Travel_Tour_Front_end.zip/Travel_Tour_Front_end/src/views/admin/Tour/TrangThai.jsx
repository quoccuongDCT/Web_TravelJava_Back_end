import React, { useState } from "react";
import { Modal, Form, Switch, Button, message } from "antd";
import axios from "axios";

const FormChuyenDoiTrangThai = ({ visible, tour, onCancel, onSuccess }) => {
  const [status, setStatus] = useState(tour.trangThai); // Default to the current status of the tour
  const [loading, setLoading] = useState(false);
  const [filterOptions, setFilterOptions] = useState([]); // Store filter options for "Tên Tour"
  const [data, setData] = useState([]); // Dữ liệu bảng

  const handleStatusChange = (checked) => {
    setStatus(checked); // Update status state when user toggles the switch
  };

  // Hàm này sẽ được gọi khi trang được tải lại với URL có tham số tenDanhMuc
  const fetchTours = async (tenDanhMuc) => {
    if (!tenDanhMuc) {
      console.warn("Không có danh mục được cung cấp, không tải dữ liệu.");
      return;
    }

    try {
      const url = `http://localhost:8080/api/tours/danhmuctour/${tenDanhMuc}`;
      const response = await axios.get(url);

      // Lấy danh sách tour từ response
      const tours = response.data;

      // Cập nhật filterOptions với tên tour duy nhất
      const uniqueTenTours = [...new Set(tours.map((tour) => tour.tenTour))];

      setFilterOptions(uniqueTenTours); // Cập nhật filterOptions với tên tour

      // Sắp xếp dữ liệu theo ID giảm dần
      const sortedData = tours.sort((a, b) => b.id - a.id);

      // Cập nhật dữ liệu vào state
      setData(sortedData);
    } catch (error) {
      console.error("Lỗi khi tải dữ liệu tour:", error);
      message.error("Không thể tải dữ liệu tour.");
    }
  };

  const handleSubmit = async () => {
    setLoading(true);
    try {
      // Send the updated status to the backend
      const response = await axios.put(
        `http://localhost:8080/api/tours/update-status/${tour.id}`,
        { trangThai: status }
      );

      if (response.status === 200) {
        message.success(
          `Cập nhật trạng thái thành công cho Tour: ${tour.tenTour}`
        );
        onSuccess(); // Callback after success
      } else {
        message.error("Không thể cập nhật trạng thái.");
      }
    } catch (error) {
      message.error("Đã xảy ra lỗi khi cập nhật trạng thái.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <Modal
      title={`Cập nhật trạng thái của Tour: ${tour.tenTour}`}
      visible={visible}
      onCancel={onCancel}
      footer={[
        <Button key="cancel" onClick={onCancel}>
          Hủy
        </Button>,
        <Button
          key="submit"
          type="primary"
          loading={loading}
          onClick={handleSubmit}
        >
          Cập nhật
        </Button>,
      ]}
    >
      <Form layout="vertical">
        <Form.Item name="switch" label="Trạng Thái" valuePropName="checked">
          <Switch
            checkedChildren="Hoạt Động"
            unCheckedChildren="Ngưng Hoạt Động"
            checked={status}
            onChange={handleStatusChange}
          />
        </Form.Item>
      </Form>
    </Modal>
  );
};

export default FormChuyenDoiTrangThai;
