import React, { useEffect, useState, useRef } from "react";
import {
  Button,
  Checkbox,
  Form,
  Input,
  Modal,
  Upload,
  Image,
  Select,
  InputNumber,
  message,
} from "antd";
import { PlusOutlined } from "@ant-design/icons";
import axios from "axios";
import { Editor } from "@tinymce/tinymce-react";
import "bootstrap/dist/css/bootstrap.min.css";
import { initializeApp } from "firebase/app";
import "./style.css";
import {
  getStorage,
  ref,
  uploadString,
  getDownloadURL,
} from "firebase/storage";

import { GoogleGenerativeAI } from "@google/generative-ai";

const { TextArea } = Input;

// Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyAtXg4mkxx1gic_VlvyxWcEloGZ6VFyymg",
  authDomain: "travel-e7f79.firebaseapp.com",
  projectId: "travel-e7f79",
  storageBucket: "travel-e7f79.appspot.com",
  messagingSenderId: "52519186637",
  appId: "1:52519186637:web:d0bb8aa8a499a7179b3984",
  measurementId: "G-HLNSGQZCPH",
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const storage = getStorage(app);

const getBase64 = (file) =>
  new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => resolve(reader.result);
    reader.onerror = (error) => reject(error);
  });

const FormThemTour = ({ visible, onCancel, onBack, reloadData }) => {
  const [componentDisabled, setComponentDisabled] = useState(false);
  const [previewOpen, setPreviewOpen] = useState(false);
  const [previewImage, setPreviewImage] = useState("");
  const [fileList, setFileList] = useState([]);
  const [number, setNumber] = useState(0);
  const [loaiTourList, setLoaiTourList] = useState([]);
  const [danhMucTourList, setDanhMucTourList] = useState([]);
  const [selectedDanhMuc, setSelectedDanhMuc] = useState(null);
  const editorRef = useRef(null); // Khai báo editorRef
  const [tourName, setTourName] = useState("");
  const [loading, setLoading] = useState(false);
  const apiKey = "AIzaSyBNk4leALxM6dnL0ogzpnCYrr8H6OoUCO8"; // Tích hợp API key trực tiếp

  const handleGenerate = async () => {
    if (!tourName) {
      // If the tour name is empty, show a popup with a message
      message.info("Vui lòng nhập Tên Tour trước khi chọn gợi ý !");
      return;
    } // Prevent generating if tour name is empty
    setLoading(true);

    try {
      const genAI = new GoogleGenerativeAI(apiKey);
      const model = await genAI.getGenerativeModel({
        model: "gemini-1.5-flash",
      });
      const result = await model.generateContent(tourName); // Use the tour name as input

      // Set the generated content directly into the TinyMCE editor
      if (editorRef.current) {
        editorRef.current.setContent(result.response.text());
      }
    } catch (error) {
      console.error("Error generating content:", error);
      if (editorRef.current) {
        editorRef.current.setContent(
          "Không thể tạo phản hồi. Vui lòng thử lại."
        );
      }
    } finally {
      setLoading(false);
    }
  };
  useEffect(() => {
    // Lấy tenDanhMuc từ URL
    const urlParams = new URLSearchParams(window.location.search);
    const tenDanhMuc = urlParams.get("tenDanhMuc");

    const fetchDanhMucTour = async () => {
      try {
        const response = await axios.get(
          "http://localhost:8080/api/danhmuctour"
        );
        const danhMucTourData = response.data;

        setDanhMucTourList(danhMucTourData);

        // Tự động chọn danh mục dựa trên URL
        if (tenDanhMuc) {
          const matchingDanhMuc = danhMucTourData.find(
            (item) => item.tenDanhMuc === tenDanhMuc
          );
          if (matchingDanhMuc) {
            setSelectedDanhMuc(matchingDanhMuc.id);
          }
        }
      } catch (error) {
        console.error("Lỗi khi lấy danh mục tour:", error);
        message.error("Không thể tải danh mục tour.");
      }
    };

    fetchDanhMucTour();
  }, []);
  useEffect(() => {
    const fetchTourData = async () => {
      try {
        const [loaiTourResponse, danhMucTourResponse] = await Promise.all([
          axios.get("http://localhost:8080/api/loaitour"),
          axios.get("http://localhost:8080/api/danhmuctour"),
        ]);

        // Set Loai Tour list and remove duplicates
        const loaiTourData = loaiTourResponse.data;
        const uniqueLoaiTourData = Array.from(
          new Set(loaiTourData.map((item) => item.id))
        ).map((id) => loaiTourData.find((item) => item.id === id));
        setLoaiTourList(uniqueLoaiTourData);

        // Set Danh Muc Tour list and remove duplicates
        const danhMucTourData = danhMucTourResponse.data;
        const uniqueDanhMucTourData = Array.from(
          new Set(danhMucTourData.map((item) => item.id))
        ).map((id) => danhMucTourData.find((item) => item.id === id));
        setDanhMucTourList(uniqueDanhMucTourData);
      } catch (error) {
        console.error(
          "Lỗi khi lấy danh sách loại tour hoặc danh mục tour:",
          error
        );
      }
    };

    fetchTourData();
  }, []);

  const handlePreview = async (file) => {
    if (!file.url && !file.preview) {
      file.preview = await getBase64(file.originFileObj);
    }
    setPreviewImage(file.url || file.preview);
    setPreviewOpen(true);
  };

  const handleChange = ({ fileList: newFileList }) => setFileList(newFileList);

  const uploadButton = (
    <div>
      <PlusOutlined />
      <div style={{ marginTop: 8 }}>Tải lên</div>
    </div>
  );

  const onNumberChange = (value) => {
    setNumber(value);
  };

  const uploadImageToFirebase = async (base64Image) => {
    try {
      const imageRef = ref(storage, `images/${Date.now()}.png`);
      await uploadString(imageRef, base64Image, "data_url");
      return await getDownloadURL(imageRef);
    } catch (error) {
      console.error("Lỗi khi upload hình ảnh lên Firebase:", error);
      throw error;
    }
  };

  // Function to check if tour name exists
  const isTourNameDuplicate = async (tenTour) => {
    try {
      const response = await axios.get(
        `http://localhost:8080/api/tours?tenTour=${tenTour}`
      );
      return response.data.exists; // Assuming the API returns { exists: true/false }
    } catch (error) {
      console.error("Lỗi khi kiểm tra tên tour:", error);
      return false;
    }
  };

  const onFinish = async (values) => {
    try {
      const isDuplicate = await isTourNameDuplicate(values.tenTour);
      if (isDuplicate) {
        message.error("Tên tour đã tồn tại! Vui lòng chọn tên khác.");
        return;
      }

      const hinhAnhBase64 =
        fileList.length > 0 ? await getBase64(fileList[0].originFileObj) : "";

      const hinhAnhUrl = hinhAnhBase64
        ? await uploadImageToFirebase(hinhAnhBase64)
        : null;
      const noiDung = editorRef.current?.getContent() || ""; // Lấy nội dung từ TinyMCE

      // Kiểm tra nội dung trước khi gửi
      if (!noiDung.trim()) {
        message.error("Nội Dung không được bỏ trống!");
        return;
      }
      const tourData = {
        danhMucTour: { id: values.danhMucTour },
        loaiTour: { id: values.loaiTour },
        tenTour: values.tenTour,
        soNgay: values.soNgay,
        moTa: values.moTa,
        hinhAnh: hinhAnhUrl,
        soLuongNguoi: number,
        soTour: values.soTour,
        trangThai: true,
        noiDung: noiDung,
        diemKhoiHanh: values.diemKhoiHanh,
        // Sử dụng object thay vì chỉ ID
      };

      const response = await axios.post(
        "http://localhost:8080/api/tours/them",
        tourData
      );
      if (response.status === 200) {
        reloadData(); // Refresh danh sách tour sau khi thêm thành công
        message.success("Tour đã được thêm thành công!");
        onCancel();
      }
    } catch (error) {
      if (error.response) {
        console.error("Lỗi khi thêm tour:", error.response.data);
        message.error(
          `Có lỗi xảy ra khi thêm tour: ${
            error.response.data.message || "Unknown error"
          }`
        );
      } else {
        console.error("Lỗi không phải từ server:", error);
        message.error("Có lỗi xảy ra khi thêm tour.");
      }
    }
  };

  return (
    <div className="container-fluid mt-5">
      <Modal
        title="Thêm Tour Du Lịch"
        visible={visible}
        onCancel={onCancel}
        footer={null}
        width={900}
      >
        <Checkbox
          className="mb-3"
          checked={componentDisabled}
          onChange={(e) => setComponentDisabled(e.target.checked)}
        >
          Vô hiệu hóa biểu mẫu
        </Checkbox>
        <Form
          layout="vertical"
          disabled={componentDisabled}
          onFinish={onFinish}
        >
          <div className="row">
            <div className="col-lg-6">
              <Form.Item
                label="Danh Mục Tour"
                name="danhMucTour"
                initialValue={selectedDanhMuc} // Giá trị mặc định lấy từ URL
                rules={[
                  { required: true, message: "Danh Mục Tour không bỏ trống!" },
                ]}
              >
                <Select
                  placeholder="Chọn Danh Mục Tour"
                  defaultValue={selectedDanhMuc}
                  value={selectedDanhMuc}
                  onChange={(value) => setSelectedDanhMuc(value)}
                >
                  {danhMucTourList.map((item) => (
                    <Select.Option key={item.id} value={item.id} disabled>
                      {item.tenDanhMuc}
                    </Select.Option>
                  ))}
                </Select>
              </Form.Item>
            </div>
            {/* {danhMucTourList.map((item) => (
              <Select.Option key={item.id} value={item.id}>
                {item.tenDanhMuc}
              </Select.Option>
            ))} */}
            <div className="col-lg-6">
              <Form.Item
                label="Loại Tour"
                name="loaiTour"
                rules={[
                  { required: true, message: "Loại Tour không bỏ trống!" },
                ]}
              >
                <Select placeholder="Chọn loại tour">
                  {loaiTourList.map((item) => (
                    <Select.Option key={item.id} value={item.id}>
                      {item.loaiTour} {/* Display the name here */}
                    </Select.Option>
                  ))}
                </Select>
              </Form.Item>
            </div>
            <div className="col-lg-6">
              <Form.Item
                label="Tên Tour"
                name="tenTour"
                rules={[
                  { required: true, message: "Tên Tour không bỏ trống!" },
                ]}
              >
                <Input
                  value={tourName}
                  onChange={(e) => setTourName(e.target.value)}
                  className="rounded-lg text-xs"
                />
              </Form.Item>
            </div>
            <div className="col-lg-6">
              <Form.Item
                label="Số Ngày"
                name="soNgay"
                rules={[{ required: true, message: "Số Ngày không bỏ trống!" }]}
              >
                <Input className="rounded-lg text-xs" />
              </Form.Item>
            </div>
            <div className="col-lg-6">
              <Form.Item
                label="Điểm khởi hành"
                name="diemKhoiHanh"
                rules={[
                  { required: true, message: "Điểm khởi hành không bỏ trống!" },
                ]}
              >
                <Input className="rounded-lg text-xs" />
              </Form.Item>
            </div>
            <div className="col-lg-6">
              <Form.Item
                label="Hình Ảnh"
                name="hinhAnh"
                // rules={[
                //   {
                //     required: true,
                //     message: "Vui lòng tải lên hình ảnh!",
                //   },
                // ]}
              >
                <Upload
                  listType="picture-card"
                  fileList={fileList}
                  onPreview={handlePreview}
                  onChange={handleChange}
                  // className={fileList.length === 0 ? "upload-error" : ""}
                >
                  {fileList.length >= 1 ? null : uploadButton}
                </Upload>
                <Modal
                  visible={previewOpen}
                  title="Xem trước hình ảnh"
                  footer={null}
                  onCancel={() => setPreviewOpen(false)}
                >
                  <Image
                    alt="example"
                    style={{ width: "100%" }}
                    src={previewImage}
                  />
                </Modal>
              </Form.Item>
            </div>
            <div className="col-lg-6">
              <Form.Item
                label="Số Lượng Người"
                name="soLuong"
                rules={[
                  { required: true, message: "Số Lượng Người không bỏ trống!" },
                  {
                    type: "number",
                    min: 1,
                    message: "Số Lượng Người phải lớn hơn 0!",
                  },
                ]}
              >
                <InputNumber
                  min={0}
                  defaultValue={number}
                  onChange={onNumberChange}
                  style={{ width: 200 }}
                />
              </Form.Item>
            </div>
            <div className="col-lg-6">
              <Form.Item
                label="Số Lượng Tour"
                name="soTour"
                rules={[
                  { required: true, message: "Số Lượng Tour không bỏ trống!" },
                  {
                    type: "number",
                    min: 1,
                    message: "Số Lượng Tour phải lớn hơn 0!",
                  },
                ]}
              >
                <InputNumber
                  defaultValue={number}
                  min={0}
                  onChange={onNumberChange}
                  style={{ width: 200 }}
                />
              </Form.Item>
            </div>
            <div className="col-lg-12">
              <Form.Item
                label="Nội Dung"
                // Loại bỏ `name` để quản lý riêng nội dung TinyMCE
                rules={[
                  { required: true, message: "Nội Dung không bỏ trống!" },
                ]}
              >
                <Button
                  onClick={handleGenerate}
                  type="default"
                  disabled={loading}
                >
                  {loading ? "Đang tạo gợi ý..." : "Gợi ý nội dung"}
                </Button>

                <Editor
                  apiKey="4bscneoksvcb1t8gkcv05q02fz4oqvv6n4pxk59anep55a4t"
                  onInit={(_, editor) => (editorRef.current = editor)}
                  initialValue=""
                  init={{
                    height: 300, // Giảm chiều cao để phù hợp hơn
                    menubar: false,
                    plugins: [
                      "advlist",
                      "autolink",
                      "lists",
                      "link",
                      "image",
                      "charmap",
                      "preview",
                      "anchor",
                      "searchreplace",
                      "visualblocks",
                      "code",
                      "fullscreen",
                      "insertdatetime",
                      "media",
                      "table",
                      "help",
                      "wordcount",
                    ],
                    toolbar:
                      "undo redo | blocks | " +
                      "bold italic forecolor | alignleft aligncenter " +
                      "alignright alignjustify | bullist numlist outdent indent | " +
                      "removeformat | image | help",
                    content_style:
                      "body { font-family:Helvetica,Arial,sans-serif; font-size:14px }",
                    file_picker_callback: (callback, value, meta) => {
                      // Tạo input chọn file
                      const input = document.createElement("input");
                      input.setAttribute("type", "file");
                      input.setAttribute("accept", "image/*");

                      // Khi người dùng chọn file
                      // Khi người dùng chọn file
                      input.onchange = async function () {
                        const file = this.files[0];
                        if (file) {
                          try {
                            // Chuyển file thành base64
                            const base64 = await getBase64(file);

                            // Upload lên Firebase Storage
                            const storageRef = ref(
                              storage,
                              `images/${file.name}`
                            );
                            await uploadString(storageRef, base64, "data_url");

                            // Lấy URL của hình ảnh đã upload
                            const downloadURL = await getDownloadURL(
                              storageRef
                            );

                            // Gọi callback để chèn URL vào trong nội dung của TinyMCE
                            callback(downloadURL, { alt: file.name });
                          } catch (error) {
                            console.error("Error uploading image:", error);
                          }
                        }
                      };

                      input.click();
                    },
                  }}
                />
              </Form.Item>
            </div>

            <div className="col-lg-12">
              <Form.Item label="Mô Tả" name="moTa">
                <TextArea rows={4} />
              </Form.Item>
            </div>
          </div>
          <div className="text-right">
            <Button onClick={onBack}>Trở Về</Button>
            <Button style={{ marginLeft: 10 }} type="primary" htmlType="submit">
              Thêm Tour
            </Button>
          </div>
        </Form>
      </Modal>
    </div>
  );
};

export default FormThemTour;
