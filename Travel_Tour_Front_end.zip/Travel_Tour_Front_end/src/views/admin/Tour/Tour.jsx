import React, { useState, useEffect } from "react";
import {
  Table,
  Tooltip,
  Tag,
  Button,
  Image,
  ConfigProvider,
  Space,
  Modal,
  message,
} from "antd";
import {
  AntDesignOutlined,
  DeleteOutlined,
  HighlightTwoTone,
  CommentOutlined,
  SyncOutlined,
  EyeTwoTone,
} from "@ant-design/icons";
// import TimKiem from "./TimKiem_Tour.jsx"; // Thành phần tìm kiếm
import ThemTour from "./ThemTour.jsx"; // Thành phần thêm tour
import CapNhatTour from "./CapNhatTour.jsx"; // Thành phần cập nhật tour
// import dayjs from "dayjs"; // Thư viện định dạng ngày tháng
import FormChuyenDoiTrangThai from "./TrangThai.jsx";
import axios from "axios"; // Thư viện gọi API
import { useNavigate,useLocation } from "react-router-dom";

// Cột dữ liệu của bảng

const columns = (
  navigateToTour,
  showEditModal,
  handleDelete,
  showStatusModal,
  handleDanhGia,
  showStatusModals,
  filterOptions
) => [
  {
    title: "STT",
    dataIndex: "id",
    key: "id",
    fixed: "left",
    render: (_, record, index) => (
      <Tooltip placement="topLeft" title={`Tour ID: ${record.tenDanhMuc}`}>
        <a
          href="#!"
          aria-label={`Tour ID: ${record.tenDanhMuc}`} // Thêm aria-label cho thẻ a
          onClick={(e) => {
            e.preventDefault();
            navigateToTour(record.tenDanhMuc); // Gọi hàm điều hướng
          }}
        ></a>
        {index + 1}
      </Tooltip>
    ),
    width: 100,
  },
  {
    title: "Danh Mục Tour",
    dataIndex: "danhMucTour",
    key: "danhMucTour",
    ellipsis: {
      showTitle: false,
    },
    render: (danhMucTour) => (
      <Tooltip placement="topLeft" title={danhMucTour.tenDanhMuc}>
        {danhMucTour.tenDanhMuc}
      </Tooltip>
    ),
    width: 200,
  },
  {
    title: "Loại Tour",
    dataIndex: "loaiTour",
    key: "loaiTour",
    ellipsis: {
      showTitle: false,
    },
    render: (loaiTour) => (
      <Tooltip placement="topLeft" title={loaiTour.loaiTour}>
        {loaiTour.loaiTour}
      </Tooltip>
    ),
    width: 200,
  },
  {
    title: "Tên Tour",
    dataIndex: "tenTour",
    key: "tenTour",
    ellipsis: {
      showTitle: false,
    },
    render: (tenTour) => (
      <Tooltip placement="topLeft" title={tenTour}>
        {tenTour}
      </Tooltip>
    ),
    filters: filterOptions.map((tenTour) => ({
      text: tenTour,
      value: tenTour,
    })),
    onFilter: (value, record) => record.tenTour.includes(value),
    filterSearch: true,
    width: 200,
  },
  {
    title: "Số Ngày",
    dataIndex: "soNgay",
    key: "soNgay",
    ellipsis: {
      showTitle: false,
    },
    render: (soNgay) => (
      <Tooltip placement="topLeft" title={soNgay}>
        {soNgay}
      </Tooltip>
    ),
    width: 200,
  },
  {
    title: "Ảnh",
    dataIndex: "hinhAnh",
    key: "hinhAnh",

    render: (anh) => (
      <Image src={anh} alt="Profile" style={{ width: 500, height: 120 }} />
    ),
    width: 250,
  },
  {
    title: "Số Lượng Người",
    dataIndex: "soLuongNguoi",
    key: "soLuongNguoi",
    width: 200,
    sorter: (a, b) => a.soLuongNguoi - b.soLuongNguoi,
  },
  {
    title: "Số Tour",
    dataIndex: "soTour",
    key: "soTour",
    width: 200,
    sorter: (a, b) => a.soTour - b.soTour,
  },
  {
    title: "Trạng Thái",
    dataIndex: "trangThai",
    key: "trangThai",
    ellipsis: { showTitle: false },
    render: (_, { trangThai, soLuongNguoi, soTour }) => {
      let color = "#0E9F6E"; // Default color for "Hoạt động"
      let statusText = "Hoạt động"; // Default status text

      // Update status and color if conditions are met
      if (!trangThai || soLuongNguoi === 0 || soTour === 0) {
        color = "#F05252"; // Color for "Ngưng hoạt động"
        statusText = "Ngưng hoạt động";
      }

      return (
        <Tooltip placement="topLeft" title={statusText}>
          <Tag color={color} key={statusText}>
            {statusText.toUpperCase()}
          </Tag>
        </Tooltip>
      );
    },
    width: 150,
  },
  {
    title: "",
    key: "action",
    render: (_, record) => (
      <Space size="middle">
        {/* Nút Cập nhật trạng thái */}
        <Tooltip title="Cập nhật Trạng Thái của Tour">
          <Button
            icon={<SyncOutlined />}
            type="primary"
            onClick={() => showStatusModals(record)} // Gọi hàm cập nhật trạng thái
          ></Button>
        </Tooltip>
        {/* Nút đổi trạng thái */}
        <Tooltip title="Xem thông tin Biến thể tour">
          <Button
            icon={<EyeTwoTone />}
            onClick={() => showStatusModal(record.tenTour)}
          ></Button>
        </Tooltip>
        {/* Nút Sửa */}
        <Tooltip title="Cập nhật thông tin Tour">
          <Button
            icon={<HighlightTwoTone />}
            onClick={() => showEditModal(record)} // Hiển thị modal với dữ liệu tour được chọn
          ></Button>
        </Tooltip>
        {/* Nút Xóa */}
        <Tooltip title="Xóa Tour">
          {" "}
          <Button
            icon={<DeleteOutlined />}
            danger
            onClick={() => handleDelete(record.id, record.tenTour)} // Gọi hàm xóa
          ></Button>
        </Tooltip>

        {/* Nút Đánh Giá */}
        <Tooltip title="Xem chi tiết số lượt Đánh Giá">
          {" "}
          <Button
            icon={<CommentOutlined />}
            onClick={() => handleDanhGia(record.tenTour)} // Gọi hàm thông tin tour
          ></Button>
        </Tooltip>
      </Space>
    ),
    width: 250,
  },
];

// Component chính
const FormTour = () => {
  const location = useLocation();

  const [visible, setVisible] = useState(false); // Trạng thái hiển thị modal
  const [editingUser, setEditingUser] = useState(null); // Trạng thái tour đang chỉnh sửa
  const [statusModalVisible, setStatusModalVisible] = useState(false); // Trạng thái modal chuyển đổi trạng thái
  const [editingTour, setEditingTour] = useState(null);
  const [data, setData] = useState([]); // Dữ liệu bảng
  const navigate = useNavigate();
  const [currentDanhMuc, setCurrentDanhMuc] = useState(null); // Lưu danh mục hiện tại
  const [filterOptions, setFilterOptions] = useState([]); // Store filter options for "Tên Tour"
  const [danhMucTour, setDanhMucTour] = useState(""); // biến lưu trạng thái tour
  const tenDanhMuc = location.state?.tenDanhMuc;
  useEffect(() => {
    // const urlparams = new URLSearchParams(window.location.search);
    // const tenDanhMuc = urlparams.get("tenDanhMuc");
    if (tenDanhMuc) {
      setDanhMucTour(tenDanhMuc);
      fetchTours(tenDanhMuc);
    } else {
      fetchTours();
    }
  }, []);
  const navigateToTour = async (tenDanhMuc) => {
    try {
      // Giải mã lại tenDanhMuc nếu nó bị mã hóa
      const decodedTenDanhMuc = decodeURIComponent(tenDanhMuc);

      // Gọi API để lấy danh sách tour theo tenDanhMuc
      const response = await axios.get(
        `http://localhost:8080/api/tours/danhmuctour/${decodedTenDanhMuc}`
      );

      if (response.status === 200) {
        // Lấy danh sách tour từ response
        const tours = response.data;

        // Cập nhật filterOptions với tên tour duy nhất
        const uniqueTenTours = [...new Set(tours.map((tour) => tour.tenTour))];

        setFilterOptions(uniqueTenTours); // Cập nhật filterOptions với tên tour

        // Nếu có dữ liệu, điều hướng đến trang với dữ liệu đã lọc
        navigate(`/admin/tour?tenDanhMuc=${decodedTenDanhMuc}`);
      } else {
        message.error("Không tìm thấy dữ liệu tour cho danh mục này.");
      }
    } catch (error) {
      console.error("Lỗi khi gọi API:", error);
      message.error("Lỗi khi gọi API.");
    }
  };
  // Hàm xử lý xem chi tiết
  const showStatusModal = (tenTour) => {
    // Giải mã URL nếu tenDanhMuc đã bị mã hóa
    const decodedTenDanhMuc = decodeURIComponent(tenTour);

    // Điều hướng đến URL với tenDanhMuc đã giải mã
    // window.location.href = `http://localhost:3000/admin/bien-the-tour?tenTour=${decodedTenDanhMuc}`;
    
    navigate(`/admin/bien-the-tour?tenTour=${decodedTenDanhMuc}`);
  };
  const showStatusModals = (tour) => {
    setEditingTour(tour); // Save the current tour data
    setStatusModalVisible(true); // Open the status change modal
  };

  // Hàm này sẽ được gọi khi trang được tải lại với URL có tham số tenDanhMuc
  const fetchTours = async (tenDanhMuc) => {
    if (!tenDanhMuc) {
      console.warn("Không có danh mục được cung cấp, không tải dữ liệu.");
      return;
    }

    try {
      const url = `http://localhost:8080/api/tours/danhmuctour/${tenDanhMuc}`;
      const response = await axios.get(url);

      // Lấy danh sách tour từ response
      const tours = response.data;

      // Cập nhật filterOptions với tên tour duy nhất
      const uniqueTenTours = [...new Set(tours.map((tour) => tour.tenTour))];

      setFilterOptions(uniqueTenTours); // Cập nhật filterOptions với tên tour

      // Sắp xếp dữ liệu theo ID giảm dần
      const sortedData = tours.sort((a, b) => b.id - a.id);

      // Cập nhật dữ liệu vào state
      setData(sortedData);
    } catch (error) {
      console.error("Lỗi khi tải dữ liệu tour:", error);
      message.error("Không thể tải dữ liệu tour.");
    }
  };
  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search);
    const tenDanhMuc = urlParams.get("tenDanhMuc"); // Lấy tham số tenDanhMuc từ URL

    setCurrentDanhMuc(tenDanhMuc); // Lưu danh mục hiện tại
    fetchTours(tenDanhMuc); // Gọi API khi có tenDanhMuc trong URL
  }, []);

  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search);
    const tenDanhMuc = urlParams.get("tenDanhMuc"); // Lấy tham số tenDanhMuc từ URL

    if (tenDanhMuc) {
      fetchTours(tenDanhMuc); // Gọi API khi có tenDanhMuc trong URL
    } else {
      fetchTours(); // Gọi API lấy tất cả dữ liệu khi không có tham số
    }
  }, []);
  useEffect(() => {
    fetchTours();
  }, []);

  const handleDelete = (id, tenTour) => {
    // Show the confirmation popup with the category name included
    Modal.confirm({
      title: `Bạn có chắc chắn muốn xóa Tour với Tên Tour: ${tenTour}`, // Display the category name in the confirmation message
      okText: "Có", // Text for the OK button (Yes)
      cancelText: "Không", // Text for the Cancel button (No)
      onOk: async () => {
        // onOk is called when the user clicks "Yes"
        try {
          // Make the DELETE request to the backend
          await axios.delete(`http://localhost:8080/api/tours/delete/${id}`);

          // Remove the deleted item from the local state to update the UI
          setData((prevData) => prevData.filter((item) => item.id !== id));

          // Show success message
          message.success(`Đã xóa thành công: ${tenTour}`);
        } catch (error) {
          console.error("Lỗi khi xóa Tên Tour:", error);
          message.error("Không thể xóa Tên Tour.");
        }
      },
      onCancel: () => {
        // Optionally, log or handle the cancel action
        console.log("Xóa bị hủy");
      },
    });
  };

  // const handleUpdateSuccess = async () => {
  //   try {
  //     const response = await axios.get("http://localhost:8080/api/tours");
  //     setData(response.data); // Cập nhật dữ liệu
  //     setVisible(false); // Đóng modal
  //     const sortedData = response.data.sort((a, b) => b.id - a.id);
  //     setData(sortedData); // Cập nhật dữ liệu đã được sắp xếp
  //     setEditingUser(null); // Xóa thông tin tour đang chỉnh sửa
  //   } catch (error) {
  //     message.error("Không thể tải dữ liệu từ server.");
  //   }
  // };
  const handleUpdateSuccess = async () => {
    const urlParams = new URLSearchParams(window.location.search);
    const tenDanhMuc = urlParams.get("tenDanhMuc"); // Lấy tham số tenDanhMuc từ URL

    if (tenDanhMuc) {
      fetchTours(tenDanhMuc); // Gọi API khi có tenDanhMuc trong URL
    } else {
      fetchTours(); // Gọi API lấy tất cả dữ liệu khi không có tham số
    }
  };

  const showModal = () => {
    setVisible(true); // Mở modal thêm tour
  };
  const handleDanhGia = (tenTour) => {
    // Giải mã URL nếu tenDanhMuc đã bị mã hóa
    const decodedTenTour = decodeURIComponent(tenTour);

    // Điều hướng đến URL với tenDanhMuc đã giải mã
    // window.location.href = `http://localhost:3000/admin/danh-gia?tenTour=${decodedTenTour}`;
    navigate(`/admin/danh-gia?tenTour=${decodedTenTour}`);
  };
  const handleCancel = () => {
    setVisible(false); // Đóng modal
    setEditingUser(null); // Reset trạng thái sau khi đóng modal
  };
  // const showStatusModal = (tour) => {
  //   setEditingTour(tour); // Lưu tour cần đổi trạng thái
  //   setStatusModalVisible(true); // Mở modal chuyển đổi trạng thái
  // };

  const handleStatusCancel = () => {
    setStatusModalVisible(false); // Đóng modal chuyển đổi trạng thái
  };

  const showEditModal = (tour) => {
    setEditingUser(tour); // Đặt tour đang được chỉnh sửa
    setVisible(true); // Mở modal
  };
  const handleStatusUpdateSuccess = () => {
    // Đóng modal và cập nhật dữ liệu
    setStatusModalVisible(false);
    handleUpdateSuccess();
  };

  return (
    <div className="container">
      <h3>Danh Sách Tour</h3>
      {/* Nút "Thêm" */}
      <ConfigProvider>
        <div className="button-container">
          <Button
            className="nguoidung-them"
            type="primary"
            size="large"
            icon={<AntDesignOutlined />}
            onClick={showModal}
          >
            Thêm
          </Button>
        </div>
        <ThemTour
          visible={visible}
          onCancel={handleCancel}
          reloadData={() => fetchTours(currentDanhMuc)} // Gọi lại API với danh mục hiện tại
        />
      </ConfigProvider>
      {/* Tìm kiếm tour */}
      {/* <TimKiem /> */}
      {/* Bảng tour */}
      <div
        className="table-container align-items-center"
        style={{ marginRight: "-100px" }}
      >
        {data.length === 0 ? (
          // Hiển thị thông báo khi không có dữ liệu
          <div style={{ textAlign: "center", marginTop: "20px" }}>
            <h4>
              Không có Tour nào cho Danh Mục Tour:{" "}
              <strong style={{ textTransform: "uppercase" }}>
                {decodeURIComponent(danhMucTour || "Không xác định")}
              </strong>
            </h4>
          </div>
        ) : (
          <Table
            columns={columns(
              navigateToTour,

              showEditModal,
              handleDelete,
              showStatusModal,
              handleDanhGia,
              showStatusModals,
              filterOptions
            )}
            scroll={{ x: 1800 }}
            dataSource={data} // Map dữ liệu API vào bảng
            rowKey="id" // Đặt rowKey là id
          />
        )}
      </div>
      {/* Modal cập nhật tour */}
      {editingUser && (
        <CapNhatTour
          visible={visible}
          onCancel={handleCancel}
          userData={editingUser} // Tên biến truyền vào model phải trùng
          onUpdateSuccess={handleUpdateSuccess} // Gọi callback khi thành công
        />
      )}
      {/* Modal Chuyển Đổi Trạng Thái */}
      <FormChuyenDoiTrangThai
        visible={statusModalVisible}
        tour={editingTour ? editingTour : {}} // Đảm bảo 'tour' không phải null
        onSuccess={handleStatusUpdateSuccess}
        onCancel={handleStatusCancel}
      />
    </div>
  );
};

export default FormTour;
