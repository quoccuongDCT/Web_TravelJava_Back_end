import React, { useState, useEffect, useRef } from "react";
import {
  Button,
  Checkbox,
  Form,
  Input,
  Modal,
  Upload,
  Image,
  Select,
  InputNumber,
  message,
} from "antd";
// Định dạng ngày tháng năm
// import moment from "moment";
import { PlusOutlined } from "@ant-design/icons";
import axios from "axios";
import { Editor } from "@tinymce/tinymce-react";
import { initializeApp } from "firebase/app";
import {
  getStorage,
  ref,
  uploadString,
  getDownloadURL,
} from "firebase/storage";

const { TextArea } = Input;

const firebaseConfig = {
  apiKey: "AIzaSyAtXg4mkxx1gic_VlvyxWcEloGZ6VFyymg",
  authDomain: "travel-e7f79.firebaseapp.com",
  projectId: "travel-e7f79",
  storageBucket: "travel-e7f79.appspot.com",
  messagingSenderId: "52519186637",
  appId: "1:52519186637:web:d0bb8aa8a499a7179b3984",
  measurementId: "G-HLNSGQZCPH",
};

const app = initializeApp(firebaseConfig);
const storage = getStorage(app);

const getBase64 = (file) =>
  new Promise((resolve, reject) => {
    if (!file || !file.originFileObj) {
      reject(new Error("Đối tượng tệp không hợp lệ"));
      return;
    }
    const reader = new FileReader();
    reader.readAsDataURL(file.originFileObj);
    reader.onload = () => resolve(reader.result);
    reader.onerror = (error) => reject(error);
  });

const FormCapNhatTour = ({
  visible,
  onCancel,
  // onBack,
  userData,
  onUpdateSuccess,
}) => {
  const [form] = Form.useForm();
  const [componentDisabled, setComponentDisabled] = useState(false);
  const [previewOpen, setPreviewOpen] = useState(false);
  const [previewImage, setPreviewImage] = useState("");
  const [fileList, setFileList] = useState([]);
  const [number, setNumber] = useState(0);
  const [loaiTourList, setLoaiTourList] = useState([]);
  const [danhMucTourList, setdanhMucTourList] = useState([]);
  const editorRef = useRef(null);
  useEffect(() => {
    if (userData) {
      setFileList(userData.hinhAnh ? [{ url: userData.hinhAnh }] : []);
    }
  }, [userData]);

  const handlePreview = async (file) => {
    if (!file.url && !file.preview) {
      file.preview = await getBase64(file.originFileObj);
    }
    setPreviewImage(file.url || file.preview);
    setPreviewOpen(true);
  };
  // Lấy danh sách loại tour từ API khi component được mount
  useEffect(() => {
    const fetchLoaiTour = async () => {
      try {
        const response = await axios.get("http://localhost:8080/api/loaitour"); // API lấy danh sách loại tour
        setLoaiTourList(response.data);
      } catch (error) {
        console.error("Lỗi khi lấy danh sách loại tour:", error);
      }
    };

    fetchLoaiTour();
  }, []);
  useEffect(() => {
    const fetchLoaiTour = async () => {
      try {
        const response = await axios.get(
          "http://localhost:8080/api/danhmuctour"
        ); // API lấy danh sách loại tour
        setdanhMucTourList(response.data);
      } catch (error) {
        console.error("Lỗi khi lấy danh sách Danh mục tour:", error);
      }
    };

    fetchLoaiTour();
  }, []);

  const handleChange = ({ fileList: newFileList }) => setFileList(newFileList);

  const uploadButton = (
    <div>
      <PlusOutlined />
      <div style={{ marginTop: 8 }}>Tải lên</div>
    </div>
  );
  const onNumberChange = (value) => {
    setNumber(value);
  };
  const uploadImageToFirebase = async (base64Image) => {
    try {
      const imageRef = ref(storage, `images/${Date.now()}.png`);
      await uploadString(imageRef, base64Image, "data_url");
      return await getDownloadURL(imageRef);
    } catch (error) {
      console.error("Lỗi khi upload hình ảnh lên Firebase:", error);
      throw error;
    }
  };

  const onFinish = async (values) => {
    try {
      const hinhAnhBase64 =
        fileList.length > 0 && fileList[0].originFileObj
          ? await getBase64(fileList[0])
          : "";
      const hinhAnhUrl = hinhAnhBase64
        ? await uploadImageToFirebase(hinhAnhBase64)
        : userData?.hinhAnh;
      const noiDung = editorRef.current?.getContent() || ""; // Lấy nội dung từ TinyMCE

      // Kiểm tra nội dung trước khi gửi
      if (!noiDung.trim()) {
        message.error("Nội Dung không được bỏ trống!");
        return;
      }
      const formData = {
        danhMucTour: { id: values.danhMucTour },
        loaiTour: { id: values.loaiTour },
        tenTour: values.tenTour,
        soNgay: values.soNgay,
        moTa: values.moTa,
        hinhAnh: hinhAnhUrl,
        soLuongNguoi: values.soLuongNguoi,
        soTour: values.soTour,
        trangThai: true,
        noiDung,
        diemKhoiHanh: values.diemKhoiHanh,
      };
      if (userData?.id) {
        const response = await axios.put(
          `http://localhost:8080/api/tours/update/${userData.id}`,
          formData
        );
        onUpdateSuccess();
        setLoaiTourList(response.data);
        setdanhMucTourList(response.data);
        console.log(response.data);
        message.success("Cập nhật tour thành công");
      } else {
        message.error("Không tìm thấy tour để cập nhật");
      }

      onCancel();
    } catch (error) {
      console.error(
        "Lỗi cập nhật tour:",
        error.response?.data || error.message
      );
      console.error("Lỗi cập nhật tour:", error);
    }
  };
  useEffect(() => {
    if (userData) {
      form.setFieldsValue({
        danhMucTour: userData?.danhMucTour?.id,
        loaiTour: userData?.loaiTour?.id,
        tenTour: userData?.tenTour,
        soNgay: userData?.soNgay,
        moTa: userData?.moTa,
        soLuongNguoi: userData?.soLuongNguoi,
        soTour: userData?.soTour,
        trangThai: userData?.trangThai ? "true" : "false",
        diemKhoiHanh: userData?.diemKhoiHanh,
        // Set the content of TinyMCE editor
      });
      // Set the content of TinyMCE editor
      if (editorRef.current) {
        editorRef.current.setContent(userData.noiDung || "");
      }
    }
  }, [userData, form]);
  return (
    <div className="container-fluid mt-5">
      <Modal
        title="Cập Nhật Tour Du Lịch"
        visible={visible}
        onCancel={onCancel}
        footer={null}
        width={900}
      >
        <Checkbox
          className="mb-3"
          checked={componentDisabled}
          onChange={(e) => setComponentDisabled(e.target.checked)}
        >
          Vô hiệu hóa biểu mẫu
        </Checkbox>
        <Form
          layout="vertical"
          disabled={componentDisabled}
          onFinish={onFinish}
          form={form}
        >
          <div className="row">
            <div className="col-lg-6">
              <Form.Item
                label="Danh Mục Tour"
                name="danhMucTour"
                rules={[
                  { required: true, message: "Danh Mục Tour không bỏ trống!" },
                ]}
              >
                <Select placeholder="Chọn loại Danh mục tour">
                  {danhMucTourList.map((item) => (
                    <Select.Option key={item.id} value={item.id}>
                      {item.tenDanhMuc} {/* Display the name here */}
                    </Select.Option>
                  ))}
                </Select>
              </Form.Item>
            </div>
            <div className="col-lg-6">
              <Form.Item
                label="Loại Tour"
                name="loaiTour"
                rules={[
                  { required: true, message: "Loại Tour không bỏ trống!" },
                ]}
              >
                <Select placeholder="Chọn loại tour">
                  {loaiTourList.map((itemLoaiTour) => (
                    <Select.Option
                      key={itemLoaiTour.id}
                      value={itemLoaiTour.id}
                    >
                      {itemLoaiTour.loaiTour} {/* Display the name here */}
                    </Select.Option>
                  ))}
                </Select>
              </Form.Item>
            </div>
            <div className="col-lg-6">
              <Form.Item
                label="Tên Tour"
                name="tenTour"
                rules={[
                  { required: true, message: "Tên Tour không bỏ trống!" },
                ]}
              >
                <Input className="rounded-lg text-xs" />
              </Form.Item>
            </div>
            <div className="col-lg-6">
              <Form.Item
                label="Số Ngày"
                name="soNgay"
                rules={[{ required: true, message: "Số Ngày không bỏ trống!" }]}
              >
                <Input className="rounded-lg text-xs" />
              </Form.Item>
            </div>
            <div className="col-lg-6">
              <Form.Item
                label="Điểm khởi hành"
                name="diemKhoiHanh"
                rules={[
                  { required: true, message: "Điểm khởi hành không bỏ trống!" },
                ]}
              >
                <Input className="rounded-lg text-xs" />
              </Form.Item>
            </div>
            <div className="col-lg-6">
              <Form.Item
                label="Hình Ảnh"
                name="hinhAnh"
                // rules={[
                //   {
                //     required: true,
                //     message: "Vui lòng tải lên hình ảnh!",
                //   },
                // ]}
              >
                <Upload
                  listType="picture-card"
                  fileList={fileList}
                  onPreview={handlePreview}
                  onChange={handleChange}
                  // className={fileList.length === 0 ? "upload-error" : ""}
                >
                  {fileList.length >= 1 ? null : uploadButton}
                </Upload>
                <Modal
                  visible={previewOpen}
                  title="Xem trước hình ảnh"
                  footer={null}
                  onCancel={() => setPreviewOpen(false)}
                >
                  <Image
                    alt="example"
                    style={{ width: "100%" }}
                    src={previewImage}
                  />
                </Modal>
              </Form.Item>
            </div>
            <div className="col-lg-6">
              <Form.Item
                label="Số Lượng Người"
                name="soLuongNguoi"
                rules={[
                  { required: true, message: "Số Lượng Người không bỏ trống!" },
                  {
                    type: "number",
                    min: 1,
                    message: "Số Lượng Người phải lớn hơn 0!",
                  },
                ]}
              >
                <InputNumber
                  min={0}
                  defaultValue={number}
                  onChange={onNumberChange}
                  style={{ width: 200 }}
                />
              </Form.Item>
            </div>
            <div className="col-lg-6">
              <Form.Item
                label="Số Lượng Tour"
                name="soTour"
                rules={[
                  { required: true, message: "Số Lượng Tour không bỏ trống!" },
                  {
                    type: "number",
                    min: 1,
                    message: "Số Lượng Tour phải lớn hơn 0!",
                  },
                ]}
              >
                <InputNumber
                  defaultValue={number}
                  min={0}
                  onChange={onNumberChange}
                  style={{ width: 200 }}
                />
              </Form.Item>
            </div>
            <div className="col-lg-12">
              <Form.Item
                label="Nội Dung"
                // Loại bỏ `name` để quản lý riêng nội dung TinyMCE
                rules={[
                  { required: true, message: "Nội Dung không bỏ trống!" },
                ]}
              >
                <Editor
                  apiKey="4bscneoksvcb1t8gkcv05q02fz4oqvv6n4pxk59anep55a4t"
                  onInit={(_, editor) => (editorRef.current = editor)}
                  initialValue={userData?.noiDung || ""}
                  init={{
                    height: 300, // Giảm chiều cao để phù hợp hơn
                    menubar: false,
                    plugins: [
                      "advlist",
                      "autolink",
                      "lists",
                      "link",
                      "image",
                      "charmap",
                      "preview",
                      "anchor",
                      "searchreplace",
                      "visualblocks",
                      "code",
                      "fullscreen",
                      "insertdatetime",
                      "media",
                      "table",
                      "help",
                      "wordcount",
                    ],
                    toolbar:
                      "undo redo | blocks | " +
                      "bold italic forecolor | alignleft aligncenter " +
                      "alignright alignjustify | bullist numlist outdent indent | " +
                      "removeformat | image | help",
                    content_style:
                      "body { font-family:Helvetica,Arial,sans-serif; font-size:14px }",
                    file_picker_callback: (callback, value, meta) => {
                      // Tạo input chọn file
                      const input = document.createElement("input");
                      input.setAttribute("type", "file");
                      input.setAttribute("accept", "image/*");

                      // Khi người dùng chọn file
                      // Khi người dùng chọn file
                      input.onchange = async function () {
                        const file = this.files[0];
                        if (file) {
                          try {
                            // Chuyển file thành base64
                            const base64 = await getBase64(file);

                            // Upload lên Firebase Storage
                            const storageRef = ref(
                              storage,
                              `images/${file.name}`
                            );
                            await uploadString(storageRef, base64, "data_url");

                            // Lấy URL của hình ảnh đã upload
                            const downloadURL = await getDownloadURL(
                              storageRef
                            );

                            // Gọi callback để chèn URL vào trong nội dung của TinyMCE
                            callback(downloadURL, { alt: file.name });
                          } catch (error) {
                            console.error("Error uploading image:", error);
                          }
                        }
                      };

                      input.click();
                    },
                  }}
                />
              </Form.Item>
            </div>

            <div className="col-lg-12">
              <Form.Item label="Mô Tả" name="moTa">
                <TextArea rows={4} />
              </Form.Item>
            </div>
          </div>
          <div className="text-right">
            <Button onClick={onCancel}>Quay lại</Button>
            <Button style={{ marginLeft: 10 }} type="primary" htmlType="submit">
              Cập Nhật
            </Button>
          </div>
        </Form>
      </Modal>
    </div>
  );
};

export default FormCapNhatTour;
