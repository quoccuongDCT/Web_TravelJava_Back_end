import React, { useState, useEffect } from "react";
import { Table, Tooltip, message } from "antd";
import TimKiem from "./TimKiem_TinTuc";

// Cột dữ liệu của bảng
const columns = (showEditModal) => [
  {
    title: "ID",
    dataIndex: "id",
    key: "index",
    render: (_, __, index) => (
      <a href="#!" onClick={(e) => e.preventDefault()}>
        {index + 1}
      </a>
    ),
    width: 50,
  },
  {
    title: "Họ Và Tên ",
    dataIndex: "nguoiDung",
    key: "nguoiDung",
    ellipsis: {
      showTitle: false,
    },
    render: (nguoiDung) => (
      <Tooltip placement="topLeft" title={nguoiDung.hoTen}>
        {nguoiDung.hoTen}
      </Tooltip>
    ),
  },
  {
    title: "Tên Tour",
    dataIndex: "tour",
    key: "tour",
    ellipsis: {
      showTitle: false,
    },
    render: (tour) => (
      <Tooltip placement="topLeft" title={tour.tenTour}>
        {tour.tenTour}
      </Tooltip>
    ),
  },
  {
    title: "Thích",
    dataIndex: "thich",
    key: "thich",
    render: (thich) => (
      <Tooltip placement="topLeft" title={thich ? "Đã thích" : "Chưa thích"}>
        {thich ? "Đã thích" : "Chưa thích"}
      </Tooltip>
    ),
  },
];

// Component chính
const App = () => {
  const [data, setData] = useState([]);

  const fetchYeuThichs = async () => {
    try {
      const response = await fetch("http://localhost:8080/api/yeuthich");
      const tours = await response.json();

      // Sắp xếp theo id từ lớn đến nhỏ
      const sortedYeuThichs = tours.sort((a, b) => b.id - a.id);
      setData(sortedYeuThichs);
    } catch (error) {
      message.error("Tải dữ liệu thất bại.");
    }
  };

  useEffect(() => {
    fetchYeuThichs();
  }, []);

  const showEditModal = (record) => {
    // Function logic for showing edit modal
    console.log("Show edit modal for", record);
  };

  return (
    <div className="container">
      <h3>Quản Lý Yêu Thích</h3>
      {/* Tìm kiếm người dùng */}
      <TimKiem />

      {/* Bảng người dùng */}
      <div className="table-container align-items-center">
        <Table columns={columns(showEditModal)} dataSource={data} rowKey="id" />
      </div>
    </div>
  );
};

export default App;
