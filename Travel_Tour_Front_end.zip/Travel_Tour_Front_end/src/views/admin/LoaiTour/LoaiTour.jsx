import React, { useState, useEffect } from "react";
import axios from "axios"; // Import axios
import { Table, Tooltip, Button, ConfigProvider, Space, message } from "antd";
import {
  AntDesignOutlined,
  DeleteOutlined,
  HighlightTwoTone,
} from "@ant-design/icons";
// import "./Css/NhanVien.css";
import ThemLoaiTour from "./ThemLoaiTour.jsx";
import CapNhatLoaiTour from "./CapNhatLoaiTour.jsx";
import TimKiemLoaiTour from "./TimKiem_LoaiTour.jsx";

// Cột dữ liệu của bảng
const columns = (showEditModal, handleDelete) => [
  {
    title: "STT",
    dataIndex: "id",
    key: "id",
    fixed: "left",
    render: (_, __, index) => (
      <a href="#!" onClick={(e) => e.preventDefault()}>
        {index + 1}
      </a>
    ),
    width: 100,
  },
  {
    title: "Tên Loại Tour",
    dataIndex: "loaiTour",
    key: "loaiTour",
    ellipsis: {
      showTitle: false,
    },
    render: (loaiTour) => (
      <Tooltip placement="topLeft" title={loaiTour}>
        {loaiTour}
      </Tooltip>
    ),
  },
  {
    title: "",
    key: "action",
    fixed: "right",
    render: (_, record) => (
      <Space size="middle">
        {/* Nút Sửa */}
        <Button
          icon={<HighlightTwoTone />}
          onClick={() => showEditModal(record)} // Hiển thị modal với dữ liệu người dùng được chọn
        ></Button>

        {/* Nút Xóa */}
        <Button
          icon={<DeleteOutlined />}
          danger
          onClick={() => handleDelete(record.id)} // Gọi hàm xóa
        ></Button>
      </Space>
    ),
  },
];

// Component chính
const FormLoaiTourForm = () => {
  const [visible, setVisible] = useState(false);
  const [editingUser, setEditingUser] = useState(null);
  const [data, setData] = useState([]); // Trạng thái lưu trữ dữ liệu
  // const [selectedUserId, setSelectedUserId] = useState(null);

  // Gọi API khi component được tải
  const fetchData = async () => {
    try {
      const response = await axios.get("http://localhost:8080/api/loaitour");
      const sortedNhanViens = response.data.sort((a, b) => b.id - a.id);
      setData(sortedNhanViens); // Update the data state
    } catch (error) {
      console.error("Lỗi khi tải dữ liệu:", error);
      message.error("Không thể tải dữ liệu từ server."); // Hiển thị thông báo lỗi
    }
  };
  useEffect(() => {
    fetchData();
  }, []); // Chạy một lần khi component được tải

  const showModal = () => {
    setVisible(true);
  };

  // Xử lý xem chi tiết
  const handleChiTiet = (record) => {
    // setSelectedUserId(record.id); // Lưu ID người dùng đã chọn vào state
    setVisible(true); // Hiển thị modal chi tiết người dùng
  };

  const handleCancel = () => {
    setVisible(false);
    setEditingUser(null);
  };

  const showEditModal = (user) => {
    setEditingUser(user);
    setVisible(true);
  };
  const handleUpdateSuccess = async () => {
    try {
      const response = await axios.get("http://localhost:8080/api/loaitour");
      const sortedNhanViens = response.data.sort((a, b) => b.id - a.id);
      setData(sortedNhanViens); // Update the data state
      setVisible(false); // Close the modal
      setEditingUser(null); // Clear the editing user
      // handleUpdateSuccess();
    } catch (error) {
      message.error("Không thể tải dữ liệu từ server.");
    }
  };
  // Hàm xử lý xóa và hiển thị thông báo
  const handleDelete = async (id) => {
    const confirmDelete = window.confirm(
      `Bạn có chắc chắn muốn xóa Loại Tour với ID: ${id}?`
    );
    if (confirmDelete) {
      try {
        // Make the DELETE request to the backend
        await axios.delete(`http://localhost:8080/api/loaitour/delete/${id}`);

        // Remove the deleted user from the local state
        setData((prevData) => prevData.filter((user) => user.id !== id));

        message.success(`Đã xóa thành công: ${id}`); // Show success message
      } catch (error) {
        console.error("Lỗi khi xóa Danh mục tour:", error);
        message.error("Không thể xóa Danh mục tour."); // Show error message
      }
    }
  };

  // Remove the earlier declaration of handleDelete here

  return (
    <div className="container">
      <h3>Loại Tour</h3>

      {/* Nút "Thêm" */}
      <ConfigProvider>
        <div className="button-container">
          <Button
            className="nguoidung-them"
            type="primary"
            size="large"
            icon={<AntDesignOutlined />}
            onClick={showModal}
          >
            Thêm
          </Button>
        </div>
        <ThemLoaiTour
          visible={visible}
          onCancel={handleCancel}
          reloadData={fetchData}
        />
      </ConfigProvider>

      {/* Tìm kiếm người dùng */}
      {/* <TimKiemLoaiTour /> */}

      {/* Bảng người dùng */}
      <div
        className="table-container align-items-center"
        style={{ marginRight: "-100px" }}
      >
        <Table
          columns={columns(showEditModal, handleDelete, handleChiTiet)}
          // scroll={{ x: 2100 }}
          dataSource={data}
          rowKey="id"
        />
      </div>

      {/* Các phần khác , Hàm cập nhật người dùng  */}
      {editingUser && (
        <CapNhatLoaiTour
          visible={visible}
          onCancel={handleCancel}
          categoryData={editingUser} // Pass the editing user data
          onUpdateSuccess={handleUpdateSuccess} // Pass the callback
        />
      )}
    </div>
  );
};

export default FormLoaiTourForm;
