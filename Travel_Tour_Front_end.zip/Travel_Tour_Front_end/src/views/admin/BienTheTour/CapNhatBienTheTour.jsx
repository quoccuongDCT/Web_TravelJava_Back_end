import React, { useState, useEffect, useRef } from "react";
import {
  Button,
  Checkbox,
  Form,
  Input,
  DatePicker,
  Modal,
  Select,
  message,
} from "antd";
import "bootstrap/dist/css/bootstrap.min.css";
import moment from "moment";
import axios from "axios";
import { Editor } from "@tinymce/tinymce-react";
import { initializeApp } from "firebase/app";
import {
  getStorage,
  ref,
  uploadString,
  getDownloadURL,
} from "firebase/storage";

// Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyAtXg4mkxx1gic_VlvyxWcEloGZ6VFyymg",
  authDomain: "travel-e7f79.firebaseapp.com",
  projectId: "travel-e7f79",
  storageBucket: "travel-e7f79.appspot.com",
  messagingSenderId: "52519186637",
  appId: "1:52519186637:web:d0bb8aa8a499a7179b3984",
  measurementId: "G-HLNSGQZCPH",
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const storage = getStorage(app); // Initialize storage

// Function to convert file to base64
const getBase64 = (file) =>
  new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => resolve(reader.result);
    reader.onerror = (error) => reject(error);
  });

const FormCapNhatBienTheTour = ({
  visible,
  onCancel,
  onBack,
  userData,
  onUpdateSuccess,
}) => {
  const [componentDisabled, setComponentDisabled] = useState(false);
  const [tourList, settourList] = useState([]);
  const [hotlsList, setHotelsList] = useState([]);
  const [phuongTienList, setPhuongTienList] = useState([]);
  const [giamGiaList, setGiamGiaList] = useState([]);
  const [form] = Form.useForm();
  const editorRef = useRef(null);

  useEffect(() => {
    if (visible) {
      form.resetFields();
    }
  }, [visible, form]);

  const formatCurrencyVND = (value) => {
    return new Intl.NumberFormat("vi-VN", {
      style: "currency",
      currency: "VND",
    }).format(value);
  };
  useEffect(() => {
    const fetchTour = async () => {
      try {
        const response = await axios.get("http://localhost:8080/api/tours");
        settourList(response.data);
      } catch (error) {
        message.error("Lỗi khi tải dữ liệu!");
        console.error("Lỗi khi lấy danh sách tour:", error);
      }
    };
    fetchTour();
  }, []);
  useEffect(() => {
    const fetchTour = async () => {
      try {
        const response = await axios.get("http://localhost:8080/api/hotels");
        setHotelsList(response.data);
      } catch (error) {
        message.error("Lỗi khi tải dữ liệu!");
        console.error("Lỗi khi lấy danh sách tour:", error);
      }
    };
    fetchTour();
  }, []);
  useEffect(() => {
    const fetchTour = async () => {
      try {
        const response = await axios.get(
          "http://localhost:8080/api/phuongtien"
        );
        setPhuongTienList(response.data);
      } catch (error) {
        message.error("Lỗi khi tải dữ liệu!");
        console.error("Lỗi khi lấy danh sách tour:", error);
      }
    };
    fetchTour();
  }, []);
  useEffect(() => {
    const fetchTour = async () => {
      try {
        const response = await axios.get("http://localhost:8080/api/giamgia");
        setGiamGiaList(response.data);
      } catch (error) {
        message.error("Lỗi khi tải dữ liệu!");
        console.error("Lỗi khi lấy danh sách tour:", error);
      }
    };
    fetchTour();
  }, []);
  const onFinish = async (values) => {
    const ghiChu = editorRef.current.getContent();

    const bienTheTour = {
      tour: { id: values.tour },
      hotels: { id: values.hotels },
      phuongTien: { id: values.phuongTien },
      giamGia: { id: values.giamGia },
      // giaNguoiLon: values.giaNguoiLon,
      giaNguoiLon: parseFloat(String(values.giaNguoiLon).replace(/\D/g, "")), // Chuyển thành số thực
      // giaTreEm: values.giaTreEm,
      giaTreEm: parseFloat(String(values.giaTreEm).replace(/\D/g, "")), // Chuyển thành số thực

      ngayBatDau: values.ngayBatDau.format("YYYY-MM-DD"),
      ngayKetThuc: values.ngayKetThuc.format("YYYY-MM-DD"),
      soLuongCon: values.soLuongCon,
      soLuongTong: values.soLuongTong,
      maTour: values.maTour,
      ghiChu,
    };
    console.log("bienTheTour", bienTheTour)
    if (userData?.id) {
      const response = await axios.put(
        `http://localhost:8080/api/bienthetour/update/${userData.id}`,
        bienTheTour
      );
      onUpdateSuccess();
      settourList(response.data);
      console.log(response.data);
      message.success("Cập nhật biến thể tour thành công");
    } else {
      message.error("Không tìm thấy biến thể tour để cập nhật");
    }

    onCancel();
  };
  useEffect(() => {
    console.log("----", userData);
    if (userData) {
      form.setFieldsValue({
        tour: userData.tour?.id,
        hotels: userData.hotels?.id,
        phuongTien: userData.phuongTien?.id,
        giamGia: userData.giamGia?.id,
        giaNguoiLon: userData.giaNguoiLon,
        giaTreEm: userData.giaTreEm,
        ngayBatDau: userData.ngayBatDau
          ? moment(userData.ngayBatDau, "YYYY-MM-DD")
          : null,
        ngayKetThuc: userData.ngayKetThuc
          ? moment(userData.ngayKetThuc, "YYYY-MM-DD")
          : null,
        soLuongCon: userData.soLuongCon,
        soLuongTong: userData.soLuongTong,
        maTour: userData.maTour,
      });
      if (editorRef.current) {
        editorRef.current.setContent(userData.ghiChu || "");
      }
    }
  }, [userData, form]);
  return (
    <div className="container-fluid mt-5">
      <Modal
        title="Cập Nhật Biến Thể Tour"
        visible={visible}
        onCancel={onCancel}
        footer={null}
        width={900}
      >
        <Checkbox
          className="mb-3"
          checked={componentDisabled}
          onChange={(e) => setComponentDisabled(e.target.checked)}
        >
          Vô hiệu hóa biểu mẫu
        </Checkbox>
        <Form
          layout="vertical"
          disabled={componentDisabled}
          onFinish={onFinish}
          form={form}
        >
          <div className="row">
            <div className="col-lg-6">
              <Form.Item
                label="Tên Tour"
                name="tour"
                rules={[
                  {
                    required: true,
                    message: "Tên tour không bỏ trống!",
                  },
                ]}
              >
                <Select placeholder="chọn loại tour">
                  {tourList.map((item) => (
                    <Select.Option key={item.id} value={item.id}>
                      {item.tenTour}
                    </Select.Option>
                  ))}
                </Select>
              </Form.Item>
            </div>
            <div className="col-lg-6">
              <Form.Item
                label="Tên Khách Sạn"
                name="hotels"
                rules={[
                  {
                    required: true,
                    message: "Tên khách sạn không bỏ trống!",
                  },
                ]}
              >
                <Select placeholder="chọn loại Hotels">
                  {hotlsList.map((item) => (
                    <Select.Option key={item.id} value={item.id}>
                      {item.tenKhachSan}
                    </Select.Option>
                  ))}
                </Select>
              </Form.Item>
            </div>
            <div className="col-lg-6">
              <Form.Item
                label="Tên Phương Tiện"
                name="phuongTien"
                rules={[
                  {
                    required: true,
                    message: "Tên Phương tiện không bỏ trống!",
                  },
                ]}
              >
                <Select placeholder="chọn loại Phương tiện">
                  {phuongTienList.map((item) => (
                    <Select.Option key={item.id} value={item.id}>
                      {item.tenPhuongTien}
                    </Select.Option>
                  ))}
                </Select>
              </Form.Item>
            </div>{" "}
            <div className="col-lg-6">
              <Form.Item
                label="Giảm giá "
                name="giamGia"
                rules={[
                  {
                    required: true,
                    message: "Tên Giảm Giá không bỏ trống!",
                  },
                ]}
              >
                <Select placeholder="chọn loại Phương tiện">
                  {giamGiaList.map((item) => (
                    <Select.Option key={item.id} value={item.id}>
                      {item.tieuDe}
                    </Select.Option>
                  ))}
                </Select>
              </Form.Item>
            </div>
            <div className="col-lg-6">
              <Form.Item
                label="Giá Người Lớn"
                name="giaNguoiLon"
                rules={[
                  {
                    required: true,
                    message: "Giá người lớn không được để trống!",
                  },
                ]}
              >
                <Input
                  placeholder="Giá người lớn"
                  className="block w-full p-2 text-gray-900 border border-gray-300 rounded-lg bg-gray-50 text-xs focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                  onChange={(e) =>
                    form.setFieldsValue({
                      giaNguoiLon: formatCurrencyVND(
                        e.target.value.replace(/\D/g, "")
                      ),
                    })
                  }
                />
              </Form.Item>
            </div>
            {/* Input for "Giá Trẻ Em" */}
            <div className="col-lg-6">
              <Form.Item
                label="Giá Trẻ Em"
                name="giaTreEm"
                rules={[
                  {
                    required: true,
                    message: "Giá trẻ em không được để trống!",
                  },
                ]}
              >
                <Input
                  placeholder="Giá trẻ em"
                  className="block w-full p-2 text-gray-900 border border-gray-300 rounded-lg bg-gray-50 text-xs focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                  onChange={(e) =>
                    form.setFieldsValue({
                      giaTreEm: formatCurrencyVND(
                        e.target.value.replace(/\D/g, "")
                      ),
                    })
                  }
                />
              </Form.Item>
            </div>
            <div className="col-lg-6">
              <Form.Item
                label="Ngày Bắt Đầu"
                name="ngayBatDau"
                rules={[
                  { required: true, message: "Ngày bắt đầu không bỏ trống!" },
                ]}
              >
                <DatePicker className="w-100" format="DD/MM/YYYY" />
              </Form.Item>
            </div>
            <div className="col-lg-6">
              <Form.Item
                label="Ngày Kết Thúc"
                name="ngayKetThuc"
                rules={[
                  { required: true, message: "Ngày kết thúc không bỏ trống!" },
                ]}
              >
                <DatePicker className="w-100" format="DD/MM/YYYY" />
              </Form.Item>
            </div>
            <div className="col-lg-6">
              <Form.Item
                label="Số Lượng Còn"
                name="soLuongCon"
                rules={[
                  { required: true, message: "Số lượng còn không bỏ trống!" },
                ]}
              >
                <Input className="rounded-lg text-xs" />
              </Form.Item>
            </div>
            <div className="col-lg-6">
              <Form.Item
                label="Số Lượng Tổng"
                name="soLuongTong"
                rules={[
                  { required: true, message: "Số Lượng Tổng không bỏ trống!" },
                ]}
              >
                <Input className="rounded-lg text-xs" />
              </Form.Item>
            </div>
            <div className="col-lg-6">
              <Form.Item
                label="Mã Tour"
                name="maTour"
                rules={[{ required: true, message: "Mã tour không bỏ trống!" }]}
              >
                <Input className="rounded-lg text-xs" />
              </Form.Item>
            </div>
            {/* TinyMCE Content */}
            <div className="col-lg-12">
              <Form.Item
                label="Ghi Chú "
                rules={[
                  { required: true, message: "Nội Dung không bỏ trống!" },
                ]}
              >
                <Editor
                  apiKey="4bscneoksvcb1t8gkcv05q02fz4oqvv6n4pxk59anep55a4t"
                  onInit={(_, editor) => (editorRef.current = editor)}
                  initialValue={userData?.ghiChu || ""}
                  init={{
                    height: 300,
                    menubar: false,
                    plugins: [
                      "advlist",
                      "autolink",
                      "lists",
                      "link",
                      "image",
                      "charmap",
                      "preview",
                      "anchor",
                      "searchreplace",
                      "visualblocks",
                      "code",
                      "fullscreen",
                      "insertdatetime",
                      "media",
                      "table",
                      "help",
                      "wordcount",
                    ],
                    toolbar:
                      "undo redo | blocks | " +
                      "bold italic forecolor | alignleft aligncenter " +
                      "alignright alignjustify | bullist numlist outdent indent | " +
                      "removeformat | image | help",
                    content_style:
                      "body { font-family:Helvetica,Arial,sans-serif; font-size:14px }",
                    file_picker_callback: (callback, value, meta) => {
                      // Tạo input chọn file
                      const input = document.createElement("input");
                      input.setAttribute("type", "file");
                      input.setAttribute("accept", "image/*");

                      // Khi người dùng chọn file
                      // Khi người dùng chọn file
                      input.onchange = async function () {
                        const file = this.files[0];
                        if (file) {
                          try {
                            // Chuyển file thành base64
                            const base64 = await getBase64(file);

                            // Upload lên Firebase Storage
                            const storageRef = ref(
                              storage,
                              `images/${file.name}`
                            );
                            await uploadString(storageRef, base64, "data_url");

                            // Lấy URL của hình ảnh đã upload
                            const downloadURL = await getDownloadURL(
                              storageRef
                            );

                            // Gọi callback để chèn URL vào trong nội dung của TinyMCE
                            callback(downloadURL, { alt: file.name });
                          } catch (error) {
                            console.error("Error uploading image:", error);
                          }
                        }
                      };

                      input.click();
                    },
                  }}
                />
              </Form.Item>
            </div>
            {/* Thay thế phần Video bằng URL */}
          </div>
          <div className="text-right">
            <Button onClick={onBack}>Quay Lại</Button>
            <Button style={{ marginLeft: 10 }} type="primary" htmlType="submit">
              Cập Nhật Biến Thể Tour
            </Button>
          </div>
        </Form>
      </Modal>
    </div>
  );
};

export default FormCapNhatBienTheTour;
