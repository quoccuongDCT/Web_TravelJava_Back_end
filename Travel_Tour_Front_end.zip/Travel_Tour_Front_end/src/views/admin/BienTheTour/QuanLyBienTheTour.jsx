import React, { useState, useEffect } from "react";
import {
  Table,
  Tooltip,
  Button,
  ConfigProvider,
  Space,
  message,
  Modal,
} from "antd";
import {
  AntDesignOutlined,
  DeleteOutlined,
  HighlightTwoTone,
  EyeTwoTone,
  DollarOutlined,
} from "@ant-design/icons";
// import TimKiem from "./TimKiem_BienTheTour"; // Kiểm tra tệp này
import ThemBienTheTour from "./ThemBienTheTour"; // Kiểm tra
import CapNhatBienTheTour from "./CapNhatBienTheTour"; // Kiểm tra
import axios from "axios";
import { useNavigate } from "react-router-dom";

// Cột dữ liệu của bảng
const columns = (
  handleBienTheTour,
  navigateToBienTheTour,
  showEditModal,
  handleDelete,
  renderStars,
  handleHoaDon,
  formatCurrencyVND
) => [
  {
    title: "STT",
    dataIndex: "id",
    key: "id",
    fixed: "left",
    render: (_, record, index) => (
      <Tooltip placement="topLeft" title={`Tour ID: ${record.tenTour}`}>
        <a
          href="#!"
          aria-label={`Tour ID: ${record.tenTour}`} // Thêm aria-label cho thẻ a
          onClick={(e) => {
            e.preventDefault();
            navigateToBienTheTour(record.tenTour); // Gọi hàm điều hướng
          }}
        ></a>
        {index + 1}
      </Tooltip>
    ),
    width: 70,
  },
  {
    title: "Mã Tour",
    dataIndex: "maTour",
    key: "maTour",
    ellipsis: {
      showTitle: false,
    },
    render: (maTour) => (
      <Tooltip placement="topLeft" title={maTour}>
        {maTour}
      </Tooltip>
    ),
    width: 100,
  },
  {
    title: "Tên Tour",
    dataIndex: "tour",
    key: "tour",
    ellipsis: {
      showTitle: false,
    },
    render: (tour) => (
      <Tooltip placement="topLeft" title={tour?.tenTour}>
        {tour?.tenTour}
      </Tooltip>
    ),
  },

  {
    title: "Tên Khách Sạn",
    dataIndex: "hotels",
    key: "hotels",
    ellipsis: {
      showTitle: false,
    },
    render: (hotels) => (
      <Tooltip placement="topLeft" title={hotels?.danhGiaKhachSan}>
        {hotels?.tenKhachSan} - {renderStars(hotels?.danhGiaKhachSan)}
      </Tooltip>
    ),
    width: 200,
  },
  {
    title: "Tên Phương Tiện ",
    dataIndex: "phuongTien",
    key: "phuongTien",
    ellipsis: {
      showTitle: false,
    },
    render: (phuongTien) => (
      <Tooltip placement="topLeft" title={phuongTien?.tenPhuongTien}>
        {phuongTien?.tenPhuongTien}
      </Tooltip>
    ),
  },
  {
    title: "Giảm Giá",
    dataIndex: "giamGia",
    key: "giamGia",
    ellipsis: {
      showTitle: false,
    },
    render: (giamGia) => (
      <Tooltip placement="topLeft" title={giamGia?.tieuDe}>
        {giamGia?.tieuDe}
      </Tooltip>
    ),
  },
  {
    title: "Giá Người Lớn",
    dataIndex: "giaNguoiLon",
    key: "giaNguoiLon",
    ellipsis: {
      showTitle: false,
    },
    render: (giaNguoiLon) => (
      <Tooltip placement="topLeft" title={giaNguoiLon}>
        {formatCurrencyVND(giaNguoiLon)}
      </Tooltip>
    ),
    sorter: (a, b) => a.giaNguoiLon - b.giaNguoiLon,
  },
  {
    title: "Giá Trẻ Em",
    dataIndex: "giaTreEm",
    key: "giaTreEm",
    ellipsis: {
      showTitle: false,
    },
    render: (giaTreEm) => (
      <Tooltip placement="topLeft" title={giaTreEm}>
        {formatCurrencyVND(giaTreEm)}
      </Tooltip>
    ),
    sorter: (a, b) => a.giaTreEm - b.giaTreEm,
  },
  {
    title: "Ngày Bắt Đầu",
    dataIndex: "ngayBatDau",
    key: "ngayBatDau",
    ellipsis: {
      showTitle: false,
    },
    render: (ngayBatDau) => (
      <Tooltip placement="topLeft" title={ngayBatDau}>
        {new Date(ngayBatDau).toLocaleDateString("vi-VN", {
          day: "2-digit",
          month: "2-digit",
          year: "numeric",
        })}
      </Tooltip>
    ),
    sorter: (a, b) => {
      // Convert the string date to JavaScript Date objects or timestamps for comparison
      const dateA = new Date(a.ngayBatDau);
      const dateB = new Date(b.ngayBatDau);
      return dateA - dateB; // Sorting in ascending order (earlier dates come first)
    },
  },
  {
    title: "Ngày Kết Thúc",
    dataIndex: "ngayKetThuc",
    key: "ngayKetThuc",
    ellipsis: {
      showTitle: false,
    },
    render: (ngayKetThuc) => (
      <Tooltip placement="topLeft" title={ngayKetThuc}>
        {new Date(ngayKetThuc).toLocaleDateString("vi-VN", {
          day: "2-digit",
          month: "2-digit",
          year: "numeric",
        })}
      </Tooltip>
    ),
    sorter: (a, b) => {
      const dateA = new Date(a.ngayKetThuc);
      const dateB = new Date(b.ngayKetThuc);
      return dateB - dateA; // sắp xếp theo ngày
    },
  },
  {
    title: "Số Lượng Còn ",
    dataIndex: "soLuongCon",
    key: "soLuongCon",
    ellipsis: {
      showTitle: false,
    },
    render: (soLuongCon) => (
      <Tooltip placement="topLeft" title={soLuongCon}>
        {soLuongCon}
      </Tooltip>
    ),
    sorter: (a, b) => a.soLuongCon - b.soLuongCon,
  },
  {
    title: "Số Lượng Tổng ",
    dataIndex: "soLuongTong",
    key: "soLuongTong",
    ellipsis: {
      showTitle: false,
    },
    render: (soLuongTong) => (
      <Tooltip placement="topLeft" title={soLuongTong}>
        {soLuongTong}
      </Tooltip>
    ),
    sorter: (a, b) => a.soLuongTong - b.soLuongTong,
  },
  {
    title: "",
    key: "action",
    render: (_, record) => (

      <Space size="middle">
        {/* Nút xem chi tiết  */}
        <Tooltip title="Xem thông tin Lịch Trình Tour">
          <Button
            icon={<EyeTwoTone />}
            onClick={() => handleBienTheTour(record.tour?.tenTour)} // Gọi hàm thông tin tour
          ></Button>
        </Tooltip>
        {/* Nút xem hóa đơn  */}
        <Tooltip title="Xem hóa đơn Tour">
          <Button
            icon={<DollarOutlined />}
            onClick={() => handleHoaDon(record?.id)}
          ></Button>
        </Tooltip>

        {/* Nút Sửa */}
        <Tooltip title="Cập nhật thông tin Biến Thể Tour">
          <Button
            icon={<HighlightTwoTone />}
            onClick={() => showEditModal(record)} // Hiển thị modal chỉnh sửa
          ></Button>
        </Tooltip>

        {/* Nút Xóa */}
        <Tooltip title="Xóa Biến Thể Tour">
          <Button
            icon={<DeleteOutlined />}
            danger
            onClick={() => handleDelete(record.id, record.tour?.tenTour)} // Gọi hàm xóa
          ></Button>
        </Tooltip>
      </Space>
    ),
    width: 150,
  },
];

// Component chính
const FormQuanLyBienTheTour = () => {
  const [visible, setVisible] = useState(false);
  const [editingUser, setEditingUser] = useState(null); // Trạng thái người dùng đang chỉnh sửa
  const [data, setData] = useState([]);
  const navigate = useNavigate();
  const [currentBienTheTour, setCurrentBienTheTour] = useState();
  const [bienTheTour, setBienTheTour] = useState("");
  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search);
    const tenTour = urlParams.get("tenTour");
    if (tenTour) {
      setBienTheTour(tenTour);
      fetchData(tenTour);
    } else {
      fetchData();
    }
  }, []);
  const navigateToBienTheTour = async (tenTour) => {
    try {
      // Giải mã lại tenDanhMuc nếu nó bị mã hóa
      const decodedTenTour = decodeURIComponent(tenTour);

      // Gọi API để lấy danh sách tour theo tenDanhMuc
      const response = await axios.get(
        `http://localhost:8080/api/bienthetour/bienthetour/${decodedTenTour}`
      );

      if (response.status === 200) {
        // Nếu có dữ liệu, điều hướng đến trang với dữ liệu đã lọc
        navigate(`/admin/bien-the-tour?tenTour=${decodedTenTour}`);
      } else {
        message.error("Không tìm thấy dữ liệu tour cho danh mục này.");
      }
    } catch (error) {
      console.error("Lỗi khi gọi API:", error);
      message.error("Lỗi khi gọi API.");
    }
  };

  // Hàm gọi API để lấy dữ liệu
  const fetchData = async (tenTour) => {
    if (!tenTour) {
      console.warn("Không có Tour được cung cấp, không thể tải Tour.");
      return;
    }
    try {
      const url = `http://localhost:8080/api/bienthetour/bienthetour/${tenTour}`;
      const response = await axios.get(url);
      const sortedData = response.data.sort((a, b) => b.id - a.id);
      console.log("sortedData",sortedData)
      setData(sortedData); // Cập nhật dữ liệu với các tour theo danh mục
      // console.log(response.data);
    } catch (error) {
      message.error("Lỗi khi tải dữ liệu tour.");
    }
  };
  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search);
    const tenTour = urlParams.get("tenTour"); // Lấy tham số tenDanhMuc từ URL

    setCurrentBienTheTour(tenTour); //
    fetchData(tenTour);
  }, []);
  const showModal = () => {
    setVisible(true);
  };

  //Hàm xem hóa đơn theo biến thể tour
  const handleHoaDon = (idBienTheTour) => {
    const decodedIdBienTheTour = decodeURIComponent(idBienTheTour);
    console.log("decodedIdBienTheTour",decodedIdBienTheTour)
    navigate(`/admin/hoa-don?idBienTheTour=${decodedIdBienTheTour}`);
  };

  // Hàm xử lý xem chi tiết
  const handleBienTheTour = (tenTour) => {
    // Giải mã URL nếu tenDanhMuc đã bị mã hóa
    const decodedTenTour = decodeURIComponent(tenTour);

    // Điều hướng đến URL với tenDanhMuc đã giải mã
    // window.location.href = `http://localhost:3000/admin/lich-trinh-tour?tenTour=${decodedTenTour}`;
    navigate(`/admin/lich-trinh-tour?tenTour=${decodedTenTour}`);
  };

  const handleUpdateSuccess = () => {
    const urlParams = new URLSearchParams(window.location.search);
    const tenTour = urlParams.get("tenTour"); // Lấy tham số tenDanhMuc từ URL

    setCurrentBienTheTour(tenTour); //
    fetchData(tenTour);
    // fetchData(); // Lấy lại và cập nhật dữ liệu

    setVisible(false); // Đóng modal
    setEditingUser(null); // Xóa trạng thái chỉnh sửa
  };

  const handleCancel = () => {
    setVisible(false);
    setEditingUser(null); // Reset trạng thái người dùng sau khi đóng modal
  };

  const showEditModal = (user) => {
    setEditingUser(user); // Đặt người dùng đang được chỉnh sửa
    setVisible(true); // Mở modal chỉnh sửa
  };
  const handleDelete = (id, tenTour) => {
    // Show the confirmation popup with the category name included
    Modal.confirm({
      title: `Bạn có chắc chắn muốn xóa Biến Thể Tour với Tên Tour: ${tenTour}`, // Display the category name in the confirmation message
      okText: "Có", // Text for the OK button (Yes)
      cancelText: "Không", // Text for the Cancel button (No)
      onOk: async () => {
        // onOk is called when the user clicks "Yes"
        try {
          // Make the DELETE request to the backend
          await axios.delete(
            `http://localhost:8080/api/bienthetour/delete/${id}`
          );

          // Remove the deleted item from the local state to update the UI
          setData((prevData) => prevData.filter((item) => item.id !== id));

          // Show success message
          message.success(`Đã xóa thành công: ${tenTour}`);
        } catch (error) {
          console.error("Lỗi khi xóa Biến Thể Tour:", error);
          message.error("Không thể xóa Biến Thể Tour.");
        }
      },
      onCancel: () => {
        // Optionally, log or handle the cancel action
        console.log("Xóa bị hủy");
      },
    });
  };
  const renderStars = (stars) => {
    const maxStars = 5; // Assuming a maximum rating of 5 stars
    return Array.from({ length: maxStars }, (_, index) => (
      <span
        key={index}
        style={{ color: index < stars ? "#FFD700" : "#d3d3d3" }}
      >
        ★
      </span>
    ));
  };
  const formatCurrencyVND = (amount) => {
    return new Intl.NumberFormat("vi-VN", {
      style: "currency",
      currency: "VND",
      currencyDisplay: "code",
    })
      .format(amount)
      .replace("VNĐ", "Đ");
  };
  return (
    <div className="container">
      <h3>Quản Lý Biến Thể Tour</h3>

      {/* Nút "Thêm" */}
      <ConfigProvider>
        <div className="button-container">
          <Button
            className="bienthetour-them"
            type="primary"
            size="large"
            style={{ backgroundColor: "rgb(44, 44, 215)" }}
            icon={<AntDesignOutlined />}
            onClick={showModal}
          >
            Thêm biến thể Tour
          </Button>
        </div>
        <ThemBienTheTour
          visible={visible}
          onCancel={handleCancel}
          reloadData={() => fetchData(currentBienTheTour)}
        />
      </ConfigProvider>

      {/* Tìm kiếm người dùng */}
      {/* <TimKiem /> */}

      {/* Bảng người dùng */}
      <div
        className="table-container align-items-center"
        style={{ marginRight: "-100px" }}
      >
        {data.length === 0 ? (
          <div style={{ textAlign: "center", marginTop: "20px" }}>
            <h4>
              Không có Tour nào cho Biến Thể Tour:{" "}
              <strong style={{ textTransform: "uppercase" }}>
                {decodeURIComponent(bienTheTour || "Không xác định")}
              </strong>
            </h4>
          </div>
        ) : (
          <Table
            columns={columns(
              handleBienTheTour,
              navigateToBienTheTour,
              showEditModal,
              handleDelete,
              renderStars,
              handleHoaDon,
              formatCurrencyVND
            )}
            scroll={{ x: 2000 }}
            dataSource={data}
            rowKey="id"
          />
        )}
      </div>

      {/* Modal cập nhật tin tức */}
      {editingUser && (
        <CapNhatBienTheTour
          visible={visible}
          onCancel={handleCancel}
          userData={editingUser} // Truyền dữ liệu người dùng vào modal
          onUpdateSuccess={handleUpdateSuccess}
        />
      )}
    </div>
  );
};

export default FormQuanLyBienTheTour;
