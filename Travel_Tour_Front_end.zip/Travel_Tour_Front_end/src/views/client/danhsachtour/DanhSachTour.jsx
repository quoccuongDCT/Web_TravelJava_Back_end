// import React, { useState, useEffect } from "react";
// import { Link } from "react-router-dom";
// import axios from "axios";
// import { Swiper, SwiperSlide } from "swiper/react";
// import "swiper/css";
// import "swiper/css/navigation";
// import "swiper/css/pagination";
// import { Pagination } from "swiper/modules";

// import "react-toastify/dist/ReactToastify.css";
// import { toast } from "react-toastify";
// import BtnLikeIcon from "../componetns/BtnLikeIcon";
// import Loading from "../../../components/loading";

// export default function DanhSachTour() {
//   const [tours, setTours] = useState([]); // Danh sách tour
//   const [likedTours, setLikedTours] = useState([]); // Danh sách các tour yêu thích
//   const [shownCount, setShownCount] = useState(8); // Số lượng tour hiển thị hiện tại
//   const [sortOption, setSortOption] = useState(""); // Tùy chọn sắp xếp
//   const [priceFilter, setPriceFilter] = useState(""); // Lọc giá
//   const isLoggedIn = localStorage.getItem("id");

//   const handleLikeToggle = (tourId) => {
//     const userId = localStorage.getItem("id");
//     if (!userId) {
//       console.log("Không tìm thấy ID người dùng.");
//       return;
//     }

//     const isCurrentlyLiked = tours.find((tour) => tour.id === tourId)?.like;

//     fetch("http://localhost:8080/api/yeuthich/add", {
//       method: "POST",
//       headers: {
//         "Content-Type": "application/json",
//       },
//       body: JSON.stringify({
//         userId: userId,
//         tourId: tourId,
//       }),
//     })
//       .then((response) => response.json())
//       .then(() => {
//         if (isCurrentlyLiked) {
//           // toast.info("Đã xóa tour khỏi danh sách yêu thích!");
//         } else {
//           // toast.success("Đã thêm tour vào yêu thích!");
//         }

//         setTours((prevTours) =>
//           prevTours.map((tour) =>
//             tour.id === tourId ? { ...tour, like: !tour.like } : tour
//           )
//         );
//       })
//       .catch((error) => {
//         console.error("Lỗi khi lưu yêu thích:", error);
//         toast.error("Có lỗi xảy ra. Vui lòng thử lại sau.");
//       });
//   };

//   useEffect(() => {
//     const userId = localStorage.getItem("id");
//     if (userId) {
//       axios
//         .get(`http://localhost:8080/api/yeuthich/likedTours/${userId}`)
//         .then((response) => setLikedTours(response.data))
//         .catch((error) => console.error("Error fetching liked tours:", error));
//     }

//     axios
//       .get("http://localhost:8080/api/tours/info")
//       .then((response) => {
//         const uniqueTours = Array.from(
//           new Map(response.data.map((item) => [item.id, item])).values()
//         );
//         const mappedData = uniqueTours.map((item) => ({
//           id: item.id,
//           title: item.tenTour,
//           price: item.giaNguoiLon,
//           rating: item.danhGiaKhachSan || 0,
//           url: item.hinhAnh,
//           description: item.soNgay,
//           galleryImgs: [item.hinhAnh],
//           like: false,
//           startDate: new Date(item.ngayBatDau).toLocaleDateString(),
//         }));
//         setTours(mappedData);
//       })
//       .catch((error) => console.error("Error fetching tours:", error));
//   }, []);

//   // Không thay đổi tours gốc, chỉ lọc và sắp xếp dữ liệu khi render
//   const filteredAndSortedTours = React.useMemo(() => {
//     let filteredTours = [...tours];

//     // Lọc giá
//     if (priceFilter) {
//       switch (priceFilter) {
//         case "under-3M":
//           filteredTours = filteredTours.filter((tour) => tour.price < 3000000);
//           break;
//         case "3M-7M":
//           filteredTours = filteredTours.filter(
//             (tour) => tour.price >= 3000000 && tour.price <= 7000000
//           );
//           break;
//         case "7M-10M":
//           filteredTours = filteredTours.filter(
//             (tour) => tour.price > 7000000 && tour.price <= 10000000
//           );
//           break;
//         case "10M-15M":
//           filteredTours = filteredTours.filter(
//             (tour) => tour.price > 10000000 && tour.price <= 15000000
//           );
//           break;
//         default:
//           break;
//       }
//     }

//     // Sắp xếp
//     if (sortOption) {
//       filteredTours.sort((a, b) =>
//         sortOption === "ascending" ? a.price - b.price : b.price - a.price
//       );
//     }

//     return filteredTours;
//   }, [tours, sortOption, priceFilter]);

//   const shownTours = filteredAndSortedTours.slice(0, shownCount);

//   const handleShowMoreTours = () => {
//     setShownCount((prevCount) => Math.min(prevCount + 8, tours.length));
//   };

//   const renderStars = (stars) => {
//     const maxStars = 5;
//     return Array.from({ length: maxStars }, (_, index) => (
//       <span
//         key={index}
//         style={{ color: index < stars ? "#FFD700" : "#d3d3d3" }}
//       >
//         ★
//       </span>
//     ));
//   };

//   const formatCurrencyVND = (amount) => {
//     return new Intl.NumberFormat("vi-VN", {
//       style: "currency",
//       currency: "VND",
//     }).format(amount);
//   };

//   return (
//     <div className="space-y-6 sm:space-y-8 p-20 container">
//       <header className="flex items-center justify-between mt-5">
//         <div>
//           <h1 className="text-3xl font-semibold text-left">
//             Danh sách du lịch
//           </h1>
//           <div className="w-14 border-b border-neutral-200 dark:border-neutral-700"></div>
//         </div>
//       </header>

//       <div className="mt-2 text-left">
//         <select
//           value={sortOption}
//           onChange={(e) => setSortOption(e.target.value)}
//           className="mt-2 mr-2 p-2 border border-gray-300 rounded"
//         >
//           <option value="">Tất cả</option>
//           <option value="ascending">Theo giá tăng dần</option>
//           <option value="descending">Theo giá giảm dần</option>
//         </select>
//         <select
//           value={priceFilter}
//           onChange={(e) => setPriceFilter(e.target.value)}
//           className="mt-2 mr-2 p-2 border border-gray-300 rounded"
//         >
//           <option value="">Giá</option>
//           <option value="under-3M">Dưới 3 triệu</option>
//           <option value="3M-7M">3 triệu - 7 triệu</option>
//           <option value="7M-10M">7 triệu - 10 triệu</option>
//           <option value="10M-15M">10 triệu - 15 triệu</option>
//         </select>
//       </div>

//       <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4">
//         {shownTours.map((item) => (
//           <div className="border rounded-2xl" key={item.id}>
//             <div className="flex-col flex relative">
//               <Link to={`/chi-tiet-tour/${item.id}`}>
//                 <Swiper
//                   spaceBetween={10}
//                   slidesPerView={1}
//                   loop={false}
//                   pagination={{ clickable: true }}
//                   modules={[Pagination]}
//                   className="w-full h-[220px] rounded-2xl"
//                 >
//                   {item.galleryImgs.map((imgSrc, imgIndex) => (
//                     <SwiperSlide key={imgIndex}>
//                       <img
//                         className="w-full h-[220px] rounded-2xl"
//                         src={imgSrc}
//                         alt={`Slide ${imgIndex}`}
//                       />
//                     </SwiperSlide>
//                   ))}
//                 </Swiper>
//               </Link>
//               {isLoggedIn && (
//                 <div className="absolute p-2 right-0 z-10">
//                   <BtnLikeIcon
//                     isLiked={likedTours.some((tour) => tour.id === item.id)}
//                     onToggleLike={() => handleLikeToggle(item.id)}
//                   />
//                 </div>
//               )}
//               <div className="p-[16px] flex flex-col gap-2 text-left">
//                 <b className="text-[18px] line-clamp-3 min-h-[80px]">
//                   {item.title}
//                 </b>
//                 <span>{item.description}</span>
//                 <div className="flex gap-3">
//                   <span>{item.startDate}</span>
//                 </div>
//                 <div className="flex justify-between">
//                   <div className="flex gap-1">
//                     <span>{formatCurrencyVND(item.price)}</span>
//                     <span className="text-gray-300">/Người lớn</span>
//                   </div>
//                   <div className="flex items-center gap-2">
//                     <span>{renderStars(item.rating)}</span>
//                   </div>
//                 </div>
//               </div>
//             </div>
//           </div>
//         ))}
//       </div>
//       <div className="flex items-center justify-center">
//         {shownCount < tours.length && (
//           <button
//             className="text-gray-600 hover:text-gray-900 transition-colors border w-[133px] h-[49px] rounded-3xl flex items-center justify-center font-medium gap-2"
//             onClick={handleShowMoreTours}
//           >
//             <Loading /> Xem thêm
//           </button>
//         )}
//       </div>
//     </div>
//   );
// }
import React, { useState, useEffect } from "react";
import { Link, useLocation } from "react-router-dom";
import axios from "axios";
import { Swiper, SwiperSlide } from "swiper/react";
import "swiper/css";
import "swiper/css/navigation";
import "swiper/css/pagination";
import { Pagination } from "swiper/modules";

import "react-toastify/dist/ReactToastify.css";
import { toast } from "react-toastify";
import BtnLikeIcon from "../componetns/BtnLikeIcon";
import Loading from "../../../components/loading";

export default function DanhSachTour() {
  const [tours, setTours] = useState([]); // Danh sách tour
  const [likedTours, setLikedTours] = useState([]); // Danh sách các tour yêu thích
  const [shownCount, setShownCount] = useState(8); // Số lượng tour hiển thị hiện tại
  const [sortOption, setSortOption] = useState(""); // Tùy chọn sắp xếp
  const [priceFilter, setPriceFilter] = useState(""); // Lọc giá
  const [searchDate, setSearchDate] = useState(""); // Tìm kiếm theo ngày
  const isLoggedIn = localStorage.getItem("id");

  const location = useLocation(); // Truy xuất URL hiện tại

  // Lấy tham số danh mục từ URL
  const searchParams = new URLSearchParams(location.search);
  const danhMuc = searchParams.get("danhMuc");

  const handleLikeToggle = (tourId) => {
    const userId = localStorage.getItem("id");
    if (!userId) {
      console.log("Không tìm thấy ID người dùng.");
      return;
    }

    fetch("http://localhost:8080/api/yeuthich/add", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        userId: userId,
        tourId: tourId,
      }),
    })
      .then((response) => response.json())
      .then(() => {
        setTours((prevTours) =>
          prevTours?.map((tour) =>
            tour.id === tourId ? { ...tour, like: !tour.like } : tour
          )
        );
      })
      .catch((error) => {
        console.error("Lỗi khi lưu yêu thích:", error);
        toast.error("Có lỗi xảy ra. Vui lòng thử lại sau.");
      });
  };

  useEffect(() => {
    const fetchTours = async () => {
      try {
        let url = danhMuc
          ? `http://localhost:8080/api/tours/byDanhMuc/${danhMuc}`
          : "http://localhost:8080/api/tours/info";

        // Thêm ngày bắt đầu vào query params nếu có
        const params = new URLSearchParams();
        if (searchDate) {
          params.append("startDate", searchDate);
        }
        if (params.toString()) {
          url += `?${params.toString()}`;
        }

        const response = await axios.get(url);
        const uniqueTours = Array.from(
          new Map(response.data?.map((item) => [item.id, item])).values()
        );
        const mappedData = uniqueTours?.map((item) => ({
          id: item.id,
          title: item.tenTour,
          price: item.giaNguoiLon,
          rating: item.danhGiaKhachSan || 5,
          url: item.hinhAnh,
          description: item.soNgay,
          galleryImgs: [item.hinhAnh],
          like: false,
          startDate: new Date(item.ngayBatDau).toLocaleDateString(),
          danhMuc: item.danhMuc,
        }));
        setTours(mappedData);
      } catch (error) {
        console.error("Error fetching tours:", error);
      }
    };

    fetchTours();
  }, [danhMuc, searchDate]);

  // Lọc và sắp xếp danh sách tour
  const filteredAndSortedTours = React.useMemo(() => {
    let filteredTours = [...tours];

    // Lọc giá
    if (priceFilter) {
      switch (priceFilter) {
        case "under-3M":
          filteredTours = filteredTours.filter((tour) => tour.price < 3000000);
          break;
        case "3M-7M":
          filteredTours = filteredTours.filter(
            (tour) => tour.price >= 3000000 && tour.price <= 7000000
          );
          break;
        case "7M-10M":
          filteredTours = filteredTours.filter(
            (tour) => tour.price > 7000000 && tour.price <= 10000000
          );
          break;
        case "10M-15M":
          filteredTours = filteredTours.filter(
            (tour) => tour.price > 10000000 && tour.price <= 15000000
          );
          break;
        default:
          break;
      }
    }

    // Sắp xếp
    if (sortOption) {
      filteredTours.sort((a, b) =>
        sortOption === "ascending" ? a.price - b.price : b.price - a.price
      );
    }

    return filteredTours;
  }, [tours, sortOption, priceFilter]);

  const shownTours = filteredAndSortedTours.slice(0, shownCount);

  const handleShowMoreTours = () => {
    setShownCount((prevCount) => Math.min(prevCount + 8, tours.length));
  };

  const renderStars = (stars) => {
    const maxStars = 5;
    return Array.from({ length: maxStars }, (_, index) => (
      <span
        key={index}
        style={{ color: index < stars ? "#FFD700" : "#d3d3d3" }}
      >
        ★
      </span>
    ));
  };

  const formatCurrencyVND = (amount) => {
    return new Intl.NumberFormat("vi-VN", {
      style: "currency",
      currency: "VND",
      currencyDisplay: "code",
    }).format(amount);
  };

  return (
    <div className="space-y-6 sm:space-y-8 p-20 container">
      <header className="flex items-center justify-between mt-5">
        <div>
          <h1 className="text-3xl font-semibold text-left">
            Danh sách du lịch
          </h1>
          <div className="w-14 border-b border-neutral-200 dark:border-neutral-700"></div>
        </div>
      </header>

      {/* Bộ lọc */}
      <div className="mt-2 text-left">
        <select
          value={sortOption}
          onChange={(e) => setSortOption(e.target.value)}
          className="mt-2 mr-2 p-2 border border-gray-300 rounded"
        >
          <option value="">Tất cả</option>
          <option value="ascending">Theo giá tăng dần</option>
          <option value="descending">Theo giá giảm dần</option>
        </select>
        <select
          value={priceFilter}
          onChange={(e) => setPriceFilter(e.target.value)}
          className="mt-2 mr-2 p-2 border border-gray-300 rounded"
        >
          <option value="">Giá</option>
          <option value="under-3M">Dưới 3 triệu</option>
          <option value="3M-7M">3 triệu - 7 triệu</option>
          <option value="7M-10M">7 triệu - 10 triệu</option>
          <option value="10M-15M">10 triệu - 15 triệu</option>
        </select>

        {/* Thêm input chọn ngày */}
        <input
          type="date"
          value={searchDate}
          onChange={(e) => setSearchDate(e.target.value)}
          className="mt-2 p-2 border border-gray-300 rounded"
        />
      </div>

      {/* Hiển thị danh sách tour */}
      <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4">
        {shownTours?.map((item) => (
          <div className="border rounded-2xl" key={item.id}>
            <div className="flex-col flex relative">
              <Link to={`/chi-tiet-tour/${item.id}`}>
                <Swiper
                  spaceBetween={10}
                  slidesPerView={1}
                  loop={false}
                  pagination={{ clickable: true }}
                  modules={[Pagination]}
                  className="w-full h-[220px] rounded-2xl"
                >
                  {item.galleryImgs?.map((imgSrc, imgIndex) => (
                    <SwiperSlide key={imgIndex}>
                      <img
                        className="w-full h-[220px] rounded-2xl"
                        src={imgSrc}
                        alt={`Slide ${imgIndex}`}
                      />
                    </SwiperSlide>
                  ))}
                </Swiper>
              </Link>
              {isLoggedIn && (
                <div className="absolute p-2 right-0 z-10">
                  <BtnLikeIcon
                    isLiked={likedTours.some((tour) => tour.id === item.id)}
                    onToggleLike={() => handleLikeToggle(item.id)}
                  />
                </div>
              )}
              <div className="p-[16px] flex flex-col text-left">
                <b className="text-[18px] line-clamp-3">{item.title}</b>
                <span className="text-[14px] text-gray-500">
                  {item.description}
                </span>
                <div className="flex gap-3">
                  <span>{item.startDate}</span>
                </div>
                <div className="flex justify-between">
                  <div className="flex gap-1">
                    {/* <span>{formatCurrencyVND(item.price)}</span> */}
                    {/* <span className="text-gray-300">/Người lớn</span>4{" "} */}
                    <span style={{ color: "#b22222", fontWeight: "bold" }}>
                      {formatCurrencyVND(item.price)}
                    </span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span>{renderStars(item.rating)}</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Nút Xem thêm */}
      <div className="flex items-center justify-center">
        {shownCount < tours.length && (
          <button
            className="text-gray-600 hover:text-gray-900 transition-colors border w-[133px] h-[49px] rounded-3xl flex items-center justify-center font-medium gap-2"
            onClick={handleShowMoreTours}
          >
            <Loading /> Xem thêm
          </button>
        )}
      </div>
    </div>
  );
}
