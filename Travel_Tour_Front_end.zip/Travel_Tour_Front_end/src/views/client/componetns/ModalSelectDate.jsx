import React, { useState } from "react";
import { DatePicker, Modal, Button, Row, Col } from "antd";
import { CloseOutlined } from "@ant-design/icons";

const ModalSelectDate = ({ renderChildren }) => {
  const [isModalVisible, setIsModalVisible] = useState(false);
  const [dates, setDates] = useState([null, null]);
  const [selectedDateString, setSelectedDateString] = useState("");

  const onChangeDate = (dates) => {
    setDates(dates);
  };

  const closeModal = () => {
    setIsModalVisible(false);
  };

  const openModal = () => {
    setIsModalVisible(true);
  };

  const convertSelectedDateToString = (dates) => {
    if (!dates[0] || !dates[1]) return "Chưa chọn ngày";
    return `${dates[0].format("MMM DD")} - ${dates[1].format("MMM DD")}`;
  };

  const handleSave = () => {
    const dateString = convertSelectedDateToString(dates);
    setSelectedDateString(dateString);
    closeModal();
  };

  const renderButtonOpenModal = () => {
    return renderChildren ? (
      renderChildren({ openModal, selectedDateString }) // Truyền selectedDateString vào renderChildren
    ) : (
      <Button type="primary" onClick={openModal}>
        {selectedDateString || "Chọn ngày"}
      </Button>
    );
  };

  return (
    <>
      {renderButtonOpenModal()}
      <Modal
        title="Chuyến đi của bạn diễn ra khi nào?"
        visible={isModalVisible}
        onCancel={closeModal}
        footer={[
          <Button key="clear" onClick={() => setDates([null, null])}>
            Xóa ngày tháng
          </Button>,
          <Button key="save" type="primary" onClick={handleSave}>
            Lưu
          </Button>,
        ]}
        closeIcon={<CloseOutlined />}
        width={800}
        bodyStyle={{ padding: '20px', height: '400px', overflowY: 'auto' }} 
      >
        <Row gutter={16}>
          <Col span={12}>
            <h4>Ngày bắt đầu</h4>
            <DatePicker
              value={dates[0]}
              onChange={(date) => setDates([date, dates[1]])}
              format="YYYY/MM/DD"
              className="w-full"
            />
          </Col>
          <Col span={12}>
            <h4>Ngày kết thúc</h4>
            <DatePicker
              value={dates[1]}
              onChange={(date) => {
                // Kiểm tra nếu ngày kết thúc nhỏ hơn ngày bắt đầu
                if (dates[0] && date && date.isBefore(dates[0])) {
                  return; // Không cập nhật nếu không hợp lệ
                }
                setDates([dates[0], date]);
              }}
              format="YYYY/MM/DD"
              className="w-full"
            />
          </Col>
        </Row>
      </Modal>
    </>
  );
};

export default ModalSelectDate;
