import React, { useState } from "react";
import { Modal, Button, Row, Col } from "antd";
import { CloseOutlined } from "@ant-design/icons";

const ModalSelectGuests = ({ renderChildren, onSaveGuests }) => {
  const [showModal, setShowModal] = useState(false);
  const [adults, setAdults] = useState(0);
  const [children, setChildren] = useState(0);
  const [infants, setInfants] = useState(0);

  const closeModal = () => {
    setShowModal(false);
  };

  const openModal = () => {
    setShowModal(true);
  };

  const handleSave = () => {
    onSaveGuests({ guestAdults: adults, guestChildren: children, guestInfants: infants });
    closeModal();
  };

  const renderButtonOpenModal = () => {
    return renderChildren ? (
      renderChildren({ openModal })
    ) : (
      <Button type="primary" onClick={openModal}>
        Chọn khách
      </Button>
    );
  };

  return (
    <>
      {renderButtonOpenModal()}
      <Modal
        title={
          <div className="flex items-center">
            <CloseOutlined className="text-red-500 mr-2" />
            <span>Chọn khách</span>
          </div>
        }
        visible={showModal}
        onCancel={closeModal}
        footer={null}
        className="modal-custom"
        closeIcon={<CloseOutlined />}
        width={800}
        bodyStyle={{ padding: '20px', height: '300px', overflowY: 'auto' }} 
      >
        <div className="flex flex-col">
          <h3>Ai sẽ tham gia?</h3>
          <Row gutter={16} className="mb-4">
            <Col span={24}>
              <div className="flex items-center justify-between">
                <span>Người lớn (Từ 13 tuổi trở lên)</span>
                <div className="flex items-center">
                  <Button onClick={() => setAdults(adults > 0 ? adults - 1 : 0)}>-</Button>
                  <span className="mx-2">{adults}</span>
                  <Button onClick={() => setAdults(adults + 1)}>+</Button>
                </div>
              </div>
            </Col>
            <Col span={24}>
              <div className="flex items-center justify-between mt-2">
                <span>Trẻ em (Từ 2 đến 12 tuổi)</span>
                <div className="flex items-center">
                  <Button onClick={() => setChildren(children > 0 ? children - 1 : 0)}>-</Button>
                  <span className="mx-2">{children}</span>
                  <Button onClick={() => setChildren(children + 1)}>+</Button>
                </div>
              </div>
            </Col>
            <Col span={24}>
              <div className="flex items-center justify-between mt-2">
                <span>Trẻ sơ sinh (Từ 0 đến 2 tuổi)</span>
                <div className="flex items-center">
                  <Button onClick={() => setInfants(infants > 0 ? infants - 1 : 0)}>-</Button>
                  <span className="mx-2">{infants}</span>
                  <Button onClick={() => setInfants(infants + 1)}>+</Button>
                </div>
              </div>
            </Col>
          </Row>
          <div className="flex justify-between mt-5">
            <Button type="text" onClick={() => {
              setAdults(0);
              setChildren(0);
              setInfants(0);
            }}>
              Xóa khách hàng
            </Button>
            <Button type="primary" onClick={handleSave}>
              Lưu
            </Button>
          </div>
        </div>
      </Modal>
    </>
  );
};

export default ModalSelectGuests;
