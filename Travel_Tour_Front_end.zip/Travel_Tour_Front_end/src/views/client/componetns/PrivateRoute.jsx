import React from 'react';
import { Navigate } from 'react-router-dom';

const PrivateRoute = ({ element }) => {

  const role = localStorage.getItem('role'); 

  const isAuthenticated = () => {
    return (
      role === 'admin' || 
      role === 'nhanvien'
    );
  };

  return isAuthenticated() ? element : <Navigate to="/dangNhap" />;
};

export default PrivateRoute;








