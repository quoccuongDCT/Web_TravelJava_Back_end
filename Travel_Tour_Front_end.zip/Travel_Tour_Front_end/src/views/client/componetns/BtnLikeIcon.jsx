import React, { useState } from "react";

const BtnLikeIcon = ({
  className = "",
  colorClass = "text-white bg-opacity-30 hover:bg-opacity-50",
  isLiked = false,
  onToggleLike,
}) => {
  const [likedState, setLikedState] = useState(isLiked);

  const handleClick = () => {
    setLikedState(!likedState); // Toggle trạng thái liked
    if (onToggleLike) {
      onToggleLike(); // Gọi hàm của cha (cập nhật trạng thái yêu thích ở nơi khác)
    }
  };

  return (
    <div
      className={`nc-BtnLikeIcon flex items-center justify-center rounded-full cursor-pointer ${
        likedState ? "nc-BtnLikeIcon--liked" : ""
      } ${colorClass} ${className}`}
      title={likedState ? "Hủy yêu thích" : "Yêu thích"}
      onClick={handleClick}
    >
      <div
        className={`border-2 ${
          likedState ? "border-blue-300" : "border-gray-100"
        } rounded-2xl flex items-center p-[4px]`}
      >
        <svg
          xmlns="http://www.w3.org/2000/svg"
          className="h-5 w-5"
          fill={likedState ? "red" : "none"} // Đổi màu khi liked
          viewBox="0 0 24 24"
          stroke="red"
        >
          <path
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeWidth={1.5}
            d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z"
          />
        </svg>
        <span className="text-white text-[12px]">
          {likedState ? "HỦY YÊU THÍCH" : "YÊU THÍCH"}
        </span>
      </div>
    </div>
  );
};

export default BtnLikeIcon;
