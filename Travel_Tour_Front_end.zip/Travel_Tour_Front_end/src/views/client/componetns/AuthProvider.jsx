import React, { useEffect } from "react";
import axios from "axios";

const AuthProvider = ({ setIsLoggedIn }) => {
  useEffect(() => {
    if (window.location.hash === "#_=_") {
      window.history.replaceState({}, document.title, window.location.pathname + window.location.search);
    }

    // Kiểm tra xem đã có thông tin trong localStorage chưa
    const storedName = localStorage.getItem("hoTen");
    const storedEmail = localStorage.getItem("email");

    // Nếu đã có thông tin người dùng, không gọi API nữa
    if (storedName && storedEmail) {
      setIsLoggedIn(true);
      return;
    }

    // Hàm lấy thông tin người dùng từ Google API
    const fetchGoogleUser = async () => {
      try {
        const response = await axios.get("http://localhost:8080/api/google/tt", {
          withCredentials: true,
        });

        const data = response.data;
        console.log("gg: ", data);
        // Nếu có dữ liệu hợp lệ từ Google, lưu vào localStorage và set login
        if (data && data.hoTen) {
          localStorage.setItem("hoTen", data.hoTen);
          localStorage.setItem("email", data.email || "");
          localStorage.setItem("diaChi", data.diaChi || "");
          localStorage.setItem("role", data.vaiTro || "");
          localStorage.setItem("id", data.id || "");
          localStorage.setItem("namSinh", data.namSinh || "");
          localStorage.setItem("soDienThoai", data.soDienThoai || "");
          localStorage.setItem("token", data.token || "");
          localStorage.setItem("hinhAnh", data.hinhAnh || "");
          setIsLoggedIn(true);
        } else {
          // Nếu không có dữ liệu hợp lệ từ Google, tiếp tục gọi Facebook API
          fetchFacebookUser();
        }
      } catch (error) {
        console.error("Lỗi khi gọi API Google:", error);
        fetchFacebookUser();
      }
    };

    // Hàm lấy thông tin người dùng từ Facebook API
    const fetchFacebookUser = async () => {
      try {
        const response = await axios.get("http://localhost:8080/api/facebook/tt", {
          withCredentials: true,
        });

        const data = response.data;
        console.log("fb: ",data)
        // Nếu có dữ liệu hợp lệ từ Facebook, lưu vào localStorage và set login
        if (data && data.email) {
          localStorage.setItem("hoTen", data.hoTen || "");
          localStorage.setItem("email", data.email || "");
          localStorage.setItem("role", data.vaiTro || "");
          localStorage.setItem("id", data.id || "");
          localStorage.setItem("namSinh", data.namSinh || "");
          localStorage.setItem("soDienThoai", data.soDienThoai || "");
          localStorage.setItem("token", data.token || "");
          localStorage.setItem("hinhAnh", data.hinhAnh || "");
          localStorage.setItem("diaChi", data.diaChi || "");

          setIsLoggedIn(true);
        } else {
          setIsLoggedIn(false);
        }
      } catch (error) {
        console.error("Lỗi khi gọi API Facebook:", error);
        setIsLoggedIn(false);
      }
    };

    // Gọi API Google trước
    fetchGoogleUser();

  }, [setIsLoggedIn]);

  return null; // Component này không render gì
};

export default AuthProvider;
