import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import "./ResetPassword.css";
// import { message } from "react-messageify";
// import "react-messageify/dist/ReactToastify.css";
import { AiFillEye, AiFillEyeInvisible } from 'react-icons/ai';
import { useLocation } from "react-router-dom";
import { message} from "antd";

const DoiMatKhau = () => {
  const navigate = useNavigate();
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [showNewPassword, setShowNewPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const location = useLocation();
  const email = location.state?.email; // Lấy email từ state được truyền qua navigate
  const validateForm = () => {
    if (!newPassword) {
      message.error("Mật khẩu không được để trống.");
      return false;
    }
    if (!confirmPassword) {
      message.error("Xác nhận mật khẩu không được để trống.");
      return false;
    }
    if (newPassword !== confirmPassword) {
      message.error("Mật khẩu không khớp.");
      return false;
    }
    return true;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!validateForm()) return;

    try {
      const response = await fetch("http://localhost:8080/api/reset-password", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ email, newPassword, confirmPassword }),
      });
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message);
      }

      const data = await response.json();
      message.success(data.message);
      // setTimeout(() => {
      //   navigate("/");
      // }, 2000);
      navigate("/dangNhap");

    } catch (error) {
      message.error(error.message);
    }
  };

  return (
    <div className="ResetPassword-wrapper">
      <div className="ResetPassword-container">
        <h2 style={{
          textAlign: "center",
          fontFamily: '"Arial", "sans-serif"',
          margin: "0 auto",
          marginBottom: '30px'
        }}>
          Đặt Lại Mật Khẩu
        </h2>
        <p>Nhập mật khẩu mới! Mật khẩu có độ dài từ 6-20 ký tự bao gồm chữ cái và số</p>
        <br />
        <form className="ResetPassword-form" onSubmit={handleSubmit}>
          <div className="input-ResetPassword">
            <label>Mật khẩu mới</label>
            <div className="input-wrapper">
              <input
                type={showNewPassword ? "text" : "password"}
                placeholder="********"
                value={newPassword}
                onChange={(e) => setNewPassword(e.target.value)}
              />
              <span
                className="eye-icon"
                onClick={() => setShowNewPassword(!showNewPassword)}
              >
                {showNewPassword ? <AiFillEyeInvisible /> : <AiFillEye />}
              </span>
            </div>
          </div>

          <div className="input-ResetPassword">
            <label>Xác nhận mật khẩu</label>
            <div className="input-wrapper">
              <input
                type={showConfirmPassword ? "text" : "password"}
                placeholder="********"
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
              />
              <span
                className="eye-icon"
                onClick={() => setShowConfirmPassword(!showConfirmPassword)}
              >
                {showConfirmPassword ? <AiFillEyeInvisible /> : <AiFillEye />}
              </span>
            </div>
          </div>

          <br />
          <button type="submit" className="btn-ResetPassword">
            Đặt lại mật khẩu
          </button>
        </form>
      </div>
    </div>
  );
};

export default DoiMatKhau;
