import React, { useState } from "react";
import { useNavigate } from "react-router-dom"; 
import "./ForgotPassword.css";
// import { message } from "react-messageify"; 
// import "react-messageify/dist/ReactToastify.css"; 
import { LeftOutlined } from '@ant-design/icons';
import { message} from "antd";

const QuenMatKhau = () => {
  const navigate = useNavigate(); 
  const [email, setEmail] = useState("");
  const [isSendingOtp, setIsSendingOtp] = useState(false); 

  // Kiểm tra email hợp lệ
  const validateEmail = (email) => {
    const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
    return emailRegex.test(email);
  };

  const validateForm = () => {
    if (!email) {
      message.error("Email không được để trống.");
      return false;
    } else if (!validateEmail(email)) {
      message.error("Email không hợp lệ.");
      return false;
    }

    return true;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    // Kiểm tra form trước khi tiếp tục
    if (!validateForm()) return;
    if (isSendingOtp) {
      message.warning("Đang gửi mã OTP, vui lòng chờ.");
      return;
    }
    setIsSendingOtp(true); // Bắt đầu gửi
    try {
      const response = await fetch("http://localhost:8080/api/send-otp", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ email }),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || "Gửi OTP thất bại.");
      }

      const data = await response.json();
      message.success(data.message);
      sessionStorage.setItem("otp", data.otp);
      console.log("Mã OTP đã lưu vào sessionStorage:", data.otp); 

      navigate("/Otp", { state: { email } });
    } catch (error) {
      message.error(error.message || "Gửi OTP thất bại.");
    }finally {
      setIsSendingOtp(false); // Kết thúc gửi
    }
  };

  return (
    <div className="forgotPassword-wrapper">
      <div className="forgotPassword-container">
        <div style={{ marginLeft: "-20px", marginBottom: "30px" }}>
        <button className="back-button text-left" onClick={() => navigate(-1)}>
          <LeftOutlined /> Quay lại
        </button>
        </div>
        <strong style={{fontSize: '19px'}}>Quên mật khẩu</strong>
        <br />
        <br />
        <p>Để khôi phục nhập khẩu, bạn vui lòng nhập <strong>Email</strong> </p>
        <p className="mt-[-20px]"> <span>đã dùng để đăng ký trên hệ thống.</span></p>


        <form className="forgotPassword-form" onSubmit={handleSubmit}>
          <div className="input-forgot">
            <label>Email</label>
            <input
              type="text"
              placeholder="Địa chỉ email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
            />
          </div>
          <button type="submit" className="btn-forgotPassword">
            Khôi phục mật khẩu
          </button>
        </form>
      </div>
    </div>
  );
};

export default QuenMatKhau;
