import React from "react";
import styled from "styled-components";
import Carousel from "react-bootstrap/Carousel";

const TourNuocNgoai = ({ loaitourvatour }) => {
  // Nhóm các tour theo khu vực (Châu Á, Châu Âu, v.v...)
  const groupedTours = loaitourvatour.reduce((acc, [region, tenTour]) => {
    if (!acc[region]) {
      acc[region] = [];
    }
    acc[region].push(tenTour);
    return acc;
  }, {});

  return (
    <TourContainer>
      <ImageContainer>
        <Carousel fade interval={3000} controls={true} indicators={true}>
          <Carousel.Item>
          <a href="/danh-sach-tour">
            <img
              src="https://datviettour.com.vn/uploads/images/banner/trang-chu/slide-nhat-ban-thu.png"
              alt="Banner 1"
            />
            </a>
            <Carousel.Caption></Carousel.Caption>
          </Carousel.Item>
          <Carousel.Item>
          <a href="/danh-sach-tour">
            <img
              src="https://datviettour.com.vn/uploads/images/banner/trang-chu/slide-du-thuyen.jpg"
              alt="Banner 2"
            />
            </a>
            <Carousel.Caption></Carousel.Caption>
          </Carousel.Item>
          <Carousel.Item>
          <a href="/danh-sach-tour">
            <img
              src="https://datviettour.com.vn/uploads/images/banner/trang-chu/slide-trung-quoc-thu-2024.png"
              alt="Banner 3"
            />
            </a>
            <Carousel.Caption></Carousel.Caption>
          </Carousel.Item>
        </Carousel>
      </ImageContainer>
      <TourListContainer>
        {Object.keys(groupedTours).map((region) => (
          <Category key={region}>
            <ScrollableList>
              <ul>
                {groupedTours[region].map((tour, index) => (
                  <li key={index}>
                    <a
                      href={`/chi-tiet-tour/${region}`}
                      style={{ fontSize: "17px" }}
                    >
                      {tour}
                    </a>
                  </li>
                ))}
              </ul>
            </ScrollableList>
          </Category>
        ))}
      </TourListContainer>
    </TourContainer>
  );
};

const TourContainer = styled.div`
  display: flex;
  background-color: white;
  align-items: flex-start;
  border: solid 1px #e4e4e4;
  border-radius: 20px;
  padding: 20px;
`;

const ImageContainer = styled.div`
  flex: 1;
  display: flex;
  align-items: center;
  justify-content: center;

  .carousel {
    width: 450px; /* Đảm bảo Carousel không vượt quá kích thước này */
    /* height: 200px; */
    overflow: hidden; /* Đảm bảo không có hình nào nhảy ra ngoài container */
  }

  img {
    width: 450px;
    height: 200px;
    object-fit: cover; /* Giữ tỷ lệ ảnh và cắt ảnh nếu cần */
    border-radius: 10px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
  }
`;

const TourListContainer = styled.div`
  flex: 1;
  /* display: flex; */
  gap: 80px;
  padding-left: 1rem;
  max-height: 180px; /* Giới hạn chiều cao của danh sách */
  overflow-y: auto; /* Hiện thanh cuộn dọc nếu danh sách dài quá */

`;

const Category = styled.div`
  text-align: left;
  display: flex;
  flex-direction: column;
  /* margin-bottom: 20px; */
  max-height: 240px;
  overflow-y: auto;

  h3 {
    color: #0077b6;
    font-size: 16px;
    padding-bottom: 5px;
    font-weight: bold;
    margin: 0;
  }
`;

const ScrollableList = styled.div`
  ul {
    list-style: none; /* Bỏ ký hiệu bullet */
    padding: 0;
    margin: 0;
    display: block; /* Đảm bảo các mục xuống dòng */
    li {
      margin: 0.3rem 0;

      a {
        color: #333;
        text-decoration: none;
        font-size: 14px;
        transition: color 0.3s ease;

        &:hover {
          color: #005b96;
          font-size: 14.25px;
        }
      }
    }
  }
`;


export default TourNuocNgoai;
