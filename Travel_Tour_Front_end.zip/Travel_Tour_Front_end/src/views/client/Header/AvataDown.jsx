import React, { useState, useEffect } from "react";
import { Dropdown, Menu, Space } from "antd";
import { useNavigate } from "react-router-dom"; 
import {
  UserOutlined,
  HeartOutlined,
  HistoryOutlined ,
  LogoutOutlined,
} from "@ant-design/icons";
import { Link } from "react-router-dom";
// import { message} from "react-messageify";
// import "react-messageify/dist/ReactToastify.css";
import axios from 'axios';
import { message} from "antd";

const AvataDown = () => {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [user, setUser] = useState(null);
  const [diaChi, setDiaChi] = useState(null);
  const [avatar, setAvatar] = useState("/images/user.png");  

  const navigate = useNavigate(); 

  useEffect(() => {
    const userData = localStorage.getItem("hoTen");
    const address = localStorage.getItem("diaChi");
    const avatarFromLocalStorage = localStorage.getItem("hinhAnh");

    if (userData) {
      setUser(userData);
      setDiaChi(address === "null" || address === "" ? "Chưa cập nhật" : address);
      setIsLoggedIn(true);
    } else {
      setIsLoggedIn(false);
      setUser(null);
      setDiaChi(null);
      setAvatar("/images/user.png");
    }

    if (avatarFromLocalStorage) {
      setAvatar(avatarFromLocalStorage);
    }
  }, [localStorage.getItem("hoTen"), localStorage.getItem("diaChi")]);

  // }, [localStorage.getItem("hoTen"), localStorage.getItem("diaChi"), ]);

  // const handleLogout = async () => {
  //   try {
  //     await axios.post("http://localhost:8080/api/logout", {}, { withCredentials: true,  });

  //     localStorage.removeItem("hoTen");
  //     localStorage.removeItem("token");
  //     localStorage.removeItem("email");
  //     localStorage.removeItem("diaChi");
  //     localStorage.removeItem("role");
  //     localStorage.removeItem("namSinh");
  //     localStorage.removeItem("id");
  //     localStorage.removeItem("soDienThoai");
  //     localStorage.removeItem("hinhAnh");

  //     setIsLoggedIn(false);
  //     setUser(null);
  //     setDiaChi(null);
      
  //     message.success("đăng xuất thành công!");
  //     navigate("/");
  //   } catch (error) {
  //     message.error("Đăng xuất thất bại:", error);
  //   }
  // };
  const handleLogout = async () => {
    try {
      // Thực hiện logout frontend ngay lập tức
      localStorage.removeItem("hoTen");
      localStorage.removeItem("token");
      localStorage.removeItem("email");
      localStorage.removeItem("diaChi");
      localStorage.removeItem("role");
      localStorage.removeItem("namSinh");
      localStorage.removeItem("id");
      localStorage.removeItem("soDienThoai");
      localStorage.removeItem("hinhAnh");
  
      setIsLoggedIn(false);
      setUser(null);
      setDiaChi(null);
  
      message.success("Đăng xuất thành công!");
      navigate("/"); // Redirect ngay sau khi logout
  
      // Gửi yêu cầu logout đến backend (dù backend có chậm hay không)
      await axios.post("http://localhost:8080/api/logout", {}, { withCredentials: true });
  
    } catch (error) {
      message.error("Đăng xuất thất bại:", error);
    }
  };
  

  const menuItems = [
    {
      key: "1",
      label: (
        <Link to="/trang-tai-khoan" className="no-underline text-black">
          <UserOutlined /> Tài khoản của tôi
        </Link>
      ),
    },
    { 
      key: "2", 
      label: (
        <Link to="/danh-sach-yeu-thich" className="no-underline text-black">
          <HeartOutlined /> Danh sách yêu thích
        </Link>
      ),
    },
    {
      key: "3",
      label: (
        <Link to="/trang-tai-khoan/lich-su-giao-dich" className="no-underline text-black">
          <HistoryOutlined /> Lịch sử đặt tour
        </Link>
      ),
    },

    // { key: "4", label: <span>Help</span>, icon: <QuestionCircleOutlined /> },
    {
      key: "5",
      label: <span onClick={handleLogout}>Đăng xuất</span>,
      icon: <LogoutOutlined />,
      danger: true,
    },
  ];

  const menu = (
    <Menu>
      <Menu.Item key="0">
        <div className="flex items-center flex-row">
          <div>
            <img
              src={avatar}
              alt="avatar"
              className="w-12 h-12 rounded-full mr-3"
            />
          </div>
          <div className="flex justify-center flex-col w-auto h-12">

            <h4 className="font-semibold text-lg mt-1">{user}</h4>
            <p className="text-xs text-gray-500 mt-[-10px]"> {diaChi ? diaChi : "Chưa cập nhật"}</p>
          </div>
        </div>
      </Menu.Item>
      <Menu.Divider />
      {menuItems.map((item) => (
        <Menu.Item key={item.key} icon={item.icon} danger={item.danger}>
          {item.label}
        </Menu.Item>
      ))}
    </Menu>
  );

  return (
    <div>
      {isLoggedIn ? (
        <Dropdown overlay={menu} trigger={["click"]}>
          <button  onClick={(e) => e.preventDefault()}>
            <Space>
              <img
                src={avatar}
                alt="avatar"
                className="w-12 h-12 rounded-full"
              />
            </Space>
          </button>
        </Dropdown>
      ) : (
        <div className="flex items-center">
          <Link
            to="/dangNhap"
            className="self-center text-white group bg-blue-500 px-4 py-2 rounded-full 
            inline-flex items-center text-sm dark:text-neutral-300 font-medium 
            hover:bg-blue-600 hover:shadow-md transition duration-200 ease-in-out no-underline"
          >
            Đăng Nhập
          </Link>
        </div>
      )}
    </div>
  );
};

export default AvataDown;
