import React, { useState, useEffect } from "react";
import { Swiper, SwiperSlide } from "swiper/react";
import "swiper/css";
import "swiper/css/navigation";
import "swiper/css/pagination";
import { Pagination } from "swiper/modules";
import BtnLikeIcon from "../componetns/BtnLikeIcon";
import axios from "axios";
import { Link } from "react-router-dom";
import "react-toastify/dist/ReactToastify.css";
import { toast } from "react-toastify";

export default function DoanhSachYeuThich() {
  const [tours, setTours] = useState([]);
  const [likedTours, setLikedTours] = useState([]);

  // Toggle like status và cập nhật dữ liệu
  const handleLikeToggle = (tourId) => {
    const userId = localStorage.getItem("id");

    if (!userId) {
      toast.error("Không tìm thấy ID người dùng.");
      return;
    }
    console.log("Gửi yêu cầu lưu yêu thích", { userId, tourId });

    fetch("http://localhost:8080/api/yeuthich/add", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        userId: userId,
        tourId: tourId,
      }),
    })
      .then((response) => response.json())
      .then((data) => {
        toast.info("Đã xóa tour vào yêu thích!");
        // Cập nhật lại trạng thái yêu thích cho tour
        setTours((prevTours) =>
          prevTours.map((tour) =>
            tour.id === tourId ? { ...tour, like: !tour.like } : tour
          )
        );
        // Cập nhật lại danh sách tour yêu thích
        if (likedTours.some((tour) => tour.id === tourId)) {
          // Nếu tour đã được yêu thích, xóa khỏi danh sách yêu thích
          setLikedTours(likedTours.filter((tour) => tour.id !== tourId));
        } else {
          // Nếu tour chưa được yêu thích, thêm vào danh sách yêu thích
          setLikedTours([...likedTours, { id: tourId }]);
        }
      })
      .catch((error) => {
        // toast.error("Lỗi khi lưu yêu thích.");
        console.error("Lỗi khi lưu yêu thích:", error);
      });
  };

  const handleDeleteAll = () => {
    const userId = localStorage.getItem("id");

    if (!userId) {
      toast.error("Không tìm thấy ID người dùng.");
      return;
    }

    axios
      .delete(`http://localhost:8080/api/yeuthich/deleteAll/${userId}`)
      .then(() => {
        toast.info("Đã xóa tất cả các tour yêu thích.");
        setLikedTours([]); // Clear liked tours in state
      })
      .catch((error) => {
        toast.error("Lỗi khi xóa tất cả tour yêu thích.");
        console.error("Error deleting all liked tours:", error);
      });
  };

  useEffect(() => {
    const userId = localStorage.getItem("id");
    if (userId) {
      axios
        .get(`http://localhost:8080/api/yeuthich/likedTours/${userId}`)
        .then((response) => {
          setLikedTours(response.data);
        })
        .catch((error) => {
          // toast.error("Lỗi khi tải dữ liệu tour yêu thích.");
          console.error("Error fetching liked tours:", error);
        });
    }

    axios
        .get("http://localhost:8080/api/tours/info")
        .then((response) => {
          const uniqueTours = Array.from(
            new Map(response.data.map((item) => [item.id, item])).values()
          );

          const filteredTours = uniqueTours.filter(
            (item) => item.trangThai === true
          );

          const mappedData = filteredTours.map((item) => ({
            id: item.id,
            title: item.tenTour,
            price: item.giaNguoiLon,
            rating: item.danhGiaKhachSan || 0,
            url: item.hinhAnh,
            description: item.soNgay,
            status: item.trangThai,
            galleryImgs: [item.hinhAnh],
            like: false,
            startDate: new Date(item.ngayBatDau).toLocaleDateString(),
          }));

          setTours(mappedData);
        })
        .catch((error) => console.error("Error fetching tours:", error));
    }, []);

  const renderStars = (stars) => {
    const maxStars = 5; // Assuming a maximum rating of 5 stars
    return Array.from({ length: maxStars }, (_, index) => (
      <span
        key={index}
        style={{ color: index < stars ? "#FFD700" : "#d3d3d3" }}
      >
        ★
      </span>
    ));
  };
  const formatCurrencyVND = (amount) => {
    return new Intl.NumberFormat("vi-VN", {
      style: "currency",
      currency: "VND",
    }).format(amount);
  };
  const isTourLiked = (tourId) => {
    return likedTours.some((tour) => tour.id === tourId);
  };

  return (
    <div className="space-y-6 sm:space-y-8 p-20 container">
      <header className="flex items-center justify-between mt-5">
        <div>
          <h1 className="text-3xl font-semibold text-left">
            Danh sách yêu thích ({likedTours.length})
          </h1>
          <div className="w-14 border-b border-neutral-200 dark:border-neutral-700"></div>
        </div>
        <button
          onClick={handleDeleteAll}
          className="text-gray-600 hover:text-gray-900 transition-colors border w-[133px] h-[49px] rounded-3xl flex items-center justify-center font-medium"
        >
          Xóa tất cả
        </button>
      </header>
      <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4">
        {tours
          .filter((item) => isTourLiked(item.id)) // Lọc chỉ các tour đã yêu thích
          .map((item) => (
            <div className="border rounded-2xl" key={item.id}>
              <div className="flex-col flex relative">
                <Link to={`/chi-tiet-tour/${item.id}`}>
                  <Swiper
                    spaceBetween={10}
                    slidesPerView={1}
                    loop={false}
                    pagination={{ clickable: true }}
                    modules={[Pagination]}
                    className="w-full h-[220px] rounded-2xl"
                  >
                    {item.galleryImgs.map((imgSrc, imgIndex) => (
                      <SwiperSlide key={imgIndex}>
                        <img
                          className="w-full h-[220px] rounded-2xl"
                          src={imgSrc}
                          alt={`Slide ${imgIndex}`}
                        />
                      </SwiperSlide>
                    ))}
                  </Swiper>
                </Link>

                <div className="absolute p-2 right-0 z-10">
                  <BtnLikeIcon
                    isLiked={isTourLiked(item.id)}
                    onToggleLike={() => handleLikeToggle(item.id)}
                  />
                </div>

                <div className="p-[16px] flex flex-col gap-2 text-left">
                  <b className="text-[18px]">{item.title}</b>
                  <span>{item.description}</span>
                  <div className="flex gap-3">
                    <span>{item.startDate}</span>
                  </div>
                  <div className="flex justify-between">
                    <div className="flex gap-1">
                      <span>{formatCurrencyVND(item.price)}</span>

                      <span className="text-gray-300">/Người lớn</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <span>{renderStars(item.rating)}</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          ))}
      </div>
    </div>
  );
}
