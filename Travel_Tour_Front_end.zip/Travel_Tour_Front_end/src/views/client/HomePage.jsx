// import { useNavigate } from "react-router-dom";
import React, { useEffect } from "react";
import Recommend from "../../components/Recommend";
import ScrollToTop from "../../components/ScrollToTop";
import scrollreveal from "scrollreveal";
import BlogGrid from "./baiviet/CardComponenet";
import SildeComponent from "../../components/sildeComponent";
import Chatbot from "../../components/ChatbotClient";

const HomePage = () => {
  useEffect(() => {
    const sr = scrollreveal({
      origin: "top",
      distance: "80px",
      duration: 2000,
      reset: true,
    });
    sr.reveal(
      `
        #hero,
        #services,
        #recommend,
        #testimonials,
        footer
        `,
      {
        opacity: 0,
        interval: 300,
      }
    );
  }, []);

  return (
    <div>
      <div>
        <SildeComponent />
        {/* <ScrollToTop /> */}
        {/* <Hero /> */}
        {/* <Services /> */}
        <Recommend />
        <Chatbot />
        {/* <Testimonials />  */}
        {/* <BaiVietBlog/> */}
        <BlogGrid />
      </div>
    </div>
  );
};

export default HomePage;
