import React, { useState, useEffect } from "react";

const PaymentComponent = ({ totalTien }) => {
  const [discountResult, setDiscountResult] = useState(null);

  // Hàm cập nhật discountResult từ localStorage
  const updateDiscountResult = () => {
    const savedDiscountResult = localStorage.getItem("discountResult");
    setDiscountResult(savedDiscountResult); // Cập nhật discountResult từ localStorage
  };

  useEffect(() => {
    // Cập nhật discountResult ngay khi component được render
    updateDiscountResult();
  }, []); // Chỉ chạy khi component được render lần đầu tiên

  // useEffect để theo dõi sự thay đổi của localStorage trong cùng một tab
  useEffect(() => {
    // Theo dõi sự thay đổi của localStorage (cả trong tab hiện tại)
    const intervalId = setInterval(() => {
      updateDiscountResult(); // Cập nhật discountResult mỗi giây một lần
    }, 1000); // Kiểm tra mỗi 1 giây

    // Cleanup khi component bị hủy
    return () => clearInterval(intervalId); // Dừng việc kiểm tra khi component unmount
  }, []); // Chạy 1 lần khi component mount

  // Nếu có discountResult thì dùng giá trị đó, nếu không thì dùng totalTien
  const displayAmount = discountResult ? discountResult : totalTien;

  const formatCurrencyVND = (amount) => {
    return new Intl.NumberFormat("vi-VN", {
      style: "currency",
      currency: "VND",
      currencyDisplay: "code",
    }).format(amount);
  };

  const convertNumberToWords = (num) => {
    const units = [
      "",
      "Một",
      "Hai",
      "Ba",
      "Bốn",
      "Năm",
      "Sáu",
      "Bảy",
      "Tám",
      "Chín",
    ];
    const bigUnits = ["", "Nghìn", "Triệu", "Tỷ"];

    if (num === 0) return "Không Đồng";

    let words = "";
    let unitIndex = 0;

    while (num > 0) {
      const chunk = num % 1000;
      if (chunk !== 0) {
        words = `${chunkToWords(chunk, units)} ${
          bigUnits[unitIndex]
        } ${words}`.trim();
      }
      num = Math.floor(num / 1000);
      unitIndex++;
    }

    return words.trim() + " Đồng";
  };

  const chunkToWords = (chunk, units) => {
    const tens = [
      "",
      "Mười",
      "Hai Mươi",
      "Ba Mươi",
      "Bốn Mươi",
      "Năm Mươi",
      "Sáu Mươi",
      "Bảy Mươi",
      "Tám Mươi",
      "Chín Mươi",
    ];

    let result = "";
    const hundreds = Math.floor(chunk / 100);
    const remaining = chunk % 100;
    const tensDigit = Math.floor(remaining / 10);
    const unitsDigit = remaining % 10;

    if (hundreds > 0) result += `${units[hundreds]} Trăm `;
    if (remaining > 0) {
      if (tensDigit > 0) result += `${tens[tensDigit]} `;
      if (unitsDigit > 0) result += `${units[unitsDigit]}`;
    }

    return result.trim();
  };

  return (
    <div className="flex flex-col mb-2">
<h2 className="text-xl lg:text-2xl font-semibold w-[452.68px] h-[40px] text-left">
        CHỌN PHƯƠNG THỨC THANH TOÁN
      </h2>
      <div className="flex justify-between mt-2">
        <div className="flex-1 text-left">Tổng giá trị thanh toán:</div>
        <div className="flex-1 text-left ml-1 text-red-500">
          <b>{formatCurrencyVND(displayAmount)}</b>
          <br />
          <strong className="text-gray-500 text-sm mt-1">
            {convertNumberToWords(displayAmount)}
          </strong>
        </div>
      </div>
    </div>
  );
};

export default PaymentComponent;