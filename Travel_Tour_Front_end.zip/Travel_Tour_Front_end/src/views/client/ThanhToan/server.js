const express = require("express");
const crypto = require("crypto");
const bodyParser = require("body-parser");

const app = express();
app.use(bodyParser.json());

const MERCHANT_ID = "Z3USXN5J";
const SECRET_KEY = "0KEFC6UYKU33SAJH2KOJFU63DHSSHVJR";
const VNP_URL = "https://sandbox.vnpayment.vn/paymentv2/vpcpay.html";

app.post("/create-payment-url", (req, res) => {
  const { orderId, amount } = req.body;

  // Kiểm tra đầu vào
  if (!orderId || !amount) {
    return res.status(400).json({ error: "Missing orderId or amount" });
  }

  const date = new Date();
  const vnp_Params = {
    vnp_Version: "2.1.0",
    vnp_Command: "pay",
    vnp_TmnCode: MERCHANT_ID,
    vnp_Amount: amount * 100,
    vnp_CurrCode: "VND",
    vnp_TxnRef: orderId,
    vnp_OrderInfo: `Thanh toán đơn hàng ${orderId}`,
    vnp_OrderType: "other",
    vnp_Locale: "vn",
    vnp_RequestId: orderId,
    vnp_ReturnUrl: "http://localhost:3000/return-url",
    vnp_CreateDate: date.toISOString().slice(0, 19).replace("T", " "),
  };

  const querystring = require("qs");
  const signData = Object.keys(vnp_Params)
    .sort()
    .map((key) => `${key}=${encodeURIComponent(vnp_Params[key])}`)
    .join("&");

  const hmac = crypto.createHmac("sha512", SECRET_KEY);
  const signature = hmac.update(signData).digest("hex");
  vnp_Params.vnp_SecureHash = signature;

  const paymentUrl = `${VNP_URL}?${querystring.stringify(vnp_Params)}`;
  res.json({ url: paymentUrl });
});

// Xử lý callback từ VNPay
app.get("/return-url", (req, res) => {
  // Xử lý thông tin trả về từ VNPay và xác thực giao dịch
  console.log(req.query);
  res.send("Kết quả thanh toán");
});

const PORT = 3000;
app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});
