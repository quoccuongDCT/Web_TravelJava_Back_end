// import React, { useState, useEffect } from "react";
// import ThongTin from "./ThongTin";
// import CheckOutPageMain from "./main";
// import { useParams } from "react-router-dom";

// const ThanhToan = () => {
//   const [activeTab, setActiveTab] = useState("thongTin");
//   const [customerInfo] = useState({
//     hoTen: "",
//     email: "",
//     sdt: "",
//     diaChi: "",
//   });

//   const [passengerInfo] = useState([]);
//   const [summary] = useState(null);
//   const [isInfoCompleted] = useState(false);
//   const { id } = useParams();
//   const [dataintroduce, setDataintroduce] = useState([]);
//   useEffect(() => {
//     console.log("Received Tour ID:", id);
//   }, [id, activeTab]);
//   const handleTabChange = (tab) => {
//     setDataintroduce(JSON.parse(sessionStorage.getItem("dataintroduce")));
//     console.log("get " + tab);
//     setActiveTab(tab);
//   };

//   const handleContinue = (datainfo) => {
//     sessionStorage.setItem("dataintroduce", JSON.stringify(datainfo));
//     // setPassengerInfo(passengers);
//     // setSummary(summary);
//     // setIsInfoCompleted(true);
//     setActiveTab("checkout");
//   };

//   return (
//     <div className="flex flex-col items-center mt-[120px]">
//       <div className="flex mb-4 relative mt-5">
//         {/* Tab "Thông tin" */}
//         <button
//           className={`relative flex items-center justify-center w-52 h-12 transition duration-300 ease-in-out rounded-l-lg border-2 ${
//             activeTab === "thongTin"
//               ? "bg-[#01c675] text-white border-[#ffffff] shadow-lg"
//               : "bg-gray-200 text-gray-800 border-gray-300"
//           }`}
//           onClick={() => handleTabChange("thongTin")}
//         >
//           <span
//             className={`text-[#4a4a4a] rounded-full w-8 h-8 flex items-center justify-center mr-2 text-lg border-2 ${
//               activeTab === "thongTin"
//                 ? "border-[#ffffff] bg-[#01c675] text-white"
//                 : "border-[#4a4a4a] bg-gray-200"
//             }`}
//           >
//             1
//           </span>
//           Thông tin
//         </button>

//         {/* Tab "Thanh toán" */}
//         <button
//           className={`relative flex items-center justify-center w-52 h-12 transition duration-300 ease-in-out rounded-r-lg border-2 ${
//             activeTab === "checkout"
//               ? "bg-[#01c675] text-white border-[#ffffff] shadow-lg"
//               : "bg-gray-200 text-gray-800 border-gray-300"
//           } cursor-pointer`}
//           onClick={() => isInfoCompleted && handleTabChange("checkout")}
//           disabled={!isInfoCompleted}
//         >
//           <span
//             className={`text-[#4a4a4a] rounded-full w-8 h-8 flex items-center justify-center mr-2 text-lg border-2 ${
//               activeTab === "checkout"
//                 ? "border-[#ffffff] bg-[#01c675] text-white"
//                 : "border-[#4a4a4a] bg-gray-200"
//             }`}
//           >
//             2
//           </span>
//           Thanh toán
//         </button>
//       </div>

//       {activeTab === "thongTin" ? (
//         <ThongTin onContinue={handleContinue} data={dataintroduce} />
//       ) : (
//         <CheckOutPageMain
//           customerInfo={customerInfo}
//           passengerInfo={passengerInfo}
//           summary={summary}
//         />
//       )}
//     </div>
//   );
// };

// export default ThanhToan;
import React, { useState, useEffect } from "react";
import ThongTin from "./ThongTin";
import CheckOutPageMain from "./main";
import { useParams } from "react-router-dom";

const ThanhToan = () => {
  const [activeTab, setActiveTab] = useState("thongTin");
  const [customerInfo, setCustomerInfo] = useState({
    hoTen: "",
    email: "",
    sdt: "",
    diaChi: "",
  });
  const [isInfoCompleted, setIsInfoCompleted] = useState(false); // Cập nhật trạng thái
  const { id } = useParams();
  const [dataintroduce, setDataintroduce] = useState([]);

  useEffect(() => {
    console.log("Received Tour ID:", id);
  }, [id, activeTab]);

  const handleTabChange = (tab) => {
    setDataintroduce(JSON.parse(sessionStorage.getItem("dataintroduce")));
    console.log("get " + tab);
    setActiveTab(tab);
  };

  const handleContinue = (datainfo) => {
    sessionStorage.setItem("dataintroduce", JSON.stringify(datainfo));
    setCustomerInfo(datainfo); // Lưu thông tin khách hàng
    setIsInfoCompleted(true); // Cập nhật trạng thái khi thông tin đã hoàn thành
    setActiveTab("checkout");
  };

  // Hàm để kiểm tra nếu thông tin đã hoàn thành
  const checkInfoCompletion = () => {
    return (
      customerInfo.hoTen !== "" &&
      customerInfo.email !== "" &&
      customerInfo.sdt !== "" &&
      customerInfo.diaChi !== ""
    );
  };

  useEffect(() => {
    // Kiểm tra khi nào thông tin đã hoàn thành và cập nhật trạng thái
    setIsInfoCompleted(checkInfoCompletion());
  }, [customerInfo]);

  return (
    <div className="flex flex-col items-center mt-[120px]">
      <div className="flex mb-4 relative mt-5">
        {/* Tab "Thông tin" */}
        <button
          className={`relative flex items-center justify-center w-52 h-12 transition duration-300 ease-in-out rounded-l-lg border-2 ${
            activeTab === "thongTin"
              ? "bg-[#01c675] text-white border-[#ffffff] shadow-lg"
              : "bg-gray-200 text-gray-800 border-gray-300"
          }`}
          onClick={() => handleTabChange("thongTin")}
        >
          <span
            className={`text-[#4a4a4a] rounded-full w-8 h-8 flex items-center justify-center mr-2 text-lg border-2 ${
              activeTab === "thongTin"
                ? "border-[#ffffff] bg-[#01c675] text-white"
                : "border-[#4a4a4a] bg-gray-200"
            }`}
          >
            1
          </span>
          Thông tin
        </button>

        {/* Tab "Thanh toán" */}
        <button
          className={`relative flex items-center justify-center w-52 h-12 transition duration-300 ease-in-out rounded-r-lg border-2 ${
            activeTab === "checkout"
              ? "bg-[#01c675] text-white border-[#ffffff] shadow-lg"
              : "bg-gray-200 text-gray-800 border-gray-300"
          } cursor-pointer`}
          onClick={() => isInfoCompleted && handleTabChange("checkout")}
          disabled={!isInfoCompleted}
        >
          <span
            className={`text-[#4a4a4a] rounded-full w-8 h-8 flex items-center justify-center mr-2 text-lg border-2 ${
              activeTab === "checkout"
                ? "border-[#ffffff] bg-[#01c675] text-white"
                : "border-[#4a4a4a] bg-gray-200"
            }`}
          >
            2
          </span>
          Thanh toán
        </button>
      </div>

      {activeTab === "thongTin" ? (
        <ThongTin onContinue={handleContinue} data={dataintroduce} />
      ) : (
        <CheckOutPageMain
          customerInfo={customerInfo}
          passengerInfo={[]}
          summary={null}
        />
      )}
    </div>
  );
};

export default ThanhToan;
