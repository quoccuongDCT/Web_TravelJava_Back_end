import React, { useState, useEffect, useRef } from "react";
import { format } from "date-fns";
// import { Link } from "react-router-dom"; // Import useNavigate
import { message } from "antd";
import { useParams, useNavigate } from "react-router-dom";
import axios from "axios";
import CryptoJS from "crypto-js";
import "./main.css";
import DiscountComponent from "./MagiamGia";
import PaymentComponent from "./fromgiamgiaThanhtoan";

const vnp_TmnCode = "AKDMV6LF";
const vnp_HashSecret = "8GH8AXE9F1SJEXPSGRCBZYGP2B7IFQ9I";
const vnp_Url = "https://sandbox.vnpayment.vn/paymentv2/vpcpay.html";
const idNguoiDung = localStorage.getItem("id");
 const role = localStorage.getItem("role");
console.log("idNguoiDung", idNguoiDung);

const createPaymentUrl = async (totalTien, idChiTietGioHangList) => {
  // Ensure it's a single ID, not a list

  const discountResult = localStorage.getItem("discountResult");
  const finalAmount = discountResult ? parseFloat(discountResult) : totalTien;

  const vnp_ReturnUrl = `http://localhost:8080/api/hoadon/api/vnpay/callback/${idChiTietGioHangList}/${idNguoiDung}`; // Pass the id in the URL
  const params = {
    vnp_Version: "2.1.0",
    vnp_Command: "pay",
    vnp_TmnCode,
    vnp_Locale: "vn",
    vnp_CurrCode: "VND",
    vnp_TxnRef: generateTransactionRef(),
    vnp_OrderInfo: idChiTietGioHangList, // A single ID, not a list
    vnp_OrderType: "other",
    vnp_Amount: finalAmount * 100, // Multiply by 100 to get the amount in VND
    vnp_ReturnUrl,
    vnp_IpAddr: "127.0.0.1",
    vnp_CreateDate: new Date()
      .toISOString()
      .replace(/[^0-9]/g, "")
      .slice(0, 14),
  };

  const sortedParams = sortObject(params);

  const querystring = new URLSearchParams(sortedParams).toString();
  const secureHash = CryptoJS.HmacSHA512(querystring, vnp_HashSecret)
    .toString(CryptoJS.enc.Hex)
    .toUpperCase();

  const paymentUrl = `${vnp_Url}?${querystring}&vnp_SecureHashType=HmacSHA512&vnp_SecureHash=${secureHash}`;
  localStorage.removeItem("discountResult");
  // message.success("Thanh toán thành công");
  window.location.href = paymentUrl; // Redirect to VNPay for payment
};

const generateTransactionRef = () => {
  const date = new Date();
  const year = date.getFullYear().toString();
  const month = (date.getMonth() + 1).toString().padStart(2, "0");
  const day = date.getDate().toString().padStart(2, "0");
  const hour = date.getHours().toString().padStart(2, "0");
  const minute = date.getMinutes().toString().padStart(2, "0");
  const second = date.getSeconds().toString().padStart(2, "0");
  const randomStr = Math.random().toString(36).substring(2, 8).toUpperCase();
  return `${year}${month}${day}${hour}${minute}${second}${randomStr}`;
};

const sortObject = (obj) => {
  const sorted = {};
  Object.keys(obj)
    .sort()
    .forEach((key) => {
      sorted[key] = obj[key];
    });
  return sorted;
};

const CheckOutPagePageMain = ({
  className = "",
  customerInfo,
  passengerInfo,
  summary,
}) => {
  const [PhuongThucThanhToan, setPhuongThucThanhToan] = useState(
    ""
  ); // Đặt giá trị mặc định

  // var danhSach;

  const navigate = useNavigate();
  const danhSachRef = useRef([]); // Sử dụng useRef để lưu trữ danhSach
  const [chiTietGioHang, setChiTietGioHang] = useState(null);
  const [userID] = useState(localStorage.getItem("id"));
  const [gioHangDanhSachNguoiDiCung, setGioHangDanhSachNguoiDiCung] =
    useState(null);
  const { id } = useParams();

  useEffect(() => {
    const fetchTourData = async () => {
      try {
        // Gọi API để lấy chiTietGioHang
        const response = await axios.get(
          `http://localhost:8080/api/chitietgiohang/bychitietgiohang/${id}/${userID}`
        );

        setChiTietGioHang(response.data);
        danhSachRef.current = response.data; // Gán dữ liệu vào danhSachRef.current
        console.log("danh sách", danhSachRef.current);

        // Gọi API thứ hai nếu có dữ liệu trong danhSachRef
        if (danhSachRef.current.length > 0) {
          const response2 = await axios.get(
            `http://localhost:8080/api/giohangdanhsachnguoidicung/bygiohangdanhsachnguoidicung/${danhSachRef.current[0].id}`
          );

          setGioHangDanhSachNguoiDiCung(response2.data);
          console.log("ngu", response2.data);
        }
      } catch (error) {
        console.error("Lỗi khi lấy dữ liệu tour", error);
        message.error("Không thể tải dữ liệu tour.");
      }
    };

    fetchTourData();
  }, [id]); // Đảm bảo rằng id là dependency duy nhất

  // thanh toán tiền mặt

  const mapMoTaFields = (chiTietGioHang) => {
    return (
      chiTietGioHang?.map((item) => ({
        idChiTietGioHang: item.id,
        idBienTheTour: item.bienTheTour.id,
        tenTour: item.bienTheTour.tour.tenTour,
        ngayBatDau: item.bienTheTour.ngayBatDau,
        hotels: item.bienTheTour.hotels.danhGiaKhachSan,
        giaNguoiLon: item.bienTheTour.giaNguoiLon,
        giaTreEm: item.bienTheTour.giaTreEm,
        bienTheTour_moTa: item.bienTheTour.moTa,
        giamGia_moTa: item?.bienTheTour?.giamGia?.moTa,
        tour_moTa: item.bienTheTour.tour.moTa,
        giamGia_tour_moTa: item?.bienTheTour?.giamGia?.tour?.moTa,
      })) || []
    );
  };

  const moTaFields1 = mapMoTaFields(chiTietGioHang);
  // Lấy idChiTietGioHang của tất cả các mục
  const idChiTietGioHangList = moTaFields1.map((item) => item.idChiTietGioHang);
  const createPaymentUrlPayOS = (totalTien, idChiTietGioHangList) => {
    const discountResult = localStorage.getItem("discountResult");
    const finalAmount = discountResult ? parseFloat(discountResult) : totalTien; // Nếu có discountResult, dùng giá trị đã giảm giá, ngược lại dùng giá trị gốc

    axios
      .post(
        `http://localhost:8080/api/v1/user/create-payment-link/${idChiTietGioHangList}`,
        {
          idNguoiDung: localStorage.getItem("id"),
          idBienTheTour: id,
          tongTien: finalAmount,
          phuongThucThanhToan: PhuongThucThanhToan === "Online",
          trangThai: true,
        },
        {
          params: { someQueryParam: "value" }, // Thêm tham số query nếu cần
          headers: { "Content-Type": "application/json" },
        }
      )
      .then((response) => {
        const checkoutUrl = response.data.checkoutUrl;
        window.location.href = checkoutUrl;
      })
      .catch((error) => {
        console.error("Lỗi tạo liên kết thanh toán:", error);
      });
    localStorage.removeItem("discountResult");
  };

  const handleSubmitPayment = async (totalTien, idChiTietGioHangList) => {
    // Kiểm tra các biến trạng thái trước khi gửi
    if (!id) {
      message.error("ID Biến Thể Tour không hợp lệ!");
      return;
    }
    // const totalAmount = totalTien; // Calculate total amount based on your logic
    // Lấy tổng tiền đã giảm giá từ localStorage nếu có, nếu không thì lấy totalTien gốc
    const discountResult = localStorage.getItem("discountResult");
    const finalAmount = discountResult ? parseFloat(discountResult) : totalTien; // Nếu có discountResult, dùng giá trị đã giảm giá, ngược lại dùng giá trị gốc
    // Call the API to add the invoice (HoaDon)
    try {
      // const response = await axios.post(
      //   "http://localhost:8080/api/hoadon/them2/" + idChiTietGioHangList,
      //   {
      //     idChiTietGioHangList: idChiTietGioHangList, // Truyền idChiTietGioHangList vào API
      //     idBienTheTour: id,
      //     tongTien: totalAmount,
      //     phuongThucThanhToan: PhuongThucThanhToan === "Online" ? true : false,
      //     trangThai: true, // Assuming the invoice is paid for this case
      //   }
      const response = await axios.post(
        `http://localhost:8080/api/hoadon/them2/${idChiTietGioHangList}?idNguoiDung=${userID}`,
        {
          idChiTietGioHangList: idChiTietGioHangList, // Truyền idChiTietGioHangList vào API
          idBienTheTour: id,
          tongTien: finalAmount,
          phuongThucThanhToan: PhuongThucThanhToan === "Online" ? true : false,
          trangThai: true, // Assuming the invoice is paid for this case
        }
      );

      message.success("Thanh toán thành công");

      // if (PhuongThucThanhToan !== "Online") {
      //   localStorage.removeItem("discountResult");
      // }
      localStorage.removeItem("discountResult");
      console.log(response.data);

      // Redirect to the homepage after success
      navigate("/"); // This will redirect to http://localhost:3000 (homepage)
    } catch (error) {
      console.error("Error adding invoice", error);
      message.error("Error adding invoice");
    }
  };
  const idBienTheTour = chiTietGioHang?.[0]?.bienTheTour?.id;

  // const moTaFields = chiTietGioHang ? mapMoTaFields(danhSach) : [];
  const mapDanhSachFields = (gioHangDanhSachNguoiDiCung) => {
    return (
      gioHangDanhSachNguoiDiCung?.map((item) => {
        // Convert namSinh to a Date object
        
        const birthDate = new Date(item.namSinh);
        const currentYear = new Date().getFullYear();
        const birthYear = birthDate.getFullYear();
        const age = currentYear - birthYear;

        return {
          soNguoiLon: age > 14 ? 1 : 0, // Adult if age > 14
          soTreEm: age <= 14 ? 1 : 0, // Child if age <= 14
          namSinh: item.namSinh,
        };
      }) || []
    );
  };

  const calculateTotals = (DanhSachFields) => {
    let totalNguoiLon = 0;
    let totalTreEm = 0;

    // Lặp qua DanhSachFields để tính tổng số người lớn và trẻ em
    DanhSachFields.forEach((item) => {
      if (item.soNguoiLon) {
        totalNguoiLon += 1; // Đếm nếu có id người lớn
      }
      if (item.soTreEm) {
        totalTreEm += 1; // Đếm nếu có id trẻ em
      }
    });

    return { totalNguoiLon, totalTreEm };
  };
  // Tính tổng số người lớn và trẻ em

  const DanhSachFields = gioHangDanhSachNguoiDiCung
    ? mapDanhSachFields(gioHangDanhSachNguoiDiCung)
    : [];
  const { totalNguoiLon, totalTreEm } = calculateTotals(DanhSachFields);

  const formatDate = (date) => {
    return format(new Date(date), "dd/MM/yyyy"); // Change the format as needed
  };
  const renderStars = (stars) => {
    const maxStars = 5; // Assuming a maximum rating of 5 stars
    return Array.from({ length: maxStars }, (_, index) => (
      <span
        key={index}
        style={{ color: index < stars ? "#FFD700" : "#d3d3d3" }}
      >
        ★
      </span>
    ));
  };
  const formatCurrencyVND = (amount) => {
    return new Intl.NumberFormat("vi-VN", {
      style: "currency",
      currency: "VND",
      currencyDisplay: "code",
    }).format(amount);
  };
  const renderSidebar = () => {
    return (
      <div>
        {moTaFields1.map((item, index) => {
          // Assuming totalNguoiLon and totalTreEm are available, if not, ensure to define them properly
          // const updateTotalNguoiLon = totalNguoiLon + 1;
          // const totalTienNguoiLon = (totalNguoiLon + 1) * item.giaNguoiLon;

          // const totalTienTreEm = totalTreEm * item.giaTreEm;
          // // const additionalNguoiLonPrice = item.giaNguoiLon;
          // const totalTien = totalTienNguoiLon + totalTienTreEm;
          const totalTienNguoiLon = totalNguoiLon * item.giaNguoiLon;
          const totalTienTreEm = totalTreEm * item.giaTreEm;
          const totalTien = totalTienNguoiLon + totalTienTreEm;
          return (
            <div
              key={index}
              className="w-[550px] h-auto flex flex-col border border-light-border p-0 px-4 py-6 xl:p-8 box-border"
            >
              <div className="flex flex-col mb-2 mt-2">
                <h5 className="text-left font-semibold">Thông Tin Tour</h5>
              </div>
              <div className="flex justify-between mb-2">
                <div className="w-[40%] text-left">Tour du lịch:</div>
                <div className="w-[60%] text-left ml-1">{item.tenTour}</div>
              </div>
              <div className="flex justify-between mb-2">
                <div className="w-[40%] text-left">Ngày khởi hành:</div>
                <div className="w-[60%] text-left ml-1">
                  {formatDate(item.ngayBatDau)}
                </div>
              </div>
              <div className="flex justify-between mb-2">
                <div className="w-[40%] text-left">Khách sạn:</div>
                <div className="w-[60%] text-left ml-1">
                  {renderStars(item.hotels)}
                </div>
              </div>
              <div className="flex justify-between mb-2">
                <div className="w-[40%] text-left">Giá vé 01 khách:</div>
                <div className="w-[60%] text-left ml-1">
                  {formatCurrencyVND(item.giaNguoiLon)}/ vé người lớn
                </div>
              </div>
              {/* <div className="flex justify-between mb-2">
                <div className="w-[40%] text-left">Quà tặng:</div>
                <div className="w-[60%] text-left ml-1">
                  <b className="text-red-500">
                    Khuyến mại áp dụng cho 10 khách đăng ký đầu tiên
                  </b>
                </div>
              </div> */}

              {/* Additional info */}
              {/* <div className="w-[516.8px] h-auto flex flex-col border border-light-border p-0 px-4 py-6 xl:p-8 box-border mt-4"> */}
              <div className="flex flex-col mb-2 mt-2">
                <h5 className="text-left font-semibold">
                  Thông Tin Khách Hàng
                </h5>
              </div>
              <div className="flex justify-between mb-2">
                <div className="w-[35%] text-left"></div>
                <div className="w-[25%] text-left text-center">Số lượng</div>
                <div className="w-[25%] text-left">Thành tiền</div>
                <div className="w-[25%] text-left">Tổng</div>
              </div>

              {/* Assuming totalNguoiLon, totalTreEm are properly calculated */}
              <div className="flex justify-between mb-2">
                <div className="w-[35%] text-left">Người lớn:</div>
                <div className="w-[25%] text-left text-center">
                  <p>{totalNguoiLon}</p>
                </div>
                <div className="w-[25%] text-left">
                  {formatCurrencyVND(item.giaNguoiLon)}
                </div>
                <div className="w-[25%] text-left">
                  {formatCurrencyVND(totalTienNguoiLon)}
                </div>
              </div>
              <div className="flex justify-between mb-2">
                <div className="w-[35%] text-left">Trẻ em:</div>
                <div className="w-[25%] text-left text-center">
                  <p>{totalTreEm}</p>
                </div>
                <div className="w-[25%] text-left">
                  {formatCurrencyVND(item.giaTreEm)}
                </div>
                <div className="w-[25%] text-left">
                  {formatCurrencyVND(totalTienTreEm)}
                </div>
              </div>

              {/* Display totalTien for this item */}
              <div className="flex justify-between mb-2">
                <div className="w-[75%] text-left">Tổng tiền:</div>
                <div className="w-[25%] text-left ml-1">
                  <b className="text-red-500">{formatCurrencyVND(totalTien)}</b>
                </div>
              </div>
              {/* </div> */}
            </div>
          );
        })}
      </div>
    );
  };
  const convertNumberToWords = (num) => {
    const units = [
      "",
      "Một",
      "Hai",
      "Ba",
      "Bốn",
      "Năm",
      "Sáu",
      "Bảy",
      "Tám",
      "Chín",
    ];
    const bigUnits = ["", "Nghìn", "Triệu", "Tỷ"];

    if (num === 0) return "Không Đồng";

    let words = "";
    let unitIndex = 0;

    while (num > 0) {
      const chunk = num % 1000;
      if (chunk !== 0) {
        words = `${chunkToWords(chunk, units)} ${
          bigUnits[unitIndex]
        } ${words}`.trim();
      }
      num = Math.floor(num / 1000);
      unitIndex++;
    }

    return words.trim() + " Đồng";
  };

  // Hàm phụ chuyển đổi từng phần nghìn thành chữ
  const chunkToWords = (chunk, units) => {
    const tens = [
      "",
      "Mười",
      "Hai Mươi",
      "Ba Mươi",
      "Bốn Mươi",
      "Năm Mươi",
      "Sáu Mươi",
      "Bảy Mươi",
      "Tám Mươi",
      "Chín Mươi",
    ];

    let result = "";
    const hundreds = Math.floor(chunk / 100);
    const remaining = chunk % 100;
    const tensDigit = Math.floor(remaining / 10);
    const unitsDigit = remaining % 10;

    if (hundreds > 0) result += `${units[hundreds]} Trăm `;
    if (remaining > 0) {
      if (tensDigit > 0) result += `${tens[tensDigit]} `;
      if (unitsDigit > 0) result += `${units[unitsDigit]}`;
    }

    return result.trim();
  };
  const renderMain = () => {
    return (
      <div>
        {moTaFields1.map((item, index) => {
          // const totalTienNguoiLon = totalNguoiLon * item.giaNguoiLon;
          // const totalTienTreEm = totalTreEm * item.giaTreEm;
          // const updateNguoiLon = item.giaNguoiLon;
          // const totalTien = totalTienNguoiLon + totalTienTreEm + updateNguoiLon;
          const totalTienNguoiLon = totalNguoiLon * item.giaNguoiLon;
          const totalTienTreEm = totalTreEm * item.giaTreEm;
          // const updateNguoiLon = item.giaNguoiLon;
          const totalTien = totalTienNguoiLon + totalTienTreEm;

          return (
            <div
              key={index}
              className="w-[551.76px] flex flex-col sm:border border-light-border space-y-8 p-6"
            >
              <div>
             <PaymentComponent 
                 totalTien={totalTien} 
                />'
                <DiscountComponent
                  bienTheTourId={idBienTheTour}
                  totalTien={totalTien}
                />

              </div>

              <div className="border-b border border-light-border"></div>

              <div className="mt-[-20px]">
  <div
    className="text-left"
    style={{
      display: "flex",
      flexDirection: "column",
      gap: "5px",
    }}
  >
    {(() => {
      const role = localStorage.getItem("role") || "khachhang"; // Lấy role từ localStorage (mặc định là khachhang)
      const paymentMethods =
        role === "nhanvien"
          ? [
              "Thanh toán tiền mặt",
              "Thanh toán VN Pay",
              "Thanh toán PayOS",
            ]
          : ["Thanh toán VN Pay", "Thanh toán PayOS"]; // Khách hàng không có "Thanh toán tiền mặt"
        // Nếu role là khách hàng và PhuongThucThanhToan chưa được chọn, chọn VN Pay mặc định
        if (role === "khachhang" && !PhuongThucThanhToan) {
          setPhuongThucThanhToan("Thanh toán VN Pay");
        }
        if (role === "nhanvien" && !PhuongThucThanhToan) {
          setPhuongThucThanhToan("Thanh toán tiền mặt");
        }

      return paymentMethods.map((method, idx) => {
        const id = method.toLowerCase().replace(" ", "_");
        return (
          <div
            key={idx}
            style={{
              display: "flex",
              alignItems: "center",
              fontSize: "18px",
              color: "#01c675",
            }}
          >
            <input
              type="radio"
              id={id}
              value={method}
              checked={PhuongThucThanhToan === method}
              onChange={() => setPhuongThucThanhToan(method)}
              name="payment"
              style={{
                marginRight: "15px",
                width: "20px",
                height: "20px",
              }}
            />
            <label htmlFor={id} style={{ cursor: "pointer" }}>
              {method === "Thanh toán tiền mặt"
                ? "Thanh toán tiền mặt"
                : `Thanh toán qua ${method}`}
            </label>
          </div>
        );
      });
    })()}

    {/* Show cash payment method details */}
    {PhuongThucThanhToan === "Thanh toán tiền mặt" && role === "nhanvien" &&(
      <div className="mt-4 text-center">
        {/* <p>
          <strong>Thanh toán bằng tiền mặt</strong>
        </p> */}
        <button
          onClick={() =>
            handleSubmitPayment(totalTien, idChiTietGioHangList)
          }
          style={{
            backgroundColor: "#27822A",
            color: "#FFFFFF",
            borderRadius: "4px",
            padding: "12px 24px",
            fontSize: "1rem",
            fontWeight: "bold",
          }}
        >
          Xác nhận thanh toán
        </button>
      </div>
    )}
    {PhuongThucThanhToan === "Thanh toán VN Pay" && (
      <div className="mt-4 text-center">
        <button
          onClick={() =>
            createPaymentUrl(totalTien, idChiTietGioHangList)
          }
          style={{
            backgroundColor: "#27822A",
            color: "#FFFFFF",
            borderRadius: "4px",
            padding: "12px 24px",
            fontSize: "1rem",
            fontWeight: "bold",
          }}
        >
          Xác nhận thanh toán qua VNPAY
        </button>
      </div>
    )}
    {/* Show VN Pay or online payment details */}
    {PhuongThucThanhToan === "Thanh toán PayOS" && (
      <div className="mt-4 text-center">
        <button
          onClick={() =>
            createPaymentUrlPayOS(totalTien, idChiTietGioHangList)
          }
          style={{
            backgroundColor: "#27822A",
            color: "#FFFFFF",
            borderRadius: "4px",
            padding: "12px 24px",
            fontSize: "1rem",
            fontWeight: "bold",
          }}
        >
          Xác nhận thanh toán qua PayOS
        </button>
      </div>
    )}
  </div>
</div>

            </div>
          );
        })}
      </div>
    );
  };
  return (
    <div className={`nc-CheckOutPagePageMain ${className}`}>
      <main className="container mt-11 mb-24 lg:mb-32 flex flex-col-reverse lg:flex-row">
        <div className="w-full lg:w-3/5 xl:w-2/3 lg:pr-10">{renderMain()}</div>
        <div className="hidden lg:block flex-grow">{renderSidebar()}</div>
      </main>
    </div>
  );
};

export default CheckOutPagePageMain;
