import React, { useState, useEffect } from "react";
// import { message, ToastContainer } from "react-messageify";
// import "react-messageify/dist/ReactToastify.css";
import { Button, message, Modal } from "antd";
import axios from "axios";
import { useParams, useLocation } from "react-router-dom";
import { format } from "date-fns";
import {
  AntDesignOutlined,
  DeleteOutlined,
  HighlightTwoTone,
} from "@ant-design/icons";
import * as XLSX from "xlsx";
import { ExclamationCircleOutlined } from '@ant-design/icons'; // Import biểu tượng

const ThongTin = ({ className = "", onContinue }) => {
  const location = useLocation();
  const selectedTour = location?.state;
  const [userID] = useState(localStorage.getItem("id"));
  const hasCompanionInfo =
  selectedTour?.companionInfo && selectedTour?.companionInfo?.length > 0;
  const [PeopleList, setPeopleList] = useState({});
  console.log("data i: ", selectedTour);
  const [chiTietGioHang, setChiTietGioHang] = useState(null);
  const { id } = useParams();
  console.log("id: ", id);
 const [companionInfo, setCompanionInfo] = useState({
    hoTen: '',
    email: '',
    soDienThoai: '',
    namSinh: ''
  });
  console.log("companionInfo",companionInfo)
  const [rows, setRows] = useState([
    { hoTen: "", email: "", soDienThoai: "", namSinh: "", type: "Người lớn" },
  ]);
  const [isModalVisible, setIsModalVisible] = useState(false);  // Quản lý trạng thái hiển thị Modal

  // Hàm để mở modal
  const showModal = () => {
    setIsModalVisible(true);
  };

  // Hàm để đóng modal
  const handleCancel = () => {
    setIsModalVisible(false);
  };

  // const handleRemoveRow = () => {
  //   if (rows.length > 1) {
  //     setRows(rows.slice(0, -1));
  //   }
  // }
  const handleRemoveRow = () => {
    if (rows.length > 1) {
      const lastRow = rows[rows.length - 1];
      if (!lastRow.isSaved) {
        setRows(rows.slice(0, -1));
      } else {
        console.log("Không thể xóa dòng được đặt sẵn từ SQL!");
      }
    }
  };
 
 
 // Hàm tính tuổi từ ngày sinh
 const calculateAge = (birthDate) => {
  const today = new Date();
  let age = today.getFullYear() - birthDate.getFullYear();
  const monthDifference = today.getMonth() - birthDate.getMonth();

  // Nếu chưa đến sinh nhật trong năm nay, giảm tuổi xuống 1
  if (monthDifference < 0 || (monthDifference === 0 && today.getDate() < birthDate.getDate())) {
    age--;
  }
  return age;
};
 
  

  const handleInputChange = (index, field, value) => {
    const updatedRows = [...rows];
    updatedRows[index] = { ...updatedRows[index], [field]: value };

    // Nếu trường 'namSinh' được thay đổi, tính tuổi và tự động cập nhật 'type' (Loại khách)
    if (field === "namSinh") {
      const birthYear = new Date(value).getFullYear();
      const currentYear = new Date().getFullYear();
      const age = currentYear - birthYear;

      // Cập nhật 'type' dựa trên tuổi
      updatedRows[index].type = age < 14 ? "Trẻ em" : "Người lớn";
    }

    setRows(updatedRows); // Cập nhật lại state với các dòng đã thay đổi
  };
  // -----------------------------------------------
  useEffect(() => {
    if (selectedTour && selectedTour.companionInfo) {
      // Lấy dữ liệu companionInfo
      const companionInfo = selectedTour.companionInfo.map((item) => {
        const birthYear = new Date(item.namSinh).getFullYear();
        const currentYear = new Date().getFullYear();
        const age = currentYear - birthYear;

        // Tính type dựa trên tuổi
        const type = age < 14 ? "Trẻ em" : "Người lớn";

        
        // Trả về đối tượng với trường 'type' được tính
        return {
          ...item,
          type: type,
          isSaved: true, 
        };
      });

      // Cập nhật state rows với dữ liệu đã tính toán
      setRows(companionInfo);
    }
  }, [selectedTour]); // Cập nhật khi selectedTour thay đổi
  useEffect(() => {
  const hoTenFromLocalStorage = localStorage.getItem('hoTen');
  const emailFromLocalStorage = localStorage.getItem('email');
  const sdtFromLocalStorage = localStorage.getItem('soDienThoai');
  const namSinhFromLocalStorage = localStorage.getItem('namSinh');

  // Nếu có giá trị 'hoTen' trong localStorage, cập nhật row đầu tiên
  if (hoTenFromLocalStorage) {
    setRows((prevRows) => {
      const updatedRows = prevRows.map((row, index) => {
        if (index === 0) {
          // Cập nhật dòng đầu tiên với dữ liệu từ localStorage
          return {
            ...row,
            hoTen: hoTenFromLocalStorage,
            email: emailFromLocalStorage,
            soDienThoai: sdtFromLocalStorage,
            namSinh: namSinhFromLocalStorage,
            isSaved: false,  // Đánh dấu dòng đầu tiên là đã lưu
          };
        }
        return row;
      });
      return updatedRows;
    });
  }
}, []);

  


  
useEffect(() => {
  if (selectedTour && selectedTour.companionInfo) {
    // Lấy dữ liệu companionInfo
    const companionInfo = selectedTour.companionInfo.map((item) => {
      const birthYear = new Date(item.namSinh).getFullYear();
      const currentYear = new Date().getFullYear();
      const age = currentYear - birthYear;

      // Tính type dựa trên tuổi
      const type = age < 14 ? "Trẻ em" : "Người lớn";

      // Trả về đối tượng với trường 'type' được tính
      return {
        ...item,
        type: type,
        isSaved: true, // Đánh dấu là đã lưu
      };
    });

    // Cập nhật state rows với dữ liệu đã tính toán
    setRows(companionInfo);
  }
}, [selectedTour]); // Cập nhật khi selectedTour thay đổi

  // --------------------------------------------------
  // -----------------------------
  const handleUpdate = async () => {
    console.log("new update data: ", rows);
    try {
      const response = await axios.put(
        "http://localhost:8080/api/giohangdanhsachnguoidicung/cap-nhat", // Đảm bảo URL này đúng với API endpoint của bạn
        rows // Đây là danh sách người đi cùng đã chỉnh sửa
      );

      if (response.status === 200) {
        message.success("Cập nhật thành công!");
        console.log("Cập nhật thành công!", response.data);
        // Bạn có thể làm gì đó với response (cập nhật UI hoặc thông báo thành công)
      } else {
        message.error("Cập nhật thất bại!");
        console.error("Cập nhật thất bại!");
      }
    } catch (error) {
      message.error("Lỗi khi cập nhật!");
      console.error("Lỗi khi cập nhật:", error);
    }
  };
  // -------------------------------
  const handleDelete = async (id) => {
    try {
      if (rows.length <= 1) {
        message.error("Không thể xóa hàng khách cuối cùng!");
        return;
      }
      const response = await axios.delete(
        `http://localhost:8080/api/giohangdanhsachnguoidicung/delete2-giohangnguoidicung/${id}`
      );

      message.success(response.data);
      // Cập nhật lại rows sau khi xóa
      const updatedRows = rows.filter((row) => row.id !== id); // Loại bỏ phần tử đã xóa
      setRows(updatedRows); // Cập nhật lại state
    } catch (error) {
      if (error.response) {
        message.error(error.response.data);
      } else {
        message.error("Lỗi khi xóa giỏ hàng!");
      }
    }
  };
  // ----------------------------------

  const validateFields = () => {
    // Tính tổng số người lớn và trẻ em
  const adultCount = rows.filter((row) => row.type === "Người lớn").length;
  const childCount = rows.filter((row) => row.type === "Trẻ em").length;

  // Lấy số lượng còn của biến thể tour
  const availableQuantity = mappedFields[0]?.soLuongCon || 0; // Giả sử bạn lấy từ mảng đã map trước

  // Kiểm tra xem tổng số người lớn + trẻ em có vượt quá số lượng còn không
  const totalPeople = adultCount + childCount;
  console.log("totalPeople",totalPeople)
  console.log("availableQuantity",availableQuantity)
  if (totalPeople > availableQuantity) {
    message.error("Số lượng người tham gia không thể vượt quá số lượng còn của tour!");
    return false;
  }

  // Kiểm tra số lượng người lớn
  if (adultCount === 0) {
    message.error("Phải có ít nhất một người lớn đi kèm!");
    return false;
  }
    for (let index = 0; index < rows.length; index++) {
      const row = rows[index];

      // Validate Full Name
      if (!row.hoTen.trim()) {
        message.error(`Họ tên không được để trống (Dòng ${index + 1})`);
        return false;
      }

      // Validate Email
      if (!row.email.trim()) {
        message.error(`Email không được để trống (Dòng ${index + 1})`);
        return false;
      } else {
        const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
        if (!emailRegex.test(row.email)) {
          message.error(`Email không hợp lệ (Dòng ${index + 1})`);
          return false;
        }
      }

      // Validate Phone Number
      if (!row.soDienThoai.trim()) {
        message.error(`Số điện thoại không được để trống (Dòng ${index + 1})`);
        return false;
      } else {
        const phoneRegex = /^[0-9]{10}$/;
        if (!phoneRegex.test(row.soDienThoai)) {
          message.error(`Số điện thoại phải là 10 chữ số (Dòng ${index + 1})`);
          return false;
        }
      }

      // Validate Date of Birth (Year)
      if (!row.namSinh) {
        message.error(`Vui lòng chọn năm sinh (Dòng ${index + 1})`);
        return false;
      } else {
        const currentYear = new Date().getFullYear();
        const birthYear = new Date(row.namSinh).getFullYear();
        if (birthYear > currentYear) {
          message.error(`Năm sinh không thể trong tương lai (Dòng ${index + 1})`);
          return false;
        }
      }
        // Check if the person is under 1 year old
        const oneYearOldDate = new Date();
        oneYearOldDate.setFullYear(oneYearOldDate.getFullYear() - 1);
        const birthDate = new Date(row.namSinh);  // Chuyển đổi năm sinh thành đối tượng Date

        // So sánh tuổi với 1 năm
        if (birthDate > oneYearOldDate) {
          message.error(`Trẻ em phải trên 1 tuổi để tham gia (Dòng ${index + 1})`);
          return false;
        }
    }

    return true;
  };

  const validateAdultChild = () => {
    const adultCount = rows.filter((row) => row.type === "Người lớn").length;
    // const childCount = rows.filter((row) => row.type === "Trẻ em").length;
  
    if (adultCount === 0) {
      message.error("Phải có ít nhất một người lớn đi kèm!");
      return false;
    }
  
    return true;
  };
  
  const addRow = () => {
    const newRow = {
      hoTen: "",
      email: "",
      soDienThoai: "",
      namSinh: "",
      type: "Người lớn",
    };
    setRows((prevRows) => [...prevRows, newRow]);
  };
  // Function to map `moTa` fields if `chiTietGioHang` is not null or undefined
  console.log("chiTietGioHang",chiTietGioHang)
  const mapMoTaFields = (chiTietGioHang) => {
    return (
      chiTietGioHang?.map((item) => ({
        idChiTietGioHang: item.id,
        soLuongCon: item.bienTheTour.soLuongCon,
        chiTietGioHang_moTa: item.moTa,
        tenTour: item.bienTheTour.tour.tenTour,
        ngayBatDau: item.bienTheTour.ngayBatDau,
        hotels: item.bienTheTour.hotels.danhGiaKhachSan,
        giaNguoiLon: item.bienTheTour.giaNguoiLon,
        giaTreEm: item.bienTheTour.giaTreEm,
        bienTheTour_moTa: item?.bienTheTour.moTa,
        giamGia_moTa: item?.bienTheTour?.giamGia?.moTa,
        tour_moTa: item?.bienTheTour.tour.moTa,
        giamGia_tour_moTa: item?.bienTheTour?.giamGia?.tour?.moTa,
      })) || []
    );
  };

  const mappedFields = mapMoTaFields(chiTietGioHang);
  const formatDate2 = (date) => {
    const d = new Date(date);
    const year = d.getFullYear();
    const month = String(d.getMonth() + 1).padStart(2, '0'); // Thêm 1 vì getMonth() trả về tháng 0-11
    const day = String(d.getDate()).padStart(2, '0'); // Đảm bảo ngày có 2 chữ số
    return `${year}-${month}-${day}`;
  };
  
  const fetchPeopleList = (chiTietGioHang) => {
    console.log("ID chi tiết giỏ hàng: ", chiTietGioHang);
  
    axios
      .get(`http://localhost:8080/api/giohangdanhsachnguoidicung/danhSachNguoiDiCung?idChiTietGioHang=${chiTietGioHang}`)
      .then((response) => {
        console.log("Danh sách người đi cùng: ", response.data);
        const formattedData = response.data.map((item) => ({
          ...item,
          namSinh: formatDate2(item.namSinh),
        }));
        console.log("Dữ liệu đã format:", formattedData);
  
        setCompanionInfo(formattedData);
  
        // Biến đếm người lớn và trẻ em
        let adultCount = 0;
        let childCount = 0;
  
        // Thêm trường type và tính toán số lượng
        const calculatedData = formattedData.map((person) => {
          const birthDate = new Date(person.namSinh);
          const age = calculateAge(birthDate);
          const type = age < 14 ? "Trẻ em" : "Người lớn";
  
          if (age < 14) {
            childCount++;
          } else {
            adultCount++;
          }
  
          return {
            ...person,
            type: type, // Thêm trường phân loại
            isSaved: true,
          };
        });
  
        // Cập nhật state rows với dữ liệu đã tính
        setRows((prevRows) => {
          return [prevRows[0], ...calculatedData.slice(1)];
        });  
        // Cập nhật số lượng người lớn và trẻ em cho từng cartId
        setPeopleList((prevState) => ({
          ...prevState,
          [chiTietGioHang]: { adultCount, childCount },
        }));
  
        console.log(`Số người lớn: ${adultCount}, Số trẻ em: ${childCount}`);
      })
      .catch((error) => {
        console.error("Có lỗi khi lấy danh sách người đi cùng:", error);
      });
  };
  
 

  
  const savePassengerInfo = async (row) => {
    const passengerInfo = {
      chiTietGioHang: {
        id: mappedFields[0]?.idChiTietGioHang,
      },
      hoTen: row.hoTen,
      email: row.email,
      soDienThoai: row.soDienThoai,
      namSinh: row.namSinh,
      isSaved: false, // Chưa lưu
    };

    const response = await axios.post(
      "http://localhost:8080/api/giohangdanhsachnguoidicung/them",
      passengerInfo
    );

    if (response.status === 200) {
      // After adding passenger, update `soNguoi` in `ChiTietGioHang`
      await axios.put(
        `http://localhost:8080/api/chitietgiohang/updateSoNguoi/${passengerInfo.chiTietGioHang.id}`
      );
      return true;
    }

    return false;
  };
  // useEffect(() => {
  //   const fetchTourData = async () => {
  //     try {
  //       const response = await axios.get(
  //         `http://localhost:8080/api/chitietgiohang/bychitietgiohang/${id}`
  //       );
  //       console.log("data nek: ", response.data);
  //       setChiTietGioHang(response.data);
  //       console.log(response.data);
  //     } catch (error) {
  //       console.error("Error fetching tour data", error);
  //       message.error("Failed to load tour data.");
  //     }
  //   };

  //   fetchTourData();
  // }, [id]);
  useEffect(() => {
    const fetchTourData = async () => {
      try {
        const response = await axios.get(
          `http://localhost:8080/api/chitietgiohang/bychitietgiohang/${id}/${userID}`
        );
        console.log("data nek: ", response.data);
        setChiTietGioHang(response.data);
        console.log(response.data);
      } catch (error) {
        console.error("Error fetching tour data", error);
        message.error("Failed to load tour data.");
      }
    };

    fetchTourData();
  }, [id, userID]);

  

  // Only call `mapMoTaFields` if `chiTietGioHang` is populated
  const moTaFields = chiTietGioHang ? mapMoTaFields(chiTietGioHang) : [];
  console.log("abc", moTaFields);
  useEffect(() => {
    // Kiểm tra xem moTaFields có dữ liệu hay không
    const idChiTietGioHang = moTaFields.length > 0 ? moTaFields[0].idChiTietGioHang : null;
    console.log("idChiTietGioHang", idChiTietGioHang);
  
    // Kiểm tra nếu idChiTietGioHang thay đổi mới gọi fetchPeopleList
    if (idChiTietGioHang && idChiTietGioHang !== prevId) {  // prevId là state để lưu idChiTietGioHang cũ
      console.log("Fetching people list for cartId:", idChiTietGioHang);
      fetchPeopleList(idChiTietGioHang); // Gọi hàm với idChiTietGioHang lấy từ mảng
      setPrevId(idChiTietGioHang);  // Cập nhật prevId với id mới
    }
  }, [moTaFields]); // Dependency chỉ theo dõi moTaFields
  
  // State để lưu id trước đó
  const [prevId, setPrevId] = useState(null);
  
  // useEffect(() => {
  //   // Kiểm tra và gọi API nếu idChiTietGioHang thay đổi
  //   const chiTietGioHang = 333; // Đảm bảo dùng giá trị cố định hoặc lấy từ state/props nếu cần
  //   console.log("Fetching people list for cartId:", chiTietGioHang);
  //   fetchPeopleList(chiTietGioHang); // Gọi hàm với giá trị cứng
  // }, [moTaFields.idChiTietGioHang]); 

  // useEffect(() => {
  //   if (selectedTour && selectedTour.companionInfo) {
  //     // Lấy dữ liệu companionInfo từ SQL
  //     const companionInfo = selectedTour.companionInfo.map((item) => {
  //       const birthYear = new Date(item.namSinh).getFullYear();
  //       const currentYear = new Date().getFullYear();
  //       const age = currentYear - birthYear;

  //       const type = age < 14 ? "Trẻ em" : "Người lớn"; // Tính tuổi và loại khách

  //       return {
  //         ...item,
  //         type: type,
  //         isSaved: true, // Đánh dấu là đã lưu
  //       };
  //     });

  //     // Cập nhật state rows với dữ liệu companionInfo (dữ liệu đã lấy từ SQL)
  //     setRows(companionInfo);
  //   }
  // }, [selectedTour]);

  // const handleAddPassenger = () => {
  //   // Thêm hành khách mới vào danh sách rows mà không ảnh hưởng đến dữ liệu đã có sẵn
  //   const newPassenger = {
  //     hoTen: "",
  //     email: "",
  //     soDienThoai: "",
  //     namSinh: "",
  //     type: "Người lớn", // Có thể đặt mặc định
  //     isSaved: false, // Chưa lưu
  //   };

  //   // Thêm hành khách mới vào rows
  //   setRows(prevRows => [...prevRows, newPassenger]);
  // };

  const handleContinue = async () => {
    if (!validateFields()) return;

 // Kiểm tra số lượng trẻ em và người lớn
    if (!validateAdultChild()) {
      return;
    }  
    let successCount = 0;

    try {
      // Duyệt qua từng hành khách trong danh sách `rows`
      for (const row of rows) {
        // Chỉ lưu những hành khách chưa được lưu (isSaved: false)
        if (!row.isSaved) {
          const isSaved = await savePassengerInfo(row); // Gửi thông tin hành khách lên server để lưu
          if (isSaved) {
            // Nếu lưu thành công, đánh dấu là đã lưu
            successCount++;
            setRows((prevRows) =>
              prevRows.map((r) =>
                r.id === row.id ? { ...r, isSaved: true } : r
              )
            );
          }
        }
      }

      if (successCount > 0) {
        message.success(
          `Đã lưu thành công thông tin của ${successCount} hành khách.`
        );
        onContinue({ hoTen: "User Name" }, rows, "Summary Data");
      }
      onContinue({ hoTen: "User Name" }, rows, "Summary Data");

      console.log("Danh sách hành khách đã lưu:", rows);
      // Tiến hành bước tiếp theo trong ứng dụng của bạn
    } catch (error) {
      message.error("Đã xảy ra lỗi khi gửi thông tin.");
    }
  };
  // -----------------------------------
  const handleCreate = async () => {
    if (!validateFields()) return;

    let successCount = 0;

    try {
      // Duyệt qua từng hành khách trong danh sách `rows`
      for (const row of rows) {
        // Chỉ lưu những hành khách chưa được lưu (isSaved: false)
        if (!row.isSaved) {
          const isSaved = await savePassengerInfo(row); // Gửi thông tin hành khách lên server để lưu
          if (isSaved) {
            // Nếu lưu thành công, đánh dấu là đã lưu
            successCount++;
            setRows((prevRows) =>
              prevRows.map((r) =>
                r.id === row.id ? { ...r, isSaved: true } : r
              )
            );
          }
        }
      }

      if (successCount > 0) {
        message.success(
          `Đã lưu thành công thông tin của ${successCount} hành khách.`
        );
      }

      console.log("Danh sách hành khách đã lưu:", rows);
    } catch (error) {
      message.error("Đã xảy ra lỗi khi gửi thông tin.");
    }
  };

  const ThemGioHangDanhSachNguoiDicung = async () => {
    if (!validateFields()) return;

    let successCount = 0;

    try {
      for (const row of rows) {
        const isSaved = await savePassengerInfo(row); // Save each passenger's info
        if (isSaved) successCount++;
      }

      if (successCount > 0) {
        message.success(
          `Đã lưu thành công thông tin của ${successCount} hành khách.`
        );
        // onContinue({ hoTen: "User Name" }, rows, "Summary Data");
      }

      console.log("Danh sách hành khách đã lưu:", rows);
      // Continue to the next step in your application
    } catch (error) {
      message.error("Đã xảy ra lỗi khi gửi thông tin.");
    }
  };
  const formatDate = (date) => {
    return format(new Date(date), "dd/MM/yyyy"); // Change the format as needed
  };
  const renderStars = (stars) => {
    const maxStars = 5; // Assuming a maximum rating of 5 stars
    return Array.from({ length: maxStars }, (_, index) => (
      <span
        key={index}
        style={{ color: index < stars ? "#FFD700" : "#d3d3d3" }}
      >
        ★
      </span>
    ));
  };
  const formatCurrencyVND = (amount) => {
    return new Intl.NumberFormat("vi-VN", {
      style: "currency",
      currency: "VND",
      currencyDisplay: "code",
    }).format(amount);
  };
  const calculateTotal = (giaNguoiLon, giaTreEm) => {
    let totalAdults = 0;
    let totalChildren = 0;
  
    rows.forEach((row) => {
      if (row.type === "Người lớn") {
        totalAdults++;
      } else if (row.type === "Trẻ em") {
        totalChildren++;
      }
    });
  
    // Tính tổng tiền dựa trên giá và số lượng
    const totalPrice = totalAdults * giaNguoiLon + totalChildren * giaTreEm;
    return { totalPrice, totalAdults, totalChildren };
  };
  
 
  const renderSidebar = () => {
    return (
      <div className="mb-5">
       {moTaFields.map((item, index) => {
        const { totalPrice, totalAdults, totalChildren } = calculateTotal(
          item.giaNguoiLon,
          item.giaTreEm
        );

        return (
          <div
            key={index}
            className="w-[516.8px] h-auto flex flex-col border border-light-border p-0 px-4 py-6 xl:p-8 box-border"
          >
            <div className="flex flex-col mb-2 mt-2">
              <h5 className="text-left font-semibold">Thông tin tour:</h5>
            </div>

            <div className="flex justify-between mb-2">
              <div className="w-[40%] text-left">Tour du lịch:</div>
              <div className="w-[60%] text-left ml-1">{item.tenTour}</div>
            </div>
            <div className="flex justify-between mb-2">
              <div className="w-[40%] text-left">Ngày khởi hành:</div>
              <div className="w-[60%] text-left ml-1">
                {formatDate(item.ngayBatDau)}
              </div>
            </div>
            <div className="flex justify-between mb-2">
              <div className="w-[40%] text-left">Khách sạn:</div>
              <div className="w-[60%] text-left ml-1">
                {renderStars(item.hotels)}
              </div>
            </div>

            <div className="flex justify-between mb-2">
              <div className="w-[40%] text-left">Giá vé 01 khách:</div>
              <div className="w-[60%] text-left ml-1  ">
                {formatCurrencyVND(item.giaNguoiLon)}/ vé người lớn
              </div>
            </div>
            <div className="flex justify-between mb-2">
              <div className="w-[40%] text-left ">Tổng giá:</div>
              <div className="w-[60%] text-left ml-1 font-semibold text-red-500">
                {formatCurrencyVND(totalPrice)}
              </div>
            </div>
          </div>
        );
      })}

      </div>
    );
  };
  const renderMain = () => {
    const handleExcelUpload = (event) => {
      const file = event.target.files[0];
      if (!file) return;

      const reader = new FileReader();
      reader.onload = (e) => {
        const data = new Uint8Array(e.target.result);
        const workbook = XLSX.read(data, { type: "array" });
        const sheetName = workbook.SheetNames[0];
        const worksheet = workbook.Sheets[sheetName];
        const jsonData = XLSX.utils.sheet_to_json(worksheet, { header: 1 });

        // Convert JSON data into rows format
        const newRows = jsonData.slice(1).map((row) => ({
          hoTen: row[0] || "",
          email: row[1] || "",
          soDienThoai: row[2] || "",
          namSinh: row[3] || "",
          type: "Người lớn", // Default value for "Loại khách"
          isSaved: false, // Default state
        }));

        // Add rows to the existing data
        setRows((prevRows) => [...prevRows, ...newRows]);
      };

      reader.readAsArrayBuffer(file);
    };

    return (
      <div className="w-[940px] flex flex-col sm:border border border-light-border space-y-8 p-6">
     <div className="flex justify-between items-center">
      {/* Phần tử bên trái */}
      <div className="text-left">
        <h5>Thông tin hành khách</h5>
      </div>

      {/* Phần tử bên phải */}
      <div className="text-right" onClick={showModal}>
        <ExclamationCircleOutlined style={{ color: 'red', fontSize: '24px' }} />
      </div>
    </div>
 {/* Modal hiển thị khi nhấn vào biểu tượng */}
 <Modal
        title="Thông tin hướng dẫn"
        visible={isModalVisible}
        onCancel={handleCancel}
        footer={null}
      >
        <p className="text-lg font-semibold">Hướng dẫn nhập thông tin hành khách</p>
        <p>
          Để nhập thông tin hành khách cho tour một cách nhanh chóng, vui lòng tải về mẫu Excel dưới đây và điền đầy đủ thông tin theo yêu cầu.
        </p>
        <p>
          <span style={{ color: 'red', fontWeight: 'bold' }}>Lưu ý: </span>
          Các trường thông tin như họ tên, tuổi, số điện thoại, email là bắt buộc phải điền.
        </p>
        <div className="mt-4">
          <Button 
            type="primary" 
            href="/DanhSachHanhKhach.xlsx" // Đường dẫn đến file Excel trong thư mục public
            download="DanhSachHanhKhach.xlsx" // Đặt tên file tải về
          >
            Tải mẫu Excel
          </Button>
        </div>
        <p className="mt-4">
          Sau khi điền xong, vui lòng tải lên file Excel để hoàn tất quá trình nhập thông tin.
        </p>
      </Modal>
        <div className="overflow-x-auto w-full">
          <table className="min-w-full border border-gray-300">
            <thead>
              <tr className="bg-gray-100">
                <th className="border border-gray-300 py-2 text-center px-4 min-w-[150px]">
                  Họ tên
                </th>
                <th className="border border-gray-300 py-2 text-center px-4 min-w-[200px]">
                  Email
                </th>
                <th className="border border-gray-300 py-2 text-center px-4 min-w-[150px]">
                  Số điện thoại
                </th>
                <th className="border border-gray-300 py-2 text-center px-4 min-w-[120px]">
                  Năm sinh
                </th>
                <th className="border border-gray-300 py-2 text-center px-4 min-w-[150px]">
                  Loại khách
                </th>
                {hasCompanionInfo && (
                  <th className="border border-gray-300 py-2 text-center px-4 ">
                    Hành động
                  </th>
                )}
              </tr>
            </thead>
            <tbody>
              {rows.map((row, index) => (
                <tr key={index}>
                  <td className="border py-2 px-4 whitespace-nowrap">
                    <input
                      type="text"
                      className="w-full border-none rounded-lg py-1 px-2 text-gray-800 focus:outline-none"
                      placeholder="Nhập họ tên"
                      value={row.hoTen}
                      onChange={(e) =>
                        handleInputChange(index, "hoTen", e.target.value)
                      }
                    />
                  </td>
                  <td className="border py-2 px-4 whitespace-nowrap">
                    <input
                      type="text"
                      className="w-full border-none rounded-lg py-1 px-2 text-gray-800 focus:outline-none"
                      placeholder="Nhập Email"
                      value={row.email}
                      onChange={(e) =>
                        handleInputChange(index, "email", e.target.value)
                      }
                    />
                  </td>
                  <td className="border py-2 px-4 whitespace-nowrap">
                    <input
                      type="text"
                      className="w-full border-none rounded-lg py-1 px-2 text-gray-800 focus:outline-none"
                      placeholder="Nhập số điện thoại"
                      value={row.soDienThoai}
                      onChange={(e) =>
                        handleInputChange(index, "soDienThoai", e.target.value)
                      }
                    />
                  </td>
                  <td className="border py-2 px-4 whitespace-nowrap">
                    <input
                      type="date"
                      className="w-full border-none rounded-lg py-1 px-2 text-gray-800 focus:outline-none"
                      value={row.namSinh}
                      onChange={(e) =>
                        handleInputChange(index, "namSinh", e.target.value)
                      }
                    />
                  </td>
                  <td className="border py-2 px-4 whitespace-nowrap">
                    <span>{row.type}</span>
                  </td>
                  {hasCompanionInfo && (
                    <td className="border py-2 px-4 whitespace-nowrap">
                      <div className="flex justify-start gap-2">
                        {!row.isSaved && (
                          <button
                            className="border border-green-500 text-green-500 font-bold rounded hover:bg-green-100 flex justify-center items-center"
                            style={{ width: "40px", height: "40px" }}
                            onClick={() => handleCreate(row)}
                          >
                            <AntDesignOutlined />
                          </button>
                        )}
                        <button
                          className="border border-yellow-500 text-yellow-500 font-bold rounded hover:bg-yellow-100 flex justify-center items-center"
                          style={{ width: "40px", height: "40px" }}
                          onClick={handleUpdate}
                        >
                          <HighlightTwoTone />
                        </button>
                        <button
                          className="border border-red-500 text-red-500 font-bold rounded hover:bg-red-100 flex justify-center items-center"
                          style={{ width: "40px", height: "40px" }}
                          onClick={() => handleDelete(row.id)}
                        >
                          <DeleteOutlined />
                        </button>
                      </div>
                    </td>
                  )}
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <div className="text-right mt-2">
          <label className="bg-gray-500 text-white px-4 py-2 rounded cursor-pointer">
            Tải Excel
            <input
              type="file"
              accept=".xlsx, .xls"
              className="hidden"
              onChange={handleExcelUpload}
            />
          </label>
          <button
            className="bg-blue-500 text-white px-4 py-2 rounded ml-2"
            onClick={addRow}
          >
            Thêm hành khách
          </button>
          <button
            className="bg-red-500 text-white px-4 py-2 rounded ml-2"
            onClick={handleRemoveRow}
          >
            Xóa hành khách
          </button>
        </div>
        <div className="mt-4">
          <button
            className="bg-green-500 text-white px-4 py-2 rounded"
            onClick={handleContinue}
          >
            Tiếp tục
          </button>
        </div>
      </div>
    );
  };

  return (
    <div className={`flex ${className}`}>
      {renderMain()}
      {renderSidebar()}

      {/* <ToastContainer /> */}
    </div>
  );
};

export default ThongTin;
