import React, { useEffect, useState, useCallback } from "react";
import { Link, useLocation } from "react-router-dom";
import moment from "moment";
import { Table, Typography, Row, Col } from "antd";

const ChiTietHoaDon = () => {
  // const location = useLocation();
  // const paymentId = location.state?.paymentId;  // Replace with the dynamic paymentId if needed
  const location = useLocation();
// Kiểm tra xem có state hay không
const paymentIdFromState = location.state?.paymentId;

// Nếu không có state, lấy từ query string
const queryParams = new URLSearchParams(location.search);
const paymentIdFromQuery = queryParams.get('paymentId');

// Sử dụng `paymentId` từ state nếu có, nếu không thì dùng từ query string
const paymentId = paymentIdFromState || paymentIdFromQuery;

console.log(paymentId);
  const [paymentDetails, setPaymentDetails] = useState([]);

  const fetchPaymentDetails = useCallback(async () => {
    try {
      const response = await fetch(
        `http://localhost:8080/api/hoadon/${paymentId}`
      );
      if (!response.ok) {
        throw new Error("Không thể tải thông tin thanh toán");
      }
      const data = await response.json();
      console.log("hoa don: ", data);
      setPaymentDetails(data);  // Ensure this is an array of objects
    } catch (error) {
      console.error("Lỗi khi lấy chi tiết thanh toán:", error);
    }
  }, [paymentId]);

  useEffect(() => {
    fetchPaymentDetails();
  }, [fetchPaymentDetails]);

  // Format date to dd-mm-yyyy
  const formatDate = (date) => {
    return moment(date).format("DD-MM-YYYY");
  };

  // Check if paymentDetails is an array and has data
  const payment = paymentDetails.length > 0 ? paymentDetails[0] : {}; 

  const convertNumberToWords = (number) => {
    const units = [
      "",
      "Một",
      "Hai",
      "Ba",
      "Bốn",
      "Năm",
      "Sáu",
      "Bảy",
      "Tám",
      "Chín",
    ];
    const tens = [
      "",
      "Mười",
      "Hai Mươi",
      "Ba Mươi",
      "Bốn Mươi",
      "Năm Mươi",
      "Sáu Mươi",
      "Bảy Mươi",
      "Tám Mươi",
      "Chín Mươi",
    ];
    const powers = ["", "nghìn", "triệu", "tỷ", "nghìn tỷ"];

    if (number === 0) return "Không đồng";

    let words = [];
    let unitIndex = 0;

    while (number > 0) {
      let chunk = number % 1000;
      if (chunk > 0) {
        let chunkWords = [];
        let hundred = Math.floor(chunk / 100);
        let ten = Math.floor((chunk % 100) / 10);
        let unit = chunk % 10;

        if (hundred > 0) {
          chunkWords.push(units[hundred] + " Trăm");
        }
        if (ten > 1) {
          chunkWords.push(tens[ten]);
          if (unit > 0) {
            chunkWords.push(units[unit]);
          }
        } else if (ten === 1) {
          chunkWords.push("Mười");
          if (unit > 0) {
            chunkWords.push(units[unit]);
          }
        } else if (unit > 0) {
          chunkWords.push(units[unit]);
        }

        chunkWords.push(powers[unitIndex]);
        words.unshift(chunkWords.join(" ").trim());
      }

      number = Math.floor(number / 1000);
      unitIndex++;
    }

    return words.join(" ").trim() + " đồng";
  };

  const columns = [
    {
      title: "STT",
      dataIndex: "index",
      key: "index",
      render: (text, record, index) => index + 1,
    },
    {
      title: "Họ Tên",
      dataIndex: "hoTen",
      key: "hoTen",
    },
    {
      title: "Email",
      dataIndex: "email",
      key: "email",
    },
    {
      title: "Số điện thoại",
      dataIndex: "soDienThoai",
      key: "soDienThoai",
    },
    {
      title: "Năm Sinh",
      dataIndex: "namSinh",
      key: "namSinh",
      render: (text) => moment(text).format("DD-MM-YYYY"), // Định dạng ngày
    },
    {
      title: "Giá người lớn",
      dataIndex: "giaNguoiLon",
      key: "giaNguoiLon",
      render: (text) => text ? text.toLocaleString() + ' VNĐ' : "N/A",  // Định dạng tiền
    },
    {
      title: "Giá trẻ em",
      dataIndex: "giaTreEm",
      key: "giaTreEm",
      render: (text) => text ? text.toLocaleString() + ' VNĐ' : "N/A",  // Định dạng tiền
    },
    {
      title: "Giá Tiền",
      dataIndex: "thanhTien",
      key: "thanhTien",
      render: (text) => text ? text.toLocaleString() + ' VNĐ' : "N/A",  // Định dạng tiền
    },
  ];

  return (
    <div className="max-w-[1000px] mx-auto border border-gray-300 rounded-lg shadow-sm p-6 font-sans relative mb-20" style={{ marginTop: "140px" }}>
      {/* Tiêu đề */}
      <div className="border-b pb-4 mb-4">
        <h1 className="text-lg font-semibold text-left">Thông Tin Thanh Toán</h1>
      </div>

      {/* Header */}
      <div className="mb-6 grid grid-cols-2 gap-4 text-sm text-left">
        <div>
          <strong>Khách Hàng:</strong> {payment.nguoiDungHoTen || "N/A"}
        </div>
        <div>
          <strong>SĐT:</strong> {payment.nguoiDungSoDienThoai || "N/A"}
        </div>
        <div>
          <strong>Email:</strong> {payment.nguoiDungEmail || "N/A"}
        </div>
        <div>
          <strong>Địa Chỉ:</strong> {payment.nguoiDungDiaChi || "N/A"}
        </div>
      </div>

      {/* Tour Information */}
      <div className="mb-4">
        <h2 className="text-blue-600 font-semibold text-lg mb-2 text-left">
          {payment.tenTour || "Tour Name"}
        </h2>
        <div className="grid grid-cols-3 gap-4 text-sm text-left">
          <div>
            <strong>Mã tour:</strong> {payment.moTa || "N/A"}
          </div>
          <div>
            <strong>Trạng Thái:</strong> 
            <span 
              className={`
                ${payment.hoaDonTrangThai ? "text-green-500 font-semibold" : "text-red-500 font-semibold"}
              `}>
              {payment.hoaDonTrangThai ? " Đã thanh toán" : " Chưa thanh toán"}
            </span>
          </div>

          <div>
            <strong>Ngày Đặt:</strong> {formatDate(payment.ngayDat) || "N/A"}
          </div>
        </div>
      </div>

      {/* Table */}
      <Table
        columns={columns}
        dataSource={paymentDetails}
        rowKey={(record, index) => index}
        pagination={false}
      />

      {/* Footer */}
      <div className="mt-4 text-sm">
        <div className="text-right">
          <strong>Tổng tiền: </strong> 
          <span className="text-red-600 font-semibold text-lg">
            {payment.tongTien ? payment.tongTien.toLocaleString() : "N/A"} VNĐ
          </span>
        </div>
        <p className="italic mt-2 text-left">
          Viết bằng chữ: <strong>{convertNumberToWords(payment.tongTien)}</strong>
        </p>
      </div>
      <div className="mt-4 flex justify-end space-x-4">
        <Link 
          to="/" 
          className="bg-blue-500 text-white py-2 px-4 rounded hover:bg-blue-600 text-center no-underline"
        >
          Quay về trang chủ
        </Link>
        <Link 
          to="/trang-tai-khoan/lich-su-giao-dich" 
          className="bg-green-500 text-white py-2 px-4 rounded hover:bg-green-600 text-center no-underline"
        >
          Lịch sử đặt tour
        </Link>
      </div>

    </div>
  );
};

export default ChiTietHoaDon;
// import React, { useEffect, useState, useCallback } from "react";
// import { Modal, Form, Table } from "antd";
// import dayjs from "dayjs";
// import { useLocation } from "react-router-dom";

//   const formatCurrency = (value) => {
//     return new Intl.NumberFormat("vi-VN", {
//       style: "currency",
//       currency: "VND",
//     }).format(value);
//   };

//   const convertNumberToWords = (number) => {
//     const units = [
//       "",
//       "Một",
//       "Hai",
//       "Ba",
//       "Bốn",
//       "Năm",
//       "Sáu",
//       "Bảy",
//       "Tám",
//       "Chín",
//     ];
    
//     const tens = [
//       "",
//       "Mười",
//       "Hai Mươi",
//       "Ba Mươi",
//       "Bốn Mươi",
//       "Năm Mươi",
//       "Sáu Mươi",
//       "Bảy Mươi",
//       "Tám Mươi",
//       "Chín Mươi",
//     ];
//     const powers = ["", "nghìn", "triệu", "tỷ", "nghìn tỷ"];

//     if (number === 0) return "Không đồng";

//     let words = [];
//     let unitIndex = 0;

//     while (number > 0) {
//       let chunk = number % 1000;
//       if (chunk > 0) {
//         let chunkWords = [];
//         let hundred = Math.floor(chunk / 100);
//         let ten = Math.floor((chunk % 100) / 10);
//         let unit = chunk % 10;

//         if (hundred > 0) {
//           chunkWords.push(units[hundred] + " Trăm");
//         }
//         if (ten > 1) {
//           chunkWords.push(tens[ten]);
//           if (unit > 0) {
//             chunkWords.push(units[unit]);
//           }
//         } else if (ten === 1) {
//           chunkWords.push("Mười");
//           if (unit > 0) {
//             chunkWords.push(units[unit]);
//           }
//         } else if (unit > 0) {
//           chunkWords.push(units[unit]);
//         }

//         chunkWords.push(powers[unitIndex]);
//         words.unshift(chunkWords.join(" ").trim());
//       }

//       number = Math.floor(number / 1000);
//       unitIndex++;
//     }

//     return words.join(" ").trim() + " đồng";
//   };

// export const ChiTietHoaDon = ({ visible, onClose }) => {
//   const location = useLocation();
//   const paymentIdFromState = location.state?.paymentId;
//   const queryParams = new URLSearchParams(location.search);
//   const paymentIdFromQuery = queryParams.get("paymentId");
//   const paymentId = paymentIdFromState || paymentIdFromQuery;
//   const [paymentDetails, setPaymentDetails] = useState([]);
//   const [loading, setLoading] = useState(true);
//   const [isModalVisible, setIsModalVisible] = useState(false);
//   const isPaymentSuccess = localStorage.getItem('isPaymentSuccess') === 'true';

//    // Kiểm tra trạng thái thanh toán từ state
//   const fetchPaymentDetails = useCallback(async () => {
//     try {
//       const response = await fetch(`http://localhost:8080/api/hoadon/${paymentId}`);
//       if (!response.ok) {
//         throw new Error("Không thể tải thông tin thanh toán");
//       }
//       const data = await response.json();
//       console.log("data ", data);
//       setPaymentDetails(data);
//     } catch (error) {
//       console.error("Lỗi khi lấy chi tiết thanh toán:", error);
//     } finally {
//       setLoading(false);
//     }
//   }, [paymentId]);

//   useEffect(() => {
//     if (isPaymentSuccess && paymentId) {
//       fetchPaymentDetails();
//     }
//   }, [isPaymentSuccess, paymentId, fetchPaymentDetails]);


//   return (
//     <div>
//       <Modal
//         title="Thông Tin Thanh Toán"
//         visible={isPaymentSuccess && paymentId && visible} // Chỉ hiển thị nếu thanh toán thành công và có paymentId
//         onCancel={onClose}
//         footer={null}
//         width={1100}
   
//       >
//         <hr />
//         <div>
//           <Form layout="vertical">
//           <div className="flex gap-3 row">
//           <div className="col-lg-5 flex gap-2">
//             <label className="font-bold">Khách Hàng:</label>
//             <span>{paymentDetails[0]?.nguoiDungHoTen}</span>
//          </div>

//         <div className="col-lg-5 flex gap-2">
//           <label className="font-bold">SĐT:</label>
//           <span>{paymentDetails[0]?.nguoiDungSoDienThoai}</span>
          
//         </div>

//         <div className="col-lg-5 flex gap-2">
//           <label className="font-bold">Email:</label>
//           <span>{paymentDetails[0]?.nguoiDungEmail}</span>
          
//         </div>

//         <div className="col-lg-3 flex gap-2">
//           <label  className="font-bold">Địa Chỉ:   </label>
//           <span>{paymentDetails[0]?.nguoiDungDiaChi}</span>
       
//         </div>
//       </div>
//       <div className="mb-4">
//       <h2 className="text-blue-600 font-semibold text-lg mb-2 text-left mt-4">
//      {paymentDetails[0]?.tenTour}
//        </h2>
//         <div className="grid grid-cols-3 gap-4 text-sm text-left">
//        <div>
//           <strong>Mã tour:</strong> {paymentDetails[0]?.moTa}
//         </div>
//          <div>
//         <strong>Trạng Thái:</strong> 
//         <span 
//                 className={`
//                 ${paymentDetails[0]?.phuongThucThanhToan ? "text-green-500 font-semibold" : "text-red-500 font-semibold"}
//               `}>
//               {paymentDetails[0]?.phuongThucThanhToan ? " Đã thanh toán" : " Chưa thanh toán"}
//             </span>
//           </div>

//           <div>
//           <strong>Ngày Đặt:</strong> {dayjs(paymentDetails[0]?.ngayDat).format('DD-MM-YYYY')}
//           </div>
//         </div>
//       </div>
//             {/* <div style={{ fontSize: '17px', fontWeight: 'bold', color: '#007bff', marginBottom: '20px' }}>
//               Danh Sách Hàng Khách Đi Cùng
//             </div>      */}
//             <Table
//   dataSource={paymentDetails}
//   bordered
//   size="middle"
//   scroll={{ x: 700 }}
//   pagination={false}
// >
//   <Table.Column
//     title="STT"
//     key="stt"
//     render={(text, record, index) => index + 1}
//     width={30}
//   />
//   <Table.Column
//     title="Họ Tên"
//     dataIndex="hoTen"
//     key="hoTen"
//     width={100}
//     ellipsis
//   />
//   <Table.Column
//     title="Email"
//     dataIndex="email"
//     key="email"
//     width={100}
//     ellipsis
//   />
//   <Table.Column
//     title="Số điện thoại"
//     dataIndex="soDienThoai"
//     key="soDienThoai"
//     width={80}
//     ellipsis
//   />
//   <Table.Column
//     title="Năm Sinh"
//     dataIndex="namSinh"
//     key="namSinh"
//     width={75}
//     render={(text) => dayjs(text).format("DD-MM-YYYY")}
//     ellipsis
//   />
//   <Table.Column
//   title="Giá người lớn"
//   dataIndex="giaNguoiLon"
//   key="giaNguoiLon"
//   width={100}
//   render={(text) => {
//     return new Intl.NumberFormat('vi-VN').format(text) + ' VNĐ'; // Thêm 'VNĐ' vào cuối giá trị
//   }}
//   ellipsis
// />

// <Table.Column
//   title="Giá trẻ em"
//   dataIndex="giaTreEm"
//   key="giaTreEm"
//   width={100}
//   render={(text) => {
//     return new Intl.NumberFormat('vi-VN').format(text) + ' VNĐ'; // Thêm 'VNĐ' vào cuối giá trị
//   }}
//   ellipsis
// />

// <Table.Column
//   title="Giá tiền"
//   dataIndex="thanhTien"
//   key="thanhTien"
//   render={(text, record) => {
//     return new Intl.NumberFormat('vi-VN').format(text) + ' VNĐ'; // Thêm 'VNĐ' vào cuối giá trị
//   }}
//   width={100}
//   ellipsis
// />

// </Table>


// <div className="col-lg-12" style={{ display: 'flex', justifyContent: 'flex-end' }}>
//   <Form.Item className="tong mt-2" label="Tổng tiền">
//     <strong style={{ color: "red" }}>
//       {new Intl.NumberFormat('vi-VN').format(paymentDetails[0]?.tongTien)} <span>VNĐ</span>
//     </strong>
//   </Form.Item>
// </div>



//             <div className="col-lg-12">
//               <Form.Item>
//                 <i> Viết bằng chữ: </i>
//                 <b>{convertNumberToWords(paymentDetails[0]?.tongTien)}</b> <br />
//               </Form.Item>
//             </div>
//           </Form>
//         </div>
//       </Modal>
//     </div>
//   );
// };

// export default ChiTietHoaDon;

