import React, { useState } from "react";
import { Button, message } from "antd";
import { DeleteOutlined } from "@ant-design/icons";
import axios from "axios";

const DiscountComponent = ({ bienTheTourId, totalTien }) => {
  console.log("totalTien", totalTien);
  const [discountCode, setDiscountCode] = useState("");
  const [appliedCode, setAppliedCode] = useState("");
  const [discountResult, setDiscountResult] = useState("");
  console.log("discountCode", discountCode);
  console.log("appliedCode", appliedCode);
  console.log("discountResult", discountResult);
  const handleApply = async () => {
    if (!bienTheTourId) {
      console.log("bienTheTourId:", bienTheTourId);
      setDiscountResult("Biến thể tour không hợp lệ.");
      return;
    }

    if (discountCode) {
      try {
        // const response = await axios.get(
        //   `http://localhost:8080/api/giamgia/kiemtra/${discountCode}/${bienTheTourId}`
        // );
        const response = await axios.post(
          `http://localhost:8080/api/giamgia/kiemtra`,
          {
            maGiamGia: discountCode,
            bienTheTourId: bienTheTourId,
            totalTien: totalTien, // Truyền totalTien vào request body
          }
        );
        console.log("a", response.data);
        localStorage.setItem("discountResult", response.data);
        setDiscountResult(response.data); // Hiển thị dữ liệu từ backend
        setAppliedCode(discountCode);
      } catch (error) {
        // Nếu có lỗi, chỉ lấy thông báo lỗi để hiển thị
        const errorMessage =
          error.response?.data || "Có lỗi xảy ra khi kiểm tra mã giảm giá";
        setDiscountResult(errorMessage);
      }
    } else {
      setDiscountResult("Vui lòng nhập mã giảm giá");
    }
  };

  const handleDelete = () => {
    localStorage.removeItem("discountResult");
    setAppliedCode("");
    setDiscountCode("");
    setDiscountResult("");
  };

  return (
    <div className="flex flex-col">
      {!appliedCode && (
        <>
          <span className="font-semibold w-[452.68px] h-[40px] text-left flex gap-[60px]">
            Nhập mã giảm giá nếu có:
            <Button onClick={handleApply}>Áp dụng</Button>
          </span>
          <input
            type="text"
            className="border max-w-[200px]"
            value={discountCode}
            onChange={(e) => setDiscountCode(e.target.value)}
          />
        </>
      )}
      {appliedCode && (
        <span className="font-semibold w-[452.68px] h-[40px] text-left flex gap-[60px] items-center">
          Mã giảm: {appliedCode}
          <Button icon={<DeleteOutlined />} danger onClick={handleDelete} />
        </span>
      )}
      {discountResult && (
        <div className="mt-2">
          {/* <strong>{discountResult}</strong> */}
        </div>
      )}
    </div>
  );
};

export default DiscountComponent;
