import React, { useEffect, useState } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";
// import { message } from "react-messageify"; // Import Toastify
// import "react-messageify/dist/ReactToastify.css"; // Import CSS cho Toastify
import { message} from "antd";

const GioHang = () => {
  const [cartDetails, setCartDetails] = useState([]);
  const [PeopleList, setPeopleList] = useState({});
  const [totalPrice, setTotalPrice] = useState(0);
  const [selectedTourId, setSelectedTourId] = useState(null); // ID của tour được chọn
  const navigate = useNavigate();
  const [userID] = useState(localStorage.getItem("id"));
  const [companionInfo, setCompanionInfo] = useState({
    hoTen: '',
    email: '',
    soDienThoai: '',
    namSinh: ''
  });
  console.log("totalPrice", totalPrice)
  useEffect(() => {
    const idNguoiDung = userID; // Thay bằng id người dùng hiện tại
    axios
      .get(`http://localhost:8080/api/chitietgiohang/user?idNguoiDung=${idNguoiDung}`)
      .then((response) => {
        console.log("giỏ hàng: ",response.data);
        setCartDetails(response.data);
        const total = response.data.reduce((sum, item) => sum + item.tongTien, 0);
        setTotalPrice(total);
        // Gọi hàm fetchPeopleList cho từng cartId
        response.data.forEach(item => {
          fetchPeopleList(item.idChiTietGioHang); // Gọi fetchPeopleList với cartId của mỗi item
        });
      })
      .catch((error) => {
        console.error("Có lỗi khi lấy dữ liệu giỏ hàng:", error);
      });
  }, [userID]);
  const handleContinue = () => {
    navigate("/");
  };
  useEffect(() => {
    if (selectedTourId) {
      // Loop through cartDetails and fetch people list for the selected tour's cartId
      cartDetails.forEach(item => {
        if (item.idBienThe === selectedTourId) {
          console.log("Fetching people list for cartId:", item.idChiTietGioHang);
          fetchPeopleList(item.idChiTietGioHang);
        }
      });
    }
  }, [selectedTourId]);

  const handleDelete = async (cartId) => {
    console.log("idL ", cartId);
    try {

      await axios.delete(
        `http://localhost:8080/api/giohangdanhsachnguoidicung/delete-giohangnguoidicung/${cartId}`
       );

      const response = await axios.delete(
        `http://localhost:8080/api/chitietgiohang/delete/${cartId}`
      );
      message.success(response.data);
      // Xóa tour khỏi giỏ hàng
      setCartDetails(cartDetails.filter((item) => item.idChiTietGioHang !== cartId));
    } catch (error) {
      if (error.response) {
        message.error(error.response.data);
      } else {
        message.error("Lỗi khi xóa giỏ hàng!");
      }
    }
  };
console.log("sss",companionInfo)
  const handleBooking = () => {
    if (!selectedTourId) {
      message.error("Vui lòng chọn tour để đặt!");
      return;
    } 
    const selectedTour = cartDetails.find(item => item.idBienThe === selectedTourId);
    if (!selectedTour) {
      message.error("Không tìm thấy tour này trong giỏ hàng!");
      return;
    }
  
    // Tạo dữ liệu để gửi đi
    const dataToSend = {
      idNguoiDung: 2, // ID người dùng hiện tại, thay bằng giá trị thực tế
      idBienTheTour: selectedTourId, // ID tour đã chọn
      tongTien: selectedTour.tongTien, // Tổng tiền từ giỏ hàng
      moTa: selectedTour.tenTour, // Mô tả tour (có thể lấy từ tên tour)
      soNguoi: PeopleList[selectedTour.idChiTietGioHang]?.adultCount || 1, // Số người (nếu có, lấy từ PeopleList),
      companionInfo // Dữ liệu thông tin người đi cùng
    };
  
    console.log("Data to send:", dataToSend);
    // Chuyển hướng tới trang thanh toán với ID tour được chọn
    navigate(`/thanh-toan/${selectedTourId}`, { 
      state: 
        dataToSend, // Dữ liệu tour và người dùng
        // companionInfo // Dữ liệu thông tin người đi cùng
    });
  };

  const fetchPeopleList = (cartId) => {
    console.log("s ", cartId);

    axios
      .get(`http://localhost:8080/api/giohangdanhsachnguoidicung/danhSachNguoiDiCung?idChiTietGioHang=${cartId}`)
      .then((response) => {
        console.log("Danh sách người đi cùng: ", response.data);
        const formattedData = response.data.map((item) => ({
          ...item,
          namSinh: formatDate(item.namSinh),
        }));
        console.log("Danh sách người đi cùng sss:", formattedData);

        setCompanionInfo(formattedData); 

        // Khai báo biến đếm
        let adultCount = 0;
        let childCount = 0;

        // Kiểm tra từng người trong danh sách và tính độ tuổi
        response.data.forEach(person => {
          const birthDate = new Date(person.namSinh); // Chuyển namSinh thành Date
          const age = calculateAge(birthDate); // Tính tuổi

          if (age < 14) {
            console.log(`${person.hoTen} là trẻ em`);
            childCount++; // Tăng đếm trẻ em
          } else {
            console.log(`${person.hoTen} là người lớn`);
            adultCount++; // Tăng đếm người lớn
          }
        });
        // Cập nhật state với số lượng người lớn và trẻ em cho từng cartId
        setPeopleList(prevState => ({
          ...prevState,
          [cartId]: { adultCount, childCount }
        }));
        // Log số lượng người lớn và trẻ em
        console.log(`Số người lớn: ${adultCount}`);
        console.log(`Số trẻ em: ${childCount}`);
      })
      .catch((error) => {
        console.error("Có lỗi khi lấy danh sách người đi cùng:", error);
      });
  };

  // Hàm tính tuổi từ ngày sinh
  const calculateAge = (birthDate) => {
    const today = new Date();
    let age = today.getFullYear() - birthDate.getFullYear();
    const monthDifference = today.getMonth() - birthDate.getMonth();

    // Nếu chưa đến sinh nhật trong năm nay, giảm tuổi xuống 1
    if (monthDifference < 0 || (monthDifference === 0 && today.getDate() < birthDate.getDate())) {
      age--;
    }
    return age;
  };

  const formatDate = (dateString) => {
    const date = new Date(dateString);
    const day = String(date.getDate()).padStart(2, '0');  // Lấy ngày và bổ sung số 0 nếu cần
    const month = String(date.getMonth() + 1).padStart(2, '0'); // Lấy tháng và bổ sung số 0 nếu cần
    const year = date.getFullYear();
    return `${year}-${month}-${day}`; // Trả về ngày theo định dạng dd-mm-yyyy
  };

  return (
    <div className="container mx-auto p-6 mb-8 bg-white rounded-lg shadow-md mt-44">
      <h2 className="text-left text-3xl font-bold mb-4 text-gray-800">GIỎ HÀNG CỦA BẠN</h2>
      <p className="text-left mb-6 text-gray-600">Giỏ hàng của bạn ({cartDetails.length} tour)</p>

      <div className="overflow-x-auto">
        <table className="table-auto w-full border-collapse border border-gray-300 mb-6">
          <thead>
            <tr className="bg-gray-200 text-gray-700">
              <th className="border border-gray-300 px-4 py-2">Chọn</th>
              <th className="border border-gray-300 px-4 py-2">Tên Tour</th>
              <th className="border border-gray-300 px-4 py-2">Ngày Khởi hành</th>
              <th className="border border-gray-300 px-4 py-2">Số Người</th>
              <th className="border border-gray-300 px-4 py-2">Tổng tiền</th>
              <th className="border border-gray-300 px-4 py-2">Hành động</th>
            </tr>
          </thead>
          <tbody>
            {cartDetails.map((item) => {
              const peopleCount = PeopleList[item.idChiTietGioHang] || { adultCount: 0, childCount: 0 };
              const totalMoney = (peopleCount.adultCount * item.giaNguoiLon) + (peopleCount.childCount * item.giaTreEm);

              return (
                <tr key={item.idChiTietGioHang}>
                  <td className="border border-gray-300 px-4 py-2 text-center">
                    <input
                      type="radio"
                      name="selectedTour"
                      onChange={() => setSelectedTourId(item.idBienThe)}
                    />
                  </td>
                  <td className="border border-gray-300 px-4 py-2 text-center">{item.tenTour}</td>
                  <td className="border border-gray-300 px-4 py-2 text-center">{formatDate(item.ngayBatDau)}</td>
                  <td className="border border-gray-300 px-4 py-2 text-center">
                    {peopleCount.adultCount + peopleCount.childCount} người
                  </td>
                  <td className="border border-gray-300 px-4 py-2 text-center">
                    {totalMoney.toLocaleString()} VNĐ
                  </td>
                  <td className="border border-gray-300 px-4 py-2 text-center">
                    {/* <button
                      className={`px-3 py-1 rounded ${
                        selectedTourId === item.idBienThe
                          ? "bg-red-500 text-white hover:bg-red-600"
                          : "bg-gray-300 text-gray-500 cursor-not-allowed"
                      }`}
                      onClick={() => handleDelete(item.idChiTietGioHang)}
                      
                      disabled={selectedTourId !== item.idBienThe} // Nút chỉ kích hoạt khi tour được chọn
                    >
                      Xóa
                    </button> */}
                    <button
                      className="px-3 py-1 rounded flex items-center bg-red-500 text-white hover:bg-red-600"
                      onClick={() => handleDelete(item.idChiTietGioHang)}
                    >
                      Xóa
                    </button>

                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      <div className="flex justify-center space-x-4">
        <button
          className="bg-blue-500 text-white px-6 py-2 rounded hover:bg-blue-600"
          onClick={handleContinue}
        >
          Tiếp tục xem tour
        </button>
        <button
          className="bg-green-500 text-white px-6 py-2 rounded hover:bg-green-600"
          onClick={handleBooking}
        >
          Đặt tour
        </button>
      </div>
    </div>
  );
};

export default GioHang;

