import React, { useEffect, useState } from "react";
import { accounts } from "../../../data/accounts";
import { Modal, Input } from "antd";
import axios from "axios";
import { toast } from "react-toastify"; // Import thư viện
import "react-toastify/dist/ReactToastify.css"; // Import CSS của react-toastify
import Select from "../componetns/select";

const ThongTinCaNhan = () => {
  const account = accounts[5];
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isPasswordModalOpen, setIsPasswordModalOpen] = useState(false);
  const [avatar, setAvatar] = useState(account.avatar || "/images/user.png");
  const [user, setUser] = useState(null);
  const [oldPassword, setOldPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [hoTen, setHoTen] = useState("");
  const [email, setEmail] = useState("");
  const [soDienThoai, setSoDienThoai] = useState("");
  // const [matKhau, setMatKhau] = useState("");
  const [gioiTinh, setGioiTinh] = useState("");
  const [namSinh, setNamSinh] = useState("");
  const [diaChi, setDiaChi] = useState("");
  const showInfoModal = () => setIsModalOpen(true);
  const handleInfoOk = () => setIsModalOpen(false);
  const handleInfoCancel = () => setIsModalOpen(false);

  const showPasswordModal = () => setIsPasswordModalOpen(true);
  const handlePasswordOk = () => setIsPasswordModalOpen(false);
  const handlePasswordCancel = () => setIsPasswordModalOpen(false);

  
// Kiểm tra nếu user?.ngaySinh có giá trị hợp lệ trước khi định dạng
const formattedDate = user?.namSinh
  ? new Date(user.namSinh).toLocaleDateString("en-GB")  // Sử dụng "en-GB" để có định dạng dd/MM/yyyy
  : "Chưa có thông tin";

  const userId = localStorage.getItem('id'); // Hoặc sử dụng sessionStorage.getItem('userId')

  useEffect(() => {
    const fetchAccount = async () => {
      if (!userId) {
        console.error("User ID is not defined");
        return;
      }
      try {
        const response = await axios.get(`http://localhost:8080/api/nguoi-dung/${userId}`);
        setUser(response.data);
        
        setHoTen(response.data.hoTen);
        setEmail(response.data.email);
        setSoDienThoai(response.data.soDienThoai);
        setGioiTinh(response.data.gioiTinh ? "Nam" : "Nữ");
        setNamSinh(response.data.namSinh);
        setDiaChi(response.data.diaChi);
        // Thiết lập avatar nếu có
        if (response.data.hinhAnh) {
          setAvatar(response.data.hinhAnh);
        }
        console.log(response.data.hinhAnh)
      } catch (error) {
        console.error("Error fetching account data:", error);
      }
    };

    fetchAccount();
  }, [userId]);

  const validateEmail = (email) => {
    const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
    return emailRegex.test(email);
  };
  const validatePhoneNumber = (phoneNumber) => {
    const phoneRegex = /^(?:\+?(\d{1,3}))?(\d{10})$/; // Kiểm tra số điện thoại Việt Nam
    return phoneRegex.test(phoneNumber);
  };
  const validatePasswordFields = () => {
    if (!oldPassword) {
      toast.error("Mật khẩu không được để trống.");
      return false;
    }
  
    if (!newPassword) {
      toast.error("Mật khẩu mới không được để trống.");
      return false;
    }
  
    if (!confirmPassword) {
      toast.error("Bạn cần xác nhận mật khẩu mới.");
      return false;
    }
  
    if (newPassword !== confirmPassword) {
      toast.error("Mật khẩu mới và xát nhận mật khẩu không khớp!");
      return false;
    }
  
    return true;
  };
  const validateInfoFields = () => {
    if (!hoTen) {
      toast.error("họ tên không được để trống.");
      return false;
    }

    if (!email) {
      toast.error("Email không được để trống.");
      return false;
    } else if (!validateEmail(email)) {
      toast.error("Email không hợp lệ.");
      return false;
    }

    if (!soDienThoai) {
      toast.error("Số điện thoại không được để trống!");
      return false;
    } else if (!validatePhoneNumber(soDienThoai)) {
      toast.error("Số điện thoại không hợp lệ.");
      return false;
    } 
  
    if (!namSinh) {
      toast.error("Năm sinh không được để trống.");
      return false;
    }     // Kiểm tra năm sinh không nằm trong tương lai
    const today = new Date();
    const birthDate = new Date(namSinh);
    if (birthDate > today) {
      toast.error("Ngày sinh không được vượt quá ngày hiện tại.");
      return false;
    }
  
   
    if (!gioiTinh) {
      toast.error("vui lòng chọn giới tính.");
      return false;
    }
    
    if (!diaChi) {
      toast.error("địa chỉ không được để trống.");
      return false;
    }
    
    // if(!matKhau){
    //   toast.error("mật khẩu không được để trống.");
    //   return false;
    // }
    return true;
  };

  const handleAvatarChange = (event) => {
    const file = event.target.files[0];
    if (file) {
        const reader = new FileReader();
        reader.onload = async (e) => {
            const avatar = e.target.result;
            setAvatar(avatar); // Hiển thị ảnh mới
            
            // Gửi dữ liệu avatar lên server
            try {
                await axios.put(`http://localhost:8080/api/cap-nhat-hinh-anh/${userId}`, { hinhAnh: avatar });
                localStorage.setItem("hinhAnh", avatar);
                toast.success("Ảnh đã được cập nhật thành công!");
            } catch (error) {
              toast.error("Có lỗi khi cập nhật ảnh:", error);
            }
        };
        reader.readAsDataURL(file);
    }
};

  const handlePasswordChange = async () => {
    if (!validatePasswordFields()) {
      return;
    }
    try {
      const response =  await axios.put(`http://localhost:8080/api/nguoi-dung/doiMatKhau/${userId}`, {
        oldPassword: oldPassword, // Gửi mật khẩu cũ
        newPassword: newPassword, // Gửi mật khẩu mới
      });
      toast.success(response.data.message);
       // Sau khi cập nhật thành công, gọi lại API để lấy thông tin mới
    const updatedUserResponse = await axios.get(`http://localhost:8080/api/nguoi-dung/${userId}`);
    setUser(updatedUserResponse.data); // Cập nhật state user với dữ liệu mới
    setIsPasswordModalOpen(false);
    } catch (error) {
      if (error.response && error.response.data) {
        // Nếu có lỗi từ backend, hiển thị thông báo lỗi
        toast.error(error.response.data.error);
      } else {
        // Nếu có lỗi không phải từ backend (như lỗi mạng), thông báo lỗi chung
        toast.error("Đã có lỗi xảy ra, vui lòng thử lại.");
      }
    }
  };
  const handleInfoChange = async () => {
    if (!validateInfoFields()) {
      return;
    }
    try {
      const isMale = gioiTinh === "Nam"; // true nếu "Nam", false nếu "Nữ"
      const response = await axios.put(`http://localhost:8080/api/nguoi-dung/capNhatTaiKhoan/${userId}`, {
        hoTen,
        email,
        soDienThoai,
        gioiTinh: isMale,
        namSinh,
        diaChi
        // ,
        // matKhau
      });
      const updatedUserResponse = await axios.get(`http://localhost:8080/api/nguoi-dung/${userId}`);
      setUser(updatedUserResponse.data); // Cập nhật lại state với dữ liệu mới từ API
      console.log("data: ",response.data)
      setIsModalOpen(false);
      toast.success("Cập nhật thông tin thành công!");
    } catch (error) {
      if (error.response && error.response.data) {
        toast.error(error.response.data.message || "Có lỗi xảy ra, vui lòng thử lại.");
      } else {
        toast.error("Có lỗi xảy ra, vui lòng thử lại.");
      }
    }
  }
  return (
    <div className="p-6">
      <div className="rounded-lg bg-white p-6  shadow-md w-[883.11px] mx-auto ">
        {/* Basic Information Section */}
        <div className="border-b pb-4 mb-0 ml-[30px]">
          <h3 className="font-semibold text-lg  text-left">Thông tin cơ bản</h3>

          {/* Avatar Section */}
          <div className="flex items-center justify-between mb-0">
            <span className="text-sm font-medium">Ảnh hồ sơ</span>
            <label htmlFor="avatarInput" className="flex items-center gap-2">
              <img
                src={avatar}
                alt="Avatar"
                className="w-[100px] h-[100px] rounded-full border cursor-pointer"
              />
            </label>
          </div>

          <input
            type="file"
            id="avatarInput"
            style={{ display: "none" }}
            onChange={handleAvatarChange}
            accept="image/*"
          />

          {/* Basic Info */}
          <div className="flex flex-wrap gap-y-2 text-[16px] text-left">
            <div className="w-[35%] font-medium" style={{ color: "#444746" }}>
              Tên
            </div>
            <div className="w-[65%]">{user?.hoTen}</div>
            <div className="w-[35%] font-medium" style={{ color: "#444746" }}>
              Ngày sinh
            </div>
            {/* <div className="w-[65%]">{user?.namSinh}</div> */}
            <div className="w-[65%]">{formattedDate || "Chưa có thông tin"}</div>

            <div className="w-[35%] font-medium" style={{ color: "#444746" }}>
              Giới tính
            </div>
            <div className="w-[65%]">{user && (user.gioiTinh ? "nam" : "nữ")}</div>
            <div className="w-[35%] font-medium" style={{ color: "#444746" }}>
              Địa chỉ
            </div>
            <div className="w-[65%]">{user?.diaChi || "Chưa có thông tin"}</div>
          </div>
        </div>

        {/* Contact Information Section */}
        <div className="ml-[30px]">
          <h3 className="font-semibold text-lg mb-2 text-left ">
            Thông tin liên hệ
          </h3>
          <div className="flex flex-wrap gap-y-2 text-[16px] text-left">
            <div className="w-[35%] font-medium" style={{ color: "#444746" }}>
              Email
            </div>
            <div className="w-[65%]">{user?.email}</div>
            <div className="w-[35%] font-medium" style={{ color: "#444746" }}>
              Điện thoại
            </div>
            <div className="w-[65%]">{user?.soDienThoai || "Chưa có thông tin"}</div>
          </div>
        </div>

        {/* Buttons for editing info and changing password */}
        <div className="flex gap-4 mb-3 mt-10 ml-[30px]" >
          <button
            className="text-white font-medium w-[150px] h-[36px]"
            style={{ backgroundColor: "#3B82F6" }}
            onClick={showInfoModal}
          >
            Sửa thông tin
          </button>
          <button
            className=" text-white font-medium w-[150px] h-[36px]"
            style={{ backgroundColor: "#3B82F6" }}
            onClick={showPasswordModal}
          >
            Đổi mật khẩu
          </button>
        </div>

        {/* Modal Sửa Thông Tin */}
        <Modal
          title="Sửa Thông Tin Cá Nhân"
          open={isModalOpen}
          onOk={handleInfoOk}
          onCancel={handleInfoCancel}
          footer={null}
        >
          <div className="flex flex-col gap-4 items-end text-left">
            <Input
             placeholder="Họ tên"
              value = {hoTen} 
              onChange={(e) => setHoTen(e.target.value)} />
            <Input
             placeholder="Email"
              value = {email} 
              onChange={(e) => setEmail(e.target.value)} />
            <Input
             placeholder="Số điện thoại"
              value = {soDienThoai} 
              onChange={(e) => setSoDienThoai(e.target.value)} />
            <Input
             placeholder="Ngày sinh"
             type="Date"
              value = {namSinh} 
              onChange={(e) => setNamSinh(e.target.value)} />
              <Select
                className="w-full h-[36px] border rounded px-2" // Adjust className as needed
                value={gioiTinh}
                onChange={(e) => setGioiTinh(e.target.value)}
              >
                <option value="">Chọn giới tính</option>
                <option value="Nam">Nam</option>
                <option value="Nữ">Nữ</option>
              </Select>

            <Input
             placeholder="Địa chỉ"
              value = {diaChi} 
              onChange={(e) => setDiaChi(e.target.value)} />
              {/* <Input
              type = "password"
             placeholder="***********"
              value = {matKhau} 
              onChange={(e) => setMatKhau(e.target.value)} /> */}
            <button
              onClick={handleInfoChange}
              className="bg-blue-500 font-medium text-white w-[150px] h-[36px] mt-4"
            >
              Lưu thay đổi
            </button>
          </div>
        </Modal>

        {/* Modal Đổi Mật Khẩu */}
        <Modal
          title="Đổi Mật Khẩu"
          open={isPasswordModalOpen}
          onOk={handlePasswordOk}
          onCancel={handlePasswordCancel}
          footer={null}
        >
          <div className="flex flex-col gap-4 items-end">
            <Input.Password
             placeholder="Mật khẩu cũ"
             value={oldPassword} 
              onChange={(e) => setOldPassword(e.target.value)}  />
            <Input.Password 
            placeholder="Mật khẩu mới"
            value={newPassword} 
            onChange={(e) => setNewPassword(e.target.value)} 
          /> 
            <Input.Password 
            placeholder="Nhập lại mật khẩu mới" 
            value={confirmPassword} 
            onChange={(e) => setConfirmPassword(e.target.value)}/>
            <button
              onClick={handlePasswordChange}
              placeholder="Nhập lại mật khẩu mới" 
              value={confirmPassword} 
              onChange={(e) => setConfirmPassword(e.target.value)}
              className="bg-blue-500 font-medium text-white w-[150px] h-[36px] mt-4"
            >
              Đổi mật khẩu
            </button>
          </div>
        </Modal>
      </div>
    </div>
  );
};

export default ThongTinCaNhan;
