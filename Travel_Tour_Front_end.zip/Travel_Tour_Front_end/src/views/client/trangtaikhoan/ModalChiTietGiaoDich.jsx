import React, { useRef } from "react";
import { Modal, Form, Table } from "antd";
import dayjs from "dayjs";

  const formatCurrency = (value) => {
    return new Intl.NumberFormat("vi-VN", {
      style: "currency",
      currency: "VND",
    }).format(value);
  };

  const convertNumberToWords = (number) => {
    const units = [
      "",
      "Một",
      "Hai",
      "Ba",
      "Bốn",
      "Năm",
      "Sáu",
      "Bảy",
      "Tám",
      "Chín",
    ];
    const tens = [
      "",
      "Mười",
      "Hai Mươi",
      "Ba Mươi",
      "Bốn Mươi",
      "Năm Mươi",
      "Sáu Mươi",
      "Bảy Mươi",
      "Tám Mươi",
      "Chín Mươi",
    ];
    const powers = ["", "nghìn", "triệu", "tỷ", "nghìn tỷ"];

    if (number === 0) return "Không đồng";

    let words = [];
    let unitIndex = 0;

    while (number > 0) {
      let chunk = number % 1000;
      if (chunk > 0) {
        let chunkWords = [];
        let hundred = Math.floor(chunk / 100);
        let ten = Math.floor((chunk % 100) / 10);
        let unit = chunk % 10;

        if (hundred > 0) {
          chunkWords.push(units[hundred] + " Trăm");
        }
        if (ten > 1) {
          chunkWords.push(tens[ten]);
          if (unit > 0) {
            chunkWords.push(units[unit]);
          }
        } else if (ten === 1) {
          chunkWords.push("Mười");
          if (unit > 0) {
            chunkWords.push(units[unit]);
          }
        } else if (unit > 0) {
          chunkWords.push(units[unit]);
        }

        chunkWords.push(powers[unitIndex]);
        words.unshift(chunkWords.join(" ").trim());
      }

      number = Math.floor(number / 1000);
      unitIndex++;
    }

    return words.join(" ").trim() + " đồng";
  };

export const ModalChiTietGiaoDich = ({ isVisible, onClose, nguoiDiCung }) => {
  console.log("huy: ", nguoiDiCung[0]?.trangThai);
  console.log("nguoiDiCung bên chi tiết", nguoiDiCung)
  // console.log("nguoiDiCung bên chi tiết", nguoiDiCung[0].phuongThucThanhToan)
  const contentRef = useRef(null);


  return (
    <div>
      <Modal
        title="Chi Tiết Thông Tin Tour"
        visible={isVisible}
        onCancel={onClose}
        footer={null}
        width={900}
      >
        <hr />
        <div ref={contentRef}>
          <Form layout="vertical">
            <div className="row">
              <div
                className="col-lg-12"
                style={{ fontSize: "18px", color: "blue" }}
              >
                <strong className="Ten-Tour">{nguoiDiCung[0]?.tenTour}</strong>
              </div>
              <div className="col-lg-3">
                <Form.Item label="Ngày đặt">
                  <h6>{dayjs(nguoiDiCung[0]?.ngayDat).format("DD-MM-YYYY")}</h6>
                </Form.Item>
              </div>
              <div className="col-lg-3">
                <Form.Item label="Ngày Bắt đầu">
                  <h6>{dayjs(nguoiDiCung[0]?.ngayBatDau).format("DD-MM-YYYY")}</h6>
                </Form.Item>
              </div>

              <div className="col-lg-3">
                <Form.Item label="Trạng Thái">
                  <h6
                    style={{
                      color: nguoiDiCung[0]?.trangThai ? "green" : "red",
                    }}
                  >
                    {nguoiDiCung[0]?.trangThai
                      ? "Đã thanh toán"
                      : "Đã hủy"}
                  </h6>
                </Form.Item>
              </div>
              <div className="col-lg-3">
                <Form.Item label="Phương thức thanh toán">
                  <h6
                    style={{
                      color: nguoiDiCung[0]?.phuongThucThanhToan ? "orange" : "blue",
                    }}
                  >
                    {nguoiDiCung[0]?.phuongThucThanhToan
                      ? "Thanh toán tiền mặt"
                      : "Thanh toán Online"}
                  </h6>
                </Form.Item>
              </div>
            </div>
            <div style={{ fontSize: '17px', fontWeight: 'bold', color: '#007bff', marginBottom: '20px' }}>
              Danh Sách Hàng Khách Đi Cùng
            </div>            <Table
              dataSource={nguoiDiCung}
              bordered
              size="middle"
              scroll={{ x: 700 }}
              pagination={false}
            >
               <Table.Column
                title="STT"
                key="stt"
                render={(text, record, index) => index + 1} 
                width={40}
              />
              <Table.Column
                title="Họ Tên"
                dataIndex="hoTen"
                key="hoTen"
                width={100}
              />
              <Table.Column
                title="Email"
                dataIndex="email"
                key="email"
                width={100}
              />
              <Table.Column
                title="Số điện thoại"
                dataIndex="soDienThoai"
                key="soDienThoai"
                width={100}
              />
              <Table.Column
                title="Năm Sinh"
                dataIndex="namSinh"
                key="namSinh"
                width={100}
                render={(text) => dayjs(text).format("DD-MM-YYYY")}  
              />
            </Table>
            <div className="col-lg-12" style={{ display: 'flex', justifyContent: 'flex-end' }}>
              <Form.Item className="tong mt-2" label="Tổng tiền" 
              >
                <strong style={{ color: "red" }}>
                  {/* {formatCurrency(nguoiDiCung[0]?.tongTien)} */}
                  {new Intl.NumberFormat('vi-VN').format(nguoiDiCung[0]?.tongTien)} <span>VNĐ</span>

                </strong>
              </Form.Item>
            </div>

            <div className="col-lg-12">
              <Form.Item>
                <i> Viết bằng chữ: </i>
                {convertNumberToWords(nguoiDiCung[0]?.tongTien)} <br />
              </Form.Item>
            </div>
          </Form>
        </div>
      </Modal>
    </div>
  );
};

export default ModalChiTietGiaoDich;
