import React from "react";

const MaGiamGia = () => {
  return (
    <div className="p-4 border rounded-lg bg-white text-left">
      <h2 className="text-xl font-semibold ">Thông tin cá nhân</h2>
      <div>Họ tên: Hau Hong Hau Hau</div>
      <div>Số điện thoại: 0945734630</div>
      <div>Ngày sinh: 30/11/-0001</div>
      <div>Giới tính: Nam</div>
      <div>Email: hauhong39@gmail.com</div>
    </div>
  );
};

export default MaGiamGia;
