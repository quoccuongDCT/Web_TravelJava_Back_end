// import React, { useEffect } from "react";
// import { IoDocumentText } from "react-icons/io5";
// import { FaTruck, FaHistory, FaBarcode } from "react-icons/fa";
// import { Link, Outlet, useLocation, Navigate } from "react-router-dom";

// export const TrangTaiKhoan = () => {
//   const location = useLocation();
//   const { pathname } = location;
//   const isActive = (path) =>
//     pathname.includes(path) ? "text-blue-400 " : "text-black";

//   // Kiểm tra nếu đang ở đường dẫn tài khoản mà không ở đường dẫn con
//   const isAccountPage = pathname === "/trang-tai-khoan";
//   const isChildPage = pathname.includes("/trang-tai-khoan/");

//   return (
//     <div className="container mx-auto flex flex-col mt-[100px] p-[16px] ">
//       <div className="w-[100%]">
//         <div className="flex items-center flex-row gap-1 mt-4 p-[16px]">
//           <Link
//             to="thong-tin-ca-nhan"
//             className={`w-[324px] h-[60px] flex p-4 gap-4 no-underline hover:!text-blue-400 items-center ${isActive(
//               "thong-tin-ca-nhan"
//             )}`}
//           >
//             <IoDocumentText style={{ width: 20, height: 20 }} />
//             <span> Hồ sơ cá nhân</span>
//           </Link>

//           <Link
//             to="tra-cuu-don-hang"
//             className={`w-[324px] h-[60px] flex p-4 gap-4 no-underline hover:!text-blue-400 items-center ${isActive(
//               "tra-cuu-don-hang"
//             )}`}
//           >
//             <FaTruck style={{ width: 20, height: 20 }} />
//             <span> Tra cứu đơn hàng</span>
//           </Link>

//           <Link
//             to="lich-su-giao-dich"
//             className={`w-[324px] h-[60px] flex p-4 gap-4 no-underline hover:!text-blue-400 items-center ${isActive(
//               "lich-su-giao-dich"
//             )}`}
//           >
//             <FaHistory style={{ width: 20, height: 20 }} />
//             <span> Lịch sử giao dịch</span>
//           </Link>

//           <Link
//             to="ma-giam-gia"
//             className={`w-[324px] h-[60px] flex p-4 gap-4 no-underline hover:!text-blue-400 items-center ${isActive(
//               "ma-giam-gia"
//             )}`}
//           >
//             <FaBarcode style={{ width: 20, height: 20 }} />
//             <span> Mã giảm giá</span>
//           </Link>
//         </div>
//       </div>
//       <div className="">
//         {isAccountPage && !isChildPage && (
//           <Navigate to="thong-tin-ca-nhan" replace />
//         )}
//         <Outlet />
//       </div>
//     </div>
//   );
// };

// export default TrangTaiKhoan;
import React, { useEffect } from "react";
import { IoDocumentText } from "react-icons/io5";
import { FaHistory } from "react-icons/fa";
import { Link, Outlet, useLocation, Navigate,useNavigate  } from "react-router-dom";

export const TrangTaiKhoan = () => {
  const location = useLocation();
  const { pathname } = location;
  const isActive = (path) =>
    pathname.includes(path) ? "text-blue-400 " : "text-black";
  const navigate = useNavigate(); // Hook để điều hướng
  useEffect(() => {
    // Kiểm tra thông tin đăng nhập, ví dụ thông qua localStorage
    const user = localStorage.getItem("hoTen"); // hoặc sessionStorage nếu dùng sessionStorage
    console.log("Kiểm tra giá trị hoTen từ localStorage:", user); // Debug để xem giá trị lưu trong localStorage

    // Nếu không có user trong localStorage, điều hướng về trang đăng nhập
    if (!user) {
      navigate("/dangNhap"); // Điều hướng sử dụng useNavigate của React Router
    }

  }, [navigate]);


  // Kiểm tra nếu đang ở đường dẫn tài khoản mà không ở đường dẫn con
  const isAccountPage = pathname === "/trang-tai-khoan";
  const isChildPage = pathname.includes("/trang-tai-khoan/");
// Nếu chưa đăng nhập, điều hướng về trang đăng nhập

  return (
    <div className="container mx-auto flex flex-col mt-[100px] p-[16px] ">
      <div className="w-[100%]">
        <div className="flex items-center flex-row gap-1 mt-4 p-[16px]">
          <Link
            to="thong-tin-ca-nhan"
            className={`w-[224px] h-[60px] flex p-4 gap-4 no-underline hover:!text-blue-400 items-center ${isActive(
              "thong-tin-ca-nhan"
            )}`}
          >
            <IoDocumentText style={{ width: 20, height: 20 }} />
            <span> Hồ sơ cá nhân</span>
          </Link>

          {/* <Link
            to="tra-cuu-don-hang"
            className={`w-[324px] h-[60px] flex p-4 gap-4 no-underline hover:!text-blue-400 items-center ${isActive(
              "tra-cuu-don-hang"
            )}`}
          >
            <FaTruck style={{ width: 20, height: 20 }} />
            <span> Tra cứu đơn hàng</span>
          </Link> */}

          <Link
            to="lich-su-giao-dich"
            className={`w-[300px] h-[60px] flex p-4 gap-4 no-underline hover:!text-blue-400 items-center ${isActive(
              "lich-su-giao-dich"
            )}`}
          >
            <FaHistory style={{ width: 20, height: 20 }} />
            <span> Lịch sử đặt tour</span>
          </Link>

          {/* <Link
            to="ma-giam-gia"
            className={`w-[324px] h-[60px] flex p-4 gap-4 no-underline hover:!text-blue-400 items-center ${isActive(
              "ma-giam-gia"
            )}`}
          >
            <FaBarcode style={{ width: 20, height: 20 }} />
            <span> Mã giảm giá</span>
          </Link> */}
        </div>
      </div>
      <div className="">
        {isAccountPage && !isChildPage && (
          <Navigate to="thong-tin-ca-nhan" replace />
        )}
        <Outlet />
      </div>
    </div>
  );
};

export default TrangTaiKhoan;

