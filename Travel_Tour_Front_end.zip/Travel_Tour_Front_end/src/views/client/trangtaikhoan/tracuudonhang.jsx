import React, { useState, useEffect } from "react";
import { Input, Table } from "antd";
import axios from "axios";

const TraCuDonHang = () => {
  const [searchValue, setSearchValue] = useState("");
  const [orders, setOrders] = useState([]);
  const [filteredOrders, setFilteredOrders] = useState([]);

  useEffect(() => {
    const userId = Number(localStorage.getItem("id"));
    if (userId) {
      axios
        .get("http://localhost:8080/api/hoadon/user", {
          params: { userId },
        })
        .then((response) => {
          const data = response.data.map((hoaDon) => ({
            orderID: "DH" + hoaDon.id,
            date: new Date(hoaDon.ngayThanhToan).toLocaleDateString("vi-VN"),
            status: hoaDon.trangThai ? "Đã thanh toán" : "Chưa thanh toán",
            totalAmount: hoaDon.tongTien,
            paymentMethod: hoaDon.phuongThucThanhToan ? "Thẻ" : "Tiền mặt",
          }));
          setOrders(data);
          setFilteredOrders(data);
        })
        .catch((error) => {
          console.error("Error fetching orders:", error);
        });
    }
  }, []);

  const handleSearch = () => {
    const filtered = orders.filter((order) =>
      order.orderID.toLowerCase().includes(searchValue.toLowerCase())
    );
    setFilteredOrders(filtered);
  };

  const handleKeyUp = (e) => {
    if (e.key === "Enter") {
      handleSearch();
    }
  };

  const columns = [
    {
      title: "Mã Đơn Hàng",
      dataIndex: "orderID",
      key: "orderID",
    },
    {
      title: "Ngày Đặt",
      dataIndex: "date",
      key: "date",
    },
    {
      title: "Trạng Thái",
      dataIndex: "status",
      key: "status",
    },
    {
      title: "Tổng Tiền",
      dataIndex: "totalAmount",
      key: "totalAmount",
    },
    {
      title: "Phương Thức Thanh Toán",
      dataIndex: "paymentMethod",
      key: "paymentMethod",
    },
  ];

  return (
    <div className="flex flex-row gap-10 w-[100%] text-left mx-auto p-4 border-b rounded-lg shadow-md">
      <div className="flex flex-col gap-4 w-[20%]">
        <span className="text-blue-400 text-[18px] uppercase">
          Tra cứu theo mã đơn hàng
        </span>
        <div className="flex flex-col gap-4 mb-8">
          <span className="text-[16px] uppercase">Mã đơn hàng</span>
          <Input
            value={searchValue}
            onChange={(e) => setSearchValue(e.target.value)}
            onKeyUp={handleKeyUp}
            placeholder="Nhập mã đơn hàng"
          />
          <button
            className="bg-blue-400 font-medium text-white w-[153px] h-[36px]"
            onClick={handleSearch}
          >
            Kiểm tra
          </button>
        </div>
      </div>
      <div className="w-[80%]">
        <span className="text-blue-400 text-[18px] uppercase mb-4">
          Danh sách đơn hàng
        </span>
        <Table
          dataSource={filteredOrders}
          columns={columns}
          rowKey="orderID"
          pagination={{ pageSize: 7 }}
        />
      </div>
    </div>
  );
};

export default TraCuDonHang;
