import React, { useEffect, useState } from "react";
import axios from "axios";
import { Table, Pagination, Modal, Form, Input, Button, Space } from "antd";
import { EyeTwoTone } from "@ant-design/icons";
import { toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import ModalChiTietGiaoDich from "./ModalChiTietGiaoDich";

const LichSuGiaoDich = () => {
  const [danhSachGiaoDich, setDanhSachGiaoDich] = useState([]);
  const [trangThaiTimKiem, setTrangThaiTimKiem] = useState("");
  const [tenTourTimKiem, setTenTourTimKiem] = useState("");
  const [soLuongXem, setSoLuongXem] = useState(10);
  const [trangHienTai, setTrangHienTai] = useState(1);
  const [userID] = useState(localStorage.getItem("id"));
  const [idGiaoDichChon, setIdGiaoDichChon] = useState(null);
  const [nguoiDiCung, setNguoiDiCung] = useState([]);
  const [isModalVisible, setIsModalVisible] = useState(false);
  const [isModalVisibleChiTiet, setIsModalVisibleChiTiet] = useState(false);
  const showModal = () => setIsModalVisibleChiTiet(true);
  const closeModal = () => setIsModalVisibleChiTiet(false);
  const [form] = Form.useForm(); // Tạo form Ant Design



  const handleXemChiTiet = async (idGiaoDich) => {
    try {
      const response = await axios.get(
        `http://localhost:8080/api/danhsachnguoidicung/${idGiaoDich}?userId=${userID}`
      );
      console.log("danh sách data: ", response.data);
      setNguoiDiCung(response.data);
      setIdGiaoDichChon(idGiaoDich);
      showModal(true);
    } catch (error) {
      console.error("Lỗi khi lấy danh sách người đi cùng:", error);
    }
  };

  // -------------------------------------------------
   const layDanhSachGiaoDich = async () => {
    try {
      const response = await axios.get(
        `http://localhost:8080/api/lich-su-dat-tour/${userID}`
      );
      console.log("danh sách đặt tour: ", response.data);
      setDanhSachGiaoDich(response.data);
    } catch (error) {
      console.error("Lỗi khi lấy dữ liệu giao dịch:", error);
    }
  };

  useEffect(() => {
    if (userID) {
      layDanhSachGiaoDich();
    }
  }, [userID]);
  const handleHuyHoaDon = async (chiTietHoaDonId, cancelReason) => {
    try {
      const response = await axios.post(
        "http://localhost:8080/api/huy",
        { chiTietHoaDonId, cancelReason },
        { headers: { "Content-Type": "application/json" } }
      );
      console.log("Hủy hóa đơn thành công:", response.data);
      console.log("cancelReason", cancelReason);
      toast.success(response.data);
      layDanhSachGiaoDich(); // Cập nhật danh sách sau khi hủy
      setIsModalVisible(false); // Đóng modal sau khi hủy
    } catch (error) {
      toast.error(error.response?.data || "Lỗi khi hủy hóa đơn.");
    }
  };
  

  // const dongModal = () => {
  // setIsModalVisible(false); // Đóng modal
  // };
  
  // const dinhDangNgay = (date) => {
  //   const d = new Date(date);
  //   const day = String(d.getDate()).padStart(2, "0");
  //   const month = String(d.getMonth() + 1).padStart(2, "0"); // Month is 0-based
  //   const year = d.getFullYear();
  //   return `${day}/${month}/${year}`;
  // };

  const giaoDichLoc = danhSachGiaoDich
  .filter((giaoDich) => {
    const idMatch = giaoDich.tenTour?.toString().toLowerCase().includes(tenTourTimKiem.toLowerCase());
    const statusMatch = trangThaiTimKiem
      ? giaoDich.trangThai
        ? "Đã thanh toán" === trangThaiTimKiem
        : "Đã hủy" === trangThaiTimKiem
      : true;
    return idMatch && statusMatch;
  })
  .sort((a, b) => {
    return b.id - a.id; // Sắp xếp giảm dần theo id
  });


  const viTriBatDau = (trangHienTai - 1) * soLuongXem;
  const giaoDichHienThi = giaoDichLoc.slice(viTriBatDau, viTriBatDau + soLuongXem);

  const columns = [
    {
      title: "STT",
      dataIndex: "id",
      key: "id",
      render: (text, record, index) => <span className="text-center w-full block">{index + 1}</span>,

    },
    {
      title: "Tên tour",
      dataIndex: "tenTour",
      key: "tenTour",
      render: (text) => <span>{text}</span>,
    },
    {
      title: "Số lượng người",
      dataIndex: "soLuongNguoi",
      key: "soLuongNguoi",
      render: (text) => <span className="text-center w-full block">{text}</span>,
    },
    {
      title: "Tổng tiền",
      dataIndex: "thanhTien",
      key: "thanhTien",
      render: (text) => <span className="text-red-500 font-bold">{text?.toLocaleString()} ₫</span>,
    },
    {
      title: "Trạng thái",
      dataIndex: "trangThai",
      key: "trangThai",
      render: (text) => (
        <span className={text ? "text-green-500 font-bold" : "text-red-500 font-bold"}>
          {text ? "Đã thanh toán" : "Đã hủy"}
        </span>
      ),
    },    
    {
      title: "Phương thức thanh toán",
      dataIndex: "phuongThucThanhToan",
      key: "phuongThucThanhToan",
      render: (text) => (
        <span
          className={text ? "text-orange-500 font-medium" : "text-blue-500 font-medium"}
        >
          {text ? "Thanh toán tiền mặt" : "Thanh toán Online"}
        </span>
      ),
    },
    {
      title: "",
      key: "action",
      render: (text, record) => (
        <Space size="middle">
          {/* Nút Chi tiết */}
          <Button
            icon={<EyeTwoTone />}
            onClick={() => {
              handleXemChiTiet(record.id);
            }}
            nguoiDiCung={nguoiDiCung}
          />
          
          {/* Nút Hủy (chỉ hiển thị khi trạng thái là true) */}
          {record.trangThai && (
            <button
              onClick={() => {
                setIdGiaoDichChon(record.id); // Set the selected transaction ID
                setIsModalVisible(true); // Show the modal
              }}
              className="px-4 py-2 bg-red-500 text-white rounded hover:bg-red-700"
            >
              Hủy
            </button>
          )}
        </Space>
      ),
    },
    
    
  ];

  return (
    <div className="rounded-lg text-left border-b shadow-md p-[16px]">
      <h2 className="text-xl font-semibold mb-4">Lịch sử đặt tour</h2>

      <div className="flex justify-between items-center mb-4">
        <div className="flex items-center gap-2">
          <label htmlFor="soLuongXem" className="text-sm">
            Xem mục:
          </label>
          <select
            id="soLuongXem"
            value={soLuongXem}
            onChange={(e) => setSoLuongXem(parseInt(e.target.value))}
            className="border rounded px-2 py-1"
          >
            <option value={10}>10</option>
            <option value={25}>25</option>
            <option value={50}>50</option>
            <option value={100}>100</option>
          </select>
        </div>
        <div className="flex justify-end items-center gap-4">
          <div className="flex items-center">
            <input
              type="text"
              value={tenTourTimKiem}
              onChange={(e) => setTenTourTimKiem(e.target.value)}
              placeholder="Tìm kiếm theo tên tour"
              className="border rounded px-4 py-2 w-[220px] overflow-hidden text-ellipsis whitespace-nowrap"
            />
          </div>

          <div className="flex items-center">
            <select
              value={trangThaiTimKiem}
              onChange={(e) => setTrangThaiTimKiem(e.target.value)}
              className="border rounded px-2 py-1 h-[41.6px]"
            >
              <option value="">Trạng thái</option>
              <option value="Đã thanh toán">Đã thanh toán</option>
              <option value="Đã hủy">Đã hủy</option>
            </select>
          </div>
        </div>
      </div>

      <Table
        columns={columns}
        dataSource={giaoDichHienThi}
        pagination={false}
        rowKey="id"
      />
    <Modal
        title="Nhập lý do hủy tour"
        visible={isModalVisible}
        onCancel={() => {
          setIsModalVisible(false);
          form.resetFields(); // Reset form khi đóng modal
        }}
        footer={null}
      >
        <Form
          form={form}
          onFinish={(values) =>
            handleHuyHoaDon(idGiaoDichChon, values.cancelReason)
          }
        >
          <Form.Item
            label="Lý do hủy"
            name="cancelReason"
            rules={[
              { required: true, message: "Vui lòng nhập lý do hủy tour!" },
            ]}
          >
            <Input.TextArea rows={4} />
          </Form.Item>
          <Form.Item>
            <Button type="primary" htmlType="submit" className="w-full">
              Hủy Tour
            </Button>
          </Form.Item>
        </Form>
      </Modal>
      <Pagination
        current={trangHienTai}
        pageSize={soLuongXem}
        total={giaoDichLoc.length}
        onChange={(page) => setTrangHienTai(page)}
      />
      <ModalChiTietGiaoDich
        isVisible={isModalVisibleChiTiet}
        onClose={closeModal}
        nguoiDiCung={nguoiDiCung}
      />
    </div>
  );
};

export default LichSuGiaoDich;
