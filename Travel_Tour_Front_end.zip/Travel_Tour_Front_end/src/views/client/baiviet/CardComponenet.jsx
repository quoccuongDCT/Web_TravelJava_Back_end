import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import axios from "axios";
import { storage } from "./js/firebase"; 
import { ref, getDownloadURL } from "firebase/storage";

const BlogGrid = () => {
  const [articles, setArticles] = useState([]);

  useEffect(() => {
    const fetchArticles = async () => {
      try {
        const response = await axios.get("http://localhost:8080/api/bai-viet");
        const articlesData = response.data;

        // Lấy URL của ảnh từ Firebase Storage cho mỗi bài viết
        const articlesWithImages = await Promise.all(
          articlesData.map(async (article) => {
            try {
              const imageRef = ref(storage, article.hinhAnh); // Sử dụng hinhAnh để lấy đường dẫn ảnh
              const imageUrl = await getDownloadURL(imageRef);
              return { ...article, imageUrl };
            } catch (error) {
              console.error("Error fetching image URL:", error);
              return { ...article, imageUrl: "" }; // Nếu không lấy được URL, để trống
            }
          })
        );

        setArticles(articlesWithImages);
      } catch (error) {
        console.error("Error fetching articles:", error);
      }
    };

    fetchArticles();
  }, []);

  const latestArticles = articles
    .sort((a, b) => new Date(b.date) - new Date(a.date))
    .slice(0, 4);

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold">Bài viết</h2>
        <Link
          to="/bai-viet"
          className="text-gray-600 hover:text-gray-900 transition-colors border no-underline w-[133px] h-[49px] rounded-3xl flex items-center justify-center font-medium"
        >
          Xem tất cả
        </Link>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {latestArticles.map((post) => (
          <div key={post.id} className="bg-white rounded-lg shadow-md overflow-hidden">
            <Link to={`/chi-tiet-bai-viet/${post.id}`}>
              <img
                src={post.imageUrl || "/path/to/default/image.jpg"} // Hiển thị ảnh mặc định nếu không có URL
                alt={post.tieuDe}
                className="w-full h-48 object-cover"
              />
            </Link>
            <div className="p-4 text-left">
              <div className="flex justify-between items-center text-sm text-gray-600 mb-2">
                <span>{post.ngayDang}</span>
              </div>
              <h3 className="font-semibold text-lg mb-2 line-clamp-2">{post.tieuDe}</h3>
              <p className="text-gray-600 text-sm line-clamp-3">{post.moTa}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default BlogGrid;
