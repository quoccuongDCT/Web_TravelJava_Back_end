import React from "react";
import BaiVietMoi from "./baivietmoi";

export const BaiVietBlog = () => {
  return (
    <div>
      <div>
        <BaiVietMoi />
      </div>
    </div>
  );
};

export default BaiVietBlog;
