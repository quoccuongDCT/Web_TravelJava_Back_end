import React from "react";

export const ChuDeThinhHanh = () => {
  const section = [
    {
      id: 1,
      title: "Garden",
      postCount: 13,
      url: "/images/th_1.webp",
    },
    {
      id: 2,
      title: "Jewelry",
      postCount: 16,
      url: "/images/th_2.webp",
    },
    {
      id: 3,
      title: "Industrial",
      postCount: 15,
      url: "/images/th_3.webp",
    },
    {
      id: 4,
      title: "Tools",
      postCount: 13,
      url: "/images/th_4.webp",
    },
    {
      id: 5,
      title: "Automotive",
      postCount: 16,
      url: "/images/th_5.webp",
    },
  ];

  return (
    <div>
      <div className=" rounded-2xl max-w-[415px] max-h-[513px] bg-gray-100">
        <div className="p-[20px] border-b">
          <div className="flex justify-between items-center h-[28px]">
            <span>
              ✨<b>Chủ đề thịnh hành</b>
            </span>
            <span>Xem tất cả</span>
          </div>
        </div>
        <div className="max-h-[513px]">
          <div className="flex flex-col">
            {section.map((section) => (
              <button
                key={section.id}
                className="p-[20px] flex items-center border-t bg-gray-100 hover:bg-gray-50"
              >
                <div className="flex gap-2">
                  <div className="w-[48px] h-[48px]">
                    <img
                      src={section.url}
                      alt="Icon"
                      style={{ width: "48px", height: "48px" }} // Sử dụng style để thiết lập kích thước
                      className="inline-block mr-1 rounded-xl"
                    />{" "}
                    {/* Thêm icon */}
                  </div>
                  <div className="flex flex-col">
                    <div>
                      <b>{section.title}</b>
                    </div>
                    <div className="font-sans text-[12px] mt-[2px]">
                      {section.postCount} bài viết
                    </div>
                  </div>
                </div>
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
export default ChuDeThinhHanh;
