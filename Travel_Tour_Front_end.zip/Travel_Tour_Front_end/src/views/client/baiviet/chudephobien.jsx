import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";

export const ChuDePhoBien = () => {
  const [articles, setArticles] = useState([]);

  useEffect(() => {
    // Hàm lấy dữ liệu bài viết từ API
    const fetchArticles = async () => {
      try {
        const response = await fetch("http://localhost:8080/api/bai-viet");
        const data = await response.json();
        setArticles(data);
      } catch (error) {
        console.error("Lỗi khi lấy dữ liệu bài viết:", error);
      }
    };

    fetchArticles();
  }, []);

  return (
    <div className="rounded-2xl max-w-[415px]  bg-gray-100">
      <div className="p-[20px] border-b">
        <div className="flex justify-between items-center h-[28px]">
          <span>
            🎯 <b>Bài viết mới nhất</b>
          </span>
          <Link
            to="/bai-viet"
            className="flex justify-between items-center h-[28px] no-underline"
          >
            Xem tất cả
          </Link>
        </div>
      </div>

      <div className="flex flex-col">
        {articles.slice(0, 7).map((article, index) => ( // Giới hạn 7 bài viết
          <Link
            key={article.id}
            to={`/chi-tiet-bai-viet/${article.id}`}
            className={`p-[20px] flex items-center border-t ${
              index === 6 ? "rounded-b-2xl" : ""
            } bg-gray-100 hover:bg-gray-50`}
            style={{ textDecoration: "none" }}
          >
            <div className="ml-4 flex flex-col text-left">
              <div className="flex items-center">
                <img
                  src={
                    article.nguoiDung?.hinhAnh ||
                    "/path/to/default/user/image.jpg"
                  }
                  alt="User Logo"
                  className="w-[16px] h-[16px] rounded-full mr-1"
                />
                <div className="text-sm text-gray-500 mt-[2px]">
                  {article.nguoiDung?.hoTen || "Người dùng ẩn"} ・{" "}
                  {article.ngayDang
                    ? new Date(article.ngayDang).toLocaleDateString()
                    : "Không rõ ngày"}
                </div>
              </div>
              <div className="font-medium text-gray-900">
                {article.tieuDe || "Không có tiêu đề"}
              </div>
            </div>

            <img
              src={article.hinhAnh || "/path/to/default/image.jpg"}
              alt="Thumbnail"
              className="w-[48px] h-[48px] rounded-md object-cover ml-auto"
            />
          </Link>
        ))}
      </div>
    </div>
  );
};

export default ChuDePhoBien;
