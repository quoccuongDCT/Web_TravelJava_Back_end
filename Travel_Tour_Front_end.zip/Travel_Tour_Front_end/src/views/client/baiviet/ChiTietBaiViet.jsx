import React, { useEffect, useState } from "react";
import { BsFacebook } from "react-icons/bs";
import { FaTwitter } from "react-icons/fa";
import { Swiper, SwiperSlide } from "swiper/react";
import { Navigation, Pagination } from "swiper/modules";
import "swiper/swiper-bundle.css";
import { useParams } from "react-router-dom";
import ChuDePhoBien from "./chudephobien";

const ChiTietBaiViet = () => {
  const { id } = useParams();
  const [article, setArticle] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchArticle = async () => {
      try {
        const response = await fetch(
          `http://localhost:8080/api/bai-viet/${id}`
        );
        if (!response.ok) {
          throw new Error("Bài viết không tồn tại.");
        }
        const data = await response.json();
        setArticle(data);
      } catch (err) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };

    fetchArticle();
  }, [id]);

  if (loading) {
    return <div className="text-center">Loading...</div>;
  }

  if (error) {
    return <div className="text-center text-red-500">{error}</div>;
  }

  const author = article.nguoiDung;

  return (
    <div className="w-[1200px] mx-auto h-auto p-4 mt-[150px] flex gap-14">
      <div className="w-[700px] h-auto">
        <h1 className="text-3xl font-bold mb-2 text-left">{article.tieuDe}</h1>
        <div className="flex justify-between text-sm text-gray-500 mb-4">
          <div className="flex items-center">
            <img
              src={
                article.nguoiDung.hinhAnh || "/path/to/default/user/image.jpg"
              }
              width={"28px"}
              alt="User"
              className="rounded-full object-cover h-[28px] mr-2" 
            />
            Người đăng: {author.hoTen}
          </div>

          <div>
            Ngày đăng: {new Date(article.ngayDang).toLocaleDateString()}
          </div>
        </div>

        <img
          src={article.hinhAnh}
          alt="Bài viết"
          className="w-full h-auto rounded shadow-lg mb-4"
        />

        <section>
          <h2 className="text-2xl font-bold mb-2 text-left">
            Nội dung bài viết
          </h2>
          <div
            className="prose mb-4 text-left border p-4"
            // nội dung bài viết
            dangerouslySetInnerHTML={{ __html: article.noiDung }}
          />
          {Array.isArray(article.video) && article.video.length > 0 && (
            <Swiper
              modules={[Navigation, Pagination]}
              navigation
              pagination={{ clickable: true }}
              className="mySwiper mb-4"
            >
              {article.video.map((video, index) => (
                <SwiperSlide key={index}>
                  <iframe
                    src={video}
                    title={`Video ${index + 1}`}
                    width="100%"
                    height="315"
                    frameBorder="0"
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                    allowFullScreen
                  />
                </SwiperSlide>
              ))}
            </Swiper>
          )}
        </section>

        <div className="flex space-x-4 mb-4">
          <a
            href={`https://www.facebook.com/sharer/sharer.php?u=${window.location.href}`}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center no-underline"
          >
            <BsFacebook
              className="text-blue-600 transition duration-300 mr-1"
              size={24}
            />
            <span>Chia sẻ trên Facebook</span>
          </a>
          <a
            href={`https://twitter.com/share?url=${window.location.href}`}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center no-underline"
          >
            <FaTwitter
              className="text-blue-400 transition duration-300 mr-1"
              size={24}
            />
            <span>Chia sẻ trên Twitter</span>
          </a>
        </div>
      </div>

      <div className="w-[400px] h-auto">
        {/* <h2 className="text-xl font-bold mb-4">Tin tức mới nhất</h2> */}
        <ChuDePhoBien />
      </div>
    </div>
  );
};

export default ChiTietBaiViet;
