import React, { useState, useEffect } from "react";
import axios from "axios";
// import ChuDe from "./chude";
// import ChuDeThinhHanh from "./chudethinhhanh";
import ChuDePhoBien from "./chudephobien";
import { Link } from "react-router-dom";
import { storage } from "./js/firebase";
import { ref, getDownloadURL } from "firebase/storage";

export const BaiVietMoi = () => {
  const [articles, setArticles] = useState([]);
  const [selectedCategory] = useState(null);
  const [currentPage, setCurrentPage] = useState(1);
  const articlesPerPage = 10;

  useEffect(() => {
    const fetchArticles = async () => {
      try {
        const response = await axios.get("http://localhost:8080/api/bai-viet");
        const articlesData = response.data;

        const articlesWithImages = await Promise.all(
          articlesData.map(async (article) => {
            try {
              const imageRef = ref(storage, article.hinhAnh);
              const imageUrl = await getDownloadURL(imageRef);
              return { ...article, imageUrl };
            } catch (error) {
              console.error("Lỗi khi lấy URL hình ảnh:", error);
              return { ...article, imageUrl: "" };
            }
          })
        );

        setArticles(articlesWithImages);
      } catch (error) {
        console.error("Lỗi khi lấy bài viết:", error);
      }
    };

    fetchArticles();
  }, []);

  const filteredArticles = selectedCategory
    ? articles.filter((article) => article.category === selectedCategory)
    : articles;
  const sortedArticles = filteredArticles.sort(
    (a, b) => new Date(b.ngayDang) - new Date(a.ngayDang)
  );

  const totalPages = Math.ceil(filteredArticles.length / articlesPerPage);
  const currentArticles = sortedArticles.slice(
    (currentPage - 1) * articlesPerPage,
    currentPage * articlesPerPage
  );

  // const handleCategoryClick = (category) => {
  //   setSelectedCategory(category);
  // };

  const handlePageChange = (page) => {
    setCurrentPage(page);
  };

  return (
    <div className="max-w-[1248px] mx-auto p-3">
      <div className="pt-[112px] flex justify-between">
        <div className="max-w-[800px] flex flex-col text-left">
          <div className="flex flex-col">
            <span className="text-[36px] max-w-[672px]">
              {selectedCategory
                ? `Danh sách bài viết ${selectedCategory}`
                : "Danh sách bài viết"}
            </span>
            <span className="text-[18px] max-w-[672px] mt-2">
              Khám phá những bài viết mới
            </span>
          </div>

          <div className="flex flex-col no-underline text-black pr-4">
            {currentArticles.map((article) => (
              <div key={article.id} className="flex justify-between pt-4">
                {/* Phần nội dung: cho phép nó chiếm nhiều không gian hơn */}
                <div className="flex flex-col gap-2 p-1 flex-grow justify-between mr-[20px] max-w-[550px]">
                  <Link
                    to={`/chi-tiet-bai-viet/${article.id}`}
                    className="text-left font-bold text-black no-underline line-clamp-2"
                    style={{ maxWidth: "100%" }} // Set max width to 100% for more space
                  >
                    {article.tieuDe}
                  </Link>
                  <Link
                    to={`/chi-tiet-bai-viet/${article.id}`}
                    className="text-left line-clamp-3 h-[72px] no-underline text-black" // Đặt chiều cao cho mô tả để nó có thể dài hơn
                    style={{ maxWidth: "100%" }} // Tăng không gian cho mô tả
                  >
                    {article.moTa}
                  </Link>
                  {article.nguoiDung && (
                    <div className="h-[48px] flex items-center">
                      <img
                        src={
                          article.nguoiDung.hinhAnh ||
                          "/path/to/default/user/image.jpg"
                        }
                        width={"28px"}
                        alt="User"
                        className="rounded-full object-cover h-[28px]"
                      />
                      <div className="ml-2 flex items-center max-w-[527px]">
                        <span className="font-semibold">
                          {article.nguoiDung.hoTen}
                        </span>
                        <span className="ml-1 text-sm text-gray-600">
                          · {new Date(article.ngayDang).toLocaleDateString()}
                        </span>
                      </div>
                    </div>
                  )}
                </div>

                {/* Phần hình ảnh */}
                <div className="rounded-2xl w-[300px] h-[200px] flex-shrink-0 ml-4">
                  {" "}
                  {/* Giảm kích thước hình ảnh */}
                  {article.imageUrl ? (
                    <img
                      src={article.imageUrl}
                      alt="Article"
                      className="w-full h-full object-cover rounded-2xl"
                    />
                  ) : (
                    <img
                      src="/path/to/default/image.jpg"
                      alt="Default"
                      className="w-full h-full object-cover rounded-2xl"
                    />
                  )}
                </div>
              </div>
            ))}
          </div>

          <div className="flex justify-between items-center p-4 mt-5">
            <div className="flex gap-2">
              {[...Array(totalPages)].map((_, index) => (
                <button
                  key={index}
                  onClick={() => handlePageChange(index + 1)}
                  className={`w-11 h-11 flex items-center justify-center rounded-full border ${
                    currentPage === index + 1
                      ? "bg-purple-500 text-white"
                      : "bg-white text-gray-500"
                  }`}
                >
                  {index + 1}
                </button>
              ))}
            </div>
          </div>
        </div>
        <div className="flex flex-col gap-4">
          {/* <ChuDe articles={articles} onCategoryClick={handleCategoryClick} /> */}
          {/* <ChuDeThinhHanh /> */}
          <ChuDePhoBien />
        </div>
      </div>
    </div>
  );
};

export default BaiVietMoi;
