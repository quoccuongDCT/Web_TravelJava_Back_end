import { Modal } from "antd";
import React, { useState } from "react";
import { Link } from "react-router-dom";

export const ChuDe = ({ articles, onCategoryClick }) => {
  // Tính toán các chủ đề và số lượng bài viết trong từng chủ đề
  const categories = articles.reduce((acc, article) => {
    const category = acc.find((c) => c.title === article.category);
    if (category) {
      category.postCount += 1;
    } else {
      acc.push({ title: article.category, postCount: 1 });
    }
    return acc;
  }, []);

  // Sắp xếp chủ đề theo số lượng bài viết giảm dần
  const sortedCategories = categories.sort((a, b) => b.postCount - a.postCount);

  // Chỉ lấy tối đa 12 chủ đề để hiển thị ngoài giao diện
  const displayedCategories = sortedCategories.slice(0, 10);

  const [isModalOpen, setIsModalOpen] = useState(false);

  const showModal = () => {
    setIsModalOpen(true);
  };

  const handleCancel = () => {
    setIsModalOpen(false);
  };

  return (
    <div>
      <>
        {/* Modal hiển thị toàn bộ các chủ đề */}
        <Modal
          title="Tất cả chủ đề"
          open={isModalOpen}
          footer={null}
          onCancel={handleCancel}
          className="max-w-[500px]"
        >
          <div className="grid grid-cols-3 gap-2 bg-gray-100 p-1">
            {sortedCategories.map((category, index) => (
              <button
                key={index}
                onClick={() => {
                  onCategoryClick(category.title); // Gọi hàm chọn chủ đề
                  handleCancel(); // Đóng modal
                }}
                className="py-[10px] px-[16px] bg-white rounded-lg w-full text-left mb-2"
              >
                {category.title} ({category.postCount})
              </button>
            ))}
          </div>
        </Modal>

        {/* Hiển thị tối đa 12 chủ đề ngoài giao diện */}
        <div className="rounded-2xl max-w-[415px] max-h-[359px] bg-gray-100">
          <div className="p-[20px] border-b">
            <div className="flex justify-between items-center h-[28px] ">
              <span>
                🏷{" "}
                <a href="/bai-viet" className="no-underline text-black">
                  Chủ đề liên quan
                </a>
              </span>
              {/* Link xem tất cả để hiển thị Modal với toàn bộ chủ đề */}
              <Link
                onClick={showModal}
                style={{ color: "black", textDecoration: "none" }}
              >
                Xem tất cả
              </Link>
            </div>
          </div>

          {/* Danh sách chủ đề hiển thị bên ngoài */}
          <div className="p-[20px] h-[270px]">
            <div className="flex flex-wrap gap-2">
              {displayedCategories.map((category, index) => (
                <button
                  key={index}
                  onClick={() => {
                    onCategoryClick(category.title); // Gọi hàm chọn chủ đề
                    handleCancel(); // Đóng modal
                  }}
                  className="py-[10px] px-[16px] bg-white rounded-lg"
                >
                  {category.title} ({category.postCount})
                </button>
              ))}
            </div>
          </div>
        </div>
      </>
    </div>
  );
};

export default ChuDe;
