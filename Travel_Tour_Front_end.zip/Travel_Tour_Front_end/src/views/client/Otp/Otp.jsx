import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import "./otp.css";
// import { message } from "react-messageify";
// import "react-messageify/dist/ReactToastify.css";
import { LeftOutlined } from '@ant-design/icons';
import { useLocation } from "react-router-dom";
import { message} from "antd";

const Otp = () => {
  const navigate = useNavigate();
  const [otp, setOtp] = useState(Array(6).fill("")); // Mảng chứa 6 chữ số OTP
  // const email = sessionStorage.getItem("email");
  const [isResending, setIsResending] = useState(false); // Trạng thái để kiểm tra có đang gửi OTP không
  const [waitTime, setWaitTime] = useState(0); // Thời gian chờ trước khi có thể gửi OTP lại
  const location = useLocation();
  const email = location.state?.email; // Lấy email từ state được truyền qua navigate
  console.log("email log: ",email);
  useEffect(() => {
    if (otp.every(digit => digit !== '')) {
      handleSubmit();
    }
  }, [otp]);
  const handleChange = (element, index) => {
    if (!isNaN(element.value)) {
      const newOtp = [...otp];
      newOtp[index] = element.value || ''; // Cập nhật giá trị tại vị trí hiện tại
  
      console.log(`Input value at index ${index}:`, element.value);
      console.log("Updated OTP array after input:", newOtp); // Thêm log để kiểm tra mảng OTP
  
      setOtp(newOtp);
  
      // Chuyển tiêu điểm sang ô tiếp theo nếu có
      if (element.value && element.nextSibling) {
        element.nextSibling.focus();
      }


    }
  };
  
  const resendOtp = async () => {
    if (isResending) {
      message.warning("Đang gửi mã OTP. Vui lòng chờ."); // Thông báo nếu đang gửi
      return;
    }
    try {
      setIsResending(true); // Đặt trạng thái đang gửi
      const response = await fetch("http://localhost:8080/api/resend-otp", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ email }),
      });
  
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message);
      }
  
      const data = await response.json();
      message.success(data.message);
      sessionStorage.setItem("otp", data.otp);
      console.log("Mã OTP đã lưu vào sessionStorage:", data.otp);
      setTimeout(() => {
        sessionStorage.removeItem("otp");
      }, 2 * 60 * 1000); // 2 phút
      // Nếu bạn có thời gian chờ, bạn có thể thiết lập thời gian chờ để gửi lại mã OTP
      setWaitTime(120); // Ví dụ, đặt thời gian chờ là 120 giây
      const interval = setInterval(() => {
        setWaitTime((prev) => {
          if (prev <= 1) {
            clearInterval(interval);
            setIsResending(false); // Kết thúc trạng thái gửi
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    } catch (error) {
      message.error(error.message);
      setIsResending(false);
    }
  };
  const handleSubmit = async (e) => {
    if (e) e.preventDefault(); // Ngăn chặn sự kiện mặc định nếu được gọi từ handleChange
    const otpValue = otp.join(""); // Chuyển mảng thành chuỗi
    console.log("OTP value submitted:", otpValue); // Kiểm tra giá trị OTP
    console.log("OTP array:", otp); // Kiểm tra mảng OTP
     if (otpValue.length < 6) { // Kiểm tra xem có ít hơn 6 ký tự không
      message.error("Vui lòng nhập đủ 6 chữ số OTP.");
      return;
    }
    if (!otpValue) {
      message.error("OTP không được để trống.");
      return;
    }

    try {
      const response = await fetch("http://localhost:8080/api/verify-otp", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ otp: otpValue, email }),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message);
      }

      const data = await response.json();
      message.success(data.message);
      // Xóa OTP và email khỏi sessionStorage
      sessionStorage.removeItem("otp");
      // sessionStorage.removeItem("email");
      setTimeout(() => {
        navigate("/doimatkhau", { state: { email } });
      }, 2000);
    } catch (error) {
      message.error(error.message);
      resetOtp(); // Đặt lại các ô OTP nếu xác thực không thành công
    }
  };

  const resetOtp = () => {
    setOtp(Array(6).fill("")); // Đặt lại mảng OTP về các ô trống
    const firstInput = document.querySelector('input[type="text"]'); // Chọn ô đầu tiên
    if (firstInput) {
      firstInput.focus(); // Đặt tiêu điểm vào ô đầu tiên
      highlightInput(firstInput); // Gọi hàm nháy ô đầu tiên
    }
  };

  const highlightInput = (input) => {
    input.classList.add("highlight"); // Thêm lớp highlight
    setTimeout(() => {
      input.classList.remove("highlight"); // Loại bỏ lớp highlight sau 500ms
    }, 500);
  };

  return (
    <div className="Otp-wrapper">
      <div className="Otp-container">
        <button className="back-button text-left" onClick={() => navigate(-1)}>
          <LeftOutlined /> Quay lại
        </button>
        <br /><br />
        <p>Nhập OTP vừa được gửi tới email</p>
        <p className="email-display">{email}</p>

        <form className="Otp-form" onSubmit={handleSubmit}>
          <div className="otp-inputs">
            {otp.map((_, index) => (
              <input
                key={index}
                type="text"
                maxLength="1"
                value={otp[index]}
                onChange={(e) => handleChange(e.target, index)}
                onFocus={(e) => e.target.select()}
              />
            ))}
          </div>
          <p className="resend-text" style={{ fontSize: '14px' }}>
            {waitTime > 0 
              ? `Bạn cần đợi ${waitTime} giây trước khi gửi lại OTP.` 
              : <span>Bạn chưa nhận được OTP? <b className="resend-link" style={{ textDecoration: 'none', cursor: waitTime > 0 ? 'not-allowed' : 'pointer', color: waitTime > 0 ? 'gray' : 'blue' }} onClick={waitTime > 0 ? null : resendOtp}>Gửi lại</b></span>
            }
          </p>

        </form>
      </div>
    </div>
  );
};

export default Otp;





