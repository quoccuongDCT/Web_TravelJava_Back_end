import React from "react";
import { useLocation, useNavigate } from 'react-router-dom';

const ChiTietBill = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const { customerInfo, passengerInfo, summary, PhuongThucThanhToan } = location.state || {};
  console.log("[ctb]: ", customerInfo);
  console.log("[ctb]: ", passengerInfo);
  console.log("[ctb]: ", summary);
  console.log("PhuongThucThanhToan: ", PhuongThucThanhToan);


  const renderContent = () => {
    return (
      <div className="border rounded-lg shadow-md p-6 bg-white mt-[150px]">
        <div className="flex items-center mb-3">
          <div className="w-[30%] mr-2">
            <h2
              className="text-lg font-semibold text-left"
              style={{
                fontSize: "20px",
                fontFamily: '"Open Sans", sans-serif',
                color: "#0077B6",
              }}
            >
              Thông Tin Khách Hàng
            </h2>
          </div>
          <div className="w-[70%]">
            {/* <div className="h-1 bg-blue-500 w-full mt-2"></div>  */}
          </div>
        </div>

        <div className="space-y-3 mb-5">
          <div className="flex justify-between">
            <div
              className="w-[40%] text-left pl-5 text-base"
              style={{ fontFamily: '"Open Sans", sans-serif', fontSize: "14px" }}
            >
              Họ Tên: {customerInfo.hoTen}
            </div>
            <div
              className="w-[60%] text-left ml-1 text-base"
              style={{ fontFamily: '"Open Sans", sans-serif', fontSize: "14px" }}
            >
              Số điện thoại: {customerInfo.sdt}
            </div>
          </div>
          <div className="flex justify-between">
            <div
              className="w-[40%] text-left pl-5 text-base"
              style={{ fontFamily: '"Open Sans", sans-serif', fontSize: "14px" }}
            >
              Email: {customerInfo.email}
            </div>
            <div
              className="w-[60%] text-left ml-1 text-base"
              style={{ fontFamily: '"Open Sans", sans-serif', fontSize: "14px" }}
            >
              Địa chỉ: {customerInfo.diaChi}
            </div>
          </div>
        </div>

        <div className="flex items-center mb-3">
          <div className="w-[30%] mr-2">
            <h2
              className="text-lg font-semibold text-left"
              style={{
                fontSize: "20px",
                fontFamily: '"Open Sans", sans-serif',
                color: "#0077B6", 
              }}
            >
              Thông Tin Tour
            </h2>
          </div>
          <div className="w-[70%]">
            {/* <div className="h-1 bg-blue-500 w-full mt-2"></div> */}
          </div>
        </div>

        <div className="space-y-3 mb-5">
          <div
            className="text-left pl-5 text-base"
            style={{ fontFamily: '"Open Sans", sans-serif', fontSize: "14px" }}
          >
            Tên tour: <b className="text-red-500">Tour Đà Lạt - Mộng Mơ</b>
          </div>
          <div className="flex justify-between">
            <div
              className="w-[40%] text-left pl-5 text-base"
              style={{ fontFamily: '"Open Sans", sans-serif', fontSize: "14px" }}
            >
              Điểm khởi hành: Hà Nội
            </div>
            <div
              className="w-[60%] text-left ml-1 text-base"
              style={{ fontFamily: '"Open Sans", sans-serif', fontSize: "14px" }}
            >
              Ngày khởi hành: 01/12/2024
            </div>
          </div>
          <div className="flex justify-between">
            <div
              className="w-[40%] text-left pl-5 text-base"
              style={{ fontFamily: '"Open Sans", sans-serif', fontSize: "14px" }}
            >
              Thời gian: 3 ngày 2 đêm
            </div>
            <div
              className="w-[60%] text-left ml-1 text-base"
              style={{ fontFamily: '"Open Sans", sans-serif', fontSize: "14px" }}
            >
              Khách sạn: 5 sao
            </div>
          </div>
        </div>

        <div className="mb-3">
          <h2
            className="text-lg font-semibold text-left"
            style={{
              fontSize: "20px",
              fontFamily: '"Open Sans", sans-serif',
              color: "#0077B6", 
            }}
          >
            Danh Sách Khách Đi Tour
          </h2>
        </div>

        <div className="mt-4 overflow-x-auto w-full">
        <div
              className="w-auto text-right ml-1 text-base"
              style={{ fontFamily: '"Open Sans", sans-serif', fontSize: "14px" }}
            >
             Tổng tiền: <b className="text-red-500">{summary.tong.tongTatCa.toLocaleString()}₫</b>
            </div>
            <table className="min-w-full w-full bg-white border border-gray-300 rounded-lg shadow-sm">
            <thead>
              <tr className="bg-gray-200 text-gray-700">
                <th className="py-2 px-4 border border-gray-300 text-left font-medium">STT</th>
                <th className="py-2 px-4 border border-gray-300 text-left font-medium">Thông tin khách hàng</th>
                <th className="py-2 px-4 border border-gray-300 text-left font-medium">Giá tiền</th>
                <th className="py-2 px-4 border border-gray-300 text-left font-medium">Tổng tiền</th>
              </tr>
            </thead>
            <tbody>
              {passengerInfo.map((passenger, index) => (
                <tr className="hover:bg-gray-100" key={index}>
                  <td className="py-2 px-4 border border-gray-300 text-left">{index + 1}</td>
                  <td className="py-2 px-4 border border-gray-300 text-left">
                    <div>Họ tên: {passenger.hoTen}</div>
                    <div>Giới tính: {passenger.gioiTinh}</div>
                    <div>Loại khách: {passenger.loaiKhach}</div>
                  </td>
                  <td className="py-2 px-4 border border-gray-300 text-left"><b className="text-red-500">{passenger.gia.toLocaleString()}₫</b></td>
                  <td className="py-2 px-4 border border-gray-300 text-left"><b className="text-red-500">{passenger.gia.toLocaleString()}₫</b></td>
                </tr>
              ))}
            </tbody>
          </table>


        </div>

        <div className="flex items-center mb-3 mt-4">
          <div className="w-[30%] mr-2">
            <h2
              className="text-lg font-semibold text-left"
              style={{
                fontSize: "20px",
                fontFamily: '"Open Sans", sans-serif',
                color: "#0077B6",
              }}
            >
              Thông Tin Thanh Toán
            </h2>
          </div>
          <div className="w-[70%]">
            {/* <div className="h-1 bg-blue-500 w-full mt-2"></div>  */}
          </div>
        </div>

        <div className="space-y-3 mb-5">
          <div className="flex justify-between">
            <div
              className="w-[50%] text-left pl-5 text-base"
              style={{ fontFamily: '"Open Sans", sans-serif', fontSize: "14px" }}
            >
              Số lượng khách: {summary.totalCount}
            </div>
            <div
              className="w-[50%] text-left ml-1 text-base"
              style={{ fontFamily: '"Open Sans", sans-serif', fontSize: "14px" }}
            >
              Trạng thái: <b className="text-red-500">Chưa thanh toán</b>
            </div>
          </div>
          <div className="flex justify-between">
            <div
              className="w-[50%] text-left pl-5 text-base"
              style={{ fontFamily: '"Open Sans", sans-serif', fontSize: "14px" }}
            >
              Phương thức thanh toán: <b className="text-red-500">{PhuongThucThanhToan}</b>
            </div>
            <div
              className="w-[50%] text-left ml-1 text-base"
              style={{ fontFamily: '"Open Sans", sans-serif', fontSize: "14px" }}
            >
              Giá trị thanh toán: <b className="text-red-500">{summary.tong.tongTatCa.toLocaleString()}₫</b>
            </div>
          </div>
        </div>
        {/* Nút quay về trang chủ */}
        <div className="flex justify-center mt-6">
          <button
            onClick={() => navigate('/')} // Điều hướng về trang chủ
            className="bg-blue-500 text-white py-2 px-4 rounded-lg hover:bg-blue-700 transition duration-300"
          >
            Quay Về Trang Chủ
          </button>
        </div>
      </div>
    );
  };

  return (
    <div className={`nc-PayPage`}>
      <main className="container mt-24 mb-24 lg:mb-32">
        <div className="max-w-4xl mx-auto">{renderContent()}</div>
      </main>
    </div>
  );
};

export default ChiTietBill;
