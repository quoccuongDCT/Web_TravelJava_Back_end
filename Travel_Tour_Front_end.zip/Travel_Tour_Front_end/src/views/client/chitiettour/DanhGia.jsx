import React, { useEffect, useState } from "react";
import { Spin, message, Button, Form, Input, Rate, Avatar, Upload } from "antd";
import { UploadOutlined } from "@ant-design/icons";
import axios from "axios";
import { storage } from "./js/Config"; // Đảm bảo bạn đã cấu hình Firebase đúng
import { ref, uploadBytes, getDownloadURL } from "firebase/storage";

const DanhGia = ({ id_Tour }) => {
  const [tourData, setTourData] = useState(null);
  const [danhGia, setDanhGia] = useState([]);
  const [loading, setLoading] = useState(true);
  const [rating, setRating] = useState(0);
  const [comment, setComment] = useState("");
  const [userId, setUserId] = useState(null);
  const [fileList, setFileList] = useState([]);
  const [setIsSubmitted] = useState(false); // Trạng thái để ẩn form sau khi gửi

  useEffect(() => {
    const storedUserId = localStorage.getItem("id");
    if (storedUserId) {
      setUserId(storedUserId);
    }

    if (id_Tour) {
      const fetchTourData = async () => {
        try {
          const response = await axios.get(
            `http://localhost:8080/api/tours/chitiet/${id_Tour}`
          );
          setTourData(response.data);
        } catch (error) {
          console.error("Không thể lấy chi tiết tour", error);
          message.error("Failed to load tour data.");
        }
      };

      const fetchDanhGia = async () => {
        try {
          const response = await axios.get(
            `http://localhost:8080/api/danhgia/${id_Tour}`
          );
          setDanhGia(response.data);
        } catch (error) {
          console.error("Không thể tải bình luận", error);
          message.error("Failed to load reviews.");
        } finally {
          setLoading(false);
        }
      };

      fetchTourData();
      fetchDanhGia();
    }
  }, [id_Tour]);

  // Hàm tải ảnh lên Firebase
  const uploadToFirebase = async (file) => {
    const storageRef = ref(storage, `reviews/${file.name}`);
    await uploadBytes(storageRef, file.originFileObj);
    const url = await getDownloadURL(storageRef);
    return url;
  };

  const handleSubmitReview = async () => {
    console.log("ID Tour là: ", id_Tour);
    if (!rating || !comment || !userId || !id_Tour) {
      message.error(
        "Vui lòng chọn đánh giá, nhập bình luận, đảm bảo bạn đã đăng nhập và chọn tour."
      );
      return;
    }

    try {
      const currentDate = new Date();
      const imageUrl =
        fileList.length > 0 ? await uploadToFirebase(fileList[0]) : null;

      const newReview = {
        tour: { id: id_Tour }, // Vẫn là số nguyên
        danhGia: rating,
        moTa: comment,
        nguoiDung: userId,
        ngay: currentDate,
        hinhAnh: imageUrl,
      };

      const response = await axios.post(
        "http://localhost:8080/api/danhgia/them",
        newReview
      );
      console.log("Response:", response.data);

      message.success("Đánh giá của bạn đã được gửi.");

      const updatedDanhGia = await axios.get(
        `http://localhost:8080/api/danhgia/${id_Tour}`
      );
      setDanhGia(updatedDanhGia.data);
      setIsSubmitted(true);
      setRating(0);
      setComment("");
      setFileList([]); // Reset fileList after submission
    } catch (error) {
      console.error("Error during review submission:", error);
      // message.error("Không thể gửi đánh giá.");
    }
  };

  const handleChangeFileList = ({ fileList: newFileList }) => {
    if (newFileList.length > 1) {
      message.error("Bạn chỉ được chọn 1 ảnh.");
    } else {
      setFileList(newFileList);
    }
  };

  const handleRemoveFile = (file) => {
    setFileList(fileList.filter((item) => item.uid !== file.uid));
  };

  if (loading) {
    return <Spin size="large" />;
  }

  if (!tourData) {
    return <div>No tour data available.</div>;
  }

  return (
    <div className="back-group max-w-[1440px] mt-24 mx-auto p-6">
      {/* Chi tiết tour */}
      <div className="tour-details">
        <h2>{tourData.tenTour}</h2>
        <p>{tourData.moTa}</p>
      </div>

      {/* Phần viết đánh giá và chọn sao */}
      {userId && (
        <div className="submit-review mb-8">
          <h3>Đánh giá của bạn</h3>
          <Form>
            <Form.Item label="Chọn đánh giá" style={{ textAlign: "left" }}>
              <Rate value={rating} onChange={setRating} />
            </Form.Item>
            <Form.Item label="Bình luận">
              <Input.TextArea
                value={comment}
                onChange={(e) => setComment(e.target.value)}
                style={{ textAlign: "left", height: "100px" }}
              />
            </Form.Item>
            <Form.Item label="Chọn ảnh" style={{ textAlign: "left" }}>
              <Upload
                listType="picture"
                fileList={fileList}
                onChange={handleChangeFileList}
                onRemove={handleRemoveFile}
                beforeUpload={() => false}
                maxCount={1} // Giới hạn 1 hình ảnh tải lên
              >
                {fileList.length === 0 && (
                  <Button icon={<UploadOutlined />}>Chọn ảnh</Button>
                )}
              </Upload>
            </Form.Item>
            <Button type="primary" onClick={handleSubmitReview}>
              Gửi Đánh Giá
            </Button>
          </Form>
        </div>
      )}

      {/* Hiện các đánh giá của tour */}
      <div className="reviews">
        {danhGia.map((review) => (
          <div key={review.id} className="review-item mb-6 p-4 border-b">
            <div className="flex items-center">
              <Avatar
                src={review.hinhAnh || "https://via.placeholder.com/40"} // Hiện ảnh người dùng
              />
              <div className="ml-4 flex-1">
                <h4 className="font-semibold">
                  {review.hoTen || "Người dùng ẩn danh"}
                </h4>
                <div className="flex justify-between">
                  <Rate disabled value={review.danhGia} />
                  <span className="date">
                    {new Date(review.ngay).toLocaleDateString()}
                  </span>
                </div>
              </div>
            </div>
            <p className="mt-2">{review.moTa || "Chưa có bình luận."}</p>
            {review.hinhAnh && (
              <div className="mt-4">
                <img
                  src={review.hinhAnh}
                  alt="Hình ảnh đánh giá"
                  className="max-w-full h-auto"
                />
                {/* <Image className="max-w-full h-auto" src={review.hinhAnh} alt="Profile" style={{ width: 200, height: 100 }} /> */}
              </div>
            )}
          </div>
        ))}
      </div>

      <style jsx>{`
        .review-item {
          display: flex;
          flex-direction: column;
          padding: 16px;
          border: 1px solid #eaeaea;
          border-radius: 8px;
          margin-bottom: 16px;
          background-color: #fafafa;
        }

        .back-group {
          background-color: #d2dff340;
          border-radius: 20px;
        }
        .review-item .avatar {
          width: 40px;
          height: 40px;
          border-radius: 50%;
        }

        .review-item .info {
          display: flex;
          align-items: center;
          margin-bottom: 8px;
          justify-content: flex-start;
        }

        .review-item .info h4 {
          margin-right: 8px;
          font-size: 16px;
          text-align: left;
        }

        .review-item .info .date {
          margin-left: auto;
          font-size: 12px;
          color: #777;
        }

        .review-item .comment {
          margin-top: 12px;
          text-align: left;
        }

        .review-item img {
          width: 100px;
          height: 100px;
          object-fit: cover;
          border: 2px solid #ddd;
          border-radius: 8px;
          margin-top: 12px;
        }

        .review-item p {
          font-size: 14px;
          line-height: 1.5;
          color: #333;
          text-align: left;
          background-color: white;
          padding: 10px;
        }

        .review-item .rating {
          margin-top: 8px;
        }

        .font-semibold {
          font-size: 15px;
          text-align: left;
        }

        .ant-input-textarea[readonly] {
          background-color: #f5f5f5;
          color: #777;
        }

        .ant-input-textarea[readonly]:hover {
          border-color: #d9d9d9;
        }
      `}</style>
    </div>
  );
};

export default DanhGia;
