import React, { useEffect, useState } from "react";
import axios from "axios";
import { useParams, useNavigate } from "react-router-dom";
import { Tabs, Table, Radio, message, Spin, Tooltip, Modal, Button } from "antd";
import { AiFillPicture } from "react-icons/ai";
import ImageList from "@mui/material/ImageList";
import ImageListItem from "@mui/material/ImageListItem";
import DanhGia from "./DanhGia";
import dayjs from "dayjs";
import isBetween from "dayjs/plugin/isBetween";
import "./ChiTiet.css";
import isSameOrAfter from 'dayjs/plugin/isSameOrAfter';
dayjs.extend(isSameOrAfter);

dayjs.extend(isBetween);
const ChiTietTour = () => {
  const navigate = useNavigate(); // Khởi tạo useNavigate
  const { tourId } = useParams(); // Get tourId from URL
  const [tourData, setTourData] = useState(null); // Initialize as null
  const [selectedTourId, setSelectedTourId] = useState(null);
  const [selectedTourDetail, setSelectedTourDetail] = useState(null);
  const [itinerary, setItinerary] = useState([]);
  const [loading, setLoading] = useState(true); // Loading state
  const [mediatour, setMedatour] = useState(null);
  const [danhGia, setDanhGia] = useState(null);
  const [isPopupOpen, setIsPopupOpen] = useState(false);
  const [userID] = useState(localStorage.getItem("id"));
  const [isModalVisible, setIsModalVisible] = useState(false);

  // Hàm xử lý thay đổi radio
  const handleRadioChange2 = (e, record) => {
    setSelectedTourId(e.target.value);
  };

  // Hàm hiển thị popup khi nhấn vào "Liên Hệ"
  const handleContactClick = () => {
    setIsModalVisible(true); // Hiển thị modal
  };

  // Hàm đóng modal
  const handleCancel = () => {
    setIsModalVisible(false);
  };
  useEffect(() => {
    const fetchTourData = async () => {
      console.log("tourId", tourId);
      try {
        const response = await axios.get(
          `http://localhost:8080/api/mediatour/bymediatour/${tourId}`
        );
        console.log("msg: ", response.data);
        setMedatour(response.data);
      } catch (error) {
        console.error("Error fetching tour data", error);
        // message.error("Failed to load tour data.");
      } finally {
        setLoading(false); // Stop loading state
      }
    };

    fetchTourData();
  }, [tourId]);
  useEffect(() => {
    const fetchTourData = async () => {
      try {
        const response = await axios.get(
          `http://localhost:8080/api/danhgia/${tourId}`
        );
        setDanhGia(response.data);
      } catch (error) {
        console.error("Error fetching tour data", error);
        // message.error("Failed to load tour data.");
      } finally {
        setLoading(false); // Stop loading state
      }
    };

    fetchTourData();
  }, [tourId]);
  useEffect(() => {
    const fetchTourData = async () => {
      try {
        const response = await axios.get(
          `http://localhost:8080/api/tours/chitiet/${tourId}`
        );
        setTourData(response.data);
      } catch (error) {
        console.error("Error fetching tour data", error);
        message.error("Failed to load tour data.");
      } finally {
        setLoading(false); // Stop loading state
      }
    };

    fetchTourData();
  }, [tourId]);
  const renderStars = (stars) => {
    const maxStars = 5; // Assuming a maximum rating of 5 stars
    return Array.from({ length: maxStars }, (_, index) => (
      <span
        key={index}
        style={{ color: index < stars ? "#FFD700" : "#d3d3d3" }}
      >
        ★
      </span>
    ));
  };
  const data = (tourData || []).map((item) => ({
    id: item.id,
    ngayBatDau: item.ngayBatDau,
    giaNguoiLon: item.giaNguoiLon,
    giaTreEm: item.giaTreEm,
    soLuongCon: item.soLuongCon,
    soNgay: item.tour?.soNgay,
    noiDung: item.tour?.noiDung,
    phuongTien: item.phuongTien?.tenPhuongTien,
    danhGiaKhachSan: (
      <div>
        {item.hotels?.tenKhachSan} - {renderStars(item.hotels?.danhGiaKhachSan)}
      </div>
    ),
    tour: item.tour?.diemKhoiHanh,
    loaiTour: item.tour?.loaiTour?.loaiTour,
    hotels: `${item.hotels?.tenKhachSan} - ${item.hotels?.danhGiaKhachSan}`,
    luuTru: item.hotels?.danhGiaKhachSan,
    maTour: item.maTour,
    ghiChu: item.ghiChu,
    tenTour: item.tour?.tenTour,
  }));

  useEffect(() => {
    // Find the first available tour where `soLuongCon` is greater than 0
    const firstAvailableTour = data.find((item) => item.soLuongCon > 0);
    if (firstAvailableTour && !selectedTourId) {
      setSelectedTourId(firstAvailableTour.id); // Select the first available tour by default
      setSelectedTourDetail(firstAvailableTour); // Set detail for the first available tour by default
    }
  }, [data, selectedTourId]);

  // Fetch itinerary based on selected tour ID
  useEffect(() => {
    const fetchItinerary = async () => {
      if (selectedTourId) {
        try {
          const response = await axios.get(
            `http://localhost:8080/api/lichtrinhtour/bybienthetour/${selectedTourId}`
          );
          setItinerary(response.data);
          console.log("sss: ",response.data);
        } catch (error) {
          console.error("Error fetching itinerary:", error);
          message.error("Failed to load itinerary.");
        }
      }
    };

    fetchItinerary();
  }, [selectedTourId]);

  const handleTourSelection = async () => {
    if (!selectedTourId) {
      console.error("No tour selected");
      return;
    }

    const selectedTourData = tourData.find(
      (tour) => tour.id === selectedTourId
    );

    if (!selectedTourData) {
      console.error("Tour data not found");
      return;
    }

    const selectedTour = {
      idNguoiDung: userID, // Id người dùng
      idBienTheTour: selectedTourData.id,
      tongTien: selectedTourData.giaNguoiLon,
      moTa: selectedTourData.maTour,
      soNguoi: 1,
    };
    
    try {
      // Step 1: Check if the tour already exists in ChiTietGioHang
      const checkResponse = await fetch(
        `http://localhost:8080/api/chitietgiohang/check?idNguoiDung=${selectedTour.idNguoiDung}&idBienTheTour=${selectedTour.idBienTheTour}`
      );
      const checkData = await checkResponse.json();

      // If the tour is already in the cart, navigate to the payment page
      if (checkResponse.ok && checkData.exists) {
        message.info("Tour đã có trong giỏ hàng. Chuyển đến trang thanh toán.");
        navigate(`/thanh-toan/${selectedTourData.id}`);
        return;
      }

      // Step 2: If not, proceed to add the tour to ChiTietGioHang
      const response = await fetch(
        "http://localhost:8080/api/chitietgiohang/add",
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify(selectedTour),
        }
      );
      const data = await response.json();
      // Cập nhật số lượng giỏ hàng bằng cách gọi lại API
      const cartResponse = await fetch(
        `http://localhost:8080/api/chitietgiohang/user?idNguoiDung=${selectedTour.idNguoiDung}`
      );
      // Show success popup if the request was successful
      if (response.ok) {
        message.success("Đã thêm vào giỏ hàng thành công!");
        console.log("Tour added to ChiTietGioHang:", data);
        const cartData = await cartResponse.json();
       const cartCount = cartData.length; // Giả sử cartData là một mảng chứa các mục trong giỏ hàng

      // Lưu số lượng giỏ hàng vào sessionStorage
      sessionStorage.setItem('cartCount', cartCount.toString());
        // Navigate to payment page
        navigate(`/thanh-toan/${selectedTourData.id}`);
      } else {
        message.error("Có lỗi xảy ra khi thêm vào giỏ hàng");
      }
    } catch (error) {
      console.error("Error adding tour to ChiTietGioHang:", error);
      message.error("Không thể thêm vào giỏ hàng");
    }
  };

  const handleRadioChange = (e, record) => {
    setSelectedTourId(e.target.value);
    setSelectedTourDetail(record);
  };

  const togglePopup = () => {
    setIsPopupOpen(!isPopupOpen);
  };
  if (loading) {
    return <Spin size="large" />; // Show loading spinner
  }

  if (!tourData) {
    return <div>No tour data available.</div>;
  }
  // hàm chuyển đổi html thành văn bản thuần túy
  const stripHtmlAndShowImages = (html) => {
    const doc = new DOMParser().parseFromString(html, "text/html");

    // Lấy tất cả thẻ img và thay chúng bằng hình ảnh thực tế
    const images = doc.querySelectorAll("img");
    images.forEach((img) => {
      const imageUrl = img.getAttribute("src");
      const imageElement = `<img src="${imageUrl}" alt="${img.getAttribute(
        "alt"
      )}" width="350"/>`; // Cố định kích thước ảnh (có thể thay đổi)
      img.replaceWith(
        new DOMParser().parseFromString(imageElement, "text/html").body
          .firstChild
      );
    });

    // Trả về văn bản thuần túy sau khi thay thế các thẻ img
    return doc.body.innerHTML;
  };
  const formatCurrencyVND = (amount) => {
    return new Intl.NumberFormat("vi-VN", {
      style: "currency",
      currency: "VND",
      currencyDisplay: "code",
    }).format(amount);
  };
  const currentDate = dayjs(); // Lấy ngày hiện tại
//   const currentDate = dayjs(); // Lấy ngày hiện tại
// console.log("currentDate:", currentDate.format("YYYY-MM-DD")); // In ra ngày hiện tại theo định dạng "DD/MM/YYYY"
// // Lọc dữ liệu để chỉ lấy các dòng có ngày bắt đầu nhỏ hơn ngày hiện tại
// // Lọc dữ liệu để chỉ lấy các dòng có ngày bắt đầu nhỏ hơn ngày hiện tại
// const filteredData = data.filter(item => {
//   const startDate = dayjs(item.ngayBatDau); // Chuyển ngày bắt đầu thành đối tượng dayjs
//   console.log("Ngày bắt đầu:", startDate.format("YYYY-MM-DD")); // In ra ngày bắt đầu của từng item
//   const isBefore = startDate.isBefore(currentDate, 'day'); // So sánh ngày bắt đầu với ngày hiện tại
//   console.log(`Ngày bắt đầu ${startDate.format("YYYY-MM-DD")} so với ngày hiện tại ${currentDate.format("YYYY-MM-DD")} là: ${isBefore ? 'Trước' : 'Sau hoặc bằng'}`); // Log kết quả so sánh
//   if(!startDate >= isBefore){
//     return isBefore;
//   }
//   return isBefore; // Trả về kết quả lọc
// });
// console.log("filteredData",filteredData)
// Lọc dữ liệu để chỉ lấy các dòng có ngày bắt đầu nhỏ hơn ngày hiện tại
const filteredData = data.filter(item => dayjs(item.ngayBatDau).isSameOrAfter(currentDate));
  // Define columns and data for the table
  const columns = [
    {
      title: "STT",
      dataIndex: "id",
      key: "id",
      render: (_, __, index) => (
        <a href="#!" onClick={(e) => e.preventDefault()}>
          {index + 1}
        </a>
      ),
    },
    {
      title: "Ngày Khởi Hành",
      dataIndex: "ngayBatDau",
      key: "ngayBatDau",
      render: (ngayBatDau) => (
        <Tooltip placement="topLeft" title={ngayBatDau}>
          {dayjs(ngayBatDau).format("DD/MM/YYYY")}
        </Tooltip>
      ),
      sorter: (a, b) => dayjs(a.ngayBatDau).unix() - dayjs(b.ngayBatDau).unix(),
    },
    {
      title: "Giá",
      dataIndex: "giaNguoiLon",
      key: "giaNguoiLon",
      render: (text) => formatCurrencyVND(text),
    },
    {
      title: "Đánh Giá Khách Sạn",
      dataIndex: "danhGiaKhachSan",
      key: "danhGiaKhachSan",
    },
    {
      title: "Số Lượng Còn",
      dataIndex: "soLuongCon",
      key: "soLuongCon",
      render: (text) =>
        text === 0 ? (
          <span style={{ color: "red", fontWeight: "bold" }}>Hết chỗ</span>
        ) : (
          text
        ),
    },
    {
      title: "Chọn",
      key: "select",
      render: (_, record) =>
        record.soLuongCon === 0 ? (
          <span
            style={{ color: "#FFCC33", fontWeight: "bold", cursor: 'pointer' }}
            onClick={handleContactClick}
          >
            Liên Hệ
          </span>
        ) : (
          <Radio.Group
            name="tourSelect"
            value={selectedTourId}
            onChange={(e) => handleRadioChange(e, record)}
          >
            <Radio value={record.id}></Radio>
          </Radio.Group>
        ),
    },
  ];
  // Prepare data for the table

  // Define tab items
  const items = [
    {
      key: "1",
      label: "Lịch khởi hành",
      children: (
        <>
          <Table columns={columns} dataSource={filteredData} />

          <h2
            id="bangGia"
            className="text-2xl font-bold pt-3 mb-4 text-left text-blue-600"
          >
            Thông tin tour
          </h2>
          <div>
            {itinerary.map((item, index) => (
              <div key={item.id} className="mb-6 text-left">
                <div className="font-bold pl-2 text-blue-600">
                  Ngày {index + 1}: {item.tieuDe}
                </div>
                <p className="mt-2 pl-5">
                  • Thời gian: {item.thoiGianBatDau} - {item.thoiGianKetThuc}
                </p>

                <div className="mt-2 pl-5">
                  <strong>• Mô tả: </strong>
                  {/* Chuyển đổi nội dung và hiển thị thẻ img nếu có */}
                  <div
                    dangerouslySetInnerHTML={{
                      __html: stripHtmlAndShowImages(item.noiDung),
                    }}
                  />
                </div>
              </div>
            ))}
          </div>
        </>
      ),
    },
    {
      key: "2",
      label: "Ghi chú",
      children: (
        <>
          <Table columns={columns} dataSource={data} />
          <h2
            id="bangGia"
            className="text-2xl font-bold pt-3 mb-4 text-left text-blue-600"
          >
            Ghi Chú
          </h2>
          {selectedTourDetail && (
            <div className="text-gray-700 mb-2 text-left">
              <div
                dangerouslySetInnerHTML={{
                  __html: stripHtmlAndShowImages(selectedTourDetail.ghiChu),
                }}
              />
            </div>
          )}
        </>
      ),
    },
  ];

  function srcset(image, size, rows = 1, cols = 1) {
    return {
      src: `${image}?w=${size * cols}&h=${size * rows}&fit=crop&auto=format`,
      srcSet: `${image}?w=${size * cols}&h=${
        size * rows
      }&fit=crop&auto=format&dpr=2 2x`,
    };
  }

  const imageItems = [
    {
      key: "1",
      label: "Meida của Travel Go",
      children: (
        <div>
          <ImageList
            sx={{ width: "100%", height: 400 }}
            variant="quilted"
            cols={3} // Tạo 3 cột
            rowHeight={225} // Điều chỉnh chiều cao của hàng
          >
            {/* Render ảnh riêng */}
            {mediatour
              ?.filter((item) => item.hinhAnh) // Lọc các item có ảnh
              .map((item) => (
                <ImageListItem
                  key={item.idTour}
                  cols={1}
                  rows={1}
                  sx={{ width: "100%", height: "100%" }}
                >
                  <img
                    {...srcset(item.hinhAnh, 121, 1, 1)}
                    alt={item.idTour}
                    loading="lazy"
                    className="object-contain w-full h-full pl-1 pt-1"
                  />
                </ImageListItem>
              ))}

            {/* Render video riêng */}
            {mediatour
              .filter((item) => item.video) // Lọc các item có video
              .map((item) => (
                <ImageListItem
                  key={item.idTour}
                  cols={1}
                  rows={1}
                  sx={{ width: "100%", height: "100%" }}
                >
                  <video
                    controls
                    className="object-contain w-full h-full"
                    style={{ width: "100%", height: "100%" }}
                  >
                    <source src={item.video} type="video/mp4" />
                    Your browser does not support the video tag.
                  </video>
                </ImageListItem>
              ))}
          </ImageList>
        </div>
      ),
    },
    {
      key: "2",
      label: "Ảnh của khách hàng",
      children: (
        <div>
          <ImageList
            sx={{ width: "100%", height: 400 }}
            variant="quilted"
            cols={3} // Tạo 3 cột (2 ảnh + 1 video)
            rowHeight={225} // Điều chỉnh chiều cao của hàng
          >
            {danhGia?.map((item) => (
              <ImageListItem
                key={item.idTour}
                cols={1}
                rows={1}
                sx={{ width: "100%", height: "100%" }}
              >
                {/* Kiểm tra xem có ảnh, nếu có hiển thị ảnh trước */}

                <img
                  src={item.hinhAnh}
                  alt={item.idTour}
                  loading="lazy"
                  className="object-contain w-full h-full"
                />
              </ImageListItem>
            ))}
          </ImageList>
        </div>
      ),
    },
  ];

  return (
    <div className="max-w-[1440px] mt-24 mx-auto p-6">
      <div className="flex gap-6 mb-6">
        {/* Phần hình ảnh */}
        <div className="w-[848px] h-[500px] bg-slate-300 overflow-hidden shadow-lg">
          <img
            src={
              mediatour[0]?.hinhAnh || "/images/Blue Minimalist Travel Logo.png"
            }
            alt=""
            className="object-cover w-full h-full"
          />
        </div>
        <Modal
        title="Thông tin liên hệ về tour đã hết"
        visible={isModalVisible}
        onCancel={handleCancel}
        width={700}
        footer={[
         null
        ]}
      >
        <p>
          <strong>Thông tin liên hệ: </strong> 
          Chúng tôi rất tiếc vì tour mà bạn quan tâm đã hết. Để biết thêm thông tin về các tour mới hoặc đặt tour khác, bạn vui lòng liên hệ với chúng tôi qua các phương thức sau:
        </p>
        <ul>
          <li><strong>Email:</strong> contact@travelgo.com</li>
          <li><strong>Điện thoại:</strong> 0383028368</li>
          <li><strong>Địa chỉ:</strong> 123 Nguyễn Trãi, Quận Ninh Kiều, Cần Thơ, Việt Nam</li>
          <li><strong>Website:</strong> www.travelgo.com</li>
        </ul>
        <p>
          Chúng tôi sẽ hỗ trợ bạn nhanh chóng và cung cấp thông tin mới nhất về các tour. Cảm ơn bạn đã quan tâm!
        </p>
      </Modal>
        {/*hình ảnh phụ */}
        <div className="grid grid-cols-2 gap-2 w-[848px]">
          {mediatour.slice(0, 4).map((item, index) => (
            <div
              key={item.idTour}
              className="relative w-[340px] h-[245px] pt-1 pl-1"
            >
              <img
                src={item.hinhAnh}
                alt={item.idTour}
                className="object-cover w-full h-full"
              />
              {index === mediatour.slice(0, 4).length - 1 && (
                <button
                  onClick={togglePopup}
                  className=" btn btn-outline-light absolute bottom-4 right-4 py-2"
                >
                  <AiFillPicture />
                </button>
              )}
            </div>
          ))}

          {/* Popup */}
          {isPopupOpen && (
            <div className="mt-5 fixed inset-0 flex items-center justify-center bg-black bg-opacity-50 z-50">
              <div className=" mt-5 bg-white p-8 rounded-lg w-[1200px] h-[600px] relative overflow-y-auto">
                <button
                  onClick={togglePopup}
                  className="absolute top-4 right-4 text-gray-600 hover:text-gray-800"
                  aria-label="Close"
                >
                  &times;
                </button>
                <h2 className="text-2xl font-bold pt-3 mb-4 text-left text-blue-600">
                  Tất Cả MediaTour
                </h2>

                <Tabs defaultActiveKey="1" items={imageItems} />
              </div>
            </div>
          )}
        </div>
      </div>
      <div className="row mt-5">
        <div className=" col-lg-12 text-2xl font-bold pt-3 mb-4 text-left">
          {selectedTourDetail && <h2>{selectedTourDetail.tenTour}</h2>}
        </div>
        <div className="col-lg-8">
          {/* Tabs component */}
          <Tabs defaultActiveKey="1" items={items} />

          {/* Lặp qua mảng data để hiển thị mô tả */}
          {data.length > 0 && (
            <div className="mt-2 pl-5 text-left">
              <strong style={{ fontSize: "20px", color: "red" }}>
                • Lưu Ý:{" "}
              </strong>
              {/* Chuyển đổi nội dung và hiển thị thẻ img nếu có */}
              <div
                dangerouslySetInnerHTML={{
                  __html: data[0].noiDung, // Truy cập đúng phần tử trong mảng data
                }}
              />
            </div>
          )}

          {/* Đánh giá tour */}
          <DanhGia id_Tour={tourId} />
        </div>

        <div className="col-lg-4 mt-5">
          {selectedTourDetail && (
            <div className="mb-4 overflow-auto sticky-container">
              <div className="tour-info">
                <p className="flex items-center text-gray-700 mb-2">
                  <strong>Thời gian:</strong> {selectedTourDetail.soNgay}
                </p>
                <p className="flex items-center text-gray-700 mb-2">
                  <strong>Phương tiện:</strong> {selectedTourDetail.phuongTien}
                </p>
                <p className="flex items-center text-gray-700 mb-2">
                  <strong>Khách sạn:</strong>{" "}
                  {renderStars(selectedTourDetail.luuTru)}
                </p>
                <p className="flex items-center text-gray-700 mb-2">
                  <strong>Số chỗ còn:</strong> {selectedTourDetail.soLuongCon}
                </p>
                <p className="flex items-center text-gray-700 mb-2">
                  <strong>Giá người lớn:</strong>
                  {selectedTourDetail &&
                    new Intl.NumberFormat("vi-VN", {
                      style: "currency",
                      currency: "VND",
                      minimumFractionDigits: 0,
                      currencyDisplay: "code",
                    }).format(selectedTourDetail.giaNguoiLon)}
                </p>
                <p className="flex items-center text-gray-700 mb-2">
                  <strong>Giá trẻ em:</strong>{" "}
                  {selectedTourDetail &&
                    new Intl.NumberFormat("vi-VN", {
                      style: "currency",
                      currency: "VND",
                      minimumFractionDigits: 0,
                      currencyDisplay: "code",
                    }).format(selectedTourDetail.giaTreEm)}
                </p>
                <p className="flex items-center text-gray-700 mb-2">
                  <strong>Điểm khởi hành:</strong> {selectedTourDetail.tour}
                </p>
                <p className="flex items-center text-gray-700 mb-2">
                  <strong>Mã tour:</strong>
                  {selectedTourDetail.maTour}
                </p>
                <p className="flex items-center text-gray-700">
                  <strong>Loại tour:</strong> {selectedTourDetail.loaiTour}
                </p>
              </div>
              <div className="mb-2 border rounded-2xl p-3 bg-[#EEEEEE] sticky-price">
                <div className="flex items-center justify-between mb-2">
                  {/* Hiển thị giá tiền */}
                  <div className="text-3xl font-bold text-red-500 text-left">
                    {selectedTourDetail &&
                      new Intl.NumberFormat("vi-VN", {
                        style: "currency",
                        currency: "VND",
                        minimumFractionDigits: 0,
                        currencyDisplay: "code",
                      }).format(selectedTourDetail.giaNguoiLon)}
                  </div>

                  {/* Nút Đặt tour ngay */}
                  <button
                    className="bg-[#008080] text-white font-bold py-2 px-6 rounded-3xl hover:bg-[#006666]"
                    onClick={handleTourSelection}
                  >
                    ĐẶT TOUR NGAY
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default ChiTietTour;
