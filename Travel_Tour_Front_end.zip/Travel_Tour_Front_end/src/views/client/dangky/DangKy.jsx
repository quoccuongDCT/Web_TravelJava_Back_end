import React, { useState } from "react";
import "./signup.css";
import { useNavigate } from "react-router-dom"; 
// import { message } from "react-messageify"; 
// import "react-messageify/dist/ReactToastify.css"; 
import RadioGroup from "../componetns/radio";
import { message} from "antd";

const DangKy = () => {
  const navigate = useNavigate(); 
  const [hoTen, setHoTen] = useState("");
  const [email, setEmail] = useState("");
  const [matKhau, setMatKhau] = useState("");
  const [soDienThoai, setSoDienThoai] = useState("");
  const [diaChi, setDiaChi] = useState("");
  const [namSinh, setNamSinh] = useState("");
  const [gioiTinh, setGioiTinh] = useState(1);

  // Kiểm tra email hợp lệ
  const validateEmail = (email) => {
    const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
    return emailRegex.test(email);
  };
  const validatePhoneNumber = (phoneNumber) => {
    const phoneRegex = /^(?:\+?(\d{1,3}))?(\d{10})$/; // Kiểm tra số điện thoại Việt Nam
    return phoneRegex.test(phoneNumber);
  };
  const handleGioiTinhChange = (value) => {
    setGioiTinh(value); // Cập nhật giới tính khi thay đổi
  };

  const validateForm = () => {
    if (!hoTen) {
      message.error("Họ tên không được để trống!");
      return false;
    }

    if (!email) {
      message.error("Email không được để trống.");
      return false;
    } else if (!validateEmail(email)) {
      message.error("Email không hợp lệ.");
      return false;
    }

    if (!matKhau) {
      message.error("Mật khẩu không được để trống!");
      return false;
    }else if (matKhau.length < 3) {
      message.error("Mật khẩu phải có ít nhất 3 ký tự.");
      return false;
    }

    if (!soDienThoai) {
      message.error("Số điện thoại không được để trống!");
      return false;
    } else if (!validatePhoneNumber(soDienThoai)) {
      message.error("Số điện thoại không hợp lệ.");
      return false;
    }

    if (!diaChi) {
      message.error("Địa chỉ không được để trống!");
      return false;
    }
    if (!namSinh) {
      message.error("Năm sinh không được để trống!");
      return false;
    }
     // Kiểm tra năm sinh không nằm trong tương lai
     const today = new Date();
     const birthDate = new Date(namSinh);
     if (birthDate > today) {
       message.error("Ngày sinh không được vượt quá ngày hiện tại.");
       return false;
     }
    return true;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    // Kiểm tra form trước khi tiếp tục
    if (!validateForm()) return;
    try {
      const response = await fetch("http://localhost:8080/api/dangKy", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          hoTen,
          email,
          soDienThoai,
          diaChi,
          matKhau,
          gioiTinh,
          namSinh,
        }),
      });
      const data = await response.json();
      if (response.ok) {
        message.success("Đăng ký thành công!");

        navigate("/dangNhap");
      } else {
        message.error(data.msg);
      }
    } catch (error) {
      console.error("Error:", error);
      alert("Có lỗi xảy ra, vui lòng thử lại!");
    }
  };
  const googleLogin = async () => {
    try {
        window.location.href = "http://localhost:8080/oauth2/authorization/google";
    } catch (error) {
      message.error("Lỗi khi đăng nhập với Google: " + error.message);
    }
  };
  return (
    <div className="register-wrapper">
      <div className="register-container">
        <h2>Đăng Ký</h2>
        <form className="login-form" onSubmit={handleSubmit}>
          <div className="input-register">
            <label>Họ Tên</label>
            <input
              type="text"
              placeholder="Họ và tên"
              onChange={(e) => setHoTen(e.target.value)}
            />
          </div>
          <div className="input-register">
            <label>Email</label>
            <input
              type="text"
              placeholder="Địa chỉ email"
              onChange={(e) => setEmail(e.target.value)}
            />
          </div>
          <div className="input-register">
            <label>Mật Khẩu</label>
            <input
              type="password"
              placeholder="********"
              onChange={(e) => setMatKhau(e.target.value)}
            />
          </div>
          <div className="input-register">
            <label>SĐT</label>
            <input
              type="text"
              placeholder="Số điện thoại"
              onChange={(e) => setSoDienThoai(e.target.value)}
            />
          </div>
          <div className="input-register">
            <label>Địa chỉ</label>
            <input
              type="text"
              placeholder="Địa chỉ"
              onChange={(e) => setDiaChi(e.target.value)}
            />
          </div>
          <div className="input-register">
            <label>Năm sinh</label>
            <input
              type="date"
              onChange={(e) => setNamSinh(e.target.value)} // Lưu giá trị theo định dạng YYYY-MM-DD
            />
          </div>
          <div className="rolessss" style={{ marginLeft: "-356px" }}>
            <label>Giới tính</label>
            <br />
            <RadioGroup onGenderChange={handleGioiTinhChange} />
          </div>
          <br />
          <br />
          <button type="submit" className="btn-register" >
            Đăng ký
          </button>
        </form>
        <div className="signup-prompts">
          Đã có tài khoản? <a href="/dangnhap">Đăng nhập</a>
        </div>
        <div className="separator">hoặc</div>
        <div className="social-register">
          <button className="btn-google" onClick={googleLogin}>
            <img
              src={"./images/icons8-google-48.png"}
              alt="Google Icon"
              style={{ width: "25px", marginRight: "8px" }}
            />
            Đăng ký với Google
          </button>
          <br />
          {/* <button style={{ marginTop: "-12px" }} className="btn-facebook">
            <img
              src={"./images/icons8-facebook-48.png"}
              alt="Facebook Icon"
              style={{ width: "25px", marginRight: "8px" }}
            />
            Đăng ký với Facebook
          </button> */}
        </div>
      </div>
    </div>
  );
};

export default DangKy;
