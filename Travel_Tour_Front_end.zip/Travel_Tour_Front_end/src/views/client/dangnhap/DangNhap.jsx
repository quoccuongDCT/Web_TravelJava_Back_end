import React, { useState } from "react";
// import { message } from "react-messageify";
// import "react-messageify/dist/ReactToastify.css";
import "./login.css";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import { message} from "antd";


const DangNhap = () => {
  const navigate = useNavigate(); 
  // const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  // Kiểm tra email hợp lệ
  const validateEmail = (email) => {
    const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
    return emailRegex.test(email);
  };

  // Kiểm tra thông tin email và mật khẩu trước khi gửi yêu cầu đăng nhập
  const validateForm = () => {
    if (!email) {
      message.error("Email không được để trống.");
      return false;
    } else if (!validateEmail(email)) {
      message.error("Email không hợp lệ.");
      return false;
    }

    if (!password) {
      message.error("Mật khẩu không được để trống.");
      return false;
    }else if (password.length < 3) {
      message.error("Mật khẩu phải có ít nhất 3 ký tự.");
      return false;
    }

    return true;
  };

  const handleLogin = async (e) => {
    e.preventDefault();

    // Kiểm tra form trước khi tiếp tục
    if (!validateForm()) return;

    try {
      // Gửi yêu cầu đăng nhập bằng axios
      const response = await axios.post("http://localhost:8080/api/dangNhap", {
        email,
        matKhau: password,
      });

      // Dữ liệu từ phản hồi axios nằm trong `response.data`
      const data = response.data;
      const userRole = data.role;

      // Lưu thông tin người dùng vào localStorage
      localStorage.setItem("token", data.token);
      localStorage.setItem("hoTen", data.hoTen);
      localStorage.setItem("email", data.email);
      localStorage.setItem("namSinh", data.namSinh);
      localStorage.setItem("soDienThoai", data.soDienThoai);
      localStorage.setItem("diaChi", data.diaChi);
      localStorage.setItem("role", userRole);
      localStorage.setItem("id", data.id);
      localStorage.setItem("hinhAnh", data.hinhAnh || "");

      message.success("Đăng nhập thành công!");
  
      // setIsLoggedIn(true);
  
      // Chuyển hướng dựa trên vai trò
      if (userRole === "admin") {
        navigate("/admin");
      } else if (userRole === "nhanvien") {
        navigate("/admin");
      } else {
        navigate("/");
      }
    } catch (error) {
      if (
        error.response &&
        error.response.data &&
        error.response.data.message
      ) {
        message.error(error.response.data.message);
      } else {
        message.error("Đăng nhập thất bại!");
      }
    }
  };

  const googleLogin = async () => {
    try {
      window.location.href =
        "http://localhost:8080/oauth2/authorization/google";
    } catch (error) {
      message.error("Lỗi khi đăng nhập với Google: " + error.message);
    }
  };

  const faceLogin = async () => {
    try {
      window.location.href =
        "http://localhost:8080/oauth2/authorization/facebook";
    } catch (error) {
      message.error("Lỗi khi đăng nhập với Google: " + error.message);
    }
  };

  return (
    <div className="login-wrapper">
      <div className="login-container">
        <h2>Đăng Nhập</h2>
        <form className="login-form" onSubmit={handleLogin}>
          <div className="input-login">
            <label>Email</label>
            <input
              type="text"
              placeholder="Địa chỉ email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
            />
          </div>
          <div className="input-login">
            <label>Mật Khẩu</label>
            <input
              type="password"
              placeholder="********"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
            />
          </div>
          <a href="/quenmatkhau" className="forgot-password">
            Quên mật khẩu?
          </a>
          <br />
          <button type="submit" className="btn-login">
            Đăng nhập
          </button>
        </form>

        <div className="signup-prompts">
          Chưa có tài khoản? <a href="/dangky">Đăng ký</a>
        </div>

        <div className="separator">hoặc</div>
        <div className="social-login">
          <button className="btn-google" onClick={googleLogin}>
            <img
              src="./images/icons8-google-48.png"
              alt="Google Icon"
              style={{ width: "25px", marginRight: "8px" }}
            />
            Đăng nhập với Google
          </button>

          <button className="btn-facebook" style={{ marginTop: "12px" }} onClick={faceLogin}>
            <img
              src="./images/icons8-facebook-48.png"
              alt="Facebook Icon"
              style={{ width: "25px", marginRight: "8px" }}
            />
            Đăng nhập với Facebook
          </button>
        </div>
      </div>
    </div>
  );
};

export default DangNhap;
