import React from "react";

const FullCalendar = () => {
  return (
    <div>
      {/* <div className="flex flex-col px-6 pt-5 pb-6 ">
            <div>
              <div className="flex items-center justify-between">
                <button className="flex items-center justify-center p-2 rounded-xl">
                  <IoIosArrowBack />
                </button>
                <div>January</div>
                <button className="flex items-center justify-center p-2 rounded-xl">
                  <IoIosArrowForward />
                </button>
              </div>
              <div className="grid grid-cols-7 text-xs text-center text-gray-900">
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  MO
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  TU
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  WE
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  TH
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  Fri
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  SA
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  SU
                </span>

                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  1
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  2
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  3
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  4
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  5
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  6
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  7
                </span>

                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  8
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  9
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  10
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  12
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  13
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  14
                </span>

                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  15
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  16
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  17
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  18
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  19
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  20
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  21
                </span>

                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  22
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  23
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  24
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  25
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  26
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  27
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  28
                </span>

                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  29
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  30
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  31
                </span>
              </div>
            </div>
          </div> */}
      {/* <div className="flex flex-col px-6 pt-5 pb-6 ">
            <div>
              <div className="flex items-center justify-between">
                <button className="flex items-center justify-center p-2 rounded-xl">
                  <IoIosArrowBack />
                </button>
                <div>April</div>
                <button className="flex items-center justify-center p-2 rounded-xl">
                  <IoIosArrowForward />
                </button>
              </div>
              <div className="grid grid-cols-7 text-xs text-center text-gray-900">
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  MO
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  TU
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  WE
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  TH
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  Fri
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  SA
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  SU
                </span>

                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  1
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  2
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  3
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  4
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  5
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  6
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  7
                </span>

                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  8
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  9
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  10
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  12
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  13
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  14
                </span>

                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  15
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  16
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  17
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  18
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  19
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  20
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  21
                </span>

                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  22
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  23
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  24
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  25
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  26
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  27
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  28
                </span>

                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  29
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  30
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  31
                </span>
              </div>
            </div>
          </div> */}

      {/* <div className="flex flex-col px-6 pt-5 pb-6 ">
            <div>
              <div className="flex items-center justify-between">
                <button className="flex items-center justify-center p-2 rounded-xl">
                  <IoIosArrowBack />
                </button>
                <div>May</div>
                <button className="flex items-center justify-center p-2 rounded-xl">
                  <IoIosArrowForward />
                </button>
              </div>
              <div className="grid grid-cols-7 text-xs text-center text-gray-900">
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  MO
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  TU
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  WE
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  TH
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  Fri
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  SA
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  SU
                </span>

                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  1
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  2
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  3
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  4
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  5
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  6
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  7
                </span>

                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  8
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  9
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  10
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  12
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  13
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  14
                </span>

                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  15
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  16
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  17
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  18
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  19
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  20
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  21
                </span>

                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  22
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  23
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  24
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  25
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  26
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  27
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  28
                </span>

                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  29
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  30
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  31
                </span>
              </div>
            </div>
          </div> */}

      {/* <div className="flex flex-col px-6 pt-5 pb-6 ">
            <div>
              <div className="flex items-center justify-between">
                <button className="flex items-center justify-center p-2 rounded-xl">
                  <IoIosArrowBack />
                </button>
                <div>June</div>
                <button className="flex items-center justify-center p-2 rounded-xl">
                  <IoIosArrowForward />
                </button>
              </div>
              <div className="grid grid-cols-7 text-xs text-center text-gray-900">
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  MO
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  TU
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  WE
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  TH
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  Fri
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  SA
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  SU
                </span>

                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  1
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  2
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  3
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  4
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  5
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  6
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  7
                </span>

                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  8
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  9
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  10
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  12
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  13
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  14
                </span>

                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  15
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  16
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  17
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  18
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  19
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  20
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  21
                </span>

                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  22
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  23
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  24
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  25
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  26
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  27
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  28
                </span>

                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  29
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  30
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  31
                </span>
              </div>
            </div>
          </div> */}

      {/* <div className="flex flex-col px-6 pt-5 pb-6 ">
            <div>
              <div className="flex items-center justify-between">
                <button className="flex items-center justify-center p-2 rounded-xl">
                  <IoIosArrowBack />
                </button>
                <div>July</div>
                <button className="flex items-center justify-center p-2 rounded-xl">
                  <IoIosArrowForward />
                </button>
              </div>
              <div className="grid grid-cols-7 text-xs text-center text-gray-900">
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  MO
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  TU
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  WE
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  TH
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  Fri
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  SA
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  SU
                </span>

                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  1
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  2
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  3
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  4
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  5
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  6
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  7
                </span>

                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  8
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  9
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  10
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  12
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  13
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  14
                </span>

                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  15
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  16
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  17
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  18
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  19
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  20
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  21
                </span>

                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  22
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  23
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  24
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  25
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  26
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  27
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  28
                </span>

                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  29
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  30
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  31
                </span>
              </div>
            </div>
          </div> */}

      {/* <div className="flex flex-col px-6 pt-5 pb-6 ">
            <div>
              <div className="flex items-center justify-between">
                <button className="flex items-center justify-center p-2 rounded-xl">
                  <IoIosArrowBack />
                </button>
                <div>August</div>
                <button className="flex items-center justify-center p-2 rounded-xl">
                  <IoIosArrowForward />
                </button>
              </div>
              <div className="grid grid-cols-7 text-xs text-center text-gray-900">
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  MO
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  TU
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  WE
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  TH
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  Fri
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  SA
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  SU
                </span>

                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  1
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  2
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  3
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  4
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  5
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  6
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  7
                </span>

                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  8
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  9
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  10
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  12
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  13
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  14
                </span>

                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  15
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  16
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  17
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  18
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  19
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  20
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  21
                </span>

                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  22
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  23
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  24
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  25
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  26
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  27
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  28
                </span>

                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  29
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  30
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  31
                </span>
              </div>
            </div>
          </div> */}

      {/* <div className="flex flex-col px-6 pt-5 pb-6 ">
            <div>
              <div className="flex items-center justify-between">
                <button className="flex items-center justify-center p-2 rounded-xl">
                  <IoIosArrowBack />
                </button>
                <div>September</div>
                <button className="flex items-center justify-center p-2 rounded-xl">
                  <IoIosArrowForward />
                </button>
              </div>
              <div className="grid grid-cols-7 text-xs text-center text-gray-900">
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  MO
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  TU
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  WE
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  TH
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  Fri
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  SA
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  SU
                </span>

                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  1
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  2
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  3
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  4
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  5
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  6
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  7
                </span>

                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  8
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  9
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  10
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  12
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  13
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  14
                </span>

                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  15
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  16
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  17
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  18
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  19
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  20
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  21
                </span>

                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  22
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  23
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  24
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  25
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  26
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  27
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  28
                </span>

                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  29
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  30
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  31
                </span>
              </div>
            </div>
          </div> */}

      {/* <div className="flex flex-col px-6 pt-5 pb-6 ">
            <div>
              <div className="flex items-center justify-between">
                <button className="flex items-center justify-center p-2 rounded-xl">
                  <IoIosArrowBack />
                </button>
                <div>October</div>
                <button className="flex items-center justify-center p-2 rounded-xl">
                  <IoIosArrowForward />
                </button>
              </div>
              <div className="grid grid-cols-7 text-xs text-center text-gray-900">
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  MO
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  TU
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  WE
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  TH
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  Fri
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  SA
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  SU
                </span>

                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  1
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  2
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  3
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  4
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  5
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  6
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  7
                </span>

                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  8
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  9
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  10
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  12
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  13
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  14
                </span>

                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  15
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  16
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  17
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  18
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  19
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  20
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  21
                </span>

                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  22
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  23
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  24
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  25
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  26
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  27
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  28
                </span>

                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  29
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  30
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  31
                </span>
              </div>
            </div>
          </div> */}

      {/* <div className="flex flex-col px-6 pt-5 pb-6 ">
            <div>
              <div className="flex items-center justify-between">
                <button className="flex items-center justify-center p-2 rounded-xl">
                  <IoIosArrowBack />
                </button>
                <div>November</div>
                <button className="flex items-center justify-center p-2 rounded-xl">
                  <IoIosArrowForward />
                </button>
              </div>
              <div className="grid grid-cols-7 text-xs text-center text-gray-900">
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  MO
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  TU
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  WE
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  TH
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  Fri
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  SA
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  SU
                </span>

                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  1
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  2
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  3
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  4
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  5
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  6
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  7
                </span>

                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  8
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  9
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  10
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  12
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  13
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  14
                </span>

                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  15
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  16
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  17
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  18
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  19
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  20
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  21
                </span>

                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  22
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  23
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  24
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  25
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  26
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  27
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  28
                </span>

                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  29
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  30
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  31
                </span>
              </div>
            </div>
          </div> */}

      {/* <div className="flex flex-col px-6 pt-5 pb-6 ">
            <div>
              <div className="flex items-center justify-between">
                <button className="flex items-center justify-center p-2 rounded-xl">
                  <IoIosArrowBack />
                </button>
                <div>December</div>
                <button className="flex items-center justify-center p-2 rounded-xl">
                  <IoIosArrowForward />
                </button>
              </div>
              <div className="grid grid-cols-7 text-xs text-center text-gray-900">
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  MO
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  TU
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  WE
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  TH
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  Fri
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  SA
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  SU
                </span>

                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  1
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  2
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  3
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  4
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  5
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  6
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  7
                </span>

                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  8
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  9
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  10
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  12
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  13
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  14
                </span>

                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  15
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  16
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  17
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  18
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  19
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  20
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  21
                </span>

                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  22
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  23
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  24
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  25
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  26
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  27
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  28
                </span>

                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  29
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  30
                </span>
                <span className="flex items-center justify-center w-10 h-10 rounded-lg">
                  31
                </span>
              </div>
            </div>
          </div>  */}
    </div>
  );
};

export default FullCalendar;
