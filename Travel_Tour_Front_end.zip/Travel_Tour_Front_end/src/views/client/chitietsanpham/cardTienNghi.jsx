import React from "react";
import { GoKey } from "react-icons/go";
import {
  LiaSmokingSolid,
  LiaSuitcaseSolid,
  LiaSwimmingPoolSolid,
  LiaLuggageCartSolid,
  LiaSnowflakeSolid,
  LiaSuitcaseRollingSolid,
  LiaTvSolid,
  LiaShowerSolid,
  LiaSpaSolid,
  LiaSwimmerSolid,
  LiaUmbrellaBeachSolid,
} from "react-icons/lia";
import ModalTienNghi from "../../../components/OpenModalTienNghi";

export const CardTienNghi = ({ Amenities }) => {
  return (
    <div className="max-w-[1440px] p-4 mx-auto">
      <div className="border max-w-[791px] rounded-2xl">
        <div className="p-4 gap-4 flex flex-col">
          <div className="flex font-medium text-3xl">Tiện Nghi</div>
          <div className="flex text-left">{Amenities.title}</div>
          <hr className="max-w-[50px]" />
          <div className="flex justify-between">
            <div className="flex justify-between w-full">
              <div className="flex flex-col gap-4 w-1/3">
                <div className="flex items-center gap-2">
                  <GoKey style={{ height: 30, width: 30 }} />
                  Chìa khóa
                </div>
                <div className="flex items-center gap-2">
                  <LiaSmokingSolid style={{ height: 30, width: 30 }} />
                  Hút thuốc
                </div>
                <div className="flex items-center gap-2">
                  <LiaSuitcaseSolid style={{ height: 30, width: 30 }} />
                  Va-li
                </div>
                <div className="flex items-center gap-2">
                  <LiaSwimmingPoolSolid style={{ height: 30, width: 30 }} />
                  Hồ-bơi
                </div>
              </div>
              <div className="flex flex-col gap-4 w-1/3">
                <div className="flex items-center gap-2">
                  <LiaLuggageCartSolid style={{ height: 30, width: 30 }} />
                  Xe-hành-lý
                </div>
                <div className="flex items-center gap-2">
                  <LiaSnowflakeSolid style={{ height: 30, width: 30 }} />
                  Máy lạnh
                </div>
                <div className="flex items-center gap-2">
                  <LiaSuitcaseRollingSolid style={{ height: 30, width: 30 }} />
                  Vận chuyển va-li
                </div>
                <div className="flex items-center gap-2">
                  <LiaTvSolid style={{ height: 30, width: 30 }} />
                  TV
                </div>
              </div>
              <div className="flex flex-col gap-4 w-1/3">
                <div className="flex items-center gap-2">
                  <LiaShowerSolid style={{ height: 30, width: 30 }} />
                  Vòi hoa sen
                </div>
                <div className="flex items-center gap-2">
                  <LiaSpaSolid style={{ height: 30, width: 30 }} />
                  spa
                </div>
                <div className="flex items-center gap-2">
                  <LiaSwimmerSolid style={{ height: 30, width: 30 }} />
                  Người bơi
                </div>
                <div className="flex items-center gap-2">
                  <LiaUmbrellaBeachSolid style={{ height: 30, width: 30 }} />
                  bãi biển ô dù
                </div>
              </div>
            </div>
          </div>
          <hr className="max-w-[50px]" />

          <ModalTienNghi />
        </div>
      </div>
    </div>
  );
};

export default CardTienNghi;
