import React from "react";

export const CardThongTin = ({ accommodation }) => {
  return (
    <div className="max-w-[1440px] p-4 mx-auto">
      <div className="border max-w-[791px] rounded-2xl">
        <div className="p-4 gap-4 flex flex-col">
          <div className="flex font-medium text-3xl">Thông tin lưu trú</div>
          <hr className="max-w-[50px]" />
          <div className="flex text-left">{accommodation.description1}</div>
          <div className="flex text-left">{accommodation.description2}</div>
          <div className="flex text-left">{accommodation.description3}</div>
        </div>
      </div>
    </div>
  );
};

export default CardThongTin;
