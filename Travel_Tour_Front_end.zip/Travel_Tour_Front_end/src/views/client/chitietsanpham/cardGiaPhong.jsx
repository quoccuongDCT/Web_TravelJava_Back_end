import React from "react";

export const CardGiaPhong = ({ roomPrices }) => {
  return (
    <div className="max-w-[1440px] p-4 mx-auto">
      <div className="border max-w-[791px] rounded-2xl">
        <div className="p-4 gap-4 flex flex-col">
          <div className="flex font-medium text-3xl">Giá phòng</div>
          <div className="flex text-left">
            Giá có thể tăng vào cuối tuần hoặc ngày lễ
          </div>
          <hr className="max-w-[50px]" />
          <div className="flow-root">
            <div className="text-sm sm:text-base text-neutral-6000 dark:text-neutral-300 -mb-4">
              {roomPrices.map((price, index) => (
                <div
                  key={index}
                  className={`p-4 flex justify-between items-center space-x-4 rounded-lg ${
                    index % 2 === 0 ? "bg-neutral-100 dark:bg-neutral-800" : ""
                  }`}
                >
                  <span>{price.dayRange}</span>
                  <span>{price.price}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CardGiaPhong;
