import React from "react";
import { LiaDoorOpenSolid } from "react-icons/lia";
import { IoBedOutline } from "react-icons/io5";
import { LiaBathSolid } from "react-icons/lia";
import { AiOutlineUser } from "react-icons/ai";
import { MdOutlineStar } from "react-icons/md";
import { LiaMapMarkerAltSolid } from "react-icons/lia";
import { CiHeart } from "react-icons/ci";
import { RiShare2Line } from "react-icons/ri";

export const CardSanPham = ({ product }) => {
  return (
    <div className="max-w-[1440px] p-4 mx-auto">
      <div className="border max-w-[791px] rounded-2xl">
        <div className="p-4 flex flex-col gap-4">
          <div className="flex justify-between">
            <div>{product.name}</div>
            <div className="flex gap-4">
              <button className="flex items-center gap-1">
                <RiShare2Line style={{ height: 20, width: 20 }} />
                Share
              </button>
              <button className="flex items-center gap-1">
                <CiHeart style={{ height: 20, width: 20 }} /> Save
              </button>
            </div>
          </div>
          <div className="flex items-baseline text-4xl font-bold">
            {product.title}
          </div>
          <div className="flex gap-4">
            <div className="flex items-center gap-1">
              <MdOutlineStar className="text-yellow-500" />
              {product.point} ({product.reviewCount})
            </div>
            <div className="flex items-center gap-1">
              · <LiaMapMarkerAltSolid />
              {product.location}
            </div>
          </div>
          <div className="flex items-baseline ">
            chủ tài khoản + logo {product.host}
          </div>
          <div className="flex gap-4">
            <div className="flex gap-2">
              <AiOutlineUser style={{ height: "24px", width: "24px" }} />
              {product.guestCount} guests
            </div>
            <div className="flex gap-2">
              <IoBedOutline style={{ height: "24px", width: "24px" }} />
              {product.bedCount} beds
            </div>
            <div className="flex gap-2">
              <LiaBathSolid style={{ height: "24px", width: "24px" }} />
              {product.bathCount} baths
            </div>
            <div className="flex gap-2">
              <LiaDoorOpenSolid style={{ height: "24px", width: "24px" }} />
              {product.bedroomCount} bedrooms
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CardSanPham;
