import React from "react";
import { MdOutlineStar } from "react-icons/md";
import { BsChatLeftText } from "react-icons/bs";
import { MdAccessTime } from "react-icons/md";
import { CiCalendar } from "react-icons/ci";
export const CardThongTinSever = ({ serverInfo }) => {
  return (
    <div className="max-w-[1440px] p-4 mx-auto">
      <div className="border max-w-[791px] rounded-2xl">
        <div className="p-4 gap-4 flex flex-col">
          <div className="flex font-medium text-3xl">
            Thông tin chủ tài khoản
          </div>
          <hr className="max-w-[50px]" />
          <div className="flex gap-2">
            <div>logo</div>
            <div>
              <div className="text-lg text-left">{serverInfo.hostName}</div>
              <div className="flex items-center gap-2">
                <MdOutlineStar className="text-yellow-500" />
                <span>{serverInfo.rating}</span>
                <span>({serverInfo.reviewCount})</span>·<span> 12 Nơi</span>
              </div>
            </div>
          </div>
          <div className="text-left">
            <span>{serverInfo.description}</span>
          </div>
          <div className="flex flex-col ">
            <span className="flex items-center gap-2">
              <CiCalendar /> Gia nhập vào {serverInfo.joinDate}
            </span>
            <span className="flex items-center gap-2">
              <BsChatLeftText /> Tỷ lệ phản hồi - {serverInfo.responseRate}
            </span>
            <span className="flex items-center gap-2">
              <MdAccessTime />
              Phản hồi nhanh - {serverInfo.quickResponse}
            </span>
          </div>
          <hr className="max-w-[50px]" />
          <div className="flex">
            <button className="border w-[187px] h-[50px] rounded-3xl hover:bg-gray-100">
              Xem trang cá nhân
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
export default CardThongTinSever;
