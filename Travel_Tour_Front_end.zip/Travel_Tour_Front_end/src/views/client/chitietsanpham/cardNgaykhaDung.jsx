import React from "react";
import DateTimePicker from "./datetimepicker";

export const CardNgayKhaDung = () => {
  return (
    <div className="max-w-[1440px] p-4 mx-auto">
      <div className="border max-w-[791px] rounded-2xl">
        <div className="p-4 gap-4 flex flex-col">
          <div className="flex font-medium text-3xl">Ngày khả dụng</div>
          <div className=" text-left">
            Giá có thể tăng vào cuối tuần hoặc ngày lễ
          </div>
          <hr className="max-w-[50px]" />
          <DateTimePicker />
        </div>
      </div>
    </div>
  );
};

export default CardNgayKhaDung;
