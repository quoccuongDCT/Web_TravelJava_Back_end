import React, { useState } from "react";
import { IoIosArrowBack, IoIosArrowForward } from "react-icons/io";

export const DateTimePicker = () => {
  const [currentMonth, setCurrentMonth] = useState(new Date().getMonth()); // Lưu tháng hiện tại
  const [currentYear, setCurrentYear] = useState(new Date().getFullYear()); // Lưu năm hiện tại

  // Hàm để lấy số ngày trong tháng
  const getDaysInMonth = (month, year) =>
    new Date(year, month + 1, 0).getDate();

  // Hàm để chuyển tháng
  const handleMonthChange = (increment) => {
    setCurrentMonth((prevMonth) => {
      const newMonth = prevMonth + increment;
      if (newMonth > 11) {
        setCurrentYear((prevYear) => prevYear + 1); // Tăng năm nếu tháng lớn hơn 11 (tháng 12)
        return 0; // Đặt lại tháng về tháng 1 (0)
      } else if (newMonth < 0) {
        setCurrentYear((prevYear) => prevYear - 1); // Giảm năm nếu tháng nhỏ hơn 0 (tháng 1)
        return 11; // Đặt lại tháng về tháng 12 (11)
      }
      return newMonth; // Trả về tháng mới
    });
  };

  const daysInCurrentMonth = getDaysInMonth(currentMonth, currentYear);
  const daysInNextMonth = getDaysInMonth(currentMonth + 1, currentYear);

  const monthNames = [
    "January",
    "February",
    "March",
    "April",
    "May",
    "June",
    "July",
    "August",
    "September",
    "October",
    "November",
    "December",
  ];

  return (
    <div className="flex items-center justify-center w-full">
      <div className="flex bg-white rounded-lg ">
        <div className="flex flex-row gap-4 justify-between w-[741px]">
          {/* Lịch tháng hiện tại */}
          <div className="flex flex-col max-w-[370px] w-full">
            <div>
              <div className="flex items-center justify-between">
                <button
                  onClick={() => handleMonthChange(-1)}
                  className="flex items-center justify-center p-2 rounded-xl hover:bg-gray-50"
                >
                  <IoIosArrowBack />
                </button>
                <div>
                  {monthNames[currentMonth]} {currentYear}
                </div>
                <button
                  onClick={() => handleMonthChange(1)}
                  className="flex items-center justify-center p-2 rounded-xl hover:bg-gray-50"
                >
                  <IoIosArrowForward />
                </button>
              </div>
              <div className="grid grid-cols-7 text-xs text-center text-gray-900">
                {["MO", "TU", "WE", "TH", "FR", "SA", "SU"].map((day) => (
                  <span
                    key={day}
                    className="flex items-center justify-center w-10 h-10 rounded-lg"
                  >
                    {day}
                  </span>
                ))}
                {/* Tạo các ngày trong tháng hiện tại */}
                {Array.from({ length: daysInCurrentMonth }, (_, i) => (
                  <span
                    key={i + 1}
                    className="flex items-center justify-center w-10 h-10 rounded-lg"
                  >
                    {i + 1}
                  </span>
                ))}
              </div>
            </div>
          </div>

          {/* Lịch tháng tiếp theo */}
          <div className="flex flex-col max-w-[370px] w-full">
            <div>
              <div className="flex items-center justify-between">
                <button
                  onClick={() => handleMonthChange(-1)}
                  className="flex items-center justify-center p-2 rounded-xl hover:bg-gray-50"
                >
                  <IoIosArrowBack />
                </button>
                <div>
                  {monthNames[(currentMonth + 1) % 12]}{" "}
                  {currentMonth === 11 ? currentYear + 1 : currentYear}
                </div>
                <button
                  onClick={() => handleMonthChange(1)}
                  className="flex items-center justify-center p-2 rounded-xl hover:bg-gray-50"
                >
                  <IoIosArrowForward />
                </button>
              </div>
              <div className="grid grid-cols-7 text-xs text-center text-gray-900">
                {["MO", "TU", "WE", "TH", "FR", "SA", "SU"].map((day) => (
                  <span
                    key={day}
                    className="flex items-center justify-center w-10 h-10 rounded-lg"
                  >
                    {day}
                  </span>
                ))}
                {/* Tạo các ngày trong tháng tiếp theo */}
                {Array.from({ length: daysInNextMonth }, (_, i) => (
                  <span
                    key={i + 1}
                    className="flex items-center justify-center w-10 h-10 rounded-lg"
                  >
                    {i + 1}
                  </span>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default DateTimePicker;
