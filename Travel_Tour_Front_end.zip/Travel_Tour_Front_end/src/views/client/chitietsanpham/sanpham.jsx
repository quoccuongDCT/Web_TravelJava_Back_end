import React from "react";
import CardSanPham from "./cardSanPham";
import CardThongTin from "./cardThongTin";
import CardTienNghi from "./cardTienNghi";
import CardGiaPhong from "./cardGiaPhong";
import CardNgayKhaDung from "./cardNgaykhaDung";
import CardThongTinSever from "./cardThongtinSever";
import { MdOutlineStar } from "react-icons/md";

export const SanPham = () => {
  const product = {
    name: "Wooden house",
    title: "Beach House in Collingwood",
    point: 4.5,
    reviewCount: 112,
    location: "Tokyo, Japan",
    host: "Kevin Francis",
    guestCount: 6,
    bedCount: 6,
    bathCount: 3,
    bedroomCount: 2,
  };

  const accommodation = {
    description1:
      "Với tầm nhìn ra hồ, The Symphony 9 Tam Coc ở Ninh Bình cung cấp chỗ nghỉ, hồ bơi ngoài trời, quầy bar, sảnh khách chung, khu vườn và tiện nghi BBQ. WiFi miễn phí được cung cấp.",
    description2:
      "Tất cả các phòng đều có phòng tắm riêng với chậu rửa vệ sinh (bidet), cùng với máy sấy tóc và đồ vệ sinh cá nhân miễn phí.",
    description3:
      "The Symphony 9 Tam Coc có sân hiên. Chỗ nghỉ cung cấp cả dịch vụ cho thuê xe đạp và dịch vụ cho thuê xe hơi trong khi du khách có thể đạp xe ở khu vực gần đó.",
  };

  const Amenities = {
    title: "Về các tiện nghi và dịch vụ của khách sạn",
  };

  const roomPrices = [
    { dayRange: "Thứ Hai - Thứ Năm", price: "$199" },
    { dayRange: "Thứ Sáu - Chủ Nhật", price: "$219" },
    { dayRange: "Thuê theo tháng", price: "-8.34%" },
    { dayRange: "Thuê tối thiểu đêm", price: "1 night" },
    { dayRange: "Thuê tối đa đêm", price: "90 nights" },
  ];

  const serverInfo = {
    hostName: "Kevin Francis",
    rating: 4.5,
    reviewCount: 112,
    description:
      "Với tầm nhìn hướng hồ, The Symphony 9 Tam Cốc tại Ninh Bình cung cấp chỗ ở, hồ bơi ngoài trời, quầy bar, sảnh khách chung, a sân vườn và tiện nghi BBQ...",
    joinDate: "Tháng Ba năm 2016",
    responseRate: "100%",
    quickResponse: "trong vòng vài giờ",
  };

  return (
    <div>
      <div className="flex max-w-[1440px] mx-auto gap-4 p-4">
        <div className="bg-slate-300 w-[848px] h-[500px] rounded-2xl">d</div>
        <div className=" w-[848px] h-[500px] flex flex-col gap-4 ">
          <div className="flex gap-4">
            <div className="bg-red-200  w-[400px] h-[238px] rounded-2xl">d</div>
            <div className="bg-red-300  w-[400px] h-[238px] rounded-2xl">d</div>
          </div>
          <div className="flex gap-4">
            <div className="bg-red-400 w-[400px] h-[238px] rounded-2xl">d</div>
            <div className="bg-red-500  w-[400px] h-[238px] rounded-2xl">d</div>
          </div>
        </div>
      </div>
      <div className="max-w-[1440px] relative mx-auto z-20">
        <div className=" p-4 absolute right-0">
          <div className="border max-w-[550px] rounded-2xl">
            <div className="p-4 gap-4 flex flex-col">
              <div className="flex gap-2 justify-between">
                <div>
                  <span className="text-3xl text-left font-bold">$119</span>
                  <span>/Người</span>
                </div>
                <div className="flex items-center gap-2  ">
                  <MdOutlineStar className="text-yellow-500" />
                  <span>4.5</span>
                  <span>(112)</span>
                </div>
              </div>
              <hr className="max-w-[50px]" />
              <div className="flex justify-between">
                <span>$119 x 3 Người</span>
                <span>$357</span>
              </div>
              <div className="flex justify-between">
                <span>Phí dịch vụ</span>
                <span>$0</span>
              </div>
              <hr />
              <div className="flex justify-between">
                <span>Tổng</span>
                <span>$357</span>
              </div>
              <button className="border rounded-3xl w-[360px] h-[48px] bg-[#008080] text-lg font-bold text-white">
                Đặt vé
              </button>
            </div>
          </div>
        </div>
      </div>
      <CardSanPham product={product} />
      <CardThongTin accommodation={accommodation} />
      <CardTienNghi Amenities={Amenities} />
      <CardGiaPhong roomPrices={roomPrices} />
      <CardNgayKhaDung />
      <CardThongTinSever serverInfo={serverInfo} />
    </div>
  );
};
export default SanPham;
