// export const articles = [
//   {
//     id: "1",
//     category: "Công nghệ",
//     title:
//       "(title) Microsoft công bố cam kết 5 năm tạo cơ hội lớn hơn cho người khuyết tật",
//     description:
//       "(description) Y tế từ xa đang cung cấp những cách thức mới để bệnh nhân kết nối với các nhà cung cấp dịch vụ chăm sóc sức khỏe. (description) Y tế từ xa đang cung cấp những cách thức mới để bệnh nhân kết nối với các nhà cung cấp dịch vụ chăm sóc sức khỏe. ",
//     userId: 1,
//     date: "08-06-2023",
//     imageUrl: "/images/anh1.webp",
//     url: "/",
//   },
//   {
//     id: "2",
//     category: "Công nghệ",

//     title:
//       "(title) Gen thắng chung kết thế giới(description) Những khoảnh khắc đáng nhớ từ trận chung kết bóng đá.(description) Những khoảnh khắc đáng nhớ từ trận chung kết bóng đá.(description) Những khoảnh khắc đáng nhớ từ trận chung kết bóng đá.(description) Những khoảnh khắc đáng nhớ từ trận chung kết bóng đá.Gen thắng chung kết thế giới(description) Những khoảnh khắc đáng nhớ từ trận chung kết bóng đá.(description) Những khoảnh khắc đáng nhớ từ trận chung kết bóng đá.(description) Những khoảnh khắc đáng nhớ từ trận chung kết bóng đá.(description) Những khoảnh khắc đáng nhớ từ trận chung kết bóng đá.Gen thắng chung kết thế giới(description) Những khoảnh khắc đáng nhớ từ trận chung kết bóng đá.(description) Những khoảnh khắc đáng nhớ từ trận chung kết bóng đá.(description) Những khoảnh khắc đáng nhớ từ trận chung kết bóng đá.(description) Những khoảnh khắc đáng nhớ từ trận chung kết bóng đá.Gen thắng chung kết thế giới(description) Những khoảnh khắc đáng nhớ từ trận chung kết bóng đá.(description) Những khoảnh khắc đáng nhớ từ trận chung kết bóng đá.(description) Những khoảnh khắc đáng nhớ từ trận chung kết bóng đá.(description) Những khoảnh khắc đáng nhớ từ trận chung kết bóng đá.Gen thắng chung kết thế giới(description) Những khoảnh khắc đáng nhớ từ trận chung kết bóng đá.(description) Những khoảnh khắc đáng nhớ từ trận chung kết bóng đá.(description) Những khoảnh khắc đáng nhớ từ trận chung kết bóng đá.(description) Những khoảnh khắc đáng nhớ từ trận chung kết bóng đá.Gen thắng chung kết thế giới(description) Những khoảnh khắc đáng nhớ từ trận chung kết bóng đá.(description) Những khoảnh khắc đáng nhớ từ trận chung kết bóng đá.(description) Những khoảnh khắc đáng nhớ từ trận chung kết bóng đá.(description) Những khoảnh khắc đáng nhớ từ trận chung kết bóng đá.",
//     description:
//       "(description) Những khoảnh khắc đáng nhớ từ trận chung kết bóng đá.(description) Những khoảnh khắc đáng nhớ từ trận chung kết bóng đá.(description) Những khoảnh khắc đáng nhớ từ trận chung kết bóng đá.",
//     userId: 2,
//     date: "07-07-2024",
//     imageUrl: "/images/anh2.webp",
//     url: "/",
//   },
//   {
//     id: "3",
//     category: "Công nghệ",
//     title: "(title) Khám phá những địa điểm đẹp nhất thế giới",
//     description: "(description) Những nơi bạn nên ghé thăm trong năm nay.",
//     userId: 3,
//     date: "06-07-2024",
//     imageUrl: "/images/anh3.webp",
//     url: "/",
//   },
//   {
//     id: "4",
//     category: "Giải trí",
//     title: "(title) Top 10 bộ phim đáng xem năm 2024",
//     description: "(description) Những bộ phim bạn không thể bỏ lỡ.",
//     userId: 4,
//     date: "05-07-2024",
//     imageUrl: "/images/anh4.webp",
//     url: "/",
//   },
//   {
//     id: "5",
//     category: "Giải trí",

//     title: "(title) Lợi ích của việc tập thể dục thường xuyên",
//     description: "(description) Tập thể dục giúp cải thiện sức khỏe tổng thể.",
//     userId: 5,
//     date: "04-07-2024",
//     imageUrl: "/images/anh5.webp",
//     url: "/",
//   },
//   {
//     id: "6",
//     category: "Giải trí",

//     title: "(title) Cách quản lý tài chính cá nhân hiệu quả",
//     description:
//       "(description) Những mẹo giúp bạn tiết kiệm và đầu tư thông minh.",
//     userId: 6,
//     date: "03-07-2024",
//     imageUrl: "/images/anh6.webp",
//     url: "/",
//   },
//   {
//     id: "7",
//     category: "Giải trí",

//     title: "(title) Tầm quan trọng của giáo dục trong thời đại số",
//     description: "(description) Giáo dục là chìa khóa thành công.",
//     userId: 7,
//     date: "02-07-2024",
//     imageUrl: "/images/anh7.webp",
//     url: "/",
//   },
//   {
//     id: "8",
//     category: "Giải trí",

//     title: "(title) Những món ăn ngon không thể bỏ qua",
//     description: "(description) Khám phá ẩm thực đa dạng trên thế giới.",
//     userId: 8,
//     date: "01-07-2024",
//     imageUrl: "/images/anh8.webp",
//     url: "/",
//   },
//   {
//     id: "9",
//     category: "Giải trí",
//     title: "(title) Xu hướng thời trang năm 2024",
//     description: "(description) Những kiểu dáng và màu sắc hot nhất.",
//     userId: 9,
//     date: "30-06-2024",
//     imageUrl: "/images/anh9.webp",
//     url: "/",
//   },
//   {
//     id: "10",
//     category: "Nghệ thuật",
//     title: "(title) Triển lãm nghệ thuật nổi bật trong năm nay",
//     description: "(description) Những tác phẩm nghệ thuật đáng chú ý.",
//     userId: 10,
//     date: "29-06-2024",
//     imageUrl: "/images/anh10.webp",
//     url: "/",
//   },
//   {
//     id: "11",
//     category: "Xe cộ",
//     title: "(title) Những mẫu xe mới nhất năm 2024",
//     description: "(description) Cập nhật về các dòng xe hot trên thị trường.",
//     userId: 11,
//     date: "28-06-2024",
//     imageUrl: "/images/anh11.webp",
//     url: "/",
//   },
//   {
//     id: "12",
//     category: "Âm nhạc",
//     title: "(title) Album đáng chú ý trong năm 2024",
//     description: "(description) Nhạc mới từ các nghệ sĩ nổi tiếng.",
//     userId: 12,
//     date: "27-06-2024",
//     imageUrl: "/images/anh12.webp",
//     url: "/",
//   },
//   {
//     id: "13",
//     category: "Thế giới",
//     title: "(title) Các sự kiện chính trị đáng chú ý",
//     description: "(description) Phân tích về tình hình chính trị toàn cầu.",
//     userId: 13,
//     date: "26-06-2024",
//     imageUrl: "/images/anh13.webp",
//     url: "/",
//   },
//   {
//     id: "14",
//     category: "Khoa học",
//     title: "(title) Những phát hiện khoa học nổi bật",
//     description: "(description) Cập nhật về những nghiên cứu mới nhất.",
//     userId: 14,
//     date: "25-06-2024",
//     imageUrl: "/images/anh14.webp",
//     url: "/",
//   },
//   {
//     id: "15",
//     category: "Thú cưng",
//     title: "(title) Cách chăm sóc thú cưng của bạn",
//     description: "(description) Những lưu ý quan trọng khi nuôi thú cưng.",
//     userId: 15,
//     date: "24-06-2024",
//     imageUrl: "/images/anh15.webp",
//     url: "/",
//   },
//   {
//     id: "16",
//     category: "Làm đẹp",
//     title: "(title) Bí quyết làm đẹp tự nhiên",
//     description: "(description) Cách chăm sóc sắc đẹp từ thiên nhiên.",
//     userId: 16,
//     date: "23-06-2024",
//     imageUrl: "/images/anh16.webp",
//     url: "/",
//   },
//   {
//     id: "17",
//     category: "Khởi nghiệp",
//     title: "(title) Ý tưởng khởi nghiệp tiềm năng trong năm 2024",
//     description: "(description) Cơ hội đầu tư và khởi nghiệp hấp dẫn.",
//     userId: 17,
//     date: "22-06-2024",
//     imageUrl: "/images/anh17.webp",
//     url: "/",
//   },
//   {
//     id: "18",
//     category: "Lịch sử",
//     title: "(title) Những sự kiện lịch sử quan trọng",
//     description:
//       "(description) Những mốc son đáng nhớ trong lịch sử nhân loại.",
//     userId: 18,
//     date: "21-06-2024",
//     imageUrl: "/images/anh18.webp",
//     url: "/",
//   },
//   {
//     id: "19",
//     category: "Tâm lý",
//     title: "(title) Hiểu biết về tâm lý con người",
//     description: "(description) Những khía cạnh thú vị về tâm lý học.",
//     userId: 19,
//     date: "20-06-2024",
//     imageUrl: "/images/anh19.webp",
//     url: "/",
//   },
//   {
//     id: "20",
//     category: "Gia đình",
//     title: "(title) Cách nuôi dạy trẻ em thông minh",
//     description: "(description) Những phương pháp giáo dục hiệu quả.",
//     userId: 20,
//     date: "19-06-2024",
//     imageUrl: "/images/anh20.webp",
//     url: "/",
//   },
// ];

export const articles = [
  {
    id: "1",
    category: "Công nghệ",
    title:
      "(title) Microsoft công bố cam kết 5 năm tạo cơ hội lớn hơn cho người khuyết tật",
    description:
      "(description) Y tế từ xa đang cung cấp những cách thức mới để bệnh nhân kết nối với các nhà cung cấp dịch vụ chăm sóc sức khỏe. (description) Y tế từ xa đang cung cấp những cách thức mới để bệnh nhân kết nối với các nhà cung cấp dịch vụ chăm sóc sức khỏe. ",
    userId: 1,
    date: "07-07-2024",
    content: "Microsoft đã công bố cam kết kéo dài 5 năm để tạo ra các cơ hội lớn hơn cho người khuyết tật. Công ty này sẽ tập trung vào việc phát triển công nghệ giúp người khuyết tật tiếp cận dễ dàng hơn với các dịch vụ và sản phẩm. Microsoft đã công bố cam kết kéo dài 5 năm để tạo ra các cơ hội lớn hơn cho người khuyết tật. Công ty này sẽ tập trung vào việc phát triển công nghệ giúp người khuyết tật tiếp cận dễ dàng hơn với các dịch vụ và sản phẩm.Microsoft đã công bố cam kết kéo dài 5 năm để tạo ra các cơ hội lớn hơn cho người khuyết tật. Công ty này sẽ tập trung vào việc phát triển công nghệ giúp người khuyết tật tiếp cận dễ dàng hơn với các dịch vụ và sản phẩm.Microsoft đã công bố cam kết kéo dài 5 năm để tạo ra các cơ hội lớn hơn cho người khuyết tật. Công ty này sẽ tập trung vào việc phát triển công nghệ giúp người khuyết tật tiếp cận dễ dàng hơn với các dịch vụ và sản phẩm.Microsoft đã công bố cam kết kéo dài 5 năm để tạo ra các cơ hội lớn hơn cho người khuyết tật. Công ty này sẽ tập trung vào việc phát triển công nghệ giúp người khuyết tật tiếp cận dễ dàng hơn với các dịch vụ và sản phẩm.Microsoft đã công bố cam kết kéo dài 5 năm để tạo ra các cơ hội lớn hơn cho người khuyết tật. Công ty này sẽ tập trung vào việc phát triển công nghệ giúp người khuyết tật tiếp cận dễ dàng hơn với các dịch vụ và sản phẩm.",
    imageUrl: [
      "/images/anh1.webp",
      "/images/anh2.webp",
      "/images/anh3.webp",
      "/images/anh4.webp",
      "/images/anh5.webp",
      "/images/anh6.webp"
    ],
    videos: [
      "https://www.youtube.com/embed/RrIAqU4O2tw",
      "https://www.youtube.com/embed/anotherVideoId",
      "https://www.youtube.com/embed/yetAnotherVideoId"
    ],
    url: "/",
  },
  {
    id: "2",
    category: "Công nghệ",

    title: "(title) Gen thắng chung kết thế giới",
    description:
      "(description) Những khoảnh khắc đáng nhớ từ trận chung kết bóng đá. ",
    userId: 2,
    date: "07-07-2024",
    content: "Microsoft đã công bố cam kết kéo dài 5 năm để tạo ra các cơ hội lớn hơn cho người khuyết tật. Công ty này sẽ tập trung vào việc phát triển công nghệ giúp người khuyết tật tiếp cận dễ dàng hơn với các dịch vụ và sản phẩm. Microsoft đã công bố cam kết kéo dài 5 năm để tạo ra các cơ hội lớn hơn cho người khuyết tật. Công ty này sẽ tập trung vào việc phát triển công nghệ giúp người khuyết tật tiếp cận dễ dàng hơn với các dịch vụ và sản phẩm.Microsoft đã công bố cam kết kéo dài 5 năm để tạo ra các cơ hội lớn hơn cho người khuyết tật. Công ty này sẽ tập trung vào việc phát triển công nghệ giúp người khuyết tật tiếp cận dễ dàng hơn với các dịch vụ và sản phẩm.Microsoft đã công bố cam kết kéo dài 5 năm để tạo ra các cơ hội lớn hơn cho người khuyết tật. Công ty này sẽ tập trung vào việc phát triển công nghệ giúp người khuyết tật tiếp cận dễ dàng hơn với các dịch vụ và sản phẩm.Microsoft đã công bố cam kết kéo dài 5 năm để tạo ra các cơ hội lớn hơn cho người khuyết tật. Công ty này sẽ tập trung vào việc phát triển công nghệ giúp người khuyết tật tiếp cận dễ dàng hơn với các dịch vụ và sản phẩm.Microsoft đã công bố cam kết kéo dài 5 năm để tạo ra các cơ hội lớn hơn cho người khuyết tật. Công ty này sẽ tập trung vào việc phát triển công nghệ giúp người khuyết tật tiếp cận dễ dàng hơn với các dịch vụ và sản phẩm.",
    imageUrl: [
      "/images/anh4.webp",
      "/images/anh5.webp",
      "/images/anh6.webp"
    ],
    videos: [
      "https://www.youtube.com/embed/RrIAqU4O2tw",
      "https://www.youtube.com/embed/anotherVideoId",
      "https://www.youtube.com/embed/yetAnotherVideoId"
    ],
    url: "/",
  },
  {
    id: "3",
    category: "Công nghệ",
    title: "(title) Khám phá những địa điểm đẹp nhất thế giới",
    description: "(description) Những nơi bạn nên ghé thăm trong năm nay.",
    userId: 3,
    date: "06-07-2024",
    content: "Microsoft đã công bố cam kết kéo dài 5 năm để tạo ra các cơ hội lớn hơn cho người khuyết tật. Công ty này sẽ tập trung vào việc phát triển công nghệ giúp người khuyết tật tiếp cận dễ dàng hơn với các dịch vụ và sản phẩm. Microsoft đã công bố cam kết kéo dài 5 năm để tạo ra các cơ hội lớn hơn cho người khuyết tật. Công ty này sẽ tập trung vào việc phát triển công nghệ giúp người khuyết tật tiếp cận dễ dàng hơn với các dịch vụ và sản phẩm.Microsoft đã công bố cam kết kéo dài 5 năm để tạo ra các cơ hội lớn hơn cho người khuyết tật. Công ty này sẽ tập trung vào việc phát triển công nghệ giúp người khuyết tật tiếp cận dễ dàng hơn với các dịch vụ và sản phẩm.Microsoft đã công bố cam kết kéo dài 5 năm để tạo ra các cơ hội lớn hơn cho người khuyết tật. Công ty này sẽ tập trung vào việc phát triển công nghệ giúp người khuyết tật tiếp cận dễ dàng hơn với các dịch vụ và sản phẩm.Microsoft đã công bố cam kết kéo dài 5 năm để tạo ra các cơ hội lớn hơn cho người khuyết tật. Công ty này sẽ tập trung vào việc phát triển công nghệ giúp người khuyết tật tiếp cận dễ dàng hơn với các dịch vụ và sản phẩm.Microsoft đã công bố cam kết kéo dài 5 năm để tạo ra các cơ hội lớn hơn cho người khuyết tật. Công ty này sẽ tập trung vào việc phát triển công nghệ giúp người khuyết tật tiếp cận dễ dàng hơn với các dịch vụ và sản phẩm.",
    imageUrl: [
      "/images/anh1.webp",
      "/images/anh2.webp",
      "/images/anh3.webp",
      "/images/anh4.webp",
      "/images/anh5.webp",
      "/images/anh6.webp"
    ],
    videos: [
      "https://www.youtube.com/embed/RrIAqU4O2tw",
      "https://www.youtube.com/embed/anotherVideoId",
      "https://www.youtube.com/embed/yetAnotherVideoId"
    ],
    url: "/",
  },
  {
    id: "4",
    category: "Giải trí",
    title: "(title) Top 10 bộ phim đáng xem năm 2024",
    description: "(description) Những bộ phim bạn không thể bỏ lỡ.",
    userId: 4,
    date: "05-07-2024",
    content: "Microsoft đã công bố cam kết kéo dài 5 năm để tạo ra các cơ hội lớn hơn cho người khuyết tật. Công ty này sẽ tập trung vào việc phát triển công nghệ giúp người khuyết tật tiếp cận dễ dàng hơn với các dịch vụ và sản phẩm. Microsoft đã công bố cam kết kéo dài 5 năm để tạo ra các cơ hội lớn hơn cho người khuyết tật. Công ty này sẽ tập trung vào việc phát triển công nghệ giúp người khuyết tật tiếp cận dễ dàng hơn với các dịch vụ và sản phẩm.Microsoft đã công bố cam kết kéo dài 5 năm để tạo ra các cơ hội lớn hơn cho người khuyết tật. Công ty này sẽ tập trung vào việc phát triển công nghệ giúp người khuyết tật tiếp cận dễ dàng hơn với các dịch vụ và sản phẩm.Microsoft đã công bố cam kết kéo dài 5 năm để tạo ra các cơ hội lớn hơn cho người khuyết tật. Công ty này sẽ tập trung vào việc phát triển công nghệ giúp người khuyết tật tiếp cận dễ dàng hơn với các dịch vụ và sản phẩm.Microsoft đã công bố cam kết kéo dài 5 năm để tạo ra các cơ hội lớn hơn cho người khuyết tật. Công ty này sẽ tập trung vào việc phát triển công nghệ giúp người khuyết tật tiếp cận dễ dàng hơn với các dịch vụ và sản phẩm.Microsoft đã công bố cam kết kéo dài 5 năm để tạo ra các cơ hội lớn hơn cho người khuyết tật. Công ty này sẽ tập trung vào việc phát triển công nghệ giúp người khuyết tật tiếp cận dễ dàng hơn với các dịch vụ và sản phẩm.",
    imageUrl: [
      "/images/anh1.webp",
      "/images/anh2.webp",
      "/images/anh3.webp",
      "/images/anh4.webp",
      "/images/anh5.webp",
      "/images/anh6.webp"
    ],
    videos: [
      "https://www.youtube.com/embed/RrIAqU4O2tw",
      "https://www.youtube.com/embed/anotherVideoId",
      "https://www.youtube.com/embed/yetAnotherVideoId"
    ],
    url: "/",
  },
  {
    id: "5",
    category: "Giải trí",

    title: "(title) Lợi ích của việc tập thể dục thường xuyên",
    description: "(description) Tập thể dục giúp cải thiện sức khỏe tổng thể.",
    userId: 5,
    date: "04-07-2024",
    content: "Microsoft đã công bố cam kết kéo dài 5 năm để tạo ra các cơ hội lớn hơn cho người khuyết tật. Công ty này sẽ tập trung vào việc phát triển công nghệ giúp người khuyết tật tiếp cận dễ dàng hơn với các dịch vụ và sản phẩm. Microsoft đã công bố cam kết kéo dài 5 năm để tạo ra các cơ hội lớn hơn cho người khuyết tật. Công ty này sẽ tập trung vào việc phát triển công nghệ giúp người khuyết tật tiếp cận dễ dàng hơn với các dịch vụ và sản phẩm.Microsoft đã công bố cam kết kéo dài 5 năm để tạo ra các cơ hội lớn hơn cho người khuyết tật. Công ty này sẽ tập trung vào việc phát triển công nghệ giúp người khuyết tật tiếp cận dễ dàng hơn với các dịch vụ và sản phẩm.Microsoft đã công bố cam kết kéo dài 5 năm để tạo ra các cơ hội lớn hơn cho người khuyết tật. Công ty này sẽ tập trung vào việc phát triển công nghệ giúp người khuyết tật tiếp cận dễ dàng hơn với các dịch vụ và sản phẩm.Microsoft đã công bố cam kết kéo dài 5 năm để tạo ra các cơ hội lớn hơn cho người khuyết tật. Công ty này sẽ tập trung vào việc phát triển công nghệ giúp người khuyết tật tiếp cận dễ dàng hơn với các dịch vụ và sản phẩm.Microsoft đã công bố cam kết kéo dài 5 năm để tạo ra các cơ hội lớn hơn cho người khuyết tật. Công ty này sẽ tập trung vào việc phát triển công nghệ giúp người khuyết tật tiếp cận dễ dàng hơn với các dịch vụ và sản phẩm.",
    imageUrl: [
      "/images/anh1.webp",
      "/images/anh2.webp",
      "/images/anh3.webp",
      "/images/anh4.webp",
      "/images/anh5.webp",
      "/images/anh6.webp"
    ],
    videos: [
      "https://www.youtube.com/embed/RrIAqU4O2tw",
      "https://www.youtube.com/embed/anotherVideoId",
      "https://www.youtube.com/embed/yetAnotherVideoId"
    ],
    url: "/",
  },
  {
    id: "6",
    category: "Giải trí",

    title: "(title) Cách quản lý tài chính cá nhân hiệu quả",
    description:
      "(description) Những mẹo giúp bạn tiết kiệm và đầu tư thông minh.",
    userId: 6,
    date: "03-07-2024",
    content: "Microsoft đã công bố cam kết kéo dài 5 năm để tạo ra các cơ hội lớn hơn cho người khuyết tật. Công ty này sẽ tập trung vào việc phát triển công nghệ giúp người khuyết tật tiếp cận dễ dàng hơn với các dịch vụ và sản phẩm. Microsoft đã công bố cam kết kéo dài 5 năm để tạo ra các cơ hội lớn hơn cho người khuyết tật. Công ty này sẽ tập trung vào việc phát triển công nghệ giúp người khuyết tật tiếp cận dễ dàng hơn với các dịch vụ và sản phẩm.Microsoft đã công bố cam kết kéo dài 5 năm để tạo ra các cơ hội lớn hơn cho người khuyết tật. Công ty này sẽ tập trung vào việc phát triển công nghệ giúp người khuyết tật tiếp cận dễ dàng hơn với các dịch vụ và sản phẩm.Microsoft đã công bố cam kết kéo dài 5 năm để tạo ra các cơ hội lớn hơn cho người khuyết tật. Công ty này sẽ tập trung vào việc phát triển công nghệ giúp người khuyết tật tiếp cận dễ dàng hơn với các dịch vụ và sản phẩm.Microsoft đã công bố cam kết kéo dài 5 năm để tạo ra các cơ hội lớn hơn cho người khuyết tật. Công ty này sẽ tập trung vào việc phát triển công nghệ giúp người khuyết tật tiếp cận dễ dàng hơn với các dịch vụ và sản phẩm.Microsoft đã công bố cam kết kéo dài 5 năm để tạo ra các cơ hội lớn hơn cho người khuyết tật. Công ty này sẽ tập trung vào việc phát triển công nghệ giúp người khuyết tật tiếp cận dễ dàng hơn với các dịch vụ và sản phẩm.",
    imageUrl: [
      "/images/anh1.webp",
      "/images/anh2.webp",
      "/images/anh3.webp",
      "/images/anh4.webp",
      "/images/anh5.webp",
      "/images/anh6.webp"
    ],
    videos: [
      "https://www.youtube.com/embed/RrIAqU4O2tw",
      "https://www.youtube.com/embed/anotherVideoId",
      "https://www.youtube.com/embed/yetAnotherVideoId"
    ],
    url: "/",
  },
  {
    id: "7",
    category: "Giải trí",

    title: "(title) Tầm quan trọng của giáo dục trong thời đại số",
    description: "(description) Giáo dục là chìa khóa thành công.",
    userId: 7,
    date: "02-07-2024",
    content: "Microsoft đã công bố cam kết kéo dài 5 năm để tạo ra các cơ hội lớn hơn cho người khuyết tật. Công ty này sẽ tập trung vào việc phát triển công nghệ giúp người khuyết tật tiếp cận dễ dàng hơn với các dịch vụ và sản phẩm. Microsoft đã công bố cam kết kéo dài 5 năm để tạo ra các cơ hội lớn hơn cho người khuyết tật. Công ty này sẽ tập trung vào việc phát triển công nghệ giúp người khuyết tật tiếp cận dễ dàng hơn với các dịch vụ và sản phẩm.Microsoft đã công bố cam kết kéo dài 5 năm để tạo ra các cơ hội lớn hơn cho người khuyết tật. Công ty này sẽ tập trung vào việc phát triển công nghệ giúp người khuyết tật tiếp cận dễ dàng hơn với các dịch vụ và sản phẩm.Microsoft đã công bố cam kết kéo dài 5 năm để tạo ra các cơ hội lớn hơn cho người khuyết tật. Công ty này sẽ tập trung vào việc phát triển công nghệ giúp người khuyết tật tiếp cận dễ dàng hơn với các dịch vụ và sản phẩm.Microsoft đã công bố cam kết kéo dài 5 năm để tạo ra các cơ hội lớn hơn cho người khuyết tật. Công ty này sẽ tập trung vào việc phát triển công nghệ giúp người khuyết tật tiếp cận dễ dàng hơn với các dịch vụ và sản phẩm.Microsoft đã công bố cam kết kéo dài 5 năm để tạo ra các cơ hội lớn hơn cho người khuyết tật. Công ty này sẽ tập trung vào việc phát triển công nghệ giúp người khuyết tật tiếp cận dễ dàng hơn với các dịch vụ và sản phẩm.",
    imageUrl: [
      "/images/anh1.webp",
      "/images/anh2.webp",
      "/images/anh3.webp",
      "/images/anh4.webp",
      "/images/anh5.webp",
      "/images/anh6.webp"
    ],
    videos: [
      "https://www.youtube.com/embed/RrIAqU4O2tw",
      "https://www.youtube.com/embed/anotherVideoId",
      "https://www.youtube.com/embed/yetAnotherVideoId"
    ],
    url: "/",
  },
  {
    id: "8",
    category: "Giải trí",

    title: "(title) Những món ăn ngon không thể bỏ qua",
    description: "(description) Khám phá ẩm thực đa dạng trên thế giới.",
    userId: 8,
    date: "01-07-2024",
    content: "Microsoft đã công bố cam kết kéo dài 5 năm để tạo ra các cơ hội lớn hơn cho người khuyết tật. Công ty này sẽ tập trung vào việc phát triển công nghệ giúp người khuyết tật tiếp cận dễ dàng hơn với các dịch vụ và sản phẩm. Microsoft đã công bố cam kết kéo dài 5 năm để tạo ra các cơ hội lớn hơn cho người khuyết tật. Công ty này sẽ tập trung vào việc phát triển công nghệ giúp người khuyết tật tiếp cận dễ dàng hơn với các dịch vụ và sản phẩm.Microsoft đã công bố cam kết kéo dài 5 năm để tạo ra các cơ hội lớn hơn cho người khuyết tật. Công ty này sẽ tập trung vào việc phát triển công nghệ giúp người khuyết tật tiếp cận dễ dàng hơn với các dịch vụ và sản phẩm.Microsoft đã công bố cam kết kéo dài 5 năm để tạo ra các cơ hội lớn hơn cho người khuyết tật. Công ty này sẽ tập trung vào việc phát triển công nghệ giúp người khuyết tật tiếp cận dễ dàng hơn với các dịch vụ và sản phẩm.Microsoft đã công bố cam kết kéo dài 5 năm để tạo ra các cơ hội lớn hơn cho người khuyết tật. Công ty này sẽ tập trung vào việc phát triển công nghệ giúp người khuyết tật tiếp cận dễ dàng hơn với các dịch vụ và sản phẩm.Microsoft đã công bố cam kết kéo dài 5 năm để tạo ra các cơ hội lớn hơn cho người khuyết tật. Công ty này sẽ tập trung vào việc phát triển công nghệ giúp người khuyết tật tiếp cận dễ dàng hơn với các dịch vụ và sản phẩm.",
    imageUrl: [
      "/images/anh1.webp",
      "/images/anh2.webp",
      "/images/anh3.webp",
      "/images/anh4.webp",
      "/images/anh5.webp",
      "/images/anh6.webp"
    ],
    videos: [
      "https://www.youtube.com/embed/RrIAqU4O2tw",
      "https://www.youtube.com/embed/anotherVideoId",
      "https://www.youtube.com/embed/yetAnotherVideoId"
    ],
    url: "/",
  },
  {
    id: "9",
    category: "Giải trí",
    title: "(title) Xu hướng thời trang năm 2024",
    description: "(description) Những kiểu dáng và màu sắc hot nhất.",
    userId: 9,
    date: "30-06-2024",
    content: "Microsoft đã công bố cam kết kéo dài 5 năm để tạo ra các cơ hội lớn hơn cho người khuyết tật. Công ty này sẽ tập trung vào việc phát triển công nghệ giúp người khuyết tật tiếp cận dễ dàng hơn với các dịch vụ và sản phẩm. Microsoft đã công bố cam kết kéo dài 5 năm để tạo ra các cơ hội lớn hơn cho người khuyết tật. Công ty này sẽ tập trung vào việc phát triển công nghệ giúp người khuyết tật tiếp cận dễ dàng hơn với các dịch vụ và sản phẩm.Microsoft đã công bố cam kết kéo dài 5 năm để tạo ra các cơ hội lớn hơn cho người khuyết tật. Công ty này sẽ tập trung vào việc phát triển công nghệ giúp người khuyết tật tiếp cận dễ dàng hơn với các dịch vụ và sản phẩm.Microsoft đã công bố cam kết kéo dài 5 năm để tạo ra các cơ hội lớn hơn cho người khuyết tật. Công ty này sẽ tập trung vào việc phát triển công nghệ giúp người khuyết tật tiếp cận dễ dàng hơn với các dịch vụ và sản phẩm.Microsoft đã công bố cam kết kéo dài 5 năm để tạo ra các cơ hội lớn hơn cho người khuyết tật. Công ty này sẽ tập trung vào việc phát triển công nghệ giúp người khuyết tật tiếp cận dễ dàng hơn với các dịch vụ và sản phẩm.Microsoft đã công bố cam kết kéo dài 5 năm để tạo ra các cơ hội lớn hơn cho người khuyết tật. Công ty này sẽ tập trung vào việc phát triển công nghệ giúp người khuyết tật tiếp cận dễ dàng hơn với các dịch vụ và sản phẩm.",
    imageUrl: [
      "/images/anh1.webp",
      "/images/anh2.webp",
      "/images/anh3.webp",
      "/images/anh4.webp",
      "/images/anh5.webp",
      "/images/anh6.webp"
    ],
    videos: [
      "https://www.youtube.com/embed/RrIAqU4O2tw",
      "https://www.youtube.com/embed/anotherVideoId",
      "https://www.youtube.com/embed/yetAnotherVideoId"
    ],
    url: "/",
  },
  {
    id: "10",
    category: "Nghệ thuật",
    title: "(title) Triển lãm nghệ thuật nổi bật trong năm nay",
    description: "(description) Những tác phẩm nghệ thuật đáng chú ý.",
    userId: 10,
    date: "29-06-2024",
    content: "Microsoft đã công bố cam kết kéo dài 5 năm để tạo ra các cơ hội lớn hơn cho người khuyết tật. Công ty này sẽ tập trung vào việc phát triển công nghệ giúp người khuyết tật tiếp cận dễ dàng hơn với các dịch vụ và sản phẩm. Microsoft đã công bố cam kết kéo dài 5 năm để tạo ra các cơ hội lớn hơn cho người khuyết tật. Công ty này sẽ tập trung vào việc phát triển công nghệ giúp người khuyết tật tiếp cận dễ dàng hơn với các dịch vụ và sản phẩm.Microsoft đã công bố cam kết kéo dài 5 năm để tạo ra các cơ hội lớn hơn cho người khuyết tật. Công ty này sẽ tập trung vào việc phát triển công nghệ giúp người khuyết tật tiếp cận dễ dàng hơn với các dịch vụ và sản phẩm.Microsoft đã công bố cam kết kéo dài 5 năm để tạo ra các cơ hội lớn hơn cho người khuyết tật. Công ty này sẽ tập trung vào việc phát triển công nghệ giúp người khuyết tật tiếp cận dễ dàng hơn với các dịch vụ và sản phẩm.Microsoft đã công bố cam kết kéo dài 5 năm để tạo ra các cơ hội lớn hơn cho người khuyết tật. Công ty này sẽ tập trung vào việc phát triển công nghệ giúp người khuyết tật tiếp cận dễ dàng hơn với các dịch vụ và sản phẩm.Microsoft đã công bố cam kết kéo dài 5 năm để tạo ra các cơ hội lớn hơn cho người khuyết tật. Công ty này sẽ tập trung vào việc phát triển công nghệ giúp người khuyết tật tiếp cận dễ dàng hơn với các dịch vụ và sản phẩm.",
    imageUrl: [
      "/images/anh1.webp",
      "/images/anh2.webp",
      "/images/anh3.webp",
      "/images/anh4.webp",
      "/images/anh5.webp",
      "/images/anh6.webp"
    ],
    videos: [
      "https://www.youtube.com/embed/RrIAqU4O2tw",
      "https://www.youtube.com/embed/anotherVideoId",
      "https://www.youtube.com/embed/yetAnotherVideoId"
    ],
    url: "/",
  },
  {
    id: "11",
    category: "Xe cộ",
    title: "(title) Những mẫu xe mới nhất năm 2024",
    description: "(description) Cập nhật về các dòng xe hot trên thị trường.",
    userId: 11,
    date: "28-06-2024",
    content: "Microsoft đã công bố cam kết kéo dài 5 năm để tạo ra các cơ hội lớn hơn cho người khuyết tật. Công ty này sẽ tập trung vào việc phát triển công nghệ giúp người khuyết tật tiếp cận dễ dàng hơn với các dịch vụ và sản phẩm. Microsoft đã công bố cam kết kéo dài 5 năm để tạo ra các cơ hội lớn hơn cho người khuyết tật. Công ty này sẽ tập trung vào việc phát triển công nghệ giúp người khuyết tật tiếp cận dễ dàng hơn với các dịch vụ và sản phẩm.Microsoft đã công bố cam kết kéo dài 5 năm để tạo ra các cơ hội lớn hơn cho người khuyết tật. Công ty này sẽ tập trung vào việc phát triển công nghệ giúp người khuyết tật tiếp cận dễ dàng hơn với các dịch vụ và sản phẩm.Microsoft đã công bố cam kết kéo dài 5 năm để tạo ra các cơ hội lớn hơn cho người khuyết tật. Công ty này sẽ tập trung vào việc phát triển công nghệ giúp người khuyết tật tiếp cận dễ dàng hơn với các dịch vụ và sản phẩm.Microsoft đã công bố cam kết kéo dài 5 năm để tạo ra các cơ hội lớn hơn cho người khuyết tật. Công ty này sẽ tập trung vào việc phát triển công nghệ giúp người khuyết tật tiếp cận dễ dàng hơn với các dịch vụ và sản phẩm.Microsoft đã công bố cam kết kéo dài 5 năm để tạo ra các cơ hội lớn hơn cho người khuyết tật. Công ty này sẽ tập trung vào việc phát triển công nghệ giúp người khuyết tật tiếp cận dễ dàng hơn với các dịch vụ và sản phẩm.",
    imageUrl: [
      "/images/anh1.webp",
      "/images/anh2.webp",
      "/images/anh3.webp",
      "/images/anh4.webp",
      "/images/anh5.webp",
      "/images/anh6.webp"
    ],
    videos: [
      "https://www.youtube.com/embed/RrIAqU4O2tw",
      "https://www.youtube.com/embed/anotherVideoId",
      "https://www.youtube.com/embed/yetAnotherVideoId"
    ],
    url: "/",
  },
  {
    id: "12",
    category: "Âm nhạc",
    title: "(title) Album đáng chú ý trong năm 2024",
    description: "(description) Nhạc mới từ các nghệ sĩ nổi tiếng.",
    userId: 12,
    date: "27-06-2024",
    content: "Microsoft đã công bố cam kết kéo dài 5 năm để tạo ra các cơ hội lớn hơn cho người khuyết tật. Công ty này sẽ tập trung vào việc phát triển công nghệ giúp người khuyết tật tiếp cận dễ dàng hơn với các dịch vụ và sản phẩm. Microsoft đã công bố cam kết kéo dài 5 năm để tạo ra các cơ hội lớn hơn cho người khuyết tật. Công ty này sẽ tập trung vào việc phát triển công nghệ giúp người khuyết tật tiếp cận dễ dàng hơn với các dịch vụ và sản phẩm.Microsoft đã công bố cam kết kéo dài 5 năm để tạo ra các cơ hội lớn hơn cho người khuyết tật. Công ty này sẽ tập trung vào việc phát triển công nghệ giúp người khuyết tật tiếp cận dễ dàng hơn với các dịch vụ và sản phẩm.Microsoft đã công bố cam kết kéo dài 5 năm để tạo ra các cơ hội lớn hơn cho người khuyết tật. Công ty này sẽ tập trung vào việc phát triển công nghệ giúp người khuyết tật tiếp cận dễ dàng hơn với các dịch vụ và sản phẩm.Microsoft đã công bố cam kết kéo dài 5 năm để tạo ra các cơ hội lớn hơn cho người khuyết tật. Công ty này sẽ tập trung vào việc phát triển công nghệ giúp người khuyết tật tiếp cận dễ dàng hơn với các dịch vụ và sản phẩm.Microsoft đã công bố cam kết kéo dài 5 năm để tạo ra các cơ hội lớn hơn cho người khuyết tật. Công ty này sẽ tập trung vào việc phát triển công nghệ giúp người khuyết tật tiếp cận dễ dàng hơn với các dịch vụ và sản phẩm.",
    imageUrl: [
      "/images/anh1.webp",
      "/images/anh2.webp",
      "/images/anh3.webp",
      "/images/anh4.webp",
      "/images/anh5.webp",
      "/images/anh6.webp"
    ],
    videos: [
      "https://www.youtube.com/embed/RrIAqU4O2tw",
      "https://www.youtube.com/embed/anotherVideoId",
      "https://www.youtube.com/embed/yetAnotherVideoId"
    ],
    url: "/",
  },
  {
    id: "13",
    category: "Thế giới",
    title: "(title) Các sự kiện chính trị đáng chú ý",
    description: "(description) Phân tích về tình hình chính trị toàn cầu.",
    userId: 13,
    date: "26-06-2024",
    content: "Microsoft đã công bố cam kết kéo dài 5 năm để tạo ra các cơ hội lớn hơn cho người khuyết tật. Công ty này sẽ tập trung vào việc phát triển công nghệ giúp người khuyết tật tiếp cận dễ dàng hơn với các dịch vụ và sản phẩm. Microsoft đã công bố cam kết kéo dài 5 năm để tạo ra các cơ hội lớn hơn cho người khuyết tật. Công ty này sẽ tập trung vào việc phát triển công nghệ giúp người khuyết tật tiếp cận dễ dàng hơn với các dịch vụ và sản phẩm.Microsoft đã công bố cam kết kéo dài 5 năm để tạo ra các cơ hội lớn hơn cho người khuyết tật. Công ty này sẽ tập trung vào việc phát triển công nghệ giúp người khuyết tật tiếp cận dễ dàng hơn với các dịch vụ và sản phẩm.Microsoft đã công bố cam kết kéo dài 5 năm để tạo ra các cơ hội lớn hơn cho người khuyết tật. Công ty này sẽ tập trung vào việc phát triển công nghệ giúp người khuyết tật tiếp cận dễ dàng hơn với các dịch vụ và sản phẩm.Microsoft đã công bố cam kết kéo dài 5 năm để tạo ra các cơ hội lớn hơn cho người khuyết tật. Công ty này sẽ tập trung vào việc phát triển công nghệ giúp người khuyết tật tiếp cận dễ dàng hơn với các dịch vụ và sản phẩm.Microsoft đã công bố cam kết kéo dài 5 năm để tạo ra các cơ hội lớn hơn cho người khuyết tật. Công ty này sẽ tập trung vào việc phát triển công nghệ giúp người khuyết tật tiếp cận dễ dàng hơn với các dịch vụ và sản phẩm.",
    imageUrl: [
      "/images/anh1.webp",
      "/images/anh2.webp",
      "/images/anh3.webp",
      "/images/anh4.webp",
      "/images/anh5.webp",
      "/images/anh6.webp"
    ],
    videos: [
      "https://www.youtube.com/embed/RrIAqU4O2tw",
      "https://www.youtube.com/embed/anotherVideoId",
      "https://www.youtube.com/embed/yetAnotherVideoId"
    ],
    url: "/",
  },
  {
    id: "14",
    category: "Khoa học",
    title: "(title) Những phát hiện khoa học nổi bật",
    description: "(description) Cập nhật về những nghiên cứu mới nhất.",
    userId: 14,
    date: "25-06-2024",
    content: "Microsoft đã công bố cam kết kéo dài 5 năm để tạo ra các cơ hội lớn hơn cho người khuyết tật. Công ty này sẽ tập trung vào việc phát triển công nghệ giúp người khuyết tật tiếp cận dễ dàng hơn với các dịch vụ và sản phẩm. Microsoft đã công bố cam kết kéo dài 5 năm để tạo ra các cơ hội lớn hơn cho người khuyết tật. Công ty này sẽ tập trung vào việc phát triển công nghệ giúp người khuyết tật tiếp cận dễ dàng hơn với các dịch vụ và sản phẩm.Microsoft đã công bố cam kết kéo dài 5 năm để tạo ra các cơ hội lớn hơn cho người khuyết tật. Công ty này sẽ tập trung vào việc phát triển công nghệ giúp người khuyết tật tiếp cận dễ dàng hơn với các dịch vụ và sản phẩm.Microsoft đã công bố cam kết kéo dài 5 năm để tạo ra các cơ hội lớn hơn cho người khuyết tật. Công ty này sẽ tập trung vào việc phát triển công nghệ giúp người khuyết tật tiếp cận dễ dàng hơn với các dịch vụ và sản phẩm.Microsoft đã công bố cam kết kéo dài 5 năm để tạo ra các cơ hội lớn hơn cho người khuyết tật. Công ty này sẽ tập trung vào việc phát triển công nghệ giúp người khuyết tật tiếp cận dễ dàng hơn với các dịch vụ và sản phẩm.Microsoft đã công bố cam kết kéo dài 5 năm để tạo ra các cơ hội lớn hơn cho người khuyết tật. Công ty này sẽ tập trung vào việc phát triển công nghệ giúp người khuyết tật tiếp cận dễ dàng hơn với các dịch vụ và sản phẩm.",
    imageUrl: [
      "/images/anh1.webp",
      "/images/anh2.webp",
      "/images/anh3.webp",
      "/images/anh4.webp",
      "/images/anh5.webp",
      "/images/anh6.webp"
    ],
    videos: [
      "https://www.youtube.com/embed/RrIAqU4O2tw",
      "https://www.youtube.com/embed/anotherVideoId",
      "https://www.youtube.com/embed/yetAnotherVideoId"
    ],
    url: "/",
  },
  {
    id: "15",
    category: "Thú cưng",
    title: "(title) Cách chăm sóc thú cưng của bạn",
    description: "(description) Những lưu ý quan trọng khi nuôi thú cưng.",
    userId: 15,
    date: "24-06-2024",
    content: "Microsoft đã công bố cam kết kéo dài 5 năm để tạo ra các cơ hội lớn hơn cho người khuyết tật. Công ty này sẽ tập trung vào việc phát triển công nghệ giúp người khuyết tật tiếp cận dễ dàng hơn với các dịch vụ và sản phẩm. Microsoft đã công bố cam kết kéo dài 5 năm để tạo ra các cơ hội lớn hơn cho người khuyết tật. Công ty này sẽ tập trung vào việc phát triển công nghệ giúp người khuyết tật tiếp cận dễ dàng hơn với các dịch vụ và sản phẩm.Microsoft đã công bố cam kết kéo dài 5 năm để tạo ra các cơ hội lớn hơn cho người khuyết tật. Công ty này sẽ tập trung vào việc phát triển công nghệ giúp người khuyết tật tiếp cận dễ dàng hơn với các dịch vụ và sản phẩm.Microsoft đã công bố cam kết kéo dài 5 năm để tạo ra các cơ hội lớn hơn cho người khuyết tật. Công ty này sẽ tập trung vào việc phát triển công nghệ giúp người khuyết tật tiếp cận dễ dàng hơn với các dịch vụ và sản phẩm.Microsoft đã công bố cam kết kéo dài 5 năm để tạo ra các cơ hội lớn hơn cho người khuyết tật. Công ty này sẽ tập trung vào việc phát triển công nghệ giúp người khuyết tật tiếp cận dễ dàng hơn với các dịch vụ và sản phẩm.Microsoft đã công bố cam kết kéo dài 5 năm để tạo ra các cơ hội lớn hơn cho người khuyết tật. Công ty này sẽ tập trung vào việc phát triển công nghệ giúp người khuyết tật tiếp cận dễ dàng hơn với các dịch vụ và sản phẩm.",
    imageUrl: [
      "/images/anh1.webp",
      "/images/anh2.webp",
      "/images/anh3.webp",
      "/images/anh4.webp",
      "/images/anh5.webp",
      "/images/anh6.webp"
    ],
    videos: [
      "https://www.youtube.com/embed/RrIAqU4O2tw",
      "https://www.youtube.com/embed/anotherVideoId",
      "https://www.youtube.com/embed/yetAnotherVideoId"
    ],
    url: "/",
  },
  {
    id: "16",
    category: "Làm đẹp",
    title: "(title) Bí quyết làm đẹp tự nhiên",
    description: "(description) Cách chăm sóc sắc đẹp từ thiên nhiên.",
    userId: 16,
    date: "23-06-2024",
    content: "Microsoft đã công bố cam kết kéo dài 5 năm để tạo ra các cơ hội lớn hơn cho người khuyết tật. Công ty này sẽ tập trung vào việc phát triển công nghệ giúp người khuyết tật tiếp cận dễ dàng hơn với các dịch vụ và sản phẩm. Microsoft đã công bố cam kết kéo dài 5 năm để tạo ra các cơ hội lớn hơn cho người khuyết tật. Công ty này sẽ tập trung vào việc phát triển công nghệ giúp người khuyết tật tiếp cận dễ dàng hơn với các dịch vụ và sản phẩm.Microsoft đã công bố cam kết kéo dài 5 năm để tạo ra các cơ hội lớn hơn cho người khuyết tật. Công ty này sẽ tập trung vào việc phát triển công nghệ giúp người khuyết tật tiếp cận dễ dàng hơn với các dịch vụ và sản phẩm.Microsoft đã công bố cam kết kéo dài 5 năm để tạo ra các cơ hội lớn hơn cho người khuyết tật. Công ty này sẽ tập trung vào việc phát triển công nghệ giúp người khuyết tật tiếp cận dễ dàng hơn với các dịch vụ và sản phẩm.Microsoft đã công bố cam kết kéo dài 5 năm để tạo ra các cơ hội lớn hơn cho người khuyết tật. Công ty này sẽ tập trung vào việc phát triển công nghệ giúp người khuyết tật tiếp cận dễ dàng hơn với các dịch vụ và sản phẩm.Microsoft đã công bố cam kết kéo dài 5 năm để tạo ra các cơ hội lớn hơn cho người khuyết tật. Công ty này sẽ tập trung vào việc phát triển công nghệ giúp người khuyết tật tiếp cận dễ dàng hơn với các dịch vụ và sản phẩm.",
    imageUrl: [
      "/images/anh1.webp",
      "/images/anh2.webp",
      "/images/anh3.webp",
      "/images/anh4.webp",
      "/images/anh5.webp",
      "/images/anh6.webp"
    ],
    videos: [
      "https://www.youtube.com/embed/RrIAqU4O2tw",
      "https://www.youtube.com/embed/anotherVideoId",
      "https://www.youtube.com/embed/yetAnotherVideoId"
    ],
    url: "/",
  },
  {
    id: "17",
    category: "Khởi nghiệp",
    title: "(title) Ý tưởng khởi nghiệp tiềm năng trong năm 2024",
    description: "(description) Cơ hội đầu tư và khởi nghiệp hấp dẫn.",
    userId: 17,
    date: "22-06-2024",
    content: "Microsoft đã công bố cam kết kéo dài 5 năm để tạo ra các cơ hội lớn hơn cho người khuyết tật. Công ty này sẽ tập trung vào việc phát triển công nghệ giúp người khuyết tật tiếp cận dễ dàng hơn với các dịch vụ và sản phẩm. Microsoft đã công bố cam kết kéo dài 5 năm để tạo ra các cơ hội lớn hơn cho người khuyết tật. Công ty này sẽ tập trung vào việc phát triển công nghệ giúp người khuyết tật tiếp cận dễ dàng hơn với các dịch vụ và sản phẩm.Microsoft đã công bố cam kết kéo dài 5 năm để tạo ra các cơ hội lớn hơn cho người khuyết tật. Công ty này sẽ tập trung vào việc phát triển công nghệ giúp người khuyết tật tiếp cận dễ dàng hơn với các dịch vụ và sản phẩm.Microsoft đã công bố cam kết kéo dài 5 năm để tạo ra các cơ hội lớn hơn cho người khuyết tật. Công ty này sẽ tập trung vào việc phát triển công nghệ giúp người khuyết tật tiếp cận dễ dàng hơn với các dịch vụ và sản phẩm.Microsoft đã công bố cam kết kéo dài 5 năm để tạo ra các cơ hội lớn hơn cho người khuyết tật. Công ty này sẽ tập trung vào việc phát triển công nghệ giúp người khuyết tật tiếp cận dễ dàng hơn với các dịch vụ và sản phẩm.Microsoft đã công bố cam kết kéo dài 5 năm để tạo ra các cơ hội lớn hơn cho người khuyết tật. Công ty này sẽ tập trung vào việc phát triển công nghệ giúp người khuyết tật tiếp cận dễ dàng hơn với các dịch vụ và sản phẩm.",
    imageUrl: [
      "/images/anh1.webp",
      "/images/anh2.webp",
      "/images/anh3.webp",
      "/images/anh4.webp",
      "/images/anh5.webp",
      "/images/anh6.webp"
    ],
    videos: [
      "https://www.youtube.com/embed/RrIAqU4O2tw",
      "https://www.youtube.com/embed/anotherVideoId",
      "https://www.youtube.com/embed/yetAnotherVideoId"
    ],
    url: "/",
  },
  {
    id: "18",
    category: "Lịch sử",
    title: "(title) Những sự kiện lịch sử quan trọng",
    description:
      "(description) Những mốc son đáng nhớ trong lịch sử nhân loại.",
    userId: 18,
    date: "21-06-2024",
    content: "Microsoft đã công bố cam kết kéo dài 5 năm để tạo ra các cơ hội lớn hơn cho người khuyết tật. Công ty này sẽ tập trung vào việc phát triển công nghệ giúp người khuyết tật tiếp cận dễ dàng hơn với các dịch vụ và sản phẩm. Microsoft đã công bố cam kết kéo dài 5 năm để tạo ra các cơ hội lớn hơn cho người khuyết tật. Công ty này sẽ tập trung vào việc phát triển công nghệ giúp người khuyết tật tiếp cận dễ dàng hơn với các dịch vụ và sản phẩm.Microsoft đã công bố cam kết kéo dài 5 năm để tạo ra các cơ hội lớn hơn cho người khuyết tật. Công ty này sẽ tập trung vào việc phát triển công nghệ giúp người khuyết tật tiếp cận dễ dàng hơn với các dịch vụ và sản phẩm.Microsoft đã công bố cam kết kéo dài 5 năm để tạo ra các cơ hội lớn hơn cho người khuyết tật. Công ty này sẽ tập trung vào việc phát triển công nghệ giúp người khuyết tật tiếp cận dễ dàng hơn với các dịch vụ và sản phẩm.Microsoft đã công bố cam kết kéo dài 5 năm để tạo ra các cơ hội lớn hơn cho người khuyết tật. Công ty này sẽ tập trung vào việc phát triển công nghệ giúp người khuyết tật tiếp cận dễ dàng hơn với các dịch vụ và sản phẩm.Microsoft đã công bố cam kết kéo dài 5 năm để tạo ra các cơ hội lớn hơn cho người khuyết tật. Công ty này sẽ tập trung vào việc phát triển công nghệ giúp người khuyết tật tiếp cận dễ dàng hơn với các dịch vụ và sản phẩm.",
    imageUrl: [
      "/images/anh1.webp",
      "/images/anh2.webp",
      "/images/anh3.webp",
      "/images/anh4.webp",
      "/images/anh5.webp",
      "/images/anh6.webp"
    ],
    videos: [
      "https://www.youtube.com/embed/RrIAqU4O2tw",
      "https://www.youtube.com/embed/anotherVideoId",
      "https://www.youtube.com/embed/yetAnotherVideoId"
    ],
    url: "/",
  },
  {
    id: "19",
    category: "Tâm lý",
    title: "(title) Hiểu biết về tâm lý con người",
    description: "(description) Những khía cạnh thú vị về tâm lý học.",
    userId: 19,
    date: "20-06-2024",
    content: "Microsoft đã công bố cam kết kéo dài 5 năm để tạo ra các cơ hội lớn hơn cho người khuyết tật. Công ty này sẽ tập trung vào việc phát triển công nghệ giúp người khuyết tật tiếp cận dễ dàng hơn với các dịch vụ và sản phẩm. Microsoft đã công bố cam kết kéo dài 5 năm để tạo ra các cơ hội lớn hơn cho người khuyết tật. Công ty này sẽ tập trung vào việc phát triển công nghệ giúp người khuyết tật tiếp cận dễ dàng hơn với các dịch vụ và sản phẩm.Microsoft đã công bố cam kết kéo dài 5 năm để tạo ra các cơ hội lớn hơn cho người khuyết tật. Công ty này sẽ tập trung vào việc phát triển công nghệ giúp người khuyết tật tiếp cận dễ dàng hơn với các dịch vụ và sản phẩm.Microsoft đã công bố cam kết kéo dài 5 năm để tạo ra các cơ hội lớn hơn cho người khuyết tật. Công ty này sẽ tập trung vào việc phát triển công nghệ giúp người khuyết tật tiếp cận dễ dàng hơn với các dịch vụ và sản phẩm.Microsoft đã công bố cam kết kéo dài 5 năm để tạo ra các cơ hội lớn hơn cho người khuyết tật. Công ty này sẽ tập trung vào việc phát triển công nghệ giúp người khuyết tật tiếp cận dễ dàng hơn với các dịch vụ và sản phẩm.Microsoft đã công bố cam kết kéo dài 5 năm để tạo ra các cơ hội lớn hơn cho người khuyết tật. Công ty này sẽ tập trung vào việc phát triển công nghệ giúp người khuyết tật tiếp cận dễ dàng hơn với các dịch vụ và sản phẩm.",
    imageUrl: [
      "/images/anh1.webp",
      "/images/anh2.webp",
      "/images/anh3.webp",
      "/images/anh6.webp"
    ],
    videos: [
      "https://www.youtube.com/embed/RrIAqU4O2tw",
      "https://www.youtube.com/embed/anotherVideoId",
      "https://www.youtube.com/embed/yetAnotherVideoId"
    ],
    url: "/",
  },
  {
    id: "20",
    category: "Gia đình",
    title: "(title) Cách nuôi dạy trẻ em thông minh",
    description: "(description) Những phương pháp giáo dục hiệu quả.",
    userId: 20,
    date: "19-06-2024",
    content: "Microsoft đã công bố cam kết kéo dài 5 năm để tạo ra các cơ hội lớn hơn cho người khuyết tật. Công ty này sẽ tập trung vào việc phát triển công nghệ giúp người khuyết tật tiếp cận dễ dàng hơn với các dịch vụ và sản phẩm. Microsoft đã công bố cam kết kéo dài 5 năm để tạo ra các cơ hội lớn hơn cho người khuyết tật. Công ty này sẽ tập trung vào việc phát triển công nghệ giúp người khuyết tật tiếp cận dễ dàng hơn với các dịch vụ và sản phẩm.Microsoft đã công bố cam kết kéo dài 5 năm để tạo ra các cơ hội lớn hơn cho người khuyết tật. Công ty này sẽ tập trung vào việc phát triển công nghệ giúp người khuyết tật tiếp cận dễ dàng hơn với các dịch vụ và sản phẩm.Microsoft đã công bố cam kết kéo dài 5 năm để tạo ra các cơ hội lớn hơn cho người khuyết tật. Công ty này sẽ tập trung vào việc phát triển công nghệ giúp người khuyết tật tiếp cận dễ dàng hơn với các dịch vụ và sản phẩm.Microsoft đã công bố cam kết kéo dài 5 năm để tạo ra các cơ hội lớn hơn cho người khuyết tật. Công ty này sẽ tập trung vào việc phát triển công nghệ giúp người khuyết tật tiếp cận dễ dàng hơn với các dịch vụ và sản phẩm.Microsoft đã công bố cam kết kéo dài 5 năm để tạo ra các cơ hội lớn hơn cho người khuyết tật. Công ty này sẽ tập trung vào việc phát triển công nghệ giúp người khuyết tật tiếp cận dễ dàng hơn với các dịch vụ và sản phẩm.",
    imageUrl: [
      "/images/anh12.webp",
    ],
    videos: [
      "https://www.youtube.com/embed/RrIAqU4O2tw",
      "https://www.youtube.com/embed/anotherVideoId",
      "https://www.youtube.com/embed/yetAnotherVideoId"
    ],
    url: "/",
  },
];
