export const orders = [
  {
    orderID: "DH001",
    date: "2023-10-15",
    status: "Đã giao",
    totalAmount: "1,500,000 VND",
  },
  {
    orderID: "DH002",
    date: "2023-10-20",
    status: "Đang giao",
    totalAmount: "2,000,000 VND",
  },
  {
    orderID: "DH003",
    date: "2023-10-25",
    status: "Đã hủy",
    totalAmount: "750,000 VND",
  },
  {
    orderID: "DH004",
    date: "2023-11-01",
    status: "Đang xử lý",
    totalAmount: "1,200,000 VND",
  },
  {
    orderID: "DH005",
    date: "2023-11-05",
    status: "Đã giao",
    totalAmount: "3,000,000 VND",
  },
  {
    orderID: "DH006",
    date: "2023-11-10",
    status: "Đang giao",
    totalAmount: "850,000 VND",
  },
  {
    orderID: "DH007",
    date: "2023-11-15",
    status: "Đã hủy",
    totalAmount: "500,000 VND",
  },
  {
    orderID: "DH008",
    date: "2023-11-18",
    status: "Đang xử lý",
    totalAmount: "1,750,000 VND",
  },
];
