// const generateRandomTransaction = (index) => {
//   const paymentMethods = ["Thẻ tín dụng", "Chuyển khoản", "Ví điện tử"];
//   const descriptions = [
//     "Thanh toán tour du lịch",
//     "Thanh toán khách sạn",
//     "Thanh toán vé máy bay",
//     "Mua sắm trực tuyến",
//     "Thanh toán dịch vụ",
//   ];

//   const month = String(Math.floor(Math.random() * 12) + 1).padStart(2, "0");
//   const day = String(Math.floor(Math.random() * 28) + 1).padStart(2, "0");
//   const year = 2024; // Hoặc có thể thay đổi năm theo ý muốn

//   return {
//     stt: index + 1,
//     maDonHang: `DH${String(index + 1).padStart(3, "0")}`,
//     thoiGian: `${day}/${month}/${year}`,
//     thoiGianDate: new Date(`${year}-${month}-${day}`),
//     giaTri: `${(Math.random() * 5000000)
//       .toFixed(0)
//       .replace(/\B(?=(\d{3})+(?!\d))/g, ",")} VNĐ`,
//     phuongThuc:
//       paymentMethods[Math.floor(Math.random() * paymentMethods.length)],
//     moTa: descriptions[Math.floor(Math.random() * descriptions.length)],
//   };
// };

// const transactions = Array.from({ length: 100 }, (_, index) =>
//   generateRandomTransaction(index)
// );

// export default transactions;
