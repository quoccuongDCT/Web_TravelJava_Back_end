public class PaymentProcessor {

    private static final int MAX_RETRY_ATTEMPTS = 3;

    // Hàm xử lý thanh toán
    public boolean processPayment(Order order) {
        int attempt = 0;
        boolean success = false;

        while (attempt < MAX_RETRY_ATTEMPTS && !success) {
            try {
                attempt++;
                System.out.println("Attempting payment, attempt #" + attempt);
                success = performTransaction(order);
            } catch (NetworkException e) {
                System.out.println("Network error occurred: " + e.getMessage());
                if (attempt < MAX_RETRY_ATTEMPTS) {
                    System.out.println("Retrying payment...");
                } else {
                    logError("Network error: Unable to process payment after " + attempt + " attempts.");
                    notifyUser("Payment failed due to network issues. Please try again later.");
                }
            } catch (InsufficientFundsException e) {
                System.out.println("Payment failed: Insufficient funds.");
                notifyUser("Payment failed: Insufficient funds.");
                logError("Insufficient funds for order ID " + order.getId());
                break;
            } catch (Exception e) {
                System.out.println("Unexpected error: " + e.getMessage());
                logError("Unexpected error: " + e.getMessage());
                notifyUser("An unexpected error occurred. Please contact support.");
                break;
            }
        }
        return success;
    }

    // Giả lập thực hiện giao dịch
    private boolean performTransaction(Order order) throws NetworkException, InsufficientFundsException {
        // Giả lập các lỗi có thể xảy ra trong quá trình giao dịch
        if (Math.random() < 0.3) {
            throw new NetworkException("Network connectivity issue.");
        }
        if (Math.random() < 0.2) {
            throw new InsufficientFundsException("Insufficient funds.");
        }
        return true; // Giả sử giao dịch thành công
    }

    // Ghi log lỗi để theo dõi
    private void logError(String message) {
        System.out.println("LOG: " + message);
        // Thực tế sẽ ghi vào file hoặc hệ thống giám sát
    }

    // Thông báo cho người dùng
    private void notifyUser(String message) {
        System.out.println("User Notification: " + message);
        // Trong thực tế, sẽ hiển thị thông báo cho người dùng qua giao diện
    }
}

// Các exception mô phỏng các sự cố khác nhau
class NetworkException extends Exception {
    public NetworkException(String message) {
        super(message);
    }
}

class InsufficientFundsException extends Exception {
    public InsufficientFundsException(String message) {
        super(message);
    }
}

// Đơn hàng mô phỏng
class Order {
    private int id;
    public Order(int id) {
        this.id = id;
    }
    public int getId() {
        return id;
    }
}
