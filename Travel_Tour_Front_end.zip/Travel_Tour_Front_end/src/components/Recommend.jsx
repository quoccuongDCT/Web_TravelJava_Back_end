import React, { useState, useEffect } from "react";
import { Link, useLocation } from "react-router-dom";
import axios from "axios";
import BtnLikeIcon from "../views/client/componetns/BtnLikeIcon";
import { Swiper, SwiperSlide } from "swiper/react";
import "swiper/css";
import "swiper/css/navigation";
import "swiper/css/pagination";
import { Pagination } from "swiper/modules";
import Loading from "./loading";
import "react-toastify/dist/ReactToastify.css";
import { toast } from "react-toastify";
// import Chatbot from "./chatbot";

export default function Recommend() {
  const [tours, setTours] = useState([]); // Danh sách tour
  const [likedTours, setLikedTours] = useState([]); // Danh sách các tour yêu thích
  const [searchKeyword, setSearchKeyword] = useState(""); // Lưu từ khóa tìm kiếm
  const maxShown = 8; // Số lượng tour hiển thị mỗi lần
  const [shownCount, setShownCount] = useState(maxShown); // Số lượng tour hiển thị hiện tại
  const location = useLocation();
  const query = new URLSearchParams(location.search);

  // Xử lý yêu thích
  const handleLikeToggle = (tourId) => {
    const userId = localStorage.getItem("id");

    if (!userId) {
      console.log("Không tìm thấy ID người dùng.");
      return;
    }

    const isCurrentlyLiked = tours.find((tour) => tour.id === tourId)?.like;

    fetch("http://localhost:8080/api/yeuthich/add", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        userId: userId,
        tourId: tourId,
      }),
    })
      .then((response) => response.json())
      .then(() => {
        setTours((prevTours) =>
          prevTours.map((tour) =>
            tour.id === tourId ? { ...tour, like: !tour.like } : tour
          )
        );
      })
      .catch((error) => {
        console.error("Lỗi khi lưu yêu thích:", error);
        toast.error("Có lỗi xảy ra. Vui lòng thử lại sau.");
      });
  };

  // Fetch tours từ API
  useEffect(() => {
    const search = query.get("search");
    if (search) {
      setSearchKeyword(search); // Lưu từ khóa tìm kiếm vào state
      axios
        .get(`http://localhost:8080/api/tours/search?text=${search}`)
        .then((response) => {
          const uniqueTours = Array.from(
            new Map(response.data.map((item) => [item.id, item])).values()
          );

          const filteredTours = uniqueTours.filter(
            (item) => item.trangThai === true
          );

          const mappedData = filteredTours.map((item) => ({
            id: item.id,
            title: item.tenTour,
            price: item.giaNguoiLon,
            rating: item.danhGiaKhachSan || 0,
            url: item.hinhAnh,
            description: item.soNgay,
            status: item.trangThai,
            galleryImgs: [item.hinhAnh],
            like: false,
            startDate: new Date(item.ngayBatDau).toLocaleDateString(),
          }));

          setTours(mappedData);
        })
        .catch((error) =>
          console.error("Error fetching tours with search:", error)
        );
    } else {
      setSearchKeyword(""); // Xóa từ khóa nếu không tìm kiếm
      const userId = localStorage.getItem("id");
      if (userId) {
        axios
          .get(`http://localhost:8080/api/yeuthich/likedTours/${userId}`)
          .then((response) => setLikedTours(response.data))
          .catch((error) =>
            console.error("Error fetching liked tours:", error)
          );
      }

      axios
        .get("http://localhost:8080/api/tours/info")
        .then((response) => {
          const uniqueTours = Array.from(
            new Map(response.data.map((item) => [item.id, item])).values()
          );

          const filteredTours = uniqueTours.filter(
            (item) => item.trangThai === true
          );

          const mappedData = filteredTours.map((item) => ({
            id: item.id,
            title: item.tenTour,
            price: item.giaNguoiLon,
            rating: item.danhGiaKhachSan || 0,
            url: item.hinhAnh,
            description: item.soNgay,
            status: item.trangThai,
            galleryImgs: [item.hinhAnh],
            like: false,
            startDate: new Date(item.ngayBatDau).toLocaleDateString(),
          }));

          setTours(mappedData);
        })
        .catch((error) => console.error("Error fetching tours:", error));
    }
  }, [location]);

  const shownTours = tours.slice(0, shownCount);

  const isTourLiked = (tourId) => likedTours.some((tour) => tour.id === tourId);

  const handleShowMoreTours = () => {
    setShownCount((prevCount) => Math.min(prevCount + maxShown, tours.length));
  };

  const renderStars = (stars) => {
    const maxStars = 5;
    return Array.from({ length: maxStars }, (_, index) => (
      <span
        key={index}
        style={{ color: index < stars ? "#FFD700" : "#d3d3d3" }}
      >
        ★
      </span>
    ));
  };

  const formatCurrencyVND = (amount) => {
    return new Intl.NumberFormat("vi-VN", {
      style: "currency",
      currency: "VND",
      currencyDisplay: "code",
    }).format(amount);
  };

  const isLoggedIn = localStorage.getItem("id");

  return (
    <div className="space-y-6 sm:space-y-8 p-20 container">
      <header className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-semibold text-left ">
            Các điểm du lịch nổi bật
          </h1>
          <p>
            Những nơi du lịch nổi bật phổ biến mà <strong>Travel Go</strong>{" "}
            giới thiệu cho bạn
          </p>
          {/* Chỉ hiển thị "Kết quả tìm kiếm" khi có từ khóa */}
          {searchKeyword && (
            <p className="text-left mt-2" style={{ marginLeft: 0 }}>
              Kết quả tìm kiếm:{" "}
              <strong style={{ color: "red" }}>{searchKeyword}</strong>
            </p>
          )}
          <div className="w-14 border-b border-neutral-200 dark:border-neutral-700"></div>
        </div>
      </header>

      <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4">
        {shownTours?.map((item) => (
          <div className="border rounded-2xl" key={item.id}>
            <div className="flex-col flex relative">
              <Link to={`/chi-tiet-tour/${item.id}`}>
                <Swiper
                  spaceBetween={10}
                  slidesPerView={1}
                  loop={false}
                  pagination={{ clickable: true }}
                  modules={[Pagination]}
                  className="w-full h-[220px] rounded-2xl"
                >
                  {item.galleryImgs.map((imgSrc, imgIndex) => (
                    <SwiperSlide key={imgIndex}>
                      <img
                        className="w-full h-[220px] rounded-2xl"
                        src={imgSrc ?? ""}
                        alt={`Slide ${imgIndex}`}
                      />
                    </SwiperSlide>
                  ))}
                </Swiper>
              </Link>
              {isLoggedIn && (
                <div className="absolute p-2 right-0 z-10">
                  <BtnLikeIcon
                    isLiked={isTourLiked(item.id)}
                    onToggleLike={() => handleLikeToggle(item.id)}
                  />
                </div>
              )}
              <div className="p-[10px] flex flex-col text-left">
                <b className="text-[18px] line-clamp-3 ">{item.title}</b>
                <div className="relative">
                  <span className="text-[14px] text-gray-500 mb-2">
                    {item.description}
                  </span>
                  <div className="flex gap-3">
                    <span>{item.startDate}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span style={{ color: "#b22222", fontWeight: "bold" }}>
                      {formatCurrencyVND(item.price)}
                    </span>
                    <span>{renderStars(item.rating)}</span>
                  </div>
                  <div className="absolute bottom-0 w-full">
                    <span className="text-[14px] text-gray-500">
                      {item.someText}
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      <div className="flex items-center justify-center">
        {shownCount < tours.length && (
          <button
            className="text-gray-600 hover:text-gray-900 border rounded-3xl px-4 py-2"
            onClick={handleShowMoreTours}
          >
            <Loading /> Xem thêm
          </button>
        )}
      </div>
      {/* <Chatbot /> */}
    </div>
  );
}
