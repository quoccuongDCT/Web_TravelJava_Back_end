import { Swiper, SwiperSlide } from "swiper/react";
import "swiper/css";
import "swiper/css/pagination";
import "./SlideComponent.css";

import { Pagination, Autoplay } from "swiper/modules";

export const SlideComponent = () => {
  return (
    <div className="mt-[100px] container relative">
      <Swiper
        pagination={{
          // dynamicBullets: true, // Kích hoạt dynamic bullets
          clickable: true, // Chấm tròn có thể nhấp
        }}
        modules={[Pagination, Autoplay]}
        autoplay={{
          delay: 3000,
          disableOnInteraction: false,
        }}
        loop={true}
        // loopAdditionalSlides={3}
        className="mySwiper"
      >
      <SwiperSlide>
          <a href="/danh-sach-tour">
            <img
              src="https://hathaitour.com/media/btihl5vq/singapore-malaysia-5n4d.jpg"
              alt="Tour Singapore-Malaysia 5N4D"
              className="w-full h-[500px] object-cover"
            />
          </a>
        </SwiperSlide>
        <SwiperSlide>
          <a href="/danh-sach-tour">
            <img
              src="https://bizweb.dktcdn.net/100/006/093/themes/748856/assets/slider_3.jpg?1732762151447"
              alt=""
              className="w-full h-[500px] object-cover"
            />
          </a>
        </SwiperSlide>
        <SwiperSlide>
          <a href="/danh-sach-tour">
            <img
              src="https://www.dulichhoanganh.com/uploaded/slideshow/banner-du-lich-bien-dao-viet-nam.png"
              alt=""
              className="w-full h-[500px]"
            />
          </a>
        </SwiperSlide>
        <SwiperSlide>
          <a href="/danh-sach-tour">
            <img
              src="https://tse1.mm.bing.net/th?id=OIP.bjoa6rIUMy8I9K8BUBgHaQHaDd&pid=Api&P=0&h=180g"
              alt=""
              className="w-full h-[500px]"
            />
          </a>
        </SwiperSlide>
        <SwiperSlide>
          <a href="/danh-sach-tour">
            <img
              src="https://r2.nucuoimekong.com/wp-content/uploads/dien-gio-duyen-hai-tra-vinh.jpg"
              alt=""
              className="w-full h-[500px]"
            />
          </a>
        </SwiperSlide>
        <SwiperSlide>
          <a href="/danh-sach-tour">
            <img
              src="https://fantasea.vn/wp-content/uploads/2021/03/Du-l%E1%BB%8Bch-%C4%90%C3%A0-N%E1%BA%B5ng-1290x860.jpg"
              alt=""
              className="w-full h-[500px]"
            />
          </a>
        </SwiperSlide>
      </Swiper>
    </div>
  );
};

export default SlideComponent;
