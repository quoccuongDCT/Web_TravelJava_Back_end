import React from "react";
import { BsFacebook } from "react-icons/bs";
import { AiFillInstagram } from "react-icons/ai";
import { FaTwitter, FaYoutube } from "react-icons/fa";
import logo from "../assets/logophong.png";

const FooterContainer = () => {
  return (
    <div className="bg-[#f6f6f7] py-4 h-[300px]">
      <div className="w-full grid grid-cols-5 gap-0 px-4">
        <div className="flex flex-col px-[] w-[170px] ml-[200px]">
          <span
            className="font-bold text-lg mb-2 flex"
            style={{
              fontFamily: "'Open Sans', sans-serif",
              fontWeight: "bold",
              fontSize: "16px",
              lineHeight: "23px",
            }}
          >
             <img
                src={logo}
                alt="Logo"
                className="logo"
                style={{ width: "110px", height: "50px" }}
              />
            <b className="flex items-center text-blue-600"></b>
          </span>

          <br />
          <div className="flex flex-col items-start mb-2">
            <a
              href="https://www.facebook.com"
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center mb-2 no-underline"
            >
              <BsFacebook
                className="text-blue-600  transition duration-300"
                size={24}
              />
              <span className="text-xs ml-1 text-black font-san ">
                Facebook
              </span>
            </a>
            <a
              href="https://www.instagram.com"
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center mb-2 no-underline"
            >
              <AiFillInstagram
                className="text-pink-500  transition duration-300"
                size={24}
              />
              <span className="text-xs ml-1 text-black font-san">
                Instagram
              </span>
            </a>
            <a
              href="https://twitter.com"
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center mb-2 no-underline"
            >
              <FaTwitter
                className="text-blue-400  transition duration-300"
                size={24}
              />
              <span className="text-xs ml-1 text-black font-san">Twitter</span>
            </a>
            <a
              href="https://www.youtube.com"
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center mb-2 no-underline"
            >
              <FaYoutube
                className="text-red-600  transition duration-300"
                size={24}
              />
              <span className="text-xs ml-1 text-black font-san ">YouTube</span>
            </a>
          </div>
        </div>

        <div className="text-left flex flex-col">
          <div className="flex items-center mb-2 ml-[140px]">
            <h2
              className="font-bold text-lg"
              style={{
                fontFamily: "'Open Sans', sans-serif",
                fontWeight: "bold",
                fontSize: "16px",
                lineHeight: "23px",
              }}
            >
              DỊCH VỤ
            </h2>
          </div>
          <ul className="space-y-1 text-sm flex-grow ml-[110px] font-sans text-black text-[16px] leading-[23px] w-[250px] ">
            <li className="hover:text-green-500 cursor-pointer break-words">
              Tour du lịch trong nước
            </li>
            <li className="hover:text-green-500 cursor-pointer break-words">
              Tour du lịch nước ngoài
            </li>
            <li className="hover:text-green-500 cursor-pointer break-words">
              Trải nghiệm ẩm thực
            </li>
            <li className="hover:text-green-500 cursor-pointer break-words">
              Chuyến đi lãng mạn
            </li>
            <li className="hover:text-green-500 cursor-pointer break-words">
              Du lịch khám phá
            </li>
            <li className="hover:text-green-500 cursor-pointer break-words">
              Cho thuê xe tự lái
            </li>
            <li className="hover:text-green-500 cursor-pointer break-words">
              Hỗ trợ Visa
            </li>
            <li className="hover:text-green-500 cursor-pointer break-words">
              Đăng ký làm đại lý
            </li>
          </ul>
        </div>

        {/* Các phần còn lại của Footer */}
        <div className="text-left flex flex-col">
          <h2
            className="font-bold text-lg mb-2 ml-[130px]"
            style={{
              fontFamily: "'Open Sans', sans-serif",
              fontWeight: "bold",
              fontSize: "16px",
              lineHeight: "23px",
            }}
          >
            HƯỚNG DẪN
          </h2>
          <ul className="space-y-1 text-sm flex-grow ml-[100px] font-sans text-black text-[16px] leading-[23px] w-[283px]">
            <li className="hover:text-green-500 cursor-pointer break-words">
              Giới thiệu về công ty
            </li>
            <li className="hover:text-green-500 cursor-pointer break-words">
              Quy định và điều khoản
            </li>
            <li className="hover:text-green-500 cursor-pointer break-words">
              Hướng dẫn thanh toán trực tuyến
            </li>
            <li className="hover:text-green-500 cursor-pointer break-words">
              Hướng dẫn đặt tour online
            </li>
            <li className="hover:text-green-500 cursor-pointer break-words">
              Chính sách hủy vé
            </li>
            <li className="hover:text-green-500 cursor-pointer break-words">
              Ưu đãi du lịch
            </li>
            <li className="hover:text-green-500 cursor-pointer break-words">
              Hỗ trợ khách hàng
            </li>
            <li className="hover:text-green-500 cursor-pointer break-words">
              Khảo sát phản hồi khách hàng
            </li>
          </ul>
        </div>

        <div className="text-left flex flex-col">
          <h2
            className="font-bold text-lg mb-2 ml-[173px]"
            style={{
              fontFamily: "'Open Sans', sans-serif",
              fontWeight: "bold",
              fontSize: "16px",
              lineHeight: "23px",
            }}
          >
            THÔNG TIN
          </h2>
          <ul className="space-y-1 text-sm flex-grow ml-[142px] font-sans text-black text-[16px] leading-[23px]  w-[283px]">
            <li className="hover:text-green-500 cursor-pointer break-words">
              Tin tức du lịch
            </li>
            <li className="hover:text-green-500 cursor-pointer break-words">
              Khuyến mãi đặc biệt
            </li>
            <li className="hover:text-green-500 cursor-pointer break-words">
              Cẩm nang du lịch hữu ích
            </li>
            <li className="hover:text-green-500 cursor-pointer break-words">
              Trải nghiệm từ khách hàng
            </li>
            <li className="hover:text-green-500 cursor-pointer break-words">
              Chia sẻ kinh nghiệm du lịch
            </li>
            <li className="hover:text-green-500 cursor-pointer break-words">
              Liên hệ với chúng tôi
            </li>
            <li className="hover:text-green-500 cursor-pointer break-words">
              Hồ sơ năng lực
            </li>
            <li className="hover:text-green-500 cursor-pointer break-words">
              Khách hàng tiêu biểu
            </li>
          </ul>
        </div>

        {/* <div className="text-left flex flex-col">
          <h2
            className="font-bold text-lg mb-2 ml-[-217px]"
            style={{
              fontFamily: "'Open Sans', sans-serif",
              fontWeight: "bold",
              fontSize: "16px",
              lineHeight: "23px",
            }}
          >
            KHÁCH HÀNG TIÊU BIỂU
          </h2>
          <ul className="space-y-1 list-none list-inside text-sm ml-[-248px] font-sans text-black text-[16px] leading-[23px] w-[430px]">
            <li className="hover:text-green-500 cursor-pointer break-words">
              Đánh giá tích cực từ người dùng
            </li>
            <li className="hover:text-green-500 cursor-pointer break-words">
              Trải nghiệm đáng nhớ cùng Travel - khám phá những điểm đến thú vị
              với các dịch vụ chu đáo và an toàn.
            </li>
            <li className="hover:text-green-500 cursor-pointer break-words">
              Dịch vụ hỗ trợ nhiệt tình, sẵn sàng giải đáp mọi thắc mắc của bạn
              để hành trình của bạn hoàn hảo nhất.
            </li>
            <li className="hover:text-green-500 cursor-pointer break-words">
              Giá cả hợp lý và minh bạch, giúp bạn dễ dàng lập kế hoạch du lịch
              mà không lo ngại về chi phí ẩn.
            </li>
            <li className="hover:text-green-500 cursor-pointer break-words">
              Khuyến mãi và quà tặng hấp dẫn mỗi tháng, giúp bạn trải nghiệm
              nhiều hơn với chi phí tối ưu.
            </li>
          </ul>
        </div> */}
      </div>
    </div>
  );
};

export default FooterContainer;
