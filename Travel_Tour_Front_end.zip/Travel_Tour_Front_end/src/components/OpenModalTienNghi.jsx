import React, { useState } from "react";
import { Button, Modal } from "antd";
import { GoKey } from "react-icons/go";
import {
  LiaSmokingSolid,
  LiaSuitcaseSolid,
  LiaSwimmingPoolSolid,
  LiaLuggageCartSolid,
  LiaSnowflakeSolid,
  LiaSuitcaseRollingSolid,
  LiaTvSolid,
  LiaShowerSolid,
  LiaSpaSolid,
  LiaSwimmerSolid,
  LiaUmbrellaBeachSolid,
} from "react-icons/lia";

const ModalTienNghi = () => {
  const [isModalOpen, setIsModalOpen] = useState(false);

  const showModal = () => {
    setIsModalOpen(true);
  };

  const handleClose = () => {
    setIsModalOpen(false);
  };

  return (
    <>
      <Button
        onClick={showModal}
        style={{ borderRadius: "30px", width: 243, height: 49 }}
      >
        Xem thêm 20 tiện nghi
      </Button>
      <Modal
        title={
          <div style={{ textAlign: "center", width: "100%" }}>Tiện Nghi</div>
        }
        open={isModalOpen}
        onCancel={handleClose}
        footer={null}
        width={800}
        style={{ borderRadius: "12px" }}
      >
        <div
          style={{
            maxHeight: "400px",
            overflowY: "auto",
          }}
          className="p-4"
        >
          <hr />
          <div className="flex items-center gap-2">
            <GoKey style={{ height: 30, width: 30 }} />
            Chìa khóa
          </div>
          <hr />
          <div className="flex items-center gap-2">
            <LiaSmokingSolid style={{ height: 30, width: 30 }} />
            Hút thuốc
          </div>
          <hr />
          <div className="flex items-center gap-2">
            <LiaSuitcaseSolid style={{ height: 30, width: 30 }} />
            Ha-li
          </div>
          <hr />
          <div className="flex items-center gap-2">
            <LiaSwimmingPoolSolid style={{ height: 30, width: 30 }} />
            Hồ-bơi
          </div>
          <hr />
          <div className="flex items-center gap-2">
            <LiaLuggageCartSolid style={{ height: 30, width: 30 }} />
            Xe-hành-lý
          </div>
          <hr />
          <div className="flex items-center gap-2">
            <LiaSnowflakeSolid style={{ height: 30, width: 30 }} />
            Máy lạnh
          </div>
          <hr />
          <div className="flex items-center gap-2">
            <LiaSuitcaseRollingSolid style={{ height: 30, width: 30 }} />
            Vận chuyển va-li
          </div>
          <hr />
          <div className="flex items-center gap-2">
            <LiaTvSolid style={{ height: 30, width: 30 }} />
            TV
          </div>
          <hr />
          <div className="flex items-center gap-2">
            <LiaShowerSolid style={{ height: 30, width: 30 }} />
            Vòi hoa sen
          </div>
          <hr />
          <div className="flex items-center gap-2">
            <LiaSpaSolid style={{ height: 30, width: 30 }} />
            spa
          </div>
          <hr />
          <div className="flex items-center gap-2">
            <LiaSwimmerSolid style={{ height: 30, width: 30 }} />
            Người bơi
          </div>
          <hr />
          <div className="flex items-center gap-2">
            <LiaUmbrellaBeachSolid style={{ height: 30, width: 30 }} />
            bãi biển ô dù
          </div>
        </div>
      </Modal>
    </>
  );
};

export default ModalTienNghi;
