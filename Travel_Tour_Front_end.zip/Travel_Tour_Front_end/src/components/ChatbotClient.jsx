import React, { useState, useEffect, useRef } from "react";
import { ref, push, onValue } from "firebase/database";
import { database } from "./firebase.js"; // Import database từ firebase.js
import predefinedQuestions from "./questions.json";
import Fuse from "fuse.js"; // Import fuse.js để khớp mờ
import { GoogleGenerativeAI } from "@google/generative-ai";

const Chatbot = () => {
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [chatVisible, setChatVisible] = useState(false);
  const [context, setContext] = useState("");
  const [suggestions, setSuggestions] = useState([]);

  const messagesEndRef = useRef(null); // Tham chiếu đến phần tử chứa tin nhắn

  const userId = localStorage.getItem("id") || "unknown_user";
  const handleInputChange = (e) => {
    const value = e.target.value;
    setInput(value);

    if (value.trim() === "") {
      setSuggestions([]);
      return;
    }

    const result = fuse.search(value.trim());
    const suggestionList = result.map((item) => item.item).slice(0, 5); // Lấy tối đa 5 gợi ý
    setSuggestions(suggestionList);
  };

  // Cấu hình Fuse.js để khớp mờ
  const fuse = new Fuse(Object.keys(predefinedQuestions), {
    includeScore: true,
    threshold: 0.3, // Điều chỉnh giá trị này để kiểm soát độ chính xác của việc khớp
  });

  // Đọc tin nhắn từ Firebase
  useEffect(() => {
    const userMessagesRef = ref(database, `users/${userId}/messages`);
    const unsubscribe = onValue(userMessagesRef, (snapshot) => {
      const data = snapshot.val();
      if (data) {
        const loadedMessages = Object.entries(data).map(([key, value]) => ({
          id: key, // Lưu trữ key để nhận dạng tin nhắn
          ...value,
        }));
        setMessages(loadedMessages);
      }
    });

    return () => unsubscribe();
  }, [userId]);

  // Cuộn tự động đến tin nhắn mới nhất mỗi khi tin nhắn được cập nhật
  useEffect(() => {
    if (messagesEndRef.current) {
      messagesEndRef.current.scrollIntoView({ behavior: "smooth" });
    }
  }, [messages]);
  const inappropriateKeywords = [
    "chửi",
    "vãi",
    "đểu",
    "lừa",
    "điên",
    "ngu",
    "chó",
    "bịp",
    "mô",
    "lỏ",
    "đm",
    "dm",
    "tôi muốn có người yêu",
    "ở mô",
    "lol",
    "mẹ",
    "thô tục",
    "khiếm nhã", // Các từ khóa khiếm nhã
  ];

  const unrelatedKeywords = [
    "công nghệ",
    "thể thao",
    "chính trị",
    "giải trí",
    "giáo dục",
    "tôn giáo",
    "kinh doanh", // Các từ khóa không liên quan đến du lịch
  ];
  const handleKeyDown = (e) => {
    if (e.key === "Enter" && suggestions.length > 0) {
      setInput(suggestions[0]); // Gán gợi ý đầu tiên
      setSuggestions([]); // Ẩn danh sách gợi ý
      e.preventDefault(); // Ngăn chặn xuống dòng
    }
  };

  const handleSendMessage = async () => {
    if (!input.trim()) return; // Nếu input trống thì không làm gì
    setSuggestions([]); // Ẩn danh sách gợi ý
    setLoading(true);

    const timestamp = Date.now();

    // Kiểm tra từ khóa khiếm nhã
    const containsInappropriateWords = inappropriateKeywords.some((keyword) =>
      input.toLowerCase().includes(keyword)
    );
    if (containsInappropriateWords) {
      const botMessage = {
        sender: "bot",
        text: "Xin lỗi, tôi không thể trả lời câu hỏi này.",
        timestamp,
      };
      const userMessagesRef = ref(database, `users/${userId}/messages`);
      await push(userMessagesRef, botMessage);
      setLoading(false);
      return;
    }

    // Kiểm tra câu hỏi có liên quan đến du lịch không
    const containsUnrelatedWords = unrelatedKeywords.some((keyword) =>
      input.toLowerCase().includes(keyword)
    );
    if (containsUnrelatedWords) {
      const botMessage = {
        sender: "bot",
        text: "Xin lỗi, câu hỏi của bạn không liên quan đến du lịch.",
        timestamp,
      };
      const userMessagesRef = ref(database, `users/${userId}/messages`);
      await push(userMessagesRef, botMessage);
      setLoading(false);
      return;
    }

    // Tạo tin nhắn của người dùng
    const userMessage = {
      sender: "user",
      text: input.trim(),
      timestamp,
    };

    // Lưu tin nhắn của người dùng vào Firebase
    const userMessagesRef = ref(database, `users/${userId}/messages`);
    await push(userMessagesRef, userMessage);

    setInput("");

    // Cập nhật context
    const updatedContext = context
      ? `${context}\nNgười dùng: ${input.trim()}`
      : `Người dùng: ${input.trim()}`;

    // Khớp câu hỏi đã định nghĩa sẵn
    const result = fuse.search(input.trim());
    if (result.length > 0 && result[0].score <= 0.3) {
      // Nếu có khớp tốt
      const matchedQuestion = result[0].item;
      const botMessage = {
        sender: "bot",
        text: predefinedQuestions[matchedQuestion],
        timestamp: Date.now(),
      };

      await push(userMessagesRef, botMessage);
      setContext(
        `${updatedContext}\nBot: ${predefinedQuestions[matchedQuestion]}`
      );
      setLoading(false);
    } else {
      // Sử dụng Google Generative AI nếu không tìm thấy khớp
      try {
        const genAI = new GoogleGenerativeAI(
          "AIzaSyBNk4leALxM6dnL0ogzpnCYrr8H6OoUCO8"
        );
        const model = await genAI.getGenerativeModel({
          model: "gemini-1.5-flash",
        });

        // Gửi context với câu hỏi của người dùng đến mô hình
        const result = await model.generateContent(
          `${updatedContext}\nNgười dùng: ${input}\nBot:`
        );

        const botMessage = {
          sender: "bot",
          text: result.response.text(),
          timestamp: Date.now(),
        };

        await push(userMessagesRef, botMessage);
        setContext(`${updatedContext}\nBot: ${result.response.text()}`);
      } catch (error) {
        console.error("Lỗi khi gọi API:", error);
        const errorMessage = {
          sender: "bot",
          text: "Xin lỗi, đã xảy ra lỗi. Vui lòng thử lại.",
          timestamp: Date.now(),
        };
        await push(userMessagesRef, errorMessage);
      } finally {
        setLoading(false);
      }
    }
  };

  return (
    <div style={{ position: "relative", fontFamily: "Arial, sans-serif" }}>
      {/* Biểu tượng chat */}
      <div
        onClick={() => setChatVisible(!chatVisible)}
        style={{
          position: "fixed",
          bottom: "20px",
          right: "20px",
          backgroundColor: "#007BFF",
          borderRadius: "50%",
          width: "60px",
          height: "60px",
          color: "white",
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          fontSize: "30px",
          cursor: "pointer",
          boxShadow: "0px 4px 10px rgba(0, 0, 0, 0.2)",
        }}
      >
        💬
      </div>

      {/* Hộp thoại chat */}
      {chatVisible && (
        <div
          style={{
            position: "fixed",
            bottom: "80px",
            right: "20px",
            width: "350px",
            backgroundColor: "#fff",
            borderRadius: "10px",
            boxShadow: "0px 4px 15px rgba(0, 0, 0, 0.2)",
            padding: "15px",
            zIndex: 9999,
          }}
        >
          <div
            style={{
              display: "flex",
              justifyContent: "space-between",
              alignItems: "center",
            }}
          >
            <h3 style={{ margin: 0, color: "#007BFF", fontSize: "20px" }}>
              Chatbot
            </h3>
            <button
              onClick={() => setChatVisible(false)}
              style={{
                backgroundColor: "transparent",
                border: "none",
                fontSize: "18px",
                cursor: "pointer",
                color: "#007BFF",
                fontWeight: "bold",
              }}
            >
              ✖
            </button>
          </div>

          <div
            style={{
              border: "1px solid #ccc",
              borderRadius: "8px",
              padding: "10px",
              height: "350px",
              overflowY: "auto",
              backgroundColor: "#f9f9f9",
              marginTop: "10px",
              scrollBehavior: "smooth",
            }}
          >
            {messages
              .sort((a, b) => a.timestamp - b.timestamp)
              .map((msg, index) => (
                <div
                  key={index}
                  style={{
                    textAlign: msg.sender === "user" ? "right" : "left",
                    margin: "10px 0",
                  }}
                >
                  <span
                    style={{
                      display: "inline-block",
                      padding: "10px 15px",
                      borderRadius: "12px",
                      backgroundColor:
                        msg.sender === "user" ? "#007BFF" : "#e0e0e0",
                      color: msg.sender === "user" ? "white" : "black",
                      maxWidth: "75%",
                      wordWrap: "break-word",
                      boxShadow: "0px 2px 5px rgba(0, 0, 0, 0.1)",
                    }}
                  >
                    {msg.text}
                  </span>
                </div>
              ))}
            <div ref={messagesEndRef} /> {/* Thẻ div trống để cuộn đến */}
          </div>

          <div style={{ marginTop: "15px" }}>
            <div style={{ position: "relative" }}>
              <textarea
                value={input}
                onChange={handleInputChange}
                onKeyDown={handleKeyDown}
                placeholder="Nhập tin nhắn của bạn..."
                rows="3"
                style={{
                  width: "100%",
                  padding: "12px",
                  borderRadius: "8px",
                  border: "1px solid #ccc",
                  fontSize: "14px",
                  resize: "none",
                  boxShadow: "inset 0px 2px 4px rgba(0, 0, 0, 0.1)",
                }}
              />
              {suggestions.length > 0 && (
                <ul
                  style={{
                    position: "absolute",
                    bottom: "100%", // Đặt danh sách gợi ý phía trên ô nhập
                    left: "0",
                    width: "100%",
                    background: "#ffffff",
                    border: "1px solid #ddd",
                    borderRadius: "8px",
                    listStyleType: "none",
                    padding: "8px 0",
                    margin: "0",
                    maxHeight: "150px",
                    overflowY: "auto",
                    boxShadow: "0px 4px 15px rgba(0, 0, 0, 0.1)",
                    zIndex: 10,
                  }}
                >
                  {suggestions.map((suggestion, index) => (
                    <li
                      key={index}
                      onClick={() => {
                        setInput(suggestion); // Gán gợi ý vào ô nhập
                        setSuggestions([]); // Ẩn danh sách gợi ý
                      }}
                      style={{
                        padding: "10px 15px",
                        cursor: "pointer",
                        borderBottom:
                          index < suggestions.length - 1
                            ? "1px solid #f0f0f0"
                            : "none",
                        backgroundColor: "#ffffff",
                        transition: "background-color 0.3s ease",
                        fontSize: "14px",
                        fontFamily: "Arial, sans-serif",
                        color: "#333",
                      }}
                      onMouseEnter={(e) =>
                        (e.target.style.backgroundColor = "#f0f8ff")
                      }
                      onMouseLeave={(e) =>
                        (e.target.style.backgroundColor = "#ffffff")
                      }
                    >
                      {suggestion}
                    </li>
                  ))}
                </ul>
              )}
            </div>
            <button
              onClick={handleSendMessage}
              style={{
                width: "100%",
                padding: "12px",
                marginTop: "10px",
                background: loading ? "#ccc" : "#007BFF",
                color: "white",
                border: "none",
                borderRadius: "8px",
                cursor: loading ? "not-allowed" : "pointer",
                fontWeight: "bold",
                fontSize: "14px",
                transition: "background-color 0.3s ease",
              }}
              disabled={loading}
              onMouseEnter={(e) => {
                if (!loading) e.target.style.backgroundColor = "#0056b3";
              }}
              onMouseLeave={(e) => {
                if (!loading) e.target.style.backgroundColor = "#007BFF";
              }}
            >
              {loading ? "Đang gửi..." : "Gửi"}
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default Chatbot;
