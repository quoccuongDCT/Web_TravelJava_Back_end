import React, { useState, useEffect } from "react";
import { ref, push, onValue } from "firebase/database";
import axios from "axios";
import moment from "moment";
import { database } from "./firebase.js";
import { GoogleGenerativeAI } from "@google/generative-ai";
import "./chatbot";

const Chatbot = () => {
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [chatVisible, setChatVisible] = useState(false);

  // Ngữ cảnh hội thoại
  const [context, setContext] = useState("");

  // Dữ liệu thống kê
  const [revenueData, setRevenueData] = useState([]);
  const [tourData, setTourData] = useState([]);
  const [participantData, setParticipantData] = useState([]);
  const [participantData2, setParticipantData2] = useState([]);
  const [startDate, setStartDate] = useState(null);
  const [endDate, setEndDate] = useState(null);

  const userId = localStorage.getItem("id") || "unknown_user";

  // Đọc tin nhắn từ Firebase
  useEffect(() => {
    const userMessagesRef = ref(database, `users/${userId}/messages`);
    const unsubscribe = onValue(userMessagesRef, (snapshot) => {
      const data = snapshot.val();
      if (data) {
        const loadedMessages = Object.entries(data).map(([key, value]) => ({
          id: key,
          ...value,
        }));
        setMessages(loadedMessages);
      }
    });

    return () => unsubscribe();
  }, [userId]);

  // Gọi các API thống kê khi thay đổi startDate hoặc endDate
  useEffect(() => {
    if (startDate && endDate) {
      fetchRevenueData();
      fetchTourData();
      fetchParticipantData();
      fetchParticipantData2();
    }
  }, [startDate, endDate]);

  // Hàm gọi API để lấy dữ liệu doanh thu từ backend
  const fetchRevenueData = async () => {
    try {
      const startDateStr = startDate.format("DD/MM/YYYY");
      const endDateStr = endDate.format("DD/MM/YYYY");
      console.log("Fetching revenue data for: ", startDateStr, endDateStr); // Debug log
      const response = await axios.get(
        `http://localhost:8080/api/thongke/tong-doanh-thu?ngayBatDau=${startDateStr}&ngayKetThuc=${endDateStr}`
      );
      console.log("Revenue data response:", response.data); // Debug log
      setRevenueData(response.data);
    } catch (error) {
      console.error("Error fetching revenue data:", error);
    }
  };

  const fetchTourData = async () => {
    try {
      const startDateStr = startDate.format("DD/MM/YYYY");
      const endDateStr = endDate.format("DD/MM/YYYY");
      const response = await axios.get(
        `http://localhost:8080/api/thongke/bieu-do-so-luong-tour?ngayBatDau=${startDateStr}&ngayKetThuc=${endDateStr}`
      );
      const formattedData = response.data.map((item) => ({
        date: moment(item[0]).format("DD/MM/YYYY"),
        tour: item[1],
      }));
      setTourData(formattedData);
    } catch (error) {
      console.error("Error fetching tour data:", error);
    }
  };

  const fetchParticipantData = async () => {
    try {
      const startDateStr = startDate.format("DD/MM/YYYY");
      const endDateStr = endDate.format("DD/MM/YYYY");
      const response = await axios.get(
        `http://localhost:8080/api/thongke/table-so-luong-nguoi-tham-gia?ngayBatDau=${startDateStr}&ngayKetThuc=${endDateStr}`
      );
      const formattedData = response.data.map((item) => ({
        date: moment(item[0]).format("DD/MM/YYYY"),
        tour: item[1],
        participantCount: item[2],
      }));
      setParticipantData(formattedData);
    } catch (error) {
      console.error("Error fetching participant data:", error);
    }
  };

  const fetchParticipantData2 = async () => {
    try {
      const startDateStr = startDate.format("DD/MM/YYYY");
      const endDateStr = endDate.format("DD/MM/YYYY");
      const response = await axios.get(
        `http://localhost:8080/api/thongke/table-doanh-thu-theo-tour?ngayBatDau=${startDateStr}&ngayKetThuc=${endDateStr}`
      );
      const formattedData = response.data.map((item) => ({
        date: moment(item.nam).format("DD/MM/YYYY"),
        tour: item.tenTour,
        participantCount: item.tongTien,
      }));
      setParticipantData2(formattedData);
    } catch (error) {
      console.error("Error fetching participant data:", error);
    }
  };
  // const fetchGeminiResponse = async (query) => {
  //   try {
  //     // Initialize the GoogleGenerativeAI client with your API key
  //     const googleAI = new GoogleGenerativeAI({
  //       apiKey: "AIzaSyBNk4leALxM6dnL0ogzpnCYrr8H6OoUCO8", // Your API key
  //     });

  //     // Send the query to the API using the 'chat' method for generating text
  //     const response = await googleAI.chat({
  //       model: "text-bison-001", // Model name
  //       messages: [{ role: "user", content: query }],
  //     });

  //     // Check if the response contains valid text and return it
  //     if (response && response.text) {
  //       return response.text; // If valid text, return it
  //     } else {
  //       console.error("No valid response from Google API:", response);
  //       return "Xin lỗi, tôi không thể trả lời câu hỏi này vào lúc này.";
  //     }
  //   } catch (error) {
  //     // Handle any errors
  //     console.error("Lỗi khi gọi API Google Generative AI:", error.message);
  //     return "Xin lỗi, tôi không thể trả lời câu hỏi này vào lúc này.";
  //   }
  // };

  const handleSendMessage = async () => {
    if (!input.trim()) return;
    setLoading(true);

    const timestamp = Date.now();
    const userMessage = {
      sender: "user",
      text: input.trim(),
      timestamp,
    };
    const userMessagesRef = ref(database, `users/${userId}/messages`);
    await push(userMessagesRef, userMessage);
    setInput("");

    const updatedContext = context
      ? `${context}\nNgười dùng: ${input.trim()}`
      : `Người dùng: ${input.trim()}`;

    const normalizedInput = input.trim().toLowerCase();
    const today = moment();
    let startDate, endDate, startDateCompare, endDateCompare;

    try {
      // Kiểm tra câu hỏi liên quan đến doanh thu
      if (
        normalizedInput.includes("doanh thu hôm nay") ||
        normalizedInput.includes("doanh thu tuần này") ||
        normalizedInput.includes("doanh thu tháng này") ||
        normalizedInput.includes("so sánh")
      ) {
        // Logic xử lý doanh thu
        if (normalizedInput.includes("doanh thu hôm nay")) {
          startDate = today.clone().startOf("day");
          endDate = today.clone().endOf("day");
        } else if (normalizedInput.includes("doanh thu tuần này")) {
          startDate = today.clone().startOf("week");
          endDate = today.clone().endOf("week");
        } else if (normalizedInput.includes("doanh thu tháng này")) {
          startDate = today.clone().startOf("month");
          endDate = today.clone().endOf("month");
        }

        if (normalizedInput.includes("so sánh")) {
          if (normalizedInput.includes("tuần này với tuần trước")) {
            startDate = today.clone().startOf("week");
            endDate = today.clone().endOf("week");
            startDateCompare = today
              .clone()
              .subtract(1, "week")
              .startOf("week");
            endDateCompare = today.clone().subtract(1, "week").endOf("week");
          } else if (normalizedInput.includes("tháng này với tháng trước")) {
            startDate = today.clone().startOf("month");
            endDate = today.clone().endOf("month");
            startDateCompare = today
              .clone()
              .subtract(1, "month")
              .startOf("month");
            endDateCompare = today.clone().subtract(1, "month").endOf("month");
          } else if (normalizedInput.includes("hôm nay với hôm qua")) {
            startDate = today.clone().startOf("day");
            endDate = today.clone().endOf("day");
            startDateCompare = today.clone().subtract(1, "day").startOf("day");
            endDateCompare = today.clone().subtract(1, "day").endOf("day");
          }
        }

        // Nếu không có khoảng thời gian hợp lệ
        if (!startDate || !endDate) {
          const errorMessage = {
            sender: "bot",
            text: "Xin lỗi, tôi không thể xác định khoảng thời gian. Vui lòng thử lại.",
            timestamp: Date.now(),
          };
          await push(userMessagesRef, errorMessage);
          return;
        }

        const startDateStr = startDate.format("DD/MM/YYYY");
        const endDateStr = endDate.format("DD/MM/YYYY");
        const response = await axios.get(
          `http://localhost:8080/api/thongke/tong-doanh-thu?ngayBatDau=${startDateStr}&ngayKetThuc=${endDateStr}`
        );
        const totalRevenue = response.data || 0;

        const formattedRevenue = new Intl.NumberFormat("vi-VN", {
          style: "currency",
          currency: "VND",
          currencyDisplay: "code",
        }).format(totalRevenue);

        let comparisonMessage = "";
        if (startDateCompare && endDateCompare) {
          const startDateCompareStr = startDateCompare.format("DD/MM/YYYY");
          const endDateCompareStr = endDateCompare.format("DD/MM/YYYY");

          const responseCompare = await axios.get(
            `http://localhost:8080/api/thongke/tong-doanh-thu?ngayBatDau=${startDateCompareStr}&ngayKetThuc=${endDateCompareStr}`
          );
          const totalRevenueCompare = responseCompare.data || 0;

          const formattedRevenueCompare = new Intl.NumberFormat("vi-VN", {
            style: "currency",
            currency: "VND",
            currencyDisplay: "code",
          }).format(totalRevenueCompare);

          if (totalRevenue > totalRevenueCompare) {
            comparisonMessage = `Doanh thu ${formattedRevenue} từ ${startDateStr} đến ${endDateStr} cao hơn doanh thu ${formattedRevenueCompare} từ ${startDateCompareStr} đến ${endDateCompareStr}.`;
          } else if (totalRevenue < totalRevenueCompare) {
            comparisonMessage = `Doanh thu ${formattedRevenue} từ ${startDateStr} đến ${endDateStr} thấp hơn doanh thu ${formattedRevenueCompare} từ ${startDateCompareStr} đến ${endDateCompareStr}.`;
          } else {
            comparisonMessage = `Doanh thu ${formattedRevenue} từ ${startDateStr} đến ${endDateStr} bằng doanh thu ${formattedRevenueCompare} từ ${startDateCompareStr} đến ${endDateCompareStr}.`;
          }
        }

        const botMessage = {
          sender: "bot",
          text: `Doanh thu từ ${startDateStr} đến ${endDateStr}: ${formattedRevenue}. ${comparisonMessage}`,
          timestamp: Date.now(),
        };

        await push(userMessagesRef, botMessage);
        setContext(`${updatedContext}\nBot: ${botMessage.text}`);
      } else {
        try {
          const genAI = new GoogleGenerativeAI({
            apiKey: "AIzaSyBNk4leALxM6dnL0ogzpnCYrr8H6OoUCO8",
          });

          const model = await genAI.getGenerativeModel({
            model: "gemini-1.5-flash",
          });

          // Gửi context với câu hỏi của người dùng đến mô hình
          const result = await model.generateContent(
            `${updatedContext}\nNgười dùng: ${input}\nBot:`
          );

          const botMessage = {
            sender: "bot",
            text: result.response.text(),
            timestamp: Date.now(),
          };

          await push(userMessagesRef, botMessage);
          setContext(`${updatedContext}\nBot: ${result.response.text()}`);
        } catch (error) {
          console.error("Lỗi khi gọi API:", error);
          const errorMessage = {
            sender: "bot",
            text: "Xin lỗi, đã xảy ra lỗi. Vui lòng thử lại.",
            timestamp: Date.now(),
          };
          await push(userMessagesRef, errorMessage);
        }
      }
    } catch (error) {
      console.error("Lỗi ngoài: ", error);
      const errorMessage = {
        sender: "bot",
        text: "Đã có lỗi xảy ra. Vui lòng thử lại sau.",
        timestamp: Date.now(),
      };
      await push(userMessagesRef, errorMessage);
    } finally {
      setLoading(false); // Đảm bảo luôn gọi setLoading(false) khi kết thúc
    }
  };

  return (
    <div style={{ position: "relative", fontFamily: "Arial, sans-serif" }}>
      {/* Biểu tượng chat */}
      <div
        onClick={() => setChatVisible(!chatVisible)}
        style={{
          position: "fixed",
          bottom: "20px",
          right: "20px",
          backgroundColor: "#007BFF",
          borderRadius: "50%",
          width: "60px",
          height: "60px",
          color: "white",
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          fontSize: "30px",
          cursor: "pointer",
          boxShadow: "0px 4px 10px rgba(0, 0, 0, 0.2)",
          transition: "transform 0.2s ease",
        }}
        onMouseEnter={(e) => (e.target.style.transform = "scale(1.1)")}
        onMouseLeave={(e) => (e.target.style.transform = "scale(1)")}
      >
        💬
      </div>

      {/* Chatbox */}
      {chatVisible && (
        <div
          style={{
            position: "fixed",
            bottom: "80px",
            right: "20px",
            width: "350px",
            backgroundColor: "#fff",
            borderRadius: "10px",
            boxShadow: "0px 4px 15px rgba(0, 0, 0, 0.2)",
            padding: "15px",
            zIndex: 9999,
          }}
        >
          <div
            style={{
              display: "flex",
              justifyContent: "space-between",
              alignItems: "center",
            }}
          >
            <h3
              style={{
                margin: 0,
                fontSize: "20px",
                animation: "colorChange 5s infinite",
                backgroundImage:
                  "linear-gradient(to right, #007BFF, #00FF7F, #FFD700, #FF6347, #007BFF)",
                backgroundClip: "text",
                textFillColor: "transparent",
                WebkitBackgroundClip: "text",
                WebkitTextFillColor: "transparent",
              }}
            >
              Travel Go
            </h3>

            <button
              onClick={() => setChatVisible(false)}
              style={{
                backgroundColor: "transparent",
                border: "none",
                fontSize: "18px",
                cursor: "pointer",
                color: "#007BFF",
                fontWeight: "bold",
              }}
            >
              ✖
            </button>
          </div>

          <div
            style={{
              border: "1px solid #ccc",
              borderRadius: "8px",
              padding: "10px",
              height: "250px",
              overflowY: "auto",
              backgroundColor: "#f9f9f9",
              marginTop: "10px",
              scrollBehavior: "smooth",
            }}
          >
            {messages
              .sort((a, b) => a.timestamp - b.timestamp)
              .map((msg, index) => (
                <div
                  key={index}
                  style={{
                    textAlign: msg.sender === "user" ? "right" : "left",
                    margin: "10px 0",
                  }}
                >
                  <span
                    style={{
                      display: "inline-block",
                      padding: "10px 15px",
                      borderRadius: "12px",
                      backgroundColor:
                        msg.sender === "user" ? "#007BFF" : "#e0e0e0",
                      color: msg.sender === "user" ? "white" : "black",
                      maxWidth: "75%",
                      wordWrap: "break-word",
                      boxShadow: "0px 2px 5px rgba(0, 0, 0, 0.1)",
                    }}
                  >
                    {msg.text}
                  </span>
                </div>
              ))}
          </div>

          <div style={{ marginTop: "15px" }}>
            <textarea
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Nhập tin nhắn của bạn..."
              rows="3"
              style={{
                width: "100%",
                padding: "12px",
                borderRadius: "8px",
                border: "1px solid #ccc",
                fontSize: "14px",
                resize: "none",
                boxShadow: "inset 0px 2px 4px rgba(0, 0, 0, 0.1)",
              }}
            />
            <button
              onClick={handleSendMessage}
              style={{
                width: "100%",
                padding: "12px",
                marginTop: "10px",
                background: loading ? "#ccc" : "#007BFF",
                color: "white",
                border: "none",
                borderRadius: "8px",
                cursor: loading ? "not-allowed" : "pointer",
                fontWeight: "bold",
                fontSize: "14px",
                transition: "background-color 0.3s ease",
              }}
              disabled={loading}
              onMouseEnter={(e) => {
                if (!loading) e.target.style.backgroundColor = "#0056b3";
              }}
              onMouseLeave={(e) => {
                if (!loading) e.target.style.backgroundColor = "#007BFF";
              }}
            >
              {loading ? "Đang gửi..." : "Gửi"}
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default Chatbot;
