import React from "react";

export const BaiVietComponent = ({
  title,
  description,
  author,
  date,
  imageUrl,
}) => {
  return (
    <div className="flex justify-between w-[700px]">
      <div className="flex flex-col gap-2 p-1 flex-grow">
        {/* Tiêu đề */}
        <span className="w-[396px] text-left font-bold">{title}</span>

        {/* Mô tả */}
        <span className="w-[396px] text-left">{description}</span>

        {/* Logo và ngày đăng */}
        <div className="w-[396px] h-[48px] flex items-center mt-4">
          <img
            src={imageUrl}
            width={"28px"}
            alt=""
            className="rounded-full object-cover h-[28px]"
          />
          <div className="ml-2 flex items-center">
            <span className="font-semibold">{author}</span>
            <span className="ml-1 text-sm text-gray-600">· {date}</span>
          </div>
        </div>
      </div>

      {/* Hình ảnh + video */}
      <div className="bg-zinc-600 rounded-2xl w-[208px] h-[198.33px] overflow-hidden">
        <img
          src={imageUrl}
          alt=""
          className="w-full h-full object-cover rounded-2xl"
        />
      </div>
    </div>
  );
};

export default BaiVietComponent;
