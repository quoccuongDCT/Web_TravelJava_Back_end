// import React, { useState, useEffect, useRef } from "react";
// import styled from "styled-components";
// import logo from "../assets/Logo.jpg";
// import AvataDown from "../views/client/Header/AvataDown";
// import TourTrongNuoc from "../views/client/Header/TourTrongNuoc";
// import { FaMicrophone, FaMicrophoneSlash } from "react-icons/fa";
// import axios from "axios";
// import { useNavigate, useLocation  } from "react-router-dom";
// import ChiTietHoaDon from "../views/client/ThanhToan/ChiTietHoaDon";
// export default function Navbar() {
//   const [showDomesticTours, setShowDomesticTours] = useState(false);
//   const [showForeignTours, setShowForeignTours] = useState(false);
//   const [searchTerm, setSearchTerm] = useState("");
//   const [filteredTours, setFilteredTours] = useState([]);
//   const [danhMucTour, setDanhMucTour] = useState([]);
//   const [loaitourvatour, setLoaitourvatour] = useState([]);
//   const domesticRef = useRef(null);
//   const foreignRef = useRef(null);
//   const [cartCount, setCartCount] = useState(0); // State riêng để theo dõi số lượng giỏ hàng
//   const [cartDetails, setCartDetails] = useState([]);
//   const refs = useRef([]);
//   const dropdownDomesticRef = useRef(null);
//   const dropdownForeignRef = useRef(null);
//   const [tours, setTours] = useState([]);
//   const [startIndex, setStartIndex] = useState(0); // Vị trí bắt đầu hiển thị
//   const maxVisible = 3; // Số lượng danh mục hiển thị cùng lúc
//   const [userID] = useState(localStorage.getItem("id"));

//   const navigate = useNavigate();
//   const [listening, setListening] = useState(false);

//   const location = useLocation();
//   const [isModalVisible, setIsModalVisible] = useState(false);

//   const paymentId = location.state?.paymentId;
//   const isPaymentSuccess = location.state?.isPaymentSuccess;
//   const paymentSuccess = location.state?.paymentSuccess;

//   useEffect(() => {
//     if (paymentId && isPaymentSuccess) {
//       setIsModalVisible(true);
//     }
//   }, [paymentId, isPaymentSuccess]);
//   const closeModal = () => {
//     localStorage.removeItem('paymentId');
//     localStorage.removeItem('isPaymentSuccess');
//     setIsModalVisible(false);
//   };

//   // Hàm gọi API để lấy danh mục tour
//   useEffect(() => {
//     axios
//       .get("http://localhost:8080/api/danhmuctour")
//       .then((response) => {
//         setDanhMucTour(response.data);
//       })
//       .catch((error) => {});
//   }, []);

//   // Hàm gọi API để lấy danh sách tour theo danh mục
//   const handleCategoryClick = (idDanhMucTour) => {
//     axios
//       .get(`http://localhost:8080/api/tours/byDanhMuc/${idDanhMucTour}`)
//       .then((response) => {
//         // Optionally, handle response data, e.g. store it in state
//         setLoaitourvatour(response.data);
//       })
//       .catch((error) => {});
//   };

//   const handleClickOutside = (event) => {
//     if (
//       (domesticRef.current && domesticRef.current.contains(event.target)) ||
//       (foreignRef.current && foreignRef.current.contains(event.target))
//     ) {
//       return;
//     }
//     if (
//       dropdownDomesticRef.current &&
//       !dropdownDomesticRef.current.contains(event.target) &&
//       dropdownForeignRef.current &&
//       !dropdownForeignRef.current.contains(event.target)
//     ) {
//       setShowDomesticTours(false);
//       setShowForeignTours(false);
//     }
//   };

//   useEffect(() => {
//     document.addEventListener("mousedown", handleClickOutside);
//     return () => document.removeEventListener("mousedown", handleClickOutside);
//   }, []);

//   useEffect(() => {
//     axios
//       .get("http://localhost:8080/api/tours/info")
//       .then((response) => {
//         const mappedData = response.data.map((item) => ({
//           id: item.id,
//           title: item.tenTour,
//           price: `${item.giaNguoiLon.toLocaleString()}`,
//           rating: item.danhGiaKhachSan || 0,
//           url: item.hinhAnh,
//           description: item.soNgay,
//           galleryImgs: [item.hinhAnh],
//           like: false,
//           startDate: new Date(item.ngayBatDau).toLocaleDateString(),
//         }));
//         setTours(mappedData);
//         setFilteredTours(mappedData); // Lưu dữ liệu tour vào state
//       })
//       .catch((error) => console.error("Error fetching tours:", error));
//   }, []);

//   useEffect(() => {
//     if (searchTerm.trim() === "") {
//       setFilteredTours(tours); // Nếu không có từ khóa, hiển thị tất cả các tour
//     } else {
//       const filtered = tours.filter(
//         (tour) =>
//           tour.title.toLowerCase().includes(searchTerm.toLowerCase()) || // Tìm kiếm trong tiêu đề
//           tour.description.toLowerCase().includes(searchTerm.toLowerCase()) // Tìm kiếm trong mô tả
//       );
//       setFilteredTours(filtered); // Cập nhật danh sách tour sau khi lọc
//     }
//   }, [searchTerm, tours]);
//   useEffect(() => {
//     const fetchCartDetails = () => {
//       const idNguoiDung = userID; // Thay bằng id người dùng hiện tại
//       axios
//         .get(
//           `http://localhost:8080/api/chitietgiohang/user?idNguoiDung=${idNguoiDung}`
//         )
//         .then((response) => {
//           setCartDetails(response.data); // Cập nhật giỏ hàng
//           setCartCount(response.data.length); // Cập nhật số lượng giỏ hàng ngay lập tức
//         })
//         .catch((error) => {
//           console.error("Có lỗi khi lấy dữ liệu giỏ hàng:", error);
//         });
//     };

//     fetchCartDetails(); // Gọi hàm fetchCartDetails chỉ một lần khi component được render
//   }, [userID]); // Chỉ chạy lại khi userID thay đổi

//   // const fetchCartDetails = () => {
//   //   const idNguoiDung = userID; // Thay bằng id người dùng hiện tại
//   //   axios
//   //     .get(`http://localhost:8080/api/chitietgiohang/user/${idNguoiDung}`)
//   //     .then((response) => {
//   //       setCartDetails(response.data); // Cập nhật giỏ hàng
//   //       setCartCount(response.data.length); // Cập nhật số lượng giỏ hàng ngay lập tức

//   //     })
//   //     .catch((error) => {
//   //       console.error("Có lỗi khi lấy dữ liệu giỏ hàng:", error);
//   //     });
//   // };
//   // useEffect(() => {
//   //   fetchCartDetails();
//   // }, [cartDetails]);

//   const toggleDomesticTours = () => {
//     setShowDomesticTours(!showDomesticTours);
//     setShowForeignTours(false);
//   };

//   // ==================================================================
//   useEffect(() => {
//     let recognition;
//     if (listening) {
//       // Khởi tạo SpeechRecognition khi bật micro
//       recognition = new (window.SpeechRecognition ||
//         window.webkitSpeechRecognition)();
//       recognition.onstart = () => console.log("Bắt đầu nhận diện giọng nói.");
//       recognition.onresult = (event) => {
//         const transcript = event.results[0][0].transcript;
//         console.log("Kết quả giọng nói:", transcript);
//         setListening(false);
//         navigate("/?search=" + transcript);
//       };
//       recognition.onerror = (event) => {
//         console.error("Lỗi nhận diện giọng nói:", event.error);
//         setListening(false);
//       };
//       recognition.onend = () => {
//         console.log("Kết thúc nhận diện giọng nói.");
//         setListening(false);
//       };
//       recognition.start();
//     }

//     // Dừng nhận diện giọng nói khi tắt micro
//     return () => {
//       if (recognition) {
//         recognition.stop();
//       }
//     };
//   }, [listening, navigate]);

//   const handleNext = () => {
//     if (startIndex + maxVisible < danhMucTour.length) {
//       setStartIndex((prev) => prev + 1);
//     }
//   };

//   const handlePrev = () => {
//     if (startIndex > 0) {
//       setStartIndex((prev) => prev - 1);
//     }
//   };

//   const visibleCategories = danhMucTour.slice(
//     startIndex,
//     startIndex + maxVisible
//   );
//   const handleGioHang = () => {
//     navigate("/gio-hang");
//   };
//   return (
//     <Container>
//       <Nav>
//         <div className="brand">
//           <div className="container">
//             <img src={logo} alt="Logo" className="logo" />
//             <a href="/" className="logo-text">
//               Travel GO
//             </a>
//             <button
//               className="search-voice"
//               onClick={() => setListening((prev) => !prev)}
//             >
//               {listening ? <FaMicrophoneSlash /> : <FaMicrophone />}
//             </button>
//             <input
//               type="text"
//               placeholder="Bạn muốn tìm.. "
//               className="search-bar"
//               value={searchTerm}
//               onChange={(e) => setSearchTerm(e.target.value)}
//             />
//           </div>
//         </div>
//         <div className="menu">
//           {startIndex > 0 && <button onClick={handlePrev}>{"<"}</button>}
//           <ul className="flex items-center justify-center">
//             {visibleCategories.map((danhMuc, index) => (
//               <li
//                 key={danhMuc.id}
//                 ref={(el) => (refs.current[index] = el)}
//                 onClick={() => {
//                   handleCategoryClick(danhMuc.id);
//                   if (danhMuc.id) {
//                     toggleDomesticTours();
//                   }
//                 }}
//               >
//                 <span style={{ fontWeight: "bold" }}>{danhMuc.tenDanhMuc}</span>
//               </li>
//             ))}
//           </ul>
//           {startIndex + maxVisible < danhMucTour.length && (
//             <button onClick={handleNext}>{">"}</button>
//           )}
//           <div
//             className="relative flex items-center justify-center px-4"
//             onClick={handleGioHang}
//             style={{ cursor: "pointer" }}
//           >
//             <div className="relative">
//               <img
//                 src="https://png.pngtree.com/png-clipart/20231017/original/pngtree-black-shopping-cart-png-png-image_13329539.png"
//                 alt="Cart"
//                 className="w-10 h-10 "
//               />
//               <span className="absolute -top-2 -right-2 bg-red-500 text-white text-sm font-bold rounded-full w-6 h-6 flex items-center justify-center">
//                 {cartCount}
//               </span>
//             </div>
//           </div>
//           {paymentId && (
//         <ChiTietHoaDon visible={isModalVisible} onClose={closeModal} />
//         )}

//           <div className="avatadown">
//             <AvataDown />
//           </div>
//         </div>
//       </Nav>
//       {showDomesticTours && (
//         <DropdownMenu ref={dropdownDomesticRef}>
//           <TourTrongNuoc loaitourvatour={loaitourvatour} />
//         </DropdownMenu>
//       )}
//       {searchTerm && (
//         <SearchResults className="!max-h-[250px] overflow-y-auto  ">
//           {filteredTours.length > 0 ? (
//             filteredTours.map((tour) => (
//               <div key={tour.id}>
//                 <a
//                   className="no-underline text-black flex items-center text-[16px]"
//                   href={`/chi-tiet-tour/${tour.id}`}
//                 >
//                   <img src={tour.url} alt={tour.title} />
//                   <span>{tour.title}</span>
//                 </a>
//               </div>
//             ))
//           ) : (
//             <p>No tours found.</p>
//           )}
//         </SearchResults>
//       )}
//     </Container>
//   );
// }

// const Container = styled.div`
//   position: fixed;
//   top: 0;
//   left: 50%;
//   transform: translateX(-50%);
//   width: 97%;
//   z-index: 1000;
//   background-color: white;
//   box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
//   display: flex;
//   justify-content: center;
//   border-bottom-left-radius: 20px;
//   border-bottom-right-radius: 20px;
// `;

// const Nav = styled.nav`
//   display: flex;
//   justify-content: space-between;
//   align-items: center;
//   width: 100%;
//   height: 80px;
//   flex-wrap: nowrap;
//   font-family: Arial, sans-serif;
//   font-size: 16px;

//   .brand {
//     display: flex;
//     align-items: center;
//     gap: 1rem;
//     padding-left: 20px;
//     white-space: nowrap;

//     .container {
//       display: flex;
//       align-items: center;
//       gap: 1rem;
//       white-space: nowrap;
//     }

//     .logo {
//       height: 50px;
//       width: 50px;
//       border-radius: 50%;
//     }

//     .logo-text {
//       font-size: 20px;
//       font-weight: bold;
//       text-decoration: none;
//       color: #0077b6;
//     }

//     .search-voice {
//       background: #f0f0f0;
//       border: none;
//       border-radius: 50%;
//       width: 36px;
//       height: 36px;
//       display: flex;
//       align-items: center;
//       justify-content: center;
//       margin-right: 8px;
//       cursor: pointer;
//       font-size: 18px;
//       color: #333;
//     }

//     .search-bar {
//       padding: 8px;
//       border: 1px solid #ccc;
//       border-radius: 20px;
//       width: 350px;
//       transition: 0.3s ease;
//       margin-left: 10px;
//     }

//     // .search-bar:focus {
//     //   outline: none;
//     //   border-color: #0077b6;
//     //   width: 380px;
//     // }
//   }

//   .menu {
//     display: flex;
//     align-items: center;
//     max-width: 830px;
//     /* margin: 0 auto; */
//     overflow: hidden; /* Ẩn phần thừa */
//   }

//   .menu button {
//     border: none;
//     background-color: transparent;
//     cursor: pointer;
//     font-size: 20px;
//     padding: 5px 10px;
//   }

//   .menu ul {
//     display: flex;
//     list-style-type: none;
//     margin: 0;
//     padding: 0;
//     height: 55px;
//     overflow: hidden; /* Không cho tràn */
//   }

//   .menu li {
//     margin: 0 10px;
//     cursor: pointer;
//   }

//   .menu li span {
//     text-decoration: none;
//     color: #0077b6;
//     font-size: 16px;
//     padding: 0.5rem 1rem;
//   }

//   .menu li span:hover {
//     color: #023e8a;
//     background-color: #b3d4fc;
//     border-radius: 20px;
//   }

//   .flex {
//     display: flex;
//     list-style-type: none;
//     margin: 0;
//     padding: 0;
//     white-space: nowrap;

//     li {
//       a {
//         text-decoration: none;
//         color: #0077b6;
//         font-size: 16px;
//         padding: 0.5rem 1rem;

//         &:hover {
//           color: #023e8a;
//           background-color: #b3d4fc;
//           border-radius: 20px;
//         }
//       }
//       span {
//         text-decoration: none;
//         color: #0077b6;
//         font-size: 16px;
//         padding: 0.5rem 1rem;
//         cursor: pointer; // Thêm để trông giống nút bấm

//         &:hover {
//           color: #023e8a;
//           background-color: #b3d4fc;
//           border-radius: 20px;
//         }
//       }
//     }

//     .avatadown {
//       cursor: pointer;
//       color: #0077b6;
//       font-size: 16px;
//       text-transform: uppercase;
//       white-space: nowrap;
//     }
//   }
// `;

// const DropdownMenu = styled.div`
//   background-color: white;
//   box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
//   border-radius: 15px;
//   width: 100%;
//   padding: 1rem;
//   position: fixed;
//   top: 81px;
//   left: 50%;
//   transform: translateX(-50%);
//   z-index: 500;
// `;

// const SearchResults = styled.div`
//   background-color: white;
//   box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
//   border-radius: 15px;
//   width: 100%;
//   padding: 1rem;
//   position: absolute;
//   top: 81px;
//   left: 50%;
//   transform: translateX(-50%);
//   z-index: 500;

//   div {
//     display: flex;
//     align-items: center;
//     margin-bottom: 10px;

//     img {
//       width: 50px;
//       height: 50px;
//       border-radius: 5px;
//       margin-right: 10px;
//     }

//     h3 {
//       margin: 0;
//     }
//   }
// `;
import React, { useState, useEffect, useRef } from "react";
import styled from "styled-components";
import logo from "../assets/logophong.png";
import AvataDown from "../views/client/Header/AvataDown";
import { FaMicrophone, FaMicrophoneSlash } from "react-icons/fa";
import axios from "axios";
import { useNavigate, useLocation } from "react-router-dom";
import ChiTietHoaDon from "../views/client/ThanhToan/ChiTietHoaDon";
export default function Navbar() {
  const [showDomesticTours, setShowDomesticTours] = useState(false);
  const [showForeignTours, setShowForeignTours] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [filteredTours, setFilteredTours] = useState([]);
  const [danhMucTour, setDanhMucTour] = useState([]);
  const [loaitourvatour, setLoaitourvatour] = useState([]);
  const domesticRef = useRef(null);
  const foreignRef = useRef(null);
  const [cartCount, setCartCount] = useState(0); // State riêng để theo dõi số lượng giỏ hàng
  const [cartDetails, setCartDetails] = useState([]);
  const refs = useRef([]);
  const dropdownDomesticRef = useRef(null);
  const dropdownForeignRef = useRef(null);
  const [tours, setTours] = useState([]);
  const [startIndex, setStartIndex] = useState(0); // Vị trí bắt đầu hiển thị
  const maxVisible = 3; // Số lượng danh mục hiển thị cùng lúc
  const [userID] = useState(localStorage.getItem("id"));

  const navigate = useNavigate();
  const [listening, setListening] = useState(false);
  const location = useLocation();
  const [isModalVisible, setIsModalVisible] = useState(false);

  const paymentId = location.state?.paymentId;
  const isPaymentSuccess = location.state?.isPaymentSuccess;
  const paymentSuccess = location.state?.paymentSuccess;

  useEffect(() => {
    if (paymentId && isPaymentSuccess) {
      setIsModalVisible(true);
    }
  }, [paymentId, isPaymentSuccess]);
  const closeModal = () => {
    localStorage.removeItem("paymentId");
    localStorage.removeItem("isPaymentSuccess");
    setIsModalVisible(false);
  };
  // Hàm gọi API để lấy danh mục tour
  useEffect(() => {
    axios
      .get("http://localhost:8080/api/danhmuctour")
      .then((response) => {
        setDanhMucTour(response.data);
      })
      .catch((error) => {});
  }, []);

  // Hàm gọi API để lấy danh sách tour theo danh mục
  const handleCategoryClick = (idDanhMucTour) => {
    navigate(`/danh-sach-tour?danhMuc=${idDanhMucTour}`);
  };

  const handleClickOutside = (event) => {
    if (
      (domesticRef.current && domesticRef.current.contains(event.target)) ||
      (foreignRef.current && foreignRef.current.contains(event.target))
    ) {
      return;
    }
    if (
      dropdownDomesticRef.current &&
      !dropdownDomesticRef.current.contains(event.target) &&
      dropdownForeignRef.current &&
      !dropdownForeignRef.current.contains(event.target)
    ) {
      setShowDomesticTours(false);
      setShowForeignTours(false);
    }
  };

  useEffect(() => {
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  useEffect(() => {
    axios
      .get("http://localhost:8080/api/tours/info")
      .then((response) => {
        const mappedData = response.data.map((item) => ({
          id: item.id,
          title: item.tenTour,
          price: `${item.giaNguoiLon.toLocaleString()}`,
          rating: item.danhGiaKhachSan || 0,
          url: item.hinhAnh,
          description: item.soNgay,
          galleryImgs: [item.hinhAnh],
          like: false,
          startDate: new Date(item.ngayBatDau).toLocaleDateString(),
        }));
        setTours(mappedData);
        setFilteredTours(mappedData); // Lưu dữ liệu tour vào state
      })
      .catch((error) => console.error("Error fetching tours:", error));
  }, []);

  useEffect(() => {
    if (searchTerm.trim() === "") {
      setFilteredTours(tours); // Nếu không có từ khóa, hiển thị tất cả các tour
    } else {
      const filtered = tours.filter(
        (tour) =>
          tour.title.toLowerCase().includes(searchTerm.toLowerCase()) || // Tìm kiếm trong tiêu đề
          tour.description.toLowerCase().includes(searchTerm.toLowerCase()) // Tìm kiếm trong mô tả
      );
      setFilteredTours(filtered); // Cập nhật danh sách tour sau khi lọc
    }
  }, [searchTerm, tours]);
  useEffect(() => {
    const fetchCartDetails = () => {
      const idNguoiDung = userID; // Thay bằng id người dùng hiện tại
      axios
        .get(
          `http://localhost:8080/api/chitietgiohang/user?idNguoiDung=${idNguoiDung}`
        )
        .then((response) => {
          setCartDetails(response.data); // Cập nhật giỏ hàng
          setCartCount(response.data.length); // Cập nhật số lượng giỏ hàng ngay lập tức
        })
        .catch((error) => {
          console.error("Có lỗi khi lấy dữ liệu giỏ hàng:", error);
        });
    };

    fetchCartDetails(); // Gọi hàm fetchCartDetails chỉ một lần khi component được render
  }, [userID]); // Chỉ chạy lại khi userID thay đổi

  // const fetchCartDetails = () => {
  //   const idNguoiDung = userID; // Thay bằng id người dùng hiện tại
  //   axios
  //     .get(`http://localhost:8080/api/chitietgiohang/user/${idNguoiDung}`)
  //     .then((response) => {
  //       setCartDetails(response.data); // Cập nhật giỏ hàng
  //       setCartCount(response.data.length); // Cập nhật số lượng giỏ hàng ngay lập tức

  //     })
  //     .catch((error) => {
  //       console.error("Có lỗi khi lấy dữ liệu giỏ hàng:", error);
  //     });
  // };
  // useEffect(() => {
  //   fetchCartDetails();
  // }, [cartDetails]);

  const toggleDomesticTours = () => {
    setShowDomesticTours(!showDomesticTours);
    setShowForeignTours(false);
  };

  // ==================================================================
  useEffect(() => {
    let recognition;
    if (listening) {
      // Khởi tạo SpeechRecognition khi bật micro
      recognition = new (window.SpeechRecognition ||
        window.webkitSpeechRecognition)();
      recognition.onstart = () => console.log("Bắt đầu nhận diện giọng nói.");
      recognition.onresult = (event) => {
        const transcript = event.results[0][0].transcript;
        console.log("Kết quả giọng nói:", transcript);
        setListening(false);
        navigate("/?search=" + transcript);
      };
      recognition.onerror = (event) => {
        console.error("Lỗi nhận diện giọng nói:", event.error);
        setListening(false);
      };
      recognition.onend = () => {
        console.log("Kết thúc nhận diện giọng nói.");
        setListening(false);
      };
      recognition.start();
    }

    // Dừng nhận diện giọng nói khi tắt micro
    return () => {
      if (recognition) {
        recognition.stop();
      }
    };
  }, [listening, navigate]);

  const handleNext = () => {
    if (startIndex + maxVisible < danhMucTour.length) {
      setStartIndex((prev) => prev + 1);
    }
  };

  const handlePrev = () => {
    if (startIndex > 0) {
      setStartIndex((prev) => prev - 1);
    }
  };

  const visibleCategories = danhMucTour.slice(
    startIndex,
    startIndex + maxVisible
  );
  const handleGioHang = () => {
    navigate("/gio-hang");
  };
  return (
    <Container>
      <Nav>
        <div className="brand">
          <div className="container">
            {/* <img src={logo} alt="Logo" className="logo" /> */}
            <a href="/" className="logo-text">
              <img
                src={logo}
                alt="Logo"
                className="logo"
                style={{ width: "100px", height: "50px" }}
              />
            </a>
            <button
              className="search-voice"
              onClick={() => setListening((prev) => !prev)}
            >
              {listening ? <FaMicrophoneSlash /> : <FaMicrophone />}
            </button>
            <input
              type="text"
              placeholder="Bạn muốn tìm.. "
              className="search-bar"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
        </div>
        <div className="menu">
          {/* {startIndex > 0 && <button onClick={handlePrev}>{"<"}</button>}
          <ul className="flex items-center justify-center">
            {visibleCategories.map((danhMuc, index) => (
              <li
                key={danhMuc.id}
                ref={(el) => (refs.current[index] = el)}
                onClick={() => {
                  handleCategoryClick(danhMuc.id);
                  if (danhMuc.id) {
                    toggleDomesticTours();
                  }
                }}
              >
                <span style={{ fontWeight: "bold" }}>{danhMuc.tenDanhMuc}</span>
              </li>
            ))}
          </ul>
          {startIndex + maxVisible < danhMucTour.length && (
            <button onClick={handleNext}>{">"}</button>
          )} */}

          {startIndex > 0 && <button onClick={handlePrev}>{"<"}</button>}
          <ul className="flex items-center justify-center">
            {visibleCategories.map((danhMuc, index) => (
              <li
                key={danhMuc.id}
                ref={(el) => (refs.current[index] = el)}
                onClick={() => handleCategoryClick(danhMuc.id)}
              >
                <span style={{ fontWeight: "bold" }}>{danhMuc.tenDanhMuc}</span>
              </li>
            ))}
          </ul>
          {startIndex + maxVisible < danhMucTour.length && (
            <button onClick={handleNext}>{">"}</button>
          )}

          <div
            className="relative flex items-center justify-center px-4"
            onClick={handleGioHang}
            style={{ cursor: "pointer" }}
          >
            <div className="relative">
              <img
                src="https://png.pngtree.com/png-clipart/20231017/original/pngtree-black-shopping-cart-png-png-image_13329539.png"
                alt="Cart"
                className="w-10 h-10 "
              />
              <span className="absolute -top-2 -right-2 bg-red-500 text-white text-sm font-bold rounded-full w-6 h-6 flex items-center justify-center">
                {cartCount}
              </span>
            </div>
          </div>

          <div className="avatadown">
            <AvataDown />
          </div>
        </div>
      </Nav>
      {/* {paymentId && (
        <ChiTietHoaDon visible={isModalVisible} onClose={closeModal} />
      )}
      {/* {showDomesticTours && (
        <DropdownMenu ref={dropdownDomesticRef}>
          <TourTrongNuoc loaitourvatour={loaitourvatour} />
        </DropdownMenu>
      )} */}
      {searchTerm && (
        <SearchResults className="!max-h-[250px] overflow-y-auto  ">
          {filteredTours.length > 0 ? (
            filteredTours.map((tour) => (
              <div key={tour.id}>
                <a
                  className="no-underline text-black flex items-center text-[16px]"
                  href={`/chi-tiet-tour/${tour.id}`}
                >
                  <img src={tour.url} alt={tour.title} />
                  <span>{tour.title}</span>
                </a>
              </div>
            ))
          ) : (
            <p>No tours found.</p>
          )}
        </SearchResults>
      )}
    </Container>
  );
}

const Container = styled.div`
  position: fixed;
  top: 0;
  left: 50%;
  transform: translateX(-50%);
  width: 97%;
  z-index: 1000;
  background-color: white;
  box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
  display: flex;
  justify-content: center;
  border-bottom-left-radius: 20px;
  border-bottom-right-radius: 20px;
`;

const Nav = styled.nav`
  display: flex;
  justify-content: space-between;
  align-items: center;
  width: 100%;
  height: 80px;
  flex-wrap: nowrap;
  font-family: Arial, sans-serif;
  font-size: 16px;

  .brand {
    display: flex;
    align-items: center;
    gap: 1rem;
    padding-left: 20px;
    white-space: nowrap;

    .container {
      display: flex;
      align-items: center;
      gap: 1rem;
      white-space: nowrap;
    }


    .logo-text {
      font-size: 20px;
      font-weight: bold;
      text-decoration: none;
      color: #0077b6;
    }

    .search-voice {
      background: #f0f0f0;
      border: none;
      border-radius: 50%;
      width: 36px;
      height: 36px;
      display: flex;
      align-items: center;
      justify-content: center;
      margin-right: 8px;
      cursor: pointer;
      font-size: 18px;
      color: #333;
    }

    .search-bar {
      padding: 8px;
      border: 1px solid #ccc;
      border-radius: 20px;
      width: 350px;
      transition: 0.3s ease;
      margin-left: 10px;
    }

    // .search-bar:focus {
    //   outline: none;
    //   border-color: #0077b6;
    //   width: 380px;
    // }
  }

  .menu {
    display: flex;
    align-items: center;
    max-width: 830px;
    /* margin: 0 auto; */
    overflow: hidden; /* Ẩn phần thừa */
  }

  .menu button {
    border: none;
    background-color: transparent;
    cursor: pointer;
    font-size: 20px;
    padding: 5px 10px;
  }

  .menu ul {
    display: flex;
    list-style-type: none;
    margin: 0;
    padding: 0;
    height: 55px;
    overflow: hidden; /* Không cho tràn */
  }

  .menu li {
    margin: 0 10px;
    cursor: pointer;
  }

  .menu li span {
    text-decoration: none;
    color: #0077b6;
    font-size: 16px;
    padding: 0.5rem 1rem;
  }

  .menu li span:hover {
    color: #023e8a;
    background-color: #b3d4fc;
    border-radius: 20px;
  }

  .flex {
    display: flex;
    list-style-type: none;
    margin: 0;
    padding: 0;
    white-space: nowrap;

    li {
      a {
        text-decoration: none;
        color: #0077b6;
        font-size: 16px;
        padding: 0.5rem 1rem;

        &:hover {
          color: #023e8a;
          background-color: #b3d4fc;
          border-radius: 20px;
        }
      }
      span {
        text-decoration: none;
        color: #0077b6;
        font-size: 16px;
        padding: 0.5rem 1rem;
        cursor: pointer; // Thêm để trông giống nút bấm

        &:hover {
          color: #023e8a;
          background-color: #b3d4fc;
          border-radius: 20px;
        }
      }
    }

    .avatadown {
      cursor: pointer;
      color: #0077b6;
      font-size: 16px;
      text-transform: uppercase;
      white-space: nowrap;
    }
  }
`;

const DropdownMenu = styled.div`
  background-color: white;
  box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
  border-radius: 15px;
  width: 100%;
  padding: 1rem;
  position: fixed;
  top: 81px;
  left: 50%;
  transform: translateX(-50%);
  z-index: 500;
`;

const SearchResults = styled.div`
  background-color: white;
  box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
  border-radius: 15px;
  width: 100%;
  padding: 1rem;
  position: absolute;
  top: 81px;
  left: 50%;
  transform: translateX(-50%);
  z-index: 500;

  div {
    display: flex;
    align-items: center;
    margin-bottom: 10px;

    img {
      width: 50px;
      height: 50px;
      border-radius: 5px;
      margin-right: 10px;
    }

    h3 {
      margin: 0;
    }
  }
`;
