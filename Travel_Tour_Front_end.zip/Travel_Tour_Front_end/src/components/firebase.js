import { initializeApp, getApps } from "firebase/app";
import { getDatabase } from "firebase/database";

// Cấu hình Firebase
const firebaseConfig = {
  apiKey: "AIzaSyAtXg4mkxx1gic_VlvyxWcEloGZ6VFyymg",
  authDomain: "travel-e7f79.firebaseapp.com",
  projectId: "travel-e7f79",
  storageBucket: "travel-e7f79.appspot.com",
  messagingSenderId: "52519186637",
  appId: "1:52519186637:web:d0bb8aa8a499a7179b3984",
  measurementId: "G-HLNSGQZCPH",
  databaseURL: "https://travel-e7f79-default-rtdb.firebaseio.com/", // Cập nhật URL cơ sở dữ liệu
};
// Kiểm tra nếu Firebase chưa được khởi tạo
const app = !getApps().length ? initializeApp(firebaseConfig) : getApps()[0];

// Khởi tạo Realtime Database
const database = getDatabase(app);

export { database };
